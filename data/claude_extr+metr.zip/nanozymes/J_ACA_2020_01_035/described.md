#### Analytica Chimica Acta 1105 (2020) 162e168

Contents lists available at ScienceDirect

# Analytica Chimica Acta

journal homepage: www.elsevier.com/locate/aca

# Colorimetric acid phosphatase sensor based on MoO3 nanozyme

Zhen Lin a, b, c, d, 1 , Xiaomin Zhang a, b, 1 , Shijun Liu a, b , Linlin Zheng a, b , Yemei Bu a, b , Haohua Deng a, c , Ruiting Chen a, c , Huaping Peng a, c , Xinhua Lin a, b, d, **, Wei Chen a, c, *

a Department of Pharmaceutical Analysis, Faculty of Pharmacy, Fujian Medical University, Fuzhou, 350122, China

b Nano Medical Technology Research Institute, Fujian Medical University, Fuzhou, 350122, China

c Fujian Key Laboratory of Drug Target Discovery and Structural and Functional Research, Fujian Medical University, Fuzhou, 350122, China

d Higher Educational Key Laboratory for Nano Biomedical Technology of Fujian Province, Fujian Medical University, Fuzhou, 350122, China

### highlights graphical abstract

- Colorimetric sensor for acid phosphatase detection.
- Oxidase-mimicking activity of molybdenum oxide nanoparticles.
- Acid phosphatase catalyzes the hydrolysis of the ascorbic acid 2 phosphate.
- Ascorbic acid inhibits the catalytic activity of molybdenum oxide nanoparticles.

### article info

Article history: Received 26 October 2019 Received in revised form 7 January 2020 Accepted 16 January 2020 Available online 18 January 2020

Keywords: MoO3 nanoparticles Oxidase mimic Colorimetric assay Acid phosphatase

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a chemical process involving molybdenum oxide nanoparticles (MoO3 NPs) and their interaction with various chemical species. The process can be described as follows:

1. Starting from the left, there are representations of CH3COOH (acetic acid) and H2O (water) molecules.

2. These molecules interact with MoOx NPs (molybdenum oxide nanoparticles), which are shown as small blue squares.

3. The MoOx NPs then interact with or transform into larger MoO3 NPs, represented by a circular structure with a yellow core surrounded by smaller particles.

4. The MoO3 NPs interact with O2 (oxygen) molecules, leading to the formation of 1O2 (singlet oxygen).

5. The singlet oxygen then interacts with ABTS (2,2'-azino-bis(3-ethylbenzothiazoline-6-sulfonic acid)), represented by the abbreviation "ABTS".

6. This interaction leads to the formation of ABTS•+ (the oxidized radical cation form of ABTS).

7. The ABTS•+ can then be reduced back to ABTS, as indicated by the "Reducing ABTS•+" label.

8. There is also a pathway labeled "Reacting with ROS" (Reactive Oxygen Species) that connects the MoO3 NPs directly to the ABTS•+ formation step.

9. On the far right of the image, there are two chemical structures:
   a. The structure of ascorbic acid (AA), with the SMILES notation: O=C1O[C@H]([C@H](CO)O)C(O)=C1O
   b. A representation of a protein structure labeled "AAP ACP", likely referring to an ascorbic acid peroxidase (AAP) and possibly an acyl carrier protein (ACP).

10. The ascorbic acid structure is connected to the ABTS/ABTS•+ cycle, suggesting it may play a role in the reduction of ABTS•+ back to ABTS.

This schematic appears to be illustrating a process where MoO3 nanoparticles are used to generate reactive oxygen species, which then interact with ABTS in a cyclic process. The ascorbic acid and protein structures on the right suggest potential applications or interactions in biological systems.</DESCRIPTION_FROM_IMAGE>

## abstract

Nanozymes, or nanomaterials that mimic the behaviors of enzymes, are highly promising materials for biomedical applications because of their excellent chemical stability under harsh conditions, simple preparation method and lower costs compared with natural enzymes. We herein report the intrinsic oxidase-mimicking activity of molybdenum oxide nanoparticles (MoO3 NPs). MoO3 NPs catalyzed the oxidation of colorless 2,20 -azino-bis(3-ethylbenzothiazoline-6-sulfonic acid) (ABTS) to green product. The catalytic mechanism of the oxidase-mimicking activity of the MoO3 NPs was investigated in detail using electron spin resonance and a radical inhibition method. The oxidation of ABTS stems from 1 O2 generated from the interaction between MoO3 NPs and dissolved oxygen in the solution. Acid phosphatase (ACP) catalyzes the hydrolysis of the ascorbic acid 2-phosphate (AAP) substrate to produce ascorbic acid (AA). AA was found to fade the coloration process of the MoO3 NP-mediated ABTS oxidation. By combining the oxidase-mimicking property of the MoO3 NPs and the ACP-catalyzed hydrolysis of AAP, a novel and simple colorimetric method for detecting ACP was established. The linear range for ACP determination is 0.09e7.3 U/L with a detection limit of 0.011 U/L. This new colorimetric method was successfully applied to the detection of ACP in diluted human serum samples and screening of ACP inhibitors. The present study proposes MoO3 NPs as a new oxidase mimic for establishing various biosensing method.

© 2020 Elsevier B.V. All rights reserved.

* Corresponding author. Department of Pharmaceutical Analysis, Faculty of Pharmacy, Fujian Medical University, Fuzhou, 350122, China.

#### ** Corresponding author. Department of Pharmaceutical Analysis, Faculty of Pharmacy, Fujian Medical University, Fuzhou, 350122, China.

- E-mail addresses: xhl1963@sina.com (X. Lin), chenandhu@163.com (W. Chen).
#### 1. Introduction

Nanozymes, emerging as nanomaterial-based artificial enzymes [1e5] have been a hot research topic due to their advantageous properties such as their low cost, good chemical stability in harsh

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image appears to be the cover or title page of a scientific journal called "Analytica Chimica Acta". The background of the image features a stylized representation of scientific or analytical concepts, with faint outlines of what seem to be chemical structures, formulas, or diagrams. However, these background elements are not clear enough to interpret specific chemical structures or convert to SMILES format.

The main focus is on the journal title "Analytica Chimica Acta" presented in large, bold white text. This title suggests that the journal deals with analytical chemistry topics.

While this image does convey information about the journal's identity, it does not contain specific scientific data, graphs, or chemical structures that require detailed interpretation in the context of applied chemistry. Therefore, this image could be classified as an ABSTRACT_IMAGE in the context of conveying specific scientific information.</DESCRIPTION_FROM_IMAGE>

conditions and easy preparation compared with natural enzymes. Since the first report on the intrinsic peroxidase-like activity of ferromagnetic nanoparticles (NPs) in 2007 [6], the exploration of novel nanozymes with excellent catalytic performance has attracted much attention [5]. Many kinds of enzyme-mimicking nanomaterials have recently emerged, including metal and multimetallic nanomaterials [7e9], metal oxide-based nanomaterials [10e12], chalcogenides [13], carbon-based nanomaterials [3,14], and metal-organic framework (MOF)-based nanomaterials [15]. Among the reported enzyme mimics, oxidase mimics are attractive for the design of simple and stable sensors since they do not require unstable H2O2 as a co-substrate. To date, nanomaterials such as cerium oxide nanoparticles [16], platinum nanoparticles [17], carbon dots [18], and MnO2 nanosheets [10] have been found to possess remarkable oxidase-mimicking properties. Compared with traditional nanomaterial, nanomaterials with 3D architectures, such as 3D halos assembled from Fe3O4/Au NPs [19] and Cu(OH)2 supercages [20] exhibited enhanced catalytic property (see Table 1).

Molybdenum oxide is a functional transition metal oxide with multiphase structures including molybdenum trioxide (MoO3) [21], molybdenum dioxide (MoO2) [22], and oxygen-deficient molybdenum oxide (MoO3-x) [23]. MoO3 has excellent properties for use in catalysis and antimicrobial and bactericidal applications [24e27]. However, there have been few reports on the enzymemimicking property of MoO3. In 2014, Tremel and co-workers reported the sulfite oxidase mimicking of molybdenum trioxide nanoparticles (MoO3 NPs), which could convert sulfite to sulfate under physiological conditions. In this work, we find that MoO3 NPs exhibit an excellent oxidase-mimicking activity and can catalyze the oxidation of colorless 2,2ʹ-azino-bis(3-ethylbenzothiazoline-6 sulfonic acid) (ABTS) to produce a green product.

Acid phosphatase (ACP), an enzyme that is widely distributed in many animal and plant species, catalyzes the hydrolysis of orthophosphate monoesters and transphosphorylation reactions [28]. The concentration of ACP reflected the pathophysiological processes of some common diseases, including malignant tumor bone metastasis, prostate cancer, acute and chronic myelogenous leukemia [29e33]. Therefore, it is of great significance to develop sensitive and specific ACP activity detection methods. An impressive number of ACP detection methods has been reported, such as electrochemical [34], fluorescent [35e37], and colorimetric [38] sensors. Since the colorimetric detection of ACP has the advantages of low cost, convenience, and simple instrument requirements, it is regarded as more desirable compared with other methods. To date, only a few colorimetric detection methods for ACP have been reported. p-Nitrophenylphosphate [39], a common substrate for ACP colorimetric detection, can change to p-nitrophenol (PNP) under ACP catalysis. However, PNP exhibits strong ultravioletevisible absorption under basic conditions, whereas the optimum pH for ACP activity is acidic. Therefore, it is still important to develop colorimetric methods for ACP detection in acidic conditions. Herein, we found that ascorbic acid (AA), the product of the ACP-AA 2-phosphate (AAP) system, interferes with the oxidation of ABTS and inhibits the oxidase-mimicking property of MoO3 NPs, based on which a colorimetric ACP detection method has been established (Scheme 1). It is noted that the MoO3 NP-mediated ABTS chromogenic reaction proceeds in an acidic medium, which allows for ACP to exert its highest activity.

#### 2. Experiment

#### 2.1. Chemicals and materials

Molybdenum and acetic acid were purchased from Sinopharm Chemical Reagent (Shanghai, China). Sodium acetate, hydrogen peroxide, 2,20 -azino-bis(3-ethylbenzothiazoline-6-sulfonic acid) (ABTS), 3,30 ,5,50 -tetramethylbenzidine (TMB), 3,30 -diaminobenzidine (DAB), o-phenylenediamine (OPD), pyrogallol, AAP, AA, isopropanol, butanol, glucose, lactose, creatine, and sodium fluoride were obtained from Aladdin Reagent (Shanghai, China). Acid phosphatase (ACP), catalase, superoxide dismutase (SOD), acetyl choline, proteinase K, urease, and horseradish peroxide (HRP) were purchased from Sigma-Aldrich (Shanghai, China). All reagents were analytical grade and used without pretreatment. The blood sample was obtained from Beijing Solarbio science and technology Co., Ltd. All solutions were prepared in distilled water purified by a Milli-Q water purification system (Millipore Corp., Bedford, MA).

#### 2.2. Apparatus and measurements

High-resolution transmission electron microscopy (HRTEM) images were measured on a TecnaiG2 F30 HRTEM (Netherlands, FEI). X-ray photoelectron spectroscopy (XPS) was performed with an ESCALAB 250XI electron spectrometer (Thermo). X-ray diffraction (XRD) spectroscopy was performed on an X'Pert PRO X-ray powder diffractometer (Netherlands, PANalytical). Zeta potentials were measured on a Zetasizer Nano ZS. Infrared (IR) spectra were recorded with an iS50 Fourier transform (FT)-IR spectrophotometer (Thermo). A UV-2600 ultravioletevisible (UVevis) spectrophotometer (Shimadzu) was used to collect UVevis absorption spectra.

#### 2.3. Synthesis of MoO3 NPs

Aqueous dispersions of MoO3 NPs were prepared through the controlled catalytic oxidative dissolution of micrometer-sized molybdenum powders [40]. First, 10 mL of H2O was added to 1.0 g of molybdenum and stirred well at room temperature. Subsequently, 10 mL of H2O2 (30%, v/v) and 2 mL of acetic acid (99.5%, v/v) were injected gently into the molybdenum solution, and the solution was

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a chemical process involving molybdenum oxide nanoparticles (MoO3 NPs) and their interaction with various molecules and reactive species. The process can be described as follows:

1. On the left side, there's a representation of CH3COOH (acetic acid) and H2O (water) interacting with MoO3 NPs. This suggests a synthesis or preparation step for the nanoparticles.

2. The MoO3 NPs are depicted as a circular structure with a yellow center, surrounded by smaller particles, likely representing the nanoparticle's surface structure.

3. To the right of the MoO3 NPs, there's an interaction with O2 (molecular oxygen), leading to the formation of 1O2 (singlet oxygen), a reactive oxygen species (ROS).

4. The singlet oxygen then interacts with ABTS (2,2'-azino-bis(3-ethylbenzothiazoline-6-sulfonic acid)), represented by its chemical structure. SMILES for ABTS: C1=CC2=C(C=C1S(=O)(=O)[O-])SC(=N2)C3=NC4=C(S3)C=C(C=C4)S(=O)(=O)[O-]

5. The interaction between singlet oxygen and ABTS leads to the formation of ABTS•+ (oxidized ABTS radical cation).

6. On the right side of the image, there's a representation of a protein structure labeled as "AAP ACP", likely referring to an ascorbate peroxidase enzyme.

7. The ABTS•+ is shown to interact with a molecule labeled as "AA", which is likely ascorbic acid. SMILES for ascorbic acid: O=C1O[C@H]([C@H](CO)O)C(O)=C1O

8. The interaction between ABTS•+ and AA leads back to the reduced form of ABTS, completing a cycle.

9. There's also a note "Reacting with ROS" connecting the ABTS/AA interaction to the singlet oxygen formation, suggesting a broader context of reactive oxygen species interactions.

This schematic appears to illustrate a process where MoO3 nanoparticles are used to generate reactive oxygen species, which then participate in a series of redox reactions involving ABTS and ascorbic acid, possibly in the context of studying antioxidant activity or oxidative stress mechanisms.</DESCRIPTION_FROM_IMAGE>

Scheme 1. Principle of ACP determination based on the oxidase-mimicking property of MoO3 NPs.

stirred until the color changed from black to yellow at 0 C. The reaction mixture was stirred continuously overnight at 37 C. The obtained MoO3 NP solution was finally filtered through a 0.22 mm microporous membrane, dialyzed against purified water for 72 h and stored at 4 C away from light.

#### 2.4. Oxidase-like activity of MoO3 NPs

In this study, ABTS was chosen as a colorimetric substrate. ABTS (100 mL, 30 mM) and 100 mL of MoO3 NPs were added to 1.80 mL of acetate buffer (0.20 M with a pH value of 5.0). The solution was incubated at 37 C for 10 min. The absorbance at 420 nm (A420) of the mixture was measured by the UVevis spectrophotometer.

#### 2.5. Detection of ACP

First, 50 mL of different concentrations of ACP, 50 mL of 8 mM AAP, and 400 mL of acetate buffer (0.2 M, pH 6.0) were added to tube 1. Tube 1 was incubated at 37 C for 30 min. Acetate buffer with a volume of 350 mL (0.20 M, pH 5.0), 100 mL of MoO3 NPs and 50 mL of 30 mM ABTS were added to tube 2, and the mixture was heated at 37 C for 30 min. Fifty microliters of the solution from tube 1 was then added to tube 2 and well-mixed. Finally, the absorbance at 420 nm (A420) of the mixture was measured by the UVevis spectrophotometer.

#### 2.6. Analysis of ACP activity in human serum sample

Human serum samples were firstly centrifuged for 20 min at 10000 rpm and then passed through filter membrane (0.22 mm). 50 mL of 8 mM AAP, 350 mL of acetate buffer (0.2 M, pH 6.0) and double diluted serum samples were added to tube 1. Tube 1 was incubated at 37 C for 30 min. Acetate buffer with a volume of 350 mL (0.20 M, pH 5.0), 100 mL of MoO3 NPs and 50 mL of 30 mM ABTS were added to tube 2 and heated at 37 C for 30 min. Fifty microliters of the solution from tube 1 was then added to tube 2 and well-mixed. Finally, the absorbance at 420 nm (A420) of the mixture was measured by the UVevis spectrophotometer. Spiked recoveries experiments were carried out after the same procedures except that 50 mL of 1 U/mL or 2 U/mL ACP was added to the solution in the tube 1.

#### 3. Results and discussion

#### 3.1. Characterization of MoO3 NPs

MoO3 NPs were synthesized by the oxidization of molybdenum powder with H2O2 in the presence of acetic acid [40]. The TEM image in Fig. 1A shows that the MoO3 NPs are well dispersed with an average diameter of 2.0e4.0 nm. The lattice spacing of 0.21 nm in the HRTEM image (Fig. 1A inset) corresponds to the (410) plane of MoO3 [41]. The XRD spectrum of the MoO3 NPs is shown in Fig. 1B. The peaks at 12.82, 25.75, and 39.06 were assigned to the (020), (040), and (060) planes, respectively. The intensities of the main diffraction lines of the MoO3 NPs closely resembled the JCPDS data (JCPDS no.26e1449) (a0 ¼ 3.962 Å, b0 ¼ 13.858 Å, c0 ¼ 3.697 Å), and the prepared MoO3 NPs belong to the orthogonal crystal system [42]. The UVevis absorption spectrum of the MoO3 NPs exhibits a narrow absorption band between 200 and 300 nm (Fig. S1), and the solution is pale yellow (Fig. S1 inset). The MoO3 NPs were characterized by FT-IR spectroscopy to obtain their chemical and surface properties (Fig. 1C). The FT-IR spectrum showed three main peaks at 560, 875, and 984 cm1 . The peak at 560 cm1 can be assigned to the bending mode of the MoeOeMo entity, where the

<DESCRIPTION_FROM_IMAGE>This image contains four separate panels labeled A, B, C, and D, each presenting different analytical data related to molybdenum oxide (MoO3) nanoparticles.

Panel A: Transmission Electron Microscopy (TEM) image
This panel shows a TEM image of MoO3 nanoparticles. The particles appear as dark spots scattered across a lighter background. The scale bar indicates 5 nm. An inset in the upper right corner shows a higher magnification image of a single nanoparticle with visible lattice fringes, and a scale bar of 2 nm.

Panel B: X-ray Diffraction (XRD) pattern
This panel presents an XRD pattern of MoO3. The x-axis shows 2-Theta values ranging from 10 to 60 degrees. The y-axis represents intensity in arbitrary units (a.u.). The red line shows the experimental data for MoO3, while the black lines at the bottom represent the reference pattern for MoO3·H2O (JCPDS no.26-1449). Notable peaks are labeled with their corresponding Miller indices: (020), (110), (040), (021), and (060).

Panel C: Fourier-Transform Infrared (FTIR) spectroscopy
This panel displays an FTIR spectrum. The x-axis shows wavenumbers ranging from 500 to 4000 cm^-1, while the y-axis represents transmittance in percentage. Several characteristic peaks are labeled:
- 3435 cm^-1
- 1624 cm^-1
- 984 cm^-1
- 875 cm^-1
- 560 cm^-1

Panel D: X-ray Photoelectron Spectroscopy (XPS)
This panel shows an XPS spectrum focusing on the Mo 3d region. The x-axis represents binding energy from 228 to 240 eV, while the y-axis shows intensity in arbitrary units (a.u.). The spectrum is deconvoluted into several components:
- Raw data (red line)
- Fitted curve (gray line)
- Background (black line)
- Mo^6+ 3d5/2 peak at 233.49 eV (green line)
- Mo^6+ 3d3/2 peak at 236.64 eV (blue line)

This comprehensive set of analytical data provides information about the structure, composition, and chemical state of MoO3 nanoparticles.</DESCRIPTION_FROM_IMAGE>

Fig. 1. (A) HRTEM image, (B) X-ray diffraction pattern, (C) FT-IR spectrum, and (D) XPS Mo3d region of MoO3 NPs.

oxygen element is shared by three molybdenum elements [41]. The 875 cm1 peak is attributed to the MoeOeMo stretching vibration of Mo6þ, and the peak at 984 cm1 can be assigned to the terminal Mo]O bond, which indicates the formation of a layered orthorhombic MoO3 phase. The peak around 1627 cm1 is ascribed to the C]O group stretching vibration. The broad band at 3435 cm1 originates from the OeH groups, and these results indicate the existence of adsorbed acetic acid on the MoO3 surface. The average surface zeta potential of the MoO3 NPs was approximately 2 mV, which further proved the adsorption of acetic acid on the surface.

XPS analysis was also conducted to identify the elements contained in the MoO3 NPs. The XPS results show the existence of molybdenum (Mo) and oxygen (O) elements in the MoO3 NPs (Fig. S2 and S3). The high-resolution narrow-scan XPS of Mo3d (Fig. 2D) shows two well-resolved spectral lines due to the spinorbit of the Mo3d levels. The binding energy peaks at 233.69 and 236.64 eV can be assigned to Mo3d5/2 and Mo3d3/2, respectively. The energy separation between Mo3d5/2 and Mo3d3/2 peaks is 2.95 eV, which indicates the existence of Mo6þ in the as-prepared MoO3 NPs.

### 3.2. MoO3 NPs oxidase-mimicking activity

ABTS, a common colorimetric substrate, was chosen to assess the oxidase-mimicking activity of the MoO3 NPs. As shown in Fig. 2A, the MoO3 NPs could directly catalyze the oxidation of ABTS in the absence of HRP or H2O2, which is accompanied by a color change from colorless to green with a maximum absorbance at 420 nm. In contrast, the color of the ABTS solution showed little change in the absence of MoO3 NPs. In order to further demonstrate the general applicability of the MoO3 NPs as an oxidase mimic, other substrates including TMB, pyrogallol, DAB, and OPD were also examined, and similar catalytic behaviors were observed (Fig. S4). The catalytic property of the MoO3 NPs is also affected by pH, temperature, reaction time, and substrate concentration. Fig. S5 showed that the optimal pH, reaction time, and temperature for the catalytic reaction are 2.5, 30 min, and 70 C, respectively. ABTS at 1 mmol/L and MoO3 NPs 0.05 g/L are the optimum concentrations for the MoO3 NP-mediated ABTS chromogenic reaction. Furthermore, 1 mmol/L Mg2þ, Naþ, Kþ, Ca2þ, Zn2þ, CO3 2, H2PO4 , NO3 , Cl, SO4 2, sucrose, glucose, starch, fructose and 0.1 mmol/L creatinine and creatine had no influence on the MoO3 NP-mediated ABTS chromogenic reaction (Fig. S5F).

ESR, the most powerful and direct analytical method for reactive oxygen species, was used to confirm the radical species generated in the MoO3 NPs-mediated reaction [43,44]. 2,2,6,6- Tetramethylpiperidine (TEMP) is a specific target molecule of 1 O2. As depicted in Fig. 2B, clear TEMPO signals were observed in the MoO3 NP solution, indicating the existence of 1 O2. 5,5-Dimethyl-1 pyrroline-N-oxide (DMPO) was used as the spin trap for ▪O2 and ▪OH. The DMPO-OH and DMPO-OOH signals were absent in the MoO3 NP solution under hypoxia and air exposure conditions (Fig. S6). Radical inhibition experiments were further carried out to investigate the radicals involved in the MoO3 NP-mediated ABTS chromogenic reaction, and the results are illustrated in Fig. 2C. It was found that catalase as a H2O2 scavenger, SOD as a ▪O2 scavenger, t-butanol as a OH scavenger, have negligible influences on the ABTS oxidation. However, the catalytic property of the MoO3 NPs was greatly influenced by NaN3, a well-known and efficient 1 O2 scavenger. This result indicated that the 1 O2 radical plays an important role in the MoO3 NP-catalyzed ABTS oxidation reaction. Based on the above study, the catalytic mechanism of the MoO3 NPs

<DESCRIPTION_FROM_IMAGE>This image contains four separate graphs labeled A, B, C, and D, each presenting different scientific data. I'll describe each in detail:

A. UV-Visible Absorption Spectrum:
This graph shows the absorbance (y-axis) versus wavelength (x-axis) from 400 to 800 nm. There are two curves:
- Curve 'a' (black): Shows low absorbance across the spectrum.
- Curve 'b' (red): Shows higher absorbance with peaks around 400 nm and 750 nm.
The inset image shows two vials, likely corresponding to the samples measured.

B. Electron Spin Resonance (ESR) Spectrum:
This graph displays ESR signal intensity (y-axis) versus magnetic field strength (x-axis) from 318.3 to 319.0 mT. Three curves are shown for different atmospheres:
- N2 (black): Shows minimal signal.
- O2 (red): Shows strong, symmetric peaks at regular intervals.
- Air (blue): Shows intermediate intensity peaks at the same positions as O2.

C. Bar Graph of A420 Values:
This graph presents A420 values (y-axis) for different conditions (x-axis). The bars represent:
- Control: Highest A420 (~0.82)
- Catalase: Slightly lower than control (~0.78)
- NaN3: Very low A420 (~0.05)
- t-butanol: Moderate A420 (~0.72)
- SOD: Similar to catalase (~0.79)
Error bars are included for each measurement.

D. Enzyme Kinetics Plot:
The main graph shows initial velocity V (μM·s^-1) versus ABTS concentration (mM) from 0 to 5 mM. The curve appears to follow Michaelis-Menten kinetics, with velocity increasing rapidly at low concentrations and approaching a plateau at higher concentrations.

The inset graph is a Lineweaver-Burk plot (1/V vs 1/[ABTS]), showing a linear relationship, which is typical for enzyme kinetics analysis.

This set of graphs provides comprehensive information about spectroscopic properties, radical formation, enzyme inhibition studies, and enzyme kinetics of a particular system, likely involving a metalloenzyme or similar catalytic species.</DESCRIPTION_FROM_IMAGE>

Fig. 2. (A) UVeVis absorptions of solutions of (a) ABTS and (b) ABTS þ MoO3 NPs. Inset: photographs of each solution. (B) ESR spectra of TEMPO in MoO3 NPs solution in hypoxia environment (black), air environment (blue), and enriched oxygen environment (red). (C) Radical inhibition experiments in MoO3 NPs-ABTS system. (D) Steady-state kinetic assays of MoO3 NPs. The inset is the corresponding double reciprocal plot.

was illustrated as shown in Scheme 1. The dissolved O2 adsorbs onto the surface of the MoO3 NPs and subsequently forms 1 O2. The strongly oxidizing 1 O2 radical then reacts with ABTS to form a green product.

In order to obtain further insights into the oxidase-mimicking activity of the MoO3 NPs, the apparent steady-state kinetic parameters for the reaction were determined. In a certain range of ABTS concentration, a typical MichaeliseMenten constant and maximum initial velocity were obtained using a LineweavereBurk plot, and the results are shown in Fig. 2D. The Michaelis constant (Km) was 1.6769 mM, which demonstrates the affinity of the MoO3 NPs toward ABTS.

#### 3.3. ACP detection using MoO3 NPs as oxidase mimics

AA, a hydrolysate of AAP under ACP catalysis, was used for the ACP activity assay. AA resulted in fading of the color of the MoO3 NP-mediated ABTS reaction solution, and the absorption of ABTS\$þ decreased markedly with AA concentration ranging from 0 to 0.05 mM. At 0.05 mM AA, the catalytic oxidation of ABTS by MoO3 NPs was almost completely suppressed (Fig. 3A). The quenching kinetics of AA against the oxidase-mimic property of the MoO3 NPs has been investigated. Fig. S7 and Fig. 3B show AA rapidly decreased the absorption of ABTS\$þ. This is because AA is a wellknown antioxidant that can efficiently reduce ABTS\$þ.

ACP catalyzes the hydrolysis of orthophosphate monoesters and transphosphorylation reactions. In the present study, ACP was used to catalyze the enzymatic hydrolysis of AAP to produce AA, which inhibited the coloration process of the MoO3 NP-catalyzed ABTS oxidation. When AAP or ACP alone was mixed with MoO3 NP-ABTS, the absorption at 420 nm attributed to ABTS\$þ did not decrease (Fig. 4A). Scheme 1 illustrated the principle of the proposed method. The optimum conditions for the ACP-catalyzed hydrolysis of AAP to produce AA were investigated, and the optimal reaction pH, temperature, and time were 6.0, 37 C, and 30 min, respectively (Fig. S8).

Fig. 4B shows that for ACP in the concentration range from 0.09 to 7.3 U/L, the UVevis absorption of the solution was linear at 420 nm, which was denoted as DA420 (DA420 ¼ A0 At, where A0 and At are the absorption of the reaction solution at 420 nm with and without ACP, respectively). The corresponding linear equation was DA420 ¼ 0.242 [ACP] þ0.020 with a correlation coefficient (R2 ) of 0.9984. The detection limit for ACP was 0.011 U/L (S/N ¼ 3). In comparison with previously reported methods for ACP activity determination (Table S1), the analytical performance of the proposed method is comparable or better.

The proposed colorimetric method was also used to detect ACP activity in real human serum to evaluate the practical feasibility of the method. The recovery test results showed that the recoveries for 3 spiked human serum samples are in the range from 92.00% to 107.60% with RSD values of 0.78e4.99%, indicating that the proposed method is suitable for ACP detection in real human serum (see Table 1).

To study the specificity of this detection method for ACP, the effects of some common substances coexisting in human serum including HRP, protease K, acetylase, cholinesterase, pyrophosphate hydrolase, and lysozyme on the method were investigated. Fig. 4C shows that these proteins at a concentration 10 times higher than that of ACP had no obvious influence on the proposed sensing system, which indicated the high selectivity of this proposed method for ACP.

The screening of enzyme inhibitors is essential in drug discovery. Herein, NaF was used as a model inhibitor to investigate the possibility of utilizing the MoO3 NPs-mediated ABTS oxidation process for screening potential ACP inhibitors. Fig. 4E shows that A420 increased with NaF concentration. This is because the increased amount of NaF inhibited the ACP activity, which resulted in a decrease in AA production. The plot of inhibition efficiency versus NaF concentration yielded an IC50 of 3.1 mM. Fig. 4F also showed the inhibited effect of sodium pyrophosphate on the ACP activity. The results indicate the potential of the proposed method for ACP inhibitor screening.

#### 4. Conclusions

In summary, we demonstrated that MoO3 NPs have oxidasemimicking properties as they can facilitate the fast oxidation of ABTS, TMB, and OPD without hydrogen peroxide. The mechanistic study showed that the MoO3 NPs catalyze dissolved O2 to form 1 O2 radicals, which react with the substrate. Furthermore, AA was found to cause fading of the color change that occurs from the MoO3 NP-mediated ABTS oxidation. By combining the oxidasemimicking property of the MoO3 NPs and the ACP-catalyzed hydrolysis of AAP, a novel and simple colorimetric method for detecting ACP has been established and successfully applied to real samples. The present study not only expands the potential of oxidase mimics but also paves the way for the advancement of MoO3 NPs toward applications in biosensing and clinical diagnostics.

#### Declaration of competing interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

#### CRediT authorship contribution statement

Zhen Lin: Conceptualization, Methodology, Writing - original

<DESCRIPTION_FROM_IMAGE>The image contains two graphs side by side, both related to the effect of different concentrations of AA (likely ascorbic acid) on a chemical system.

Left Graph:
This graph shows UV-Vis absorption spectra. The x-axis represents wavelength in nanometers (nm), ranging from 400 to 500 nm. The y-axis shows absorbance, ranging from 0 to 2.4. There are five curves representing different concentrations of AA: 0 mM, 0.010 mM, 0.025 mM, 0.030 mM, and 0.050 mM. The curves show a peak around 420 nm, with the highest absorbance for 0 mM AA and decreasing absorbance as AA concentration increases. An arrow points downward at approximately 440 nm, likely indicating a significant spectral change at this wavelength.

Right Graph:
This graph shows the kinetics of a reaction. The x-axis represents time in minutes, ranging from 0 to 5 minutes. The y-axis shows absorbance at 420 nm (A420), ranging from 0 to 2.0. There are four curves representing different concentrations of AA: 0 mM, 0.010 mM, 0.025 mM, and 0.050 mM. The curves show an increase in absorbance over time, with the rate and final absorbance decreasing as AA concentration increases. The 0.050 mM AA curve shows no significant change in absorbance over time.

Key observations:
1. Increasing AA concentration leads to a decrease in absorbance in both graphs.
2. The left graph shows a characteristic absorption peak around 420 nm.
3. The right graph demonstrates that AA inhibits the reaction, with complete inhibition at 0.050 mM AA.
4. Error bars are present in the right graph, indicating replicate measurements.
5. The reaction appears to reach completion within 3-4 minutes for the lower AA concentrations.

This data suggests that AA acts as an inhibitor in the studied chemical system, with its effect being concentration-dependent.</DESCRIPTION_FROM_IMAGE>

Fig. 3. (A) The effect of AA on the MoO3 NPs-ABTS system and (B) quenching kinetics of AA in MoO3 NPs-ABTS system.

<DESCRIPTION_FROM_IMAGE>This image contains six separate graphs labeled A through F, each presenting different data related to enzymatic and chemical analyses. I'll describe each graph in detail:

A. UV-Visible Absorption Spectra:
- X-axis: Wavelength (nm) from 400 to 800 nm
- Y-axis: Absorbance from 0 to 1.6
- Four spectra labeled a, b, c, and d
- Spectra a, b, and c show similar patterns with peaks around 400 nm and 750 nm
- Spectrum d shows a sharp decline after 400 nm with no other peaks
- Inset image shows four vials labeled a, b, c, and d, corresponding to the spectra

B. Enzyme Activity Comparison:
- X-axis: Enzyme numbered 1 to 9
- Y-axis: A_20 (likely absorbance at 20 minutes) from 0 to 0.7
- Bar graph showing similar activity levels (around 0.6) for most enzymes
- Enzyme 2 shows significantly lower activity (near zero)

C. Absorbance Spectra:
- X-axis: Wavelength (nm) from 400 to 470 nm
- Y-axis: Absorbance from 0 to 4
- Multiple spectra labeled 'a' to 'g'
- Spectra show a peak around 420-430 nm, with decreasing intensity from 'a' to 'g'

D. ACP Concentration vs Absorbance Change:
- X-axis: ACP (U/L) from 0 to 8
- Y-axis: ΔA420 from 0 to 2.0
- Linear relationship between ACP concentration and absorbance change
- Data points with error bars and a fitted line

E. NaF Inhibition Efficiency:
- X-axis: NaF concentration (mmol/L) from 0 to 10
- Y-axis: Inhibition efficiency (%) from -20 to 80
- Sigmoidal curve showing increasing inhibition with NaF concentration
- Data points with error bars and a fitted curve

F. Sodium Pyrophosphate Inhibition Efficiency:
- X-axis: Sodium Pyrophosphate concentration (mmol/L) from 0 to 1.0
- Y-axis: Inhibition efficiency (%) from 0 to 0.8
- Sigmoidal curve showing increasing inhibition with sodium pyrophosphate concentration
- Data points and a fitted curve

These graphs collectively represent a comprehensive analysis of enzyme activity, spectral characteristics, and inhibition studies, likely for a specific enzyme or enzymatic system.</DESCRIPTION_FROM_IMAGE>

Fig. 4. (A) UVeVis absorption of (a) MoO3 NPs, (b) MoO3 NPs þ ABTS þ AAP, (c) MoO3 NPs þ ABTS þ ACP, and (d) MoO3 NPs þ ABTS þ AAP þ ACP. Inset is the: photographs of corresponding solutions. (B) Selectivity of the ACP detection method. The x-axis labels are (1) blank, (2) ACP, (3) HRP, (4) proteinase K, (5) acetylase, (6) cholinesterase, (7) pyrophosphate hydrolase, (8) muramidase, (9) urease. ACP with a concentration of 2 U/L was used. The concentrations of all other enzyme were 20 U/L. The absorption spectra of the MoO3 NPs þ ABTS þ AAP þ ACP system with various concentrations of ACP concentration. (D) The linear relationship between DA420 and the concentration of ACP. (E and F) Inhibition efficiency of NaF and sodium pyrophosphate on ACP.

#### Table 1

Determination of ACP activity in human serum samples.

| Sample        | Spiked (U/L) | Found (U/L) | RSD (%) | Recovery (%) |
|---------------|--------------|-------------|---------|--------------|
| Human serum 1 | 0            | 0.026       | 2.1     | e            |
|               | 1.5          | 1.64        | 4.99    | 107.60       |
|               | 3.0          | 3.10        | 1.42    | 102.47       |
| Human serum 2 | 0            | 0.26        | 4.03    | e            |
|               | 1.5          | 1.64        | 4.16    | 92.00        |
|               | 3.0          | 3.21        | 0.78    | 98.33        |
| Human serum 3 | 0            | 0.17        | 3.68    | e            |
|               | 1.5          | 1.66        | 4.12    | 99.33        |
|               | 3.0          | 3.06        | 1.73    | 96.33        |

draft. Xiaomin Zhang: Methodology, Investigation, Validation. Shijun Liu: Methodology, Investigation. Linlin Zheng: Investigation. Yemei Bu: Investigation. Haohua Deng: Investigation. Ruiting Chen: Investigation. Huaping Peng: Investigation. Xinhua Lin: Supervision. Wei Chen: Conceptualization, Supervision, Writing review & editing.

#### Acknowledgments

This work was supported by the National Natural Science Foundation of China (No. 21305015, 21775023), National Science Foundation of Fujian Province (No. 2016J06019), Joint Funds for the Innovation of Science and Technology of Fujian Province (2017Y9124), Talent Training Project of Fujian Provincial Health and Family Planning Commission (2018-CX-39), and Program for Young Top-notch Innovative Talents of Fujian Province of China.

#### Appendix A. Supplementary data

Supplementary data to this article can be found online at https://doi.org/10.1016/j.aca.2020.01.035.

#### References

- [1] H. Wei, E. Wang, Nanomaterials with enzyme-like characteristics (nanozymes): next-generation artificial enzymes, Chem. Soc. Rev. 42 (2013) 6060e6093.

- [2] B. Liu, Z. Huang, J. Liu, Boosting the oxidase mimicking activity of nanoceria by fluoride capping: rivaling protein enzymes and ultrasensitive F detection, Nanoscale 8 (2016) 13562e13567.
- [3] H. Zhang, J. Chen, Y. Yang, L. Wang, Z. Li, H. Qiu, Discriminative detection of glutathione in cell lysates based on oxidase-like activity of magnetic nanoporous graphene, Anal. Chem. 91 (2019) 5004e5010.
- [4] J.Q.X. Wu, X.Y. Wang, Q. Wang, Z.P. Lou, S.R. Li, Y.Y. Zhu, L. Qin, H. Wei, Nanomaterials with enzyme-like characteristics (nanozymes): nextgeneration artificial enzymes (II), Chem. Soc. Rev. 48 (2019) 1004e1076.
- [5] M. Liang, X. Yan, Nanozymes: from new concepts, mechanisms, and standards to applications, Acc. Chem. Res. 52 (2019) 2190e2200.
- [6] H. Wei, E. Wang, Fe3O4 magnetic nanoparticles as peroxidase mimetics and their applications in H2O2 and glucose detection, Anal. Chem. 80 (2008) 2250e2254.
- [7] X. Shen, W. Liu, X. Gao, Z. Lu, X. Wu, X. Gao, Mechanisms of oxidase and superoxide dismutation-like activities of gold, silver, platinum, and palladium, and their alloys: a general way to the activation of molecular oxygen, J. Am. Chem. Soc. 137 (2015) 15882e15891.
- [8] W.J. Luo, C.F. Zhu, S. Su, D. Li, Y. He, Q. Huang, C.H. Fan, Self-catalyzed, selflimiting growth of glucose oxidase-mimicking gold nanoparticles, ACS Nano 4 (2010) 7451e7458.
- [9] L.L. Wu, L.Y. Wang, Z.J. Xie, N. Pan, C.F. Peng, Colorimetric assay of l-cysteine based on peroxidase-mimicking DNA-Ag/Pt nanoclusters, Sens. Actuators B Chem. 235 (2016) 110e116.
- [10] J. Ge, R. Cai, X. Chen, Q. Wu, L. Zhang, Y. Jiang, C. Cui, S. Wan, W. Tan, Facile approach to prepare HSA-templated MnO2 nanosheets as oxidase mimic for colorimetric detection of glutathione, Talanta 195 (2019) 40e45.
- [11] W. Zhen, Y. Liu, L. Lin, J. Bai, X. Jia, H. Tian, X. Jiang, BSA-IrO2: catalase-like nanoparticles with high photothermal conversion efficiency and a high X-ray absorption coefficient for anti-inflammation and antitumor theranostics, Angew. Chem. Int. Ed. 57 (2018) 10309e10313.
- [12] S. Ghosh, P. Roy, N. Karmodak, E.D. Jemmis, G. Mugesh, Nanoisozymes: crystal-facet-dependent enzyme-mimetic activity of V2O5 nanomaterials, Angew. Chem. 130 (2018) 4600e4605.
- [13] W.T. Yao, H.Z. Zhu, W.G. Li, H.B. Yao, Y.C. Wu, S.H. Yu, Intrinsic peroxidase catalytic activity of Fe7S8 nanowires templated from [Fe16S20]/diethylenetriamine hybrid nanowires, Chempluschem 78 (2013) 723e727.
- [14] G.F. Liu, M. Filipovic, I. Ivanovic-Burmazovic, F. Beuerle, P. Witte, A. Hirsch, High catalytic activity of dendritic C60 monoadducts in metal-free superoxide dismutation, Angew. Chem. Int. Ed. 47 (2008) 3991e3994.
- [15] H. Tan, C. Ma, L. Gao, Q. Li, Y. Song, F. Xu, T. Wang, L. Wang, Metaleorganic framework-derived copper nanoparticle@ carbon nanocomposites as peroxidase mimics for colorimetric sensing of ascorbic acid, Chem.-A Eur. J. 20 (2014) 16377e16383.
- [16] A. Asati, S. Santra, C. Kaittanis, S. Nath, J.M. Perez, Oxidase-like activity of polymer-coated cerium oxide nanoparticles, Angew. Chem. 121 (2009) 2344e2348.
- [17] J. You, Y. Liu, C. Lu, W. Tseng, C. Yu, Colorimetric assay of heparin in plasma based on the inhibition of oxidase-like activity of citrate-capped platinum nanoparticles, Biosens. Bioelectron. 92 (2017) 442e448.
- [18] M. Huang, H. Wang, D. He, P. Jiang, Y. Zhang, Ultrafine and monodispersed iridium nanoparticles supported on nitrogen-functionalized carbon: an efficient oxidase mimic for glutathione colorimetric detection, Chem. Commun. 55 (2019) 3634e3637.
- [19] R. Cai, D. Yang, K. Lin, T.S. Cao, Y. Lyv, K. Chen, Yu Yang, Ge Jia, L. Xia, G. Christou, Y. Zhao, Z. Chen, W. Tan, 3D halos assembled from Fe3O4/Au NPs with enhanced catalytic and optical properties, Nanoscale 11 (2019) 20968e20976.
- [20] R. Cai, D. Yang, S. Peng, X. Chen, Y. Huang, Y. Liu, W. Hou, S. Yang, Z. Liu, W. Tan, Single nanoparticle to 3D supercage: framing for an artificial enzyme system, J. Am. Chem. Soc. 137 (2015) 13957e13963.
- [21] J. Li, Y. Cheng, J. Zhang, J. Fu, W. Yan, Q. Xu, Confining Pd nanoparticles and atomically dispersed Pd into defective MoO3 nanosheet for enhancing electroand photocatalytic hydrogen evolution performances, ACS Appl. Mater. Interfaces 11 (2019) 27798e27804.
- [22] C. Xia, Y. Zhou, D.B. Velusamy, A.A. Farah, P. Li, Q. Jiang, I.N. Odeh, Z. Wang, X. Zhang, H.N. Alshareef, Anomalous Li storage capability in atomically thin two-dimensional sheets of nonlayered MoO2, Nano Lett. 18 (2018) 1506e1515.
- [23] J. Wang, Y. Yang, H. Li, J. Gao, P. He, L. Bian, F. Dong, Y. He, Stable and tunable

plasmon resonance of molybdenum oxide nanosheets from the ultraviolet to the near-infrared region for ultrasensitive surface-enhanced Raman analysis, Chem. Sci. (2019) 6330e6335.

- [24] T. Sviridova, L.Y. Sadovskaуa, E. Shchukina, A. Logvinovich, D. Shchukin, D. Sviridov, Nanoengineered thin-film TiO2/h-MoO3 photocatalysts capable to accumulate photoinduced charge, J. Photochem. Photobiol. A Chem. 327 (2016) 44e50.
- [25] E. Lopes, S. Piçarra, P.L. Almeida, L.H. De, M. Aires-De-Sousa, Bactericidal efficacy of molybdenum oxide nanoparticles against antimicrobial-resistant pathogens, J. Med. Microbiol. (2018) 1042e1046.
- [26] H. Kanno, R.J. Holmes, Y. Sun, S. Kena-Cohen, S.R. Forrest, White stacked electrophosphorescent organic light-emitting devices employing MoO3 as a charge-generation layer, Adv. Mater. 18 (2006) 339e342.
- [27] Z. Chen, D. Cummins, B.N. Reinecke, E. Clark, M.K. Sunkara, T.F. Jaramillo, Coreeshell MoO3eMoS2 nanowires for hydrogen evolution: a functional design for electrocatalytic materials, Nano Lett. 11 (2011) 4168e4175.
- [28] H. Bull, P.G. Murray, D. Thomas, A. Fraser, P.N. Nelson, Acid phosphatases, Mol. Pathol. 55 (2002) 65e72.
- [29] A.V. Taira, G.S. Merrick, K.E. Wallner, M. Dattoli, Reviving the acid phosphatase test for prostate cancer, Oncology 21 (2007) 1003e1010.
- [30] S. Veeramani, T. Yuan, S. Chen, F. Lin, J.E. Petersen, S. Shaheduzzaman, S. Srivastava, R.G. MacDonald, M. Lin, Cellular prostatic acid phosphatase: a protein tyrosine phosphatase involved in androgen-independent proliferation of prostate cancer, Endocr. Relat. Cancer 12 (2005) 805e822.
- [31] C. Minkin, Bone acid phosphatase: tartrate-resistant acid phosphatase as a marker of osteoclast function, Calcif. Tissue Int. 34 (1982) 285e290.
- [32] B. Kirstein, T.J. Chambers, K. Fuller, Secretion of tartrate-resistant acid phosphatase by osteoclasts correlates with resorptive behavior, J. Cell. Biochem. 98 (2006) 1085e1094.
- [33] P. Montesinos, I. Lorenzo, G. Martín, J. Sanz, M.L. Perez-Sirvent, D. Martínez, G. Ortí, L. Algarra, J. Martínez, F. Moscardo, Tumor lysis syndrome in patients with acute myeloid leukemia: identification of risk factors and development of a predictive model, Haematol 93 (2008) 67e74.
- [34] Z. Fredj, M.B. Ali, M.N. Abbas, E. Dempsey, Determination of prostate cancer biomarker acid phosphatase at a copper phthalocyanine-modified screen printed gold transducer, Anal. Chim. Acta 1057 (2019) 98e105.
- [35] F. Shi, Y. Zhang, W. Na, X. Zhang, Y. Li, X. Su, Graphene quantum dots as selective fluorescence sensor for the detection of ascorbic acid and acid phosphatase via Cr (VI)/Cr (III)-modulated redox reaction, J. Mater. Chem. B 4 (2016) 3278e3285.
- [36] Z. Qian, L. Chai, Q. Zhou, Y. Huang, C. Tang, J. Chen, H. Feng, Reversible fluorescent nanoswitch based on carbon quantum dots nanoassembly for realtime acid phosphatase activity monitoring, Anal. Chem. 87 (2015) 7332e7339.
- [37] Z. Qu, W. Na, X. Liu, H. Liu, X. Su, A novel fluorescence biosensor for sensitivity detection of tyrosinase and acid phosphatase based on nitrogen-doped graphene quantum dots, Anal. Chim. Acta 997 (2018) 52e59.
- [38] H.H. Deng, X.L. Lin, Y.H. Liu, K.L. Li, Q.Q. Zhuang, H.P. Peng, A.L. Liu, X.H. Xia, W. Chen, Chitosan-stabilized platinum nanoparticles as effective oxidase mimics for colorimetric detection of acid phosphatase, Nanoscale 9 (2017) 10292e10300.
- [39] M.A. Andersch, A.J. Szczypinski, Use of p-nitrophenylphosphate as the substrate in determination of serum acid phosphatase, Am. J. Clin. Pathol. 17 (1947) 571e574.
- [40] E. Redel, S. Petrov, O. Dag, J. Moir, C. Huai, P. Mirtchev, G.A. Ozin, Green nanochemistry: metal oxide nanoparticles and porous thin films from bare metal powders, Small 8 (2012) 68e72.
- [41] Y. Zhan, Y. Liu, H. Zu, Y. Guo, S. Wu, H. Yang, Z. Liu, B. Lei, J. Zhuang, X. Zhang, Phase-controlled synthesis of molybdenum oxide nanoparticles for surface enhanced Raman scattering and photothermal therapy, Nanoscale 10 (2018) 5997e6004.
- [42] L. Fang, Y. Shu, A. Wang, T. Zhang, Template-free synthesis of molybdenum oxide-based hierarchical microstructures at low temperatures, J. Cryst. Growth 310 (2008) 4593e4600.
- [43] K. Dewangan, N.N. Sinha, P.K. Sharma, A.C. Pandey, N. Munichandraiah, N.S. Gajbhiye, Synthesis and characterization of single-crystalline a-MoO3 nanofibers for enhanced Li-ion intercalation applications, CrystEngComm 13 (2011) 927e933.
- [44] J. Wertz, Electron Spin Resonance: Elementary Theory and Practical Applications, Springer Science & Business Media, 2012.