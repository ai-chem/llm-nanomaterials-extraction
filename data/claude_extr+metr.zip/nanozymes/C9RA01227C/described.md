# RSC Advances

<DESCRIPTION_FROM_IMAGE>This image does not contain any scientific content related to chemistry, graphs, diagrams, or chemical structures. It simply displays the word "PAPER" in large white capital letters on a light blue background. As this does not convey any relevant scientific or chemical information, I would classify this as:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Cite this: RSC Adv., 2019, 9, 16509

Received 17th February 2019 Accepted 19th May 2019

DOI: 10.1039/c9ra01227c

rsc.li/rsc-advances

## Introduction

Developing a simple and effective sensing assay to detect biomarkers rapidly has attracted word-wide interest in the eld of bio-analysis.1,2 Till now, numerous analytical techniques based on colorimetric, uorescence, electrochemistry and surface enhanced Raman scattering have made great efforts in the detection of different disease biomarkers, including promoting the sensitivity and accuracy, and shortening the time of measurement.3–5 Among these strategies, nanozymes, as catalytic materials with enzyme mimicking activities, show great potential in bio-analysis owing to their tunable catalytic activities.6 Especially, peroxidase-mimicking nanozymes have been widely investigated to design versatile sensing platform biosensors.7,8 For instance, a selective glucose biosensor was constructed by combining peroxidase-like Fe3O4 nanozymes with glucose oxidase.9 This strategy now is generalized to detect other analytes, but this assay is only suitable to the H2O2 producing analytes.10 Taking an example, the colorimetric assay of glucose detection includes two cascade reactions: (1) glucose oxidation in the presence of glucose oxidase, (2)

<DESCRIPTION_FROM_IMAGE>The image contains a title text that reads:

"Mn₃O₄ microspheres as an oxidase mimic for rapid detection of glutathione"

This title suggests a scientific study or article about using manganese oxide (Mn₃O₄) microspheres as a synthetic substitute for oxidase enzymes, specifically for the purpose of quickly detecting glutathione.

Key points from this title:

1. Material: Mn₃O₄ (manganese(II,III) oxide) in microsphere form
2. Function: Acting as an oxidase mimic (artificial enzyme)
3. Application: Rapid detection of glutathione
4. Chemical formulas:
   - Mn₃O₄ (SMILES: [O-2].[O-2].[O-2].[O-2].[Mn+2].[Mn+3].[Mn+3])
   - Glutathione (SMILES: C(CC(=O)NC(CS)C(=O)NCC(=O)O)C(C(=O)O)N)

This title indicates a study in the field of nanomaterials and biosensing, utilizing inorganic compounds to mimic biological functions for analytical purposes.</DESCRIPTION_FROM_IMAGE>

Juqun Xi,abc Chunhua Zhu,ab Yanqiu Wang,a Qiannan Zhanga and Lei Fan *d

Exploiting a rapid and sensitive method for biomarker detection has important implications in the early diagnosis of diseases. Here, we synthesized Mn3O4 microspheres which worked as a nanozyme to exhibit outstanding oxidase-like activity for rapid colorimetric determination of glutathione (GSH). The Mn3O4 microspheres of about 800 nm in size could be prepared through a hydrothermal method, and we found that the as-prepared Mn3O4 microspheres could quickly oxidize 3,30 ,5,50 -tetramethylbenzidine (TMB) to its oxidized form (TMBox) in the absence of H2O2. After adding glutathione (GSH), TMBox was able to be changed into to its original form and resulted in the corresponding decrease in absorbance value at 652 nm. The Mn3O4-TMB system had good linearity with GSH concatenation in the range of 5– 60 mM, and the limit of detection was 0.889 mM. Furthermore, this assay possessed high selectivity specificity, which made it possible to detect GSH in human serum samples. Thus, the obtained assay based on the oxidase mimic of Mn3O4 would enlarge and exploit the application fields of nanozymes in bio-analysis.

> peroxidase-based H2O2 detection. The different optimum reaction conditions for glucose oxidase and nanozymes give rise to two separate steps of reactions rather than one-pot reaction, leading to the complicated analytical processes.11 Moreover, the two cascade reactions usually cause the error transfer, nally reducing the sensitivity and accuracy of detection. Thus, exploiting nanozymes possessing new enzymatic activities, such as oxidase-like activity that does not require unstable H2O2 as a co-substrate, to construct a colorimetric assay based on onepot reaction will simply the measurement steps, thereby solving the above conundrum.

**[View Article Online](https://doi.org/10.1039/c9ra01227c) [View Journal](https://pubs.rsc.org/en/journals/journal/RA) [| View Issue](https://pubs.rsc.org/en/journals/journal/RA?issueid=RA009029)**

It is noteworthy that very few nanozymes have oxidase-like activity. The best known examples are Au nanoparticles for glucose oxidation,12,13 and CeO2, V2O5, MnO2 can also oxidize a diverse range of substrates directly.14,15 Oxidases are important since they do not need H2O2 as a co-substrate. Mn3O4 is a versatile nanozyme and reported to have various enzyme-like activities, including catalase,16 superoxide dismutase17 and glutathione peroxidase (GPx).18 It was usually applied for wound healing, in vivo anti-inammation and cytoprotection. However, the oxidase-like activity of Mn3O4 has not been reported. The catalytic activities of Mn3O4 are attributed to the mixed oxidation states of Mn3+ and Mn2+, and related oxygen vacancies. As CeO2 and V2O5, we speculated that Mn3O4 maybe possessed oxidase-like activity as a promising candidate for developing colorimetric assays.

Herein, we reported a hydrothermal synthesis method to prepare Mn3O4 microspheres, which exhibited outstanding oxidase-like activity to convert colorless TMB rapidly into TMBox (a naked-eye visible chromogenic substrate) in the

a Institute of Translational Medicine, Department of Pharmacology, Medical College, Yangzhou University, Yangzhou 225001, Jiangsu, China

b Jiangsu Key Laboratory of Integrated Traditional Chinese and Western Medicine for Prevention and Treatment of Senile Diseases, Yangzhou 225001, Jiangsu, China

c Jiangsu Co-Innovation Center for the Prevention and Control of Important Animal Infections Disease and Zoonoses, College of Veterinary Medicine, Yangzhou University, Yangzhou 225009, Jiangsu, China

d School of Chemistry and Chemical Engineering, Yangzhou University, Yangzhou 225002, Jiangsu, China. E-mail: fanlei@yzu.edu.cn

absence of H2O2. It was found that glutathione (GSH) could selectively suppress the oxidation of TMB, converting blue TMBox to colorless TMB. Based on this phenomenon, the GSH level could be measured by monitoring the decrease of TMBox peak intensity at 652 nm. It is well known that GSH plays a critical role in the biological system as one of the most common intracellular non-protein biothiols.8 Many diseases, such as cancer, liver damage, acquired immunodeciency syndrome (AIDS), psoriasis, heart problems and leukocyte loss, are closely related to the abnormal level of cellular glutathione.19 Therefore, the accurate detection of GSH in serum is a matter of cardinal signicance for disease prevention and diagnosis. Several studies have combined materials, such as carbon quantum dots,20 Ag+21 and MnO2, 22 with TMB for colorimetric detection of GSH. We here utilized a one-pot reaction, the oxidase-like activity of Mn3O4, to detect the GSH level in human serum samples directly and rapidly. Unlike previous peroxidase-based biosensors including two cascade reactions, the proposed strategy only needed a one-pot reaction, simplifying the steps of measurement and improving the sensitivity and accuracy. **[View Article Online](https://doi.org/10.1039/c9ra01227c)**

# Experimental

#### Materials

Manganese formate dehydrate Mn(HCO2)2\$2H2O, sodium acetate (NaAc), ethanol (C2H5OH), methanol (CH3OH), acetic acid (HAc), glucose (Glu), sodium chloride (NaCl), potassium chloride (KCl), ascorbic acid (AA), and dopamine (DA) were purchased from Sinopharm Chemical Reagent (Shanghai, China). TMB (3,30 ,5,50 -tetramethylbenzidine) was obtained from Sigma-Aldrich (USA). ZnCl2, CaCl2, and MgCl2 were bought from Sangon Biotech (Shanghai, China). L-serine (Ser), glycine (Gly), L-histidine dihydrochloride (His), L-threonine (Thr), tryptophan (Try), L-arginine (Arg), cysteine (Cys) and bovine protein serum (BSA) were acquired from BBI Life Sciences (Shanghai, China). Glutathione (GSH) was purchased from Adamas Reagent (Shanghai, China). IgG was purchased from Solarbio (Beijing, China).

#### Synthesis of Mn3O4 microspheres

Mn(HCO2)2\$2H2O (0.2040 g) was dissolved in methanol (40 mL) with continuous string for 30 min, and then the mixture was transferred to a Teon autoclave and kept at 180 -C for 12 h. Aer nishing the reaction, Mn3O4 microspheres were obtained through centrifugation, washing and drying.

#### Characterization of Mn3O4 microspheres

Scanning electron microscopy (SEM, S-4800II, Hitachi, Tokyo, Japan) was applied to characterize the morphology and structure of Mn3O4 microspheres. The FT-IR spectrum was monitored on a Bruker Tensor 27 FT-IR spectrometer (Germany). The composition and surface chemistry of Mn3O4 microspheres were characterized by X-ray powder diffraction (XRD, D8 Advance, Bruker AXS, Germany) and X-ray photoelectron spectroscopy (XPS, Thermo ESCALAB 250 spectrometer, USA).

#### Oxidase-like activity of Mn3O4 microspheres and kinetic studies

The major absorbance peaks of TMBox in 0.1 M NaAc-HAc buffer (pH 4.5) appeared at 652 and 370 nm. For the evaluation of oxidase-like activity of Mn3O4 microspheres, chemicals were added into a 1.0 mL NaAc-HAc buffer solution in the order of Mn3O4 (varying amounts) and TMB (nal concentration: 0.416 mM). The color change of TMB in the presence of Mn3O4 microspheres was monitored by a UV-vis spectrometer (Hitachi UV2010, Japan). For kinetic parameters, the experiments were carried out in the NaAc-HAc buffer (0.1 M), containing 5.0 mg mL1 Mn3O4 microspheres and TMB with concentration ranging from 0 to 0.416 mM. The kinetic determination was monitored in a time-scan mode at 652 nm and the Michaelis– Menten constant was obtained through the Lineweaver–Burk plot analyzed by GraphPad.

#### Colorimetric detection of GSH

The measurement of GSH was performed at room temperature. The nal working concentrations of Mn3O4 microspheres and TMB were 10.0 mg mL1 and 0.416 mM, respectively. Aer adding different concentrations of GSH in Mn3O4-TMB buffer system, the mixture was incubated for 5 min and then the change of peak intensity (652 nm) was monitored. The calibration curve of GSH was obtained by plotting DA at 652 nm as a function of the GSH concentration. Where DA ¼ A0 A, A and A0 corresponded to the absorbance at 652 nm with and without GSH addition, respectively.

Colorimetric assay of GSH in human serum samples was performed as follows. First, the human serum samples from our local hospital (Northern Jiangsu People's Hospital, Jiangsu Province) were centrifuged at 3000 rpm for 10 min. Aerwards, 5.0 mL of serum supernatant, Mn3O4 microspheres (nal concentration: 10.0 mg mL1 ), and TMB (nal concentration: 0.416 mM) were incubated together for 5 min, and then the absorbance at 652 nm was measured.

#### Statistical analysis

Quantitative data were expressed as the means standard deviations.

# Results and discussion

Mn3O4 microspheres were synthesized according to a previously report.20 The morphology, crystalline phase and chemical composition of the obtained Mn3O4 microspheres were analyzed by SEM, XRD and XPS. The SEM image shown in Fig. 1A indicated that the prepared Mn3O4 microspheres were about 800 nm in diameter, and each microsphere was composed of small-sized Mn3O4 nanoparticles (10 nm) (Fig. 1B). Elemental mapping of the Mn3O4 microsphere (Fig. 1C) showed that O and Mn elements were homogeneously distributed within a whole microsphere. The main diffraction peaks in XRD spectrum (Fig. 2A) matched to the standard pattern of hausmannite Mn3O4 [JCPDS card no. 24-0734],23,24 conrming their crystalline nature. Furthermore, the surface of

<DESCRIPTION_FROM_IMAGE>This image contains multiple panels (A-E) presenting various analytical results related to nanoparticles and their properties. I'll describe each panel in detail:

A (left): Scanning Electron Microscope (SEM) image showing spherical nanoparticles with diameters ranging from approximately 50-100 nm. The particles appear to be uniformly distributed with some aggregation.

B (left): High-resolution Transmission Electron Microscope (TEM) image showing the detailed structure of the nanoparticles. The scale bar indicates 100 nm.

C: Energy-dispersive X-ray spectroscopy (EDS) mapping images. The left image is an SEM image of two large spherical particles. The middle image shows the distribution of one element (likely manganese) in red. The right image shows the distribution of another element (likely oxygen) in green.

A (right): UV-Vis absorption spectra of three samples (labeled 1, 2, and 3). The graph shows absorbance (Abs) vs wavelength (nm) from 400 to 800 nm. Sample 3 has the highest peak absorbance at around 650 nm.

B (right): Time-dependent absorbance measurements at 652 nm for three samples: Control (green), Mn3O4 2.5 μg/mL (red), and Mn3O4 5.0 μg/mL (blue). The graph shows absorbance increasing over time (0-300 seconds) for the Mn3O4 samples, with the higher concentration showing a greater increase.

C (bottom right): Graph showing relative activity (%) vs an unlabeled x-axis. The activity peaks at around 100% and then decreases sharply.

D: Graph of relative activity (%) vs an unlabeled x-axis, showing a gradual decrease from about 100% to 80%.

E: Graph of k (s^-1) vs an unlabeled x-axis, showing an increase from about 0.002 to 0.006 s^-1.

This image compilation provides comprehensive characterization of the nanoparticles, including their morphology, elemental composition, optical properties, and catalytic activity.</DESCRIPTION_FROM_IMAGE>

Fig. 1 (A) SEM image of Mn3O4 microspheres. (B) High-magnification SEM image of an individual Mn3O4 microsphere. (C) Elemental mapping images of Mn and O in Mn3O4 microspheres.

<DESCRIPTION_FROM_IMAGE>The image contains four separate graphs labeled A, B, C, and D, each representing different spectroscopic analyses:

A. X-ray Diffraction (XRD) Pattern:
- X-axis: 2θ (degree) ranging from 10 to 80
- Y-axis: Intensity (a.u.)
- Notable peaks labeled: (110), (101), (211), (220)
- The pattern shows characteristic peaks of a crystalline material

B. X-ray Photoelectron Spectroscopy (XPS) Survey Spectrum:
- X-axis: Binding energy (eV) ranging from 0 to 1000 eV
- Y-axis: Intensity (a.u.)
- Identified peaks: Mn3p, O1s, C1s, Mn2p
- The spectrum indicates the presence of manganese, oxygen, and carbon in the sample

C. High-resolution XPS Spectrum of Mn 2p:
- X-axis: Binding energy (eV) ranging from 635 to 665 eV
- Y-axis: Intensity (a.u.)
- Two main peaks identified: Mn 2p1/2 and Mn 2p3/2
- The spectrum shows the characteristic splitting of the Mn 2p orbital

D. Infrared (IR) Spectrum:
- X-axis: Wavenumber (cm⁻¹) ranging from 400 to 1000 cm⁻¹
- Y-axis: Transmittance (%)
- Two notable absorption bands labeled: 520 cm⁻¹ and 620 cm⁻¹
- The spectrum shows characteristic vibrational modes of the material

These spectroscopic analyses collectively provide information about the crystal structure, elemental composition, chemical state, and molecular vibrations of the studied material, which appears to be a manganese-containing compound.</DESCRIPTION_FROM_IMAGE>

Fig. 2 (A) XRD patterns of Mn3O4 microspheres. (B) XPS spectrum of Mn3O4 microspheres. (C) Mn 2p peak of Mn3O4 microspheres. (D) FT-IR spectrum of Mn3O4 microspheres.

Mn3O4 microspheres was analyzed by XPS. As shown in Fig. 2B and C, Mn 2p3/2 and 2p1/2 peaks were located at 641.67 eV and 653.35 eV, respectively. The atom ratio of Mn2+ and Mn3+ was about 1/2, which was consistent with the theoretical value.25 Moreover, the FT-IR spectrum (Fig. 2D) of Mn3O4 microspheres showed three main bands centered at (407, 502 and 620 cm1 ), which were attributed to the Mn–O vibrations of the Mn3O4 framework.17 Thus, the Mn3O4 microspheres could be obtained successfully through a hydrothermal synthesis.

Recently, Mn3O4 materials were reported to have the catalase-like and superoxide dismutase-like activities under neutral conditions for elimination of reactive oxygen species both in vitro and in vivo. 26 However, the oxidase-like activity of Mn3O4 has not been reported. We here concentrated on the investigation of the oxidase-like activity possessed by Mn3O4 microspheres, and TMB was used as the substrate of oxidaselike reaction. As presented in Fig. 3A, a deep blue color with maximum absorption peak at 652 nm indicated that Mn3O4 microspheres were able to cause the oxidation of TMB directly. This reaction occurred without the assistance of H2O2. Increasing the concentration of Mn3O4 microspheres was benecial for the occurrence of this oxidation reaction. The time-dependent absorbance change in Mn3O4-TMB was shown in Fig. 3B, and the oxidation of TMB reached a plateau at 2 min at 25 -C, which was much faster than that reported oxidase-like reactions triggered by other nanomaterials for

<DESCRIPTION_FROM_IMAGE>This image contains five separate graphs labeled A through E, each presenting different data related to a chemical analysis. I'll describe each graph in detail:

A. UV-Visible Absorption Spectrum:
This graph shows the absorption spectra of three samples (labeled 1, 2, and 3) over a wavelength range of 400-800 nm. The inset image shows three colored solutions corresponding to these samples. Sample 3 has the highest absorption peak at around 680 nm, followed by sample 2 with a lower peak at the same wavelength. Sample 1 shows minimal absorption across the spectrum.

B. Kinetic Absorption Measurement:
This graph displays the absorption at 652 nm over time (0-300 seconds) for three conditions: Control, Mn3O4 at 2.5 μg/mL, and Mn3O4 at 5.0 μg/mL. The Mn3O4 at 5.0 μg/mL shows the highest absorption, reaching a plateau around 0.75. The 2.5 μg/mL concentration shows intermediate absorption, plateauing around 0.4. The control shows negligible absorption.

C. pH-Dependent Activity:
This graph shows the relative activity of a substance (likely an enzyme) as a function of pH, ranging from 2 to 10. The activity peaks sharply at around pH 4, with a maximum relative activity of about 100%. Activity drops rapidly on either side of this optimum pH.

D. Temperature-Dependent Activity:
This graph displays the relative activity of a substance (likely the same enzyme) as a function of temperature, ranging from 30°C to 60°C. The activity remains relatively stable (around 100%) from 30°C to 40°C, then gradually decreases as temperature increases, dropping to about 80% at 60°C.

E. Kinetic Analysis:
This graph shows the initial velocity (v0) of a reaction as a function of TMB (tetramethylbenzidine) concentration, ranging from 0 to 0.4 mM. The data points follow a hyperbolic curve characteristic of Michaelis-Menten kinetics, with the reaction rate increasing rapidly at low substrate concentrations and then leveling off as it approaches saturation.

These graphs collectively provide information about the spectral properties, kinetics, and optimal conditions (pH and temperature) for what appears to be an enzyme-catalyzed reaction involving Mn3O4 nanoparticles and TMB as a substrate.</DESCRIPTION_FROM_IMAGE>

Fig. 3 (A) The visual color changes and absorbance spectra of TMB. (1) Control, (2) 2.5 mg mL1 Mn3O4 and (3) 5.0 mg mL1 Mn3O4. (B) Timedependent absorbance changes of TMB at 652 nm in the presence of Mn3O4 microspheres. (C) The oxidase-like activity of Mn3O4 microspheres was dependent on pH. TMB: 0.416 mM, Mn3O4: 5.0 mg mL1 . (D) The oxidase mimetic activity of Mn3O4 microspheres was dependent on temperature. TMB: 0.416 mM, Mn3O4: 5.0 mg mL1 . (E) The steady-state kinetic assay of Mn3O4 (5.0 mg mL1 ).

detection of GSH, such as V2O5 (13 min2 ) and Co, N-doped porous carbon hybrids (20 min).27 So, this quick response between TMB and Mn3O4 laid the foundation of rapid analysis. Similarity to natural enzymes, the catalytic activity of Mn3O4 microspheres was also related to pH (Fig. 3C) and temperature (Fig. 3D). The results showed that the optimal pH and temperature were about 4.0 and 37 -C, respectively. We also measured the maximum initial velocity (Vmax) and Michaelis– Menten constant (Km) of Mn3O4 microspheres (Fig. 3E), the obtained Km value was 0.02715 mM with TMB as the substrate, and the corresponding Vmax value was 126.7 nM s1 . These results demonstrated that Mn3O4 microspheres exhibited the excellent oxidase-like activity.

As a most abundant intracellular nonprotein thiolated tripeptide,28,29 GSH plays an important role in regulating oxidative stress for cell function and growth. An abnormal level of GSH related closely to many diseases, such as cancer, Alzheimer's disease and cardiovascular disease.30 Therefore, the sensitive and rapid determination of GSH in biological samples is a matter of cardinal signicance. So, we here utilized the oxidase-like activity of Mn3O4 microspheres to detect GSH directly. As displayed in Fig. 4A and B, an obvious blue color was

<DESCRIPTION_FROM_IMAGE>The image contains four panels labeled A, B, C, and D.

Panel A: This panel depicts a chemical reaction scheme. It shows the oxidation of TMB (3,3',5,5'-tetramethylbenzidine) by manganese oxide (MnO2) in the presence of glutathione (GSH). The reaction produces two products: TMBox (oxidized form of TMB) and TMB (reduced form). The arrows indicate the direction of the reaction.

Panel B: This panel shows an absorption spectrum graph. The x-axis represents wavelength in nanometers (nm) ranging from 400 to 800 nm. The y-axis represents absorbance (Abs) ranging from 0 to 1.5. The graph shows a peak at approximately 650 nm with a maximum absorbance of about 1.4. There are two inset images showing color changes, likely corresponding to different states of the reaction.

Panel C: This panel shows another reaction scheme, similar to Panel A. It depicts the reduction of TMBox back to TMB using glutathione (GSH). The reaction consumes 4 molecules of GSH for each molecule of TMBox reduced.

Panel D: This panel shows an absorption spectrum graph similar to Panel B. The axes and scale are identical. The graph shows a peak at the same wavelength (approximately 650 nm) with a similar maximum absorbance of about 1.4. There are also two inset images showing color changes, likely corresponding to different states of the reaction.

SMILES for TMB: CC1=CC(=C(C=C1N)C)N

SMILES for MnO2: [Mn](=O)=O

SMILES for GSH: C(CC(=O)NC(CS)C(=O)NCC(=O)O)C(C(=O)O)N

The image illustrates the redox cycling of TMB mediated by MnO2 and GSH, along with the corresponding absorption spectra and visual color changes of the reaction mixture.</DESCRIPTION_FROM_IMAGE>

Fig. 4 (A) and (B) Absorption spectra and reaction process of the TMB-Mn3O4 system with/without GSH addition at the same time. (C) and (D) Absorption spectra and reaction process of TMB-Mn3O4 system with/ without adding GSH into the solution after catalytic reaction. TMB: 5.0 mg mL1 , GSH: 60 mM.

<DESCRIPTION_FROM_IMAGE>This image contains four separate panels labeled A, B, C, and D, each presenting different scientific data related to chemistry experiments. I'll describe each panel in detail:

A. Electron Paramagnetic Resonance (EPR) Spectra:
This panel shows two EPR spectra plotted against g-Factor (x-axis) ranging from 3480 to 3560. The y-axis represents signal intensity (not labeled). Two conditions are compared:
1. Control (top spectrum)
2. Mn3O4 (bottom spectrum)
The Mn3O4 spectrum shows four distinct sharp peaks, while the control spectrum appears as a relatively flat line with some noise.

B. EPR Spectra with Sample Images:
This panel shows two EPR spectra plotted against g-Factor (x-axis) ranging from 3500 to 3540. The y-axis represents signal intensity (not labeled). Two conditions are shown, each associated with a small image:
1. Top spectrum: associated with a gray square (labeled "1")
2. Bottom spectrum: associated with a blue-green square (labeled "2")
The bottom spectrum shows a series of closely spaced peaks forming a broad signal.

C. Time-dependent Absorbance Plot:
This graph shows absorbance (y-axis) plotted against time in seconds (x-axis) from 0 to 300 seconds. Four different conditions are compared:
1. Mn3O4 + HO-inhibitor: red squares, showing a rapid decrease in absorbance over time
2. Mn3O4 + CAT: green triangles, maintaining a constant absorbance around 0.5
3. Mn3O4: blue circles, maintaining a constant absorbance around 0.8
4. HO-inhibitor: black diamonds, maintaining a constant absorbance near 0

D. UV-Vis Absorption Spectra:
This graph shows absorbance (y-axis) plotted against wavelength in nm (x-axis) from 500 to 800 nm. Three different conditions are compared:
1. O2: black line
2. Air: red line
3. N2: blue line
All three spectra show a broad absorption peak centered around 650-700 nm, with the O2 condition showing the highest absorbance, followed by air, and then N2.

These graphs collectively provide information about the electronic and optical properties of Mn3O4 under various conditions, including its interaction with oxygen and potential catalytic activity.</DESCRIPTION_FROM_IMAGE>

Fig. 5 (A) BMPO trapped EPR spectra over Mn3O4 microspheres after 1 min of reaction. (V ¼ 100 mL, pH ¼ 4.5, Mn3O4 ¼ 100 mg mL1 , BMPO ¼ 10 mM). (B) BMPO trapped EPR spectra over GSH reducing the colored TMBox to colorless TMB after 1 min of reaction. (V ¼ 1 mL, pH ¼ 4.5, Mn3O4 ¼ 10.0 mg mL1 , TMB ¼ 0.416 mM, GSH ¼ 60 mM, BMPO ¼ 10 mM). (C) Effect of HOc scavenger (hypotaurine, 10%) and H2O2 scavenger (CAT, 15 mg mL1 ) on the oxidase-like activity of Mn3O4. (D) Effect of O2 concentration on the oxidase-like activity of Mn3O4.

<DESCRIPTION_FROM_IMAGE>The image contains three parts labeled A, B, and C, each representing different aspects of an experiment involving glutathione (GSH).

A. This part shows a series of nine test tubes containing solutions with varying concentrations of GSH, ranging from 0 to 100 μM. The intensity of the solution's color decreases from left to right, indicating a correlation between GSH concentration and color intensity.

B. This is a graph showing absorption spectra. The x-axis represents wavelength (nm) from 400 to 800 nm, and the y-axis shows absorbance (A). There are multiple overlapping spectra, numbered from 1 to 9. The spectra show a prominent peak around 650-700 nm, with the peak intensity decreasing from spectrum 1 to 9. This suggests a decrease in absorption as the GSH concentration increases.

C. This graph shows a linear relationship between GSH concentration and change in absorbance at 650 nm (ΔA650nm). The x-axis represents GSH concentration (μM) from 0 to 60 μM, while the y-axis shows ΔA650nm from 0 to 1.5. Data points are plotted with error bars, and a linear regression line is fitted to the data. The equation of the line is given as ΔA = 0.1099 + 0.0191[GSH], with an R² value of 0.9908, indicating a strong linear correlation between GSH concentration and change in absorbance.

This image set demonstrates the use of spectrophotometric analysis to quantify GSH concentration, showing both the visual color change and the corresponding spectral data, along with a calibration curve for concentration determination.</DESCRIPTION_FROM_IMAGE>

Fig. 6 (A) The photos of the TMB-Mn3O4 system in different concentrations of GSH (from left to right: 0, 5, 10, 15, 25, 50, 60, 80, 100 mM). (B) UV-vis absorption spectra of TMB-Mn3O4 system with various GSH amounts (1–9: 0, 5, 10, 15, 25, 50, 60, 80, 100 mM). (C) The calibration curve of GSH. Reaction condition: 0.416 mM TMB, 10 mg mL1 Mn3O4 microspheres, pH 4.5 and room temperature.

<DESCRIPTION_FROM_IMAGE>This image contains multiple parts (A, B, C, D, and an unlabeled bar graph) presenting various analytical data related to Mn3O4 microspheres. I'll describe each part in detail:

A. EPR (Electron Paramagnetic Resonance) spectra comparing a control sample and Mn3O4. The x-axis shows g-Factor from 3480 to 3560. The Mn3O4 spectrum (red) shows more pronounced peaks compared to the control (black).

B. Another EPR spectrum, focusing on g-Factor range 3500-3540. It includes two small images labeled 1 and 2, likely showing the samples analyzed.

C. A graph plotting Absorbance (y-axis, 0 to 1.0) against Time in seconds (x-axis, 0 to 300). Three conditions are shown:
- Mn3O4 + HO• inhibitor (red squares)
- Mn3O4 + CAT (green triangles)
- Mn3O4 (blue circles)
The Mn3O4 condition shows the highest stable absorbance, while the HO• inhibitor condition shows a decline over time.

D. UV-Vis absorption spectra under different atmospheric conditions (O2, Air, N2). The x-axis shows Wavelength (nm) from 500 to 800, and the y-axis shows Absorbance from 0 to 0.8. All three conditions show a peak around 650-700 nm, with O2 having the highest absorbance.

The unlabeled bar graph on the right shows ΔA652nm (y-axis, 0 to 1.5) for various chemical species. GSH shows the highest value, followed by DA and AA. Many other species are shown with lower values.

The caption below the image reads: "Fig. 5 (A) BMPO trapped EPR spectra over Mn3O4 microspheres after..."

This image provides a comprehensive analysis of the properties and interactions of Mn3O4 microspheres using various spectroscopic and analytical techniques.</DESCRIPTION_FROM_IMAGE>

Fig. 7 Selectivity of Mn3O4-TMB system for GSH over other potential interferences. Reaction conditions: 0.416 mM TMB, 10 mg mL1 Mn3O4 microspheres, pH 4.5 and room temperature. Concentrations of the tested substances: 600 mM, except for 60 mM GSH, 6 mM DA, 6 mM Cys, 20 mM AA, 1 mg mL1 of BSA, and 1 mg mL1 IgG.

observed in the TMB-Mn3O4 system. However, when TMB, Mn3O4 microspheres and GSH were mixed together at the same time, no color change was found. This result revealed that the presence of GSH inhibited the color reaction of TMB. Moreover, when TMB and Mn3O4 microspheres were rst mixed to trigger the color reaction of TMB, a deep blue color would then fade aer the addition of GSH into the above system (Fig. 4C and D). This results revealed that the inhibition of the TMB color reaction was resulted in the reduction of the blue TMBox to colorless TMB again by GSH.

To nd the possible mechanism of the oxidase-like activity of Mn3O4 microspheres, we used BMPO-trapped EPR spectra to detect ROS generated in the catalytic reaction. We speculated that oxidase-like activity of Mn3O4 microspheres might be resulted in the catalytic capacity for activation of O2 to generate ROS.31 As shown in Fig. 5A, the BMPO/\$OH signal with intensity of 1 : 2 : 2 : 1 were observed, demonstrating the generation of \$OH in Mn3O4 system. We also detected the ESR signal of TMBox in Mn3O4 + TMB + BMPO dispersion, which proved that TMB did happen the oxidation reaction (Fig. 5B). While the GSH was added, the single of TMBox disappeared, corresponding to the results of colorimetric reaction. Thus, we speculated that the electrons provided by Mn3O4 microspheres were captured

| Comparison of colorimetric detection of glutathione based on TMB<br>Table 1 |              |          |           |  |  |  |  |
|-----------------------------------------------------------------------------|--------------|----------|-----------|--|--|--|--|
|                                                                             | Linear range | LOD      | Ref.      |  |  |  |  |
|                                                                             |              | 300 nM   | 35        |  |  |  |  |
|                                                                             | 0.26–26 mM   | 100 nM   | 22        |  |  |  |  |
|                                                                             | 0.05–30 mM   | 36 nM    | 27        |  |  |  |  |
|                                                                             | 2–25 mM      | 420 nM   | 36        |  |  |  |  |
|                                                                             | 3–30 mM      | 3 mM     | 37        |  |  |  |  |
|                                                                             | 0.01–0.5 mM  | 2.4 nM   | 2         |  |  |  |  |
|                                                                             | 0.05–20 mM   | 0.016 mM | 38        |  |  |  |  |
|                                                                             | 0.05–8.0 mM  | 0.1 mM   | 39        |  |  |  |  |
|                                                                             | 0.5–10 mM    | 0.06 mM  | 40        |  |  |  |  |
|                                                                             | 5–60 mM      | 0.889 mM | This work |  |  |  |  |
|                                                                             | H2O2 (+/)    | 1–25 mM  |           |  |  |  |  |

Table 2 Recovery test results of GSH in human serum samples

| Paper                                                          |               |            |                  |              | View Article Online<br>RSC Advances |  |  |
|----------------------------------------------------------------|---------------|------------|------------------|--------------|-------------------------------------|--|--|
| Recovery test results of GSH in human serum samples<br>Table 2 |               |            |                  |              |                                     |  |  |
| Samples                                                        | Detected (mM) | Added (mM) | Total found (mM) | Recovery (%) | RSD (%)                             |  |  |
| Serum 1<br>1.13                                                | 1.0           | 2.16  0.13 | 103.07           | 2.24         |                                     |  |  |
|                                                                | 5.0           | 5.99  0.25 | 97.37            | 2.56         |                                     |  |  |
| Serum 2<br>4.40                                                | 1.0           | 5.41  0.18 | 101.39           | 1.92         |                                     |  |  |
|                                                                | 5.0           | 9.13  0.15 | 94.69            | 1.19         |                                     |  |  |
| Serum 2<br>1.63                                                | 1.0           | 2.63  0.17 | 99.72            | 2.76         |                                     |  |  |
|                                                                | 5.0           | 6.90  0.20 | 105.41           | 1.96         |                                     |  |  |
|                                                                |               |            |                  |              |                                     |  |  |

by O2 in the air to generate H2O2. In the Fenton-like reaction, the metal ion provides an electron to H2O2 and produces HOc to further react with the organic compounds. As reported in the previous work,32 the Mn2+ and/or Mn3+ species on the surfaces of Mn3O4 could be converted into Mn4+ species, and the released electrons were trapped by the dissolved O2 in solution to generate H2O2. The H2O2 then created HOc radicals to catalyze the oxidation of substrate. In order to further conrm this result, we investigated the impacts of hypotaurine and catalase (CAT), which specically scavenges HOc radicals33 and H2O2, respectively. Fig. 5C indicated that the oxidase-like activity of Mn3O4 microspheres was retarded in the presence of CAT and hypotaurine, verifying that production of intermediates (H2O2 and HOc). Moreover, the absorbance value at 652 nm of TMB oxidation slight changed in the N2 atmosphere (bubbled with N2 for 30 min), while increased aer saturation with O2 (Fig. 5D). This phenomenon also indicated that the dissolved O2 in the reaction system played a key role in TMB oxidation reaction. Thus, GSH, known as antioxidant,34 could exhaust HOc produced from Mn3O4–O2 system and suppressed the TMB oxidation reaction. Moreover, GSH is also able to reduce the TMBox to TMB again, causing the color of the whole system fade.

According to the above results, a new bio-analysis assay sensor based on the oxidase-like activity of Mn3O4 microspheres could be proposed for the colorimetric detection of GSH. As displayed in Fig. 6, the absorption peak intensity was decreased with the GSH concentration from 0 to 100 mM, observing the color fading of the solution (Fig. 6A). This phenomena veried the possibility of the colorimetric detection of GSH again. Moreover, it was found that the dependency of the absorbance on the GSH concentration could be well presented by the equation of DA ¼ 0.1099 + 0.0191[GSH] (R2 ¼ 0.9908), and the detection limit of GSH was 0.889 mM (S/N ¼ 3). Compared with other reported colorimetric GSH sensors based on TMB (Table 1),35–40 our assay was able to offer comparable performance in terms of limit of detection (LOD) and presented a winder liner range (5–60 mM).

In order to test the specicity of the assay, several common species existed in blood were investigated. As presented in Fig. 7, various amino acids (Cys, Ser, Gly, His, Thr, Try and Arg), biologically relevant metal ions (Na+ , Mg2+, Zn2+, Ca2+ and K+ ), monosaccharides (glucose), ascorbic acid (AA), dopamine (DA), BSA and IgG were checked. The results shown in Fig. 7 indicated that only GSH could induce the obvious inhibition of TMB color reaction, showing the good selectivity of our assay for GSH detection. Furthermore, the practical possibility of the GSH colorimetric method was investigated in human serum samples by the standard addition method, and the recovery studies were also performed, giving recoveries of 94.69–105.41% (Table 2). These results showed that the proposed bio-analysis assay based on the oxidase-like activity of Mn3O4 microspheres had great potential to detect GSH in biological samples accurately and rapidly.

# Conclusions

In this study, we constructed a one-pot reaction based on the oxidase-like activity of Mn3O4 microspheres for highly sensitive and selective detection of GSH. This GSH biosensor required neither natural peroxidase nor H2O2 with good repeatability, and could be nished in 5 min, showing the simple and rapid properties. Importantly, this assay also exhibited good reliability for GSH determination in clinical samples.

# Conflicts of interest

There are no conicts to declare.

# Acknowledgements

This project was funded by the National Natural Science Foundation of China (No. 21703198), the University Natural Science Foundation of Jiangsu Province (16KJD150004). The authors also gratefully acknowledge nancial support from the Priority Academic Program Development of Jiangsu Higher Education Institutions and Top-notch Academic Programs Project of Jiangsu Higher Education Institutions.

## Notes and references

- 1 J. Wu, X. Wang, Q. Wang, Z. Lou, S. Li, Y. Zhu, L. Qin and H. Wei, Chem. Soc. Rev., 2019, 48, 1004.
- 2 X. Yan, Prog. Biochem. Biophys., 2018, 45, 101.
- 3 A. Araki and Y. Sako, J. Chromatogr., 1987, 422, 43.
- 4 Y. He, F. Qi, X. Niu, W. Zhang, X. Zhang and J. Pan, Anal. Chim. Acta, 2018, 1021, 113.
- 5 S. Lin, H. Cheng, Q. Ouyang and H. Wei, Anal. Methods, 2016, 8, 3935.
- 6 S. Lin and H. Wei, Sci. China: Life Sci., 2019, 62, 710.
- 7 Y. Liu, Y. Zheng, D. Ding and R. Guo, Langmuir, 2017, 33, 13811.

- 8 Y. Liu, H. Li, B. Guo, L. Wei, B. Chen and Y. Zhang, Biosens. Bioelectron., 2017, 91, 734. **[View Article Online](https://doi.org/10.1039/c9ra01227c)**
  - 9 Y. Liu, M. Yuan, L. Qiao and R. Guo, Biosens. Bioelectron., 2014, 52, 391.
  - 10 L. Su, J. Feng, X. Zhou, C. Ren, H. Li and X. Chen, Anal. Chem., 2012, 84, 5753.
  - 11 R. Li, M. Zhen, M. Guan, D. Chen, G. Zhang, J. Ge, P. Gong, C. Wang and C. Shu, Biosens. Bioelectron., 2013, 47, 502.
  - 12 Y. Jv, B. Li and R. Cao, Chem. Commun., 2010, 46, 8017.
  - 13 G. Majumdar, M. Goswami, T. K. Sarma, A. Paul and A. Chattopadhyay, Langmuir, 2015, 21, 1663.
  - 14 L. Yin, Y. Wang, G. Pang, Y. Koltypin and A. Gedanken, J. Colloid Interface Sci., 2002, 246, 78.
  - 15 M. Soh, D. W. Kang, H. G. Jeong, D. Kim, D. Y. Kim, W. Yang, S. Baik, I. Y. Choi, S. K. Ki, H. J. Kwon, T. Kim, C. K. Kim, S. H. Lee and T. Hyeon, Angew. Chem., Int. Ed. Engl., 2017, 56, 11399.
  - 16 J. Yao, Y. Cheng, M. Zhou, S. Zhao, S. Lin, X. Wang, J. Wu, S. Li and H. Wei, Chem. Sci., 2018, 9, 2927.
  - 17 N. Singh, M. A. Savanur, S. Srivastava, P. D'Silva and G. Mugesh, Angew. Chem., Int. Ed. Engl., 2017, 56, 14455.
  - 18 O. Baud, A. E. Greene, J. Li, H. Wang, J. J. Volpe and P. A. Rosenberg, J. Neurosci., 2004, 24, 1531.
  - 19 S. A. Zaidi and J. H. Shin, Anal. Methods, 2016, 8, 1745.
  - 20 Q. Zhong, Y. Chen, A. Su and Y. Wang, Sens. Actuators, B, 2018, 273, 1098.
  - 21 P. Ni, Y. Sun, H. Dai, J. Hu, S. Jiang, Y. Wang and Z. Li, Biosens. Bioelectron., 2015, 63, 47.
  - 22 X. Liu, Q. Wang, Y. Zhang, L. Zhang, Y. Su and Y. Lv, New J. Chem., 2013, 37, 2174.
  - 23 X. Li, L. Zhou, J. Gao, H. Miao, H. Zhang and J. Xu, Powder Technol., 2009, 190, 324.

- 24 T. Li, B. Xue, B. Wang, G. Guo, D. Han, Y. Yan and A. Dong, J. Am. Chem. Soc., 2017, 139, 12133.
- 25 J. W. Lee, A. S. Hall, J. D. Kim and T. E. Mallouk, Chem. Mater., 2012, 24, 1158.
- 26 I. L. Chapple, J. Clin. Periodontol., 2005, 24, 287.
- 27 S. Li, L. Wang, X. Zhang, H. Chai and Y. Huang, Sens. Actuators, B, 2018, 264, 312.
- 28 Y. Xu, X. Chen, R. Chai, C. Xing, H. Li and X. B. Yin, Nanoscale, 2016, 8, 13414.
- 29 X. Yan, Y. Song, C. Zhu, J. Song, D. Du, X. Su and Y. Lin, ACS Appl. Mater. Interfaces, 2016, 8, 21990.
- 30 H. S. Jung, X. Chen, J. S. Kim and J. Yoon, Chem. Soc. Rev., 2013, 42, 6019.
- 31 W. He, Y. Liu, J. Yuan, J. J. Yin, X. Wu, X. Hu, K. Zhang, J. Liu, C. Chen, Y. Ji and Y. Guo, Biomaterials, 2011, 32, 1139.
- 32 Z. Weng, J. Li, Y. Weng, M. Feng, Z. Zhuang and Y. Yu, J. Mater. Chem. A, 2017, 5, 15650.
- 33 L. Gao, K. M. Giglio, J. L. Nelson, H. Sondermann and A. J. Travis, Nanoscale, 2014, 6, 2588.
- 34 B. Halliwell, Am. J. Med., 1991, 91, 14S.
- 35 J. Liu, L. Meng, Z. Fei, P. J. Dyson, X. Jing and X. Liu, Biosens. Bioelectron., 2017, 90, 69.
- 36 J. Feng, P. Huang, S. Shi, K. Deng and F. Wu, Anal. Chim. Acta, 2017, 967, 64.
- 37 Y. Ma, Z. Zhang, C. Ren, G. Liu and X. Chen, Analyst, 2011, 137, 485.
- 38 Q. Zhong, Y. Chen, A. Su and Y. Wang, Sens. Actuators, B, 2018, 273, 1098.
- 39 P. Ni, Y. Sun, H. Dai, J. Hu, S. Jiang, Y. Wang and Z. Li, Biosens. Bioelectron., 2015, 63, 47.
- 40 H. Zou, T. Yang, J. Lan and C. Huang, Anal. Methods, 2017, 9, 841.