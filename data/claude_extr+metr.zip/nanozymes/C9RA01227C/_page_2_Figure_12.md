The image contains four panels labeled A, B, C, and D.

Panel A: This panel depicts a chemical reaction scheme. It shows the oxidation of TMB (3,3',5,5'-tetramethylbenzidine) by manganese oxide (MnO2) in the presence of glutathione (GSH). The reaction produces two products: TMBox (oxidized form of TMB) and TMB (reduced form). The arrows indicate the direction of the reaction.

Panel B: This panel shows an absorption spectrum graph. The x-axis represents wavelength in nanometers (nm) ranging from 400 to 800 nm. The y-axis represents absorbance (Abs) ranging from 0 to 1.5. The graph shows a peak at approximately 650 nm with a maximum absorbance of about 1.4. There are two inset images showing color changes, likely corresponding to different states of the reaction.

Panel C: This panel shows another reaction scheme, similar to Panel A. It depicts the reduction of TMBox back to TMB using glutathione (GSH). The reaction consumes 4 molecules of GSH for each molecule of TMBox reduced.

Panel D: This panel shows an absorption spectrum graph similar to Panel B. The axes and scale are identical. The graph shows a peak at the same wavelength (approximately 650 nm) with a similar maximum absorbance of about 1.4. There are also two inset images showing color changes, likely corresponding to different states of the reaction.

SMILES for TMB: CC1=CC(=C(C=C1N)C)N

SMILES for MnO2: [Mn](=O)=O

SMILES for GSH: C(CC(=O)NC(CS)C(=O)NCC(=O)O)C(C(=O)O)N

The image illustrates the redox cycling of TMB mediated by MnO2 and GSH, along with the corresponding absorption spectra and visual color changes of the reaction mixture.