The image contains three parts labeled A, B, and C, each representing different aspects of an experiment involving glutathione (GSH).

A. This part shows a series of nine test tubes containing solutions with varying concentrations of GSH, ranging from 0 to 100 μM. The intensity of the solution's color decreases from left to right, indicating a correlation between GSH concentration and color intensity.

B. This is a graph showing absorption spectra. The x-axis represents wavelength (nm) from 400 to 800 nm, and the y-axis shows absorbance (A). There are multiple overlapping spectra, numbered from 1 to 9. The spectra show a prominent peak around 650-700 nm, with the peak intensity decreasing from spectrum 1 to 9. This suggests a decrease in absorption as the GSH concentration increases.

C. This graph shows a linear relationship between GSH concentration and change in absorbance at 650 nm (ΔA650nm). The x-axis represents GSH concentration (μM) from 0 to 60 μM, while the y-axis shows ΔA650nm from 0 to 1.5. Data points are plotted with error bars, and a linear regression line is fitted to the data. The equation of the line is given as ΔA = 0.1099 + 0.0191[GSH], with an R² value of 0.9908, indicating a strong linear correlation between GSH concentration and change in absorbance.

This image set demonstrates the use of spectrophotometric analysis to quantify GSH concentration, showing both the visual color change and the corresponding spectral data, along with a calibration curve for concentration determination.