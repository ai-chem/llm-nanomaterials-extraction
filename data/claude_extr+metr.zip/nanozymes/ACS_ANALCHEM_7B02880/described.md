<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Subscriber access provided by UNIVERSITY OF THE SUNSHINE COAST

## **Gold-Loaded Nanoporous Ferric Oxide Nanocubes with Peroxidase-Mimicking Activity for Electrocatalytic and Colorimetric Detection of Autoantibody**

Mostafa Kamal Masud, Sharda Yadav, Md Nazmul Islam, Nam-Trung Nguyen, Carlos Salomon, Richard Kline, Hatem R. Alamri, Zeid Abdullah Alothman, Yusuke Yamauchi, Md Shahriar A. Hossain, and Muhammad J. A. Shiddiky

Anal. Chem., **Just Accepted Manuscript** • DOI: 10.1021/acs.analchem.7b02880 • Publication Date (Web): 11 Sep 2017

**Downloaded from http://pubs.acs.org on September 12, 2017**

## **Just Accepted**

"Just Accepted" manuscripts have been peer-reviewed and accepted for publication. They are posted online prior to technical editing, formatting for publication and author proofing. The American Chemical Society provides "Just Accepted" as a free service to the research community to expedite the dissemination of scientific material as soon as possible after acceptance. "Just Accepted" manuscripts appear in full in PDF format accompanied by an HTML abstract. "Just Accepted" manuscripts have been fully peer reviewed, but should not be considered the official version of record. They are accessible to all readers and citable by the Digital Object Identifier (DOI®). "Just Accepted" is an optional service offered to authors. Therefore, the "Just Accepted" Web site may not include all articles that will be published in the journal. After a manuscript is technically edited and formatted, it will be removed from the "Just Accepted" Web site and published as an ASAP article. Note that technical editing may introduce minor changes to the manuscript text and/or graphics which could affect content, and all legal disclaimers and ethical guidelines that apply to the journal pertain. ACS cannot be held responsible for errors or consequences arising from the use of information contained in these "Just Accepted" manuscripts.

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Analytical Chemistry is published by the American Chemical Society. 1155 Sixteenth Street N.W., Washington, DC 20036

Published by American Chemical Society. Copyright © American Chemical Society. However, no copyright claim is made to original U.S. Government works, or works produced by employees of any Commonwealth realm Crown government in the course of their duties.

Article

# **Gold-Loaded Nanoporous Ferric Oxide Nanocubes with Peroxidase-Mimicking Activity for Electrocatalytic and Colorimetric Detection of Autoantibody**

Mostafa Kamal Masud,†,‡ Sharda Yadav, †,§ Md. Nazmul Islam, †,§ Nam-Trung Nguyen, †

Carlos Salomon, ¥,ǂ Richard Kline,ǂ Hatem R. Alamri, Zeid A. Alothman, Yusuke

Yamauchi,*,‡ Md. Shahriar A. Hossain*,‡,|| and Muhammad J. A. Shiddiky*,†,§

†Queensland Micro- and Nanotechnology Centre (QMNC), Griffith University, Nathan, QLD 4111, Australia

‡ Australian Institute for Innovative Materials (AIIM), University of Wollongong, Innovation Campus, North Wollongong, NSW 2519, Australia

§School of Natural Sciences, Griffith University, Nathan, QLD 4111, Australia

Physics Department, Jamoum University College, Umm Al-Qura University, Makkah,

21955, Saudi Arabia

Advanced Materials Research Chair, Chemistry Department, College of Science, King Saud

University, Riyadh 11451, Saudi Arabia

¥Exosome Biology Laboratory, Centre for Clinical Diagnostics, University of Queensland Centre for Clinical Research, Royal Brisbane and Women's Hospital, The University of Queensland, Brisbane QLD 4029, Australia.

ǂMaternal-Fetal Medicine, Department of Obstetrics and Gynecology, Ochsner Clinic Foundation, New Orleans, USA.

||International Center for Materials Nanoarchitectonics (MANA), National Institute for Materials Science (NIMS), 1-1 Namiki, Tsukuba, Ibaraki 305-0044, Japan.

## **ABSTRACT**

Enzyme-mimicking activity of iron oxide based nanostructures have provided a significant advantage in developing advanced molecular sensors for biomedical and environmental applications. Herein, we introduce the horseradish peroxidase (HRP)-like activity of gold loaded nanoporous ferric oxide nanocubes (Au-NPFe2O3NC) for the development of a molecular sensor with enhanced electrocatalytic and colorimetric (naked-eye) detection of autoantibodies. The results showed that Au-NPFe2O3NC exhibits enhanced peroxidase-like activity towards the catalytic oxidation of 3,3ˊ,5,5ˊ-tertamethylbenzidine (TMB) in the presence of H2O2 at room temperature (25°C) and follows the typical Michaelis–Menten kinetics. The autoantibody sensor based on this intrinsic property of Au-NPFe2O3NC resulted excellent detection sensitivity (LOD = 0.08 U/mL) and reproducibility (% RSD = < 5% for *n* = 3) for analysing p53-specific autoantibodies using electrochemical and colorimetric (nakedeye) readouts. The clinical applicability of the sensor has been tested in detecting p53-specific autoantibody in plasma obtained from patients with epithelial ovarian cancer high-grade serous subtype (EOCHGS, number of samples = 2) and controls (benign, number of samples = 2). As Au-NPFe2O3NC possess high peroxidase-like activity for the oxidation of TMB in the presence of H2O2 (TMB is a common chromogenic substrate for HRP in ELISAs), we envisage that our assay could find a wide range of application in developing ELISA based sensing approaches in the field of medicine (*i.e.* detection of other biomarkers same as p53 autoantibody), biotechnology and environmental sciences.

#### 

## **1. Introduction**

Iron oxide (IO) nanostructures have widely been used in a variety of biomedical applications, such as tissue engineering, magnetic resonance imaging, hyperthermia, drug and gene targeting, isolation and separation of proteins or cells from samples, and *in-vivo* cell tracking.1,2 The paramagnetic properties of IO nanoparticles also allows for contactless sample preparation and handling using the emerging technology of micromagnetofluidics.3 In recent years, it has been demonstrated that IO based nanoparticles (NPs) possess an intrinsic horseradish peroxidase (HRP)-mimicking activity towards the oxidation of common chromogenic substances such as 3,3ˊ,5,5ˊ-tertamethylbenzidine (TMB), di-azo-aminobenzene, and *o*phenylenediamine , which have widely been used in catalytic decomposition of hydrogen peroxides or developing non-enzymatic glucose sensors.4,5,6 For instance, peroxidase-like activity of Fe2O3, prussian blue/Fe2O3, graphene/Fe2O3, GO_MNP(Fe3O4)/Pt, ZnFe2O4NPs have extensively been used to develop several high performance biosensors for detecting glucose, H2O2, cancer cells, L-cysteine etc.7,8,9,10,11 Similar to IO based NPs, other nanomaterials such as AuNPs, Eu2O2SNPs, CuONPs, copper–creatinine complex, AgX (X= Cl, Br, I), polyoxometalates, PtNPs, carbon nanotubes and nanodots have also been reported to exhibit peroxidase-like activity.6,12,13,14,15,16,17,18,19 The use of these peroxidase-mimetic nanomaterials for developing biosensors is highly attractive due to several reasons. First, unlike natural peroxidase (i.e., HRP) they are stable towards protease digestion or denaturation, and their structure, morphology and function are not affected by environmental stresses. Second, they are relatively easy and inexpensive to prepare and highly suitable for benchtop storage and handling. Despite these advantages, most of these materials demonstrate their highest peroxidase-like activity at higher temperature (40 – 45 °C), which limits their applications in disease specific biomolecules detection at room temperature. Therefore, design and synthesis of NPs with enhanced peroxidase-mimetics activity at room temperature are highly desirable.

Recently, we have synthesized a new class of gold-loaded superparamagnetic ferric oxide nanocube (Au-NPFe2O3NC). This Au-NPFe2O3NC exhibits multiple functionalities. First, it shows enhanced catalytic activity towards the common electroactive molecules (i.e., hexaammineruthenium(III) chloride, (Ru(NH3)6Cl3)).22 Second, highly porous framework of gold loaded Fe2O3 nanocubes allows for the direct adsorption of large amount of target DNA, RNA or protein *via* gold-DNA/RNA/Proteins affinity interactions.23,24,25,26 Third, as these nanocubes are paramagnetic, they can be used as dispersible capture vehicles to isolate the circulating biomarkers in body fluids (i.e., they can be dispersed into the sample and bind to the analytes of interest).21 As the capture event of the target analytes of interest temporally and spatially separated from the electrochemical measurement, this alleviates biofouling issues of the electrode. The Au-NPFe2O3NC nanocubes also provide a mean to reduce the biological noises associated with adsorption of non-specific species present in the body fluids via magnetic enrichment, separation, and purification steps. Fourth, the Au-NPFe2O3NC nanocubes can also be used as nanoenzymes with enhanced peroxidase-like activity. Although the functionalities of Au-NPFe2O3NC as electrocatalyst and dispersible capture vehicle have already been explored,21,22 the peroxidase-like activity of Au-NPFe2O3NC has yet to be demonstrated. In this paper, we studied this peroxidase-like activity for the development of a proof-of-concept molecular sensor for detecting circulating autoantibodies in serum or plasma samples.

Circulating autoantibodies that are elicited in responses to tumor-associated antigen (TAA) are emerging biomarkers for the early detection of cancer, as they are produced by the patient's immune system long (several months or years) before the onset of the clinical symptoms of diseases. 27,28,29 The direct quantification of TAAs in clinical samples possess severe challenges due to their low abundance and associated difficulties in identifying minor structural modification or mutation. In contrast, serum autoantibodies are relatively more stable

#### **Analytical Chemistry**

(i.e., longer half-lives due to limited proteolysis and clearance) and present as large quantities in clinical samples and therefore they have been used as circulating reporters for the early or pre-clinical detection of various cancers including ovarian, lung, and breast cancer.30,31,32,33,34 It is also important to note that, with the progression of the cancer (stages), the amount of autoantibody (produced) compared to that of TAAs is highly significant and readily detectable with the conventional detection techniques.35

Most of the widely used methods for serum autoantibody detection are mainly based on ELISA or protein arrays that employ HRP conjugated protein specific secondary antibodies to read the target autoantibody.31,32,33,34,35,36,37 These methods are however, expensive, relatively less sensitive and can only provide qualitative or semi-quantitative results. Until recently, the most advanced assay for the sensitive detection of serum autoantibody is that developed by Asensio *et al.*, where HaloTag fusion p53 protein modified commercial magnetic beads (MBs) were used as magnetic microcarriers for capturing the autoantibodies in sera.38 HRP conjugated anti-human IgG was then used to quantify captured autoantibody *via* colorimetry and amperometry. More recently, we have also developed a method using Au-NPFe2O3NC as a dispersible capture agent for autoantibody isolation and detection. Although the analytical performance of these methods are superior, they still rely on HRP-based enzymatic reaction.

Herein, we first studied the peroxidase-like activity of Au-NPFe2O3NC nanocubes towards the catalytic oxidation of TMB in the presence of H2O2. This feature of Au-NPFe2O3NC was then used to develop a molecular sensor for the colorimetric (naked-eye) and electrochemical detection of p53 autoantibody in serum or plasma samples. The method was first tested on the sample obtained from commercial p53 ELISA kit and finally challenged with a small cohort of plasma samples derived from epithelial ovarian cancer high-grade serous subtype (EOCHGS).

## **EXPERIMENTAL SECTION**

**Study group and ovarian cancer samples**. Staged samples (cross sectional) were collected at the Ochsner Baptist Medical Center in the clinical trials and obtained via The UQ Centre for Clinical research. Plasma samples were obtained in accordance with the declaration of Helsinki and approved by the Ethics Committee of The University of Queensland and the Ochsner Medical Center (New Orleans, USA). Plasma was separated from whole blood by centrifugation (2000 g x 10 min at Room temperature) and stored at -80 oC until analyses. Ovarian cancer samples were collected prospectively and assigned according to the hystotypes classification (e.g. stage I, and stage III) and stored to -80 °C in the Biobank units. Only patients with epithelial ovarian cancer high-grade serous subtype (n = 2) and benign controls (n = 2) were included in this study.

**Peroxidase-mimetic activity of Au-NPFe2O3NC.** Unless otherwise stated, the peroxidaselike activity of Au-NPFe2O3NC were carried out at room temperature using 5 µg of Au-NPFe2O3NC in 80 µL of reaction buffer (0.2 M sodium acetate (NaAc), pH 3.5) in the presence of 800 µM freshly prepared TMB (TMB dissolved in DMSO) and 700 mM H2O2. The formation of blue coloured solution was monitored and measured in time scan mode at 652 using a spectrophotometer (SpectraMax). The reaction was quenched by adding 2.0 µL of stop solution. The end point of resultant yellow colour product was measured using colorimetry (at 452 nm) and chronoamperometry. The steady-state kinetic assays were carried out using standard reaction condition (described above) by varying the concentration of H2O2 (0.01 to 1.1 M) at a fixed concentration of TMB (800 µM) and vice versa for the varying the concentration of TMB (0.01 to 1.0 mM) at 700 mM H2O2. The apparent kinetic parameters was calculated by considering a typical enzyme catalytic reaction;

$$\mathbf{E} \rightarrow \mathbf{s} \xrightarrow[\mathbf{k_{-1}}]{\mathbf{k_{-1}}} \mathbf{ES} \xrightarrow[\mathbf{k_{-1}}]{\mathbf{k_{-2}}} \mathbf{E} + \mathbf{P} \quad \dots \dots \dots \dots \text{(l)}$$

where E, S, ES and P represent the enzyme, substrate, enzyme substrate adduct and product respectively. The Michaelis-Menten equation for the catalytic system is expressed as follows,39

$$V_o = \frac{V_{\text{max}}[S]}{K_m + [S]} \dots \dots \dots \dots \text{ (2)}$$

In this equation, *Vo* is the rate of substrate conversion to product, *V*max is the maximum rate of conversion, which is attained when the active (catalytic) sites on the enzyme are saturated with substrate, [S] is the substrate concentration, and *Km* is the Michaelis-Menten constant (denotes the affinity of enzyme for the substrate), which is equivalent to the substrate concentration at the conversion rate is half of *V*max. The rearrangement of Michaelis-Menten equation gives the Lineweaver–Burk equation,40 which was used to determine enzyme kinetics terms *Km* and *V*max.

$$\frac{1}{V_{\
u}} = \frac{K_m}{V_{\text{max}}} \frac{1}{[S]} + \frac{1}{V_{\text{max}}} \dots \dots \dots \dots \dots \text{ (3)}$$

**Colorimetric and amperometric detection of serum p53 autoantibody.** The SPCE-XTR was kept at room temperature for 1 h and washed with PBS. 5.0 μL (100 ng/mL) p53 antigen was incubated onto the electrode surface for 40 min. After the incubation, the electrode surface was washed with PBS three times followed by further incubation with 1% BSA solution (blocking agent) for 15 min. 5.0 μL of diluted serum sample or tested serum sample (1:100 dilution) were then added to the electrode surface and incubated for 1 h to capture the p53 specific autoantibodies present in the sample. After washing away the unbounded or loosely attached serum proteins with PBS, the complex is incubated with 5.0 μL of freshly prepared IgG/Au-NPFe2O3NC for 40 min followed by several PBS wash to remove all unbounded IgG/Au-NPFe2O3NC. Finally, 50 μL of freshly prepared TMB substrate solution (800 µM TMB, 700 mM H2O2 in 0.2 M NaAc buffer, pH-3.5) was added and incubated for 30 min in dark. The color change was visually observed. For quantitative measurements of the amount of oxidized TMB, 2.0 μL of stop solution (2.0 M HCl) was added and absorbance was recorded at 452 nm with the SpectraMax spectrophotometer. For the electrochemical detection, 30 μL of the oxidized TMB solution was pipetted onto another clean SPE-Au, and amperometric response (*i-t*) were measured at 150 mV over 120 s. At least three replicates were measured for each standard/sample. All measurements were performed at room temperature.

## **RESULT AND DISCUSSION**

**Peroxidase-mimetic activity of Au-NPFe2O3NC.** It is now well established that natural peroxidase (HRP) can catalyse the oxidation of TMB in the presence of H2O2. This catalytic reaction generates two coloured products. First, HRP/H2O2 catalysed the oxidation of TMB that produced a blue-coloured charge-transfer complex of parent TMB (diamine) and TMB oxidised product (diimine), which could be used for qualitative (naked-eye) evaluation. Second, this blue-coloured complex turned yellow after the addition of an acid. 4,41 The yellow product is electroactive and stable at acidic pH, thus can be quantified by UV-Vis (semiquantitative, colorimetry) and electrochemical detection methods. We have recently synthesized a novel class of superparamagnetic Au-NPFe2O3NC.21,22 The details characterization data of this material have already been described in references 21 and 22. Briefly, Au-NPFe2O3NC was synthesized by depositing AuNPs on to the nanoporous iron oxide nanocubes (NPFe2O3NCs) derived from Prussian blue (PB) nanocubes.21,22 Bright field TEM and HAADF-STEM images for this materials clearly showed that they possessed highly **Page 9 of 33**

#### **Analytical Chemistry**

porous structure (Figure S1in Supporting Information). SEM images in Figure S2 (Supporting Information) resulted that the Au content is well distributed over the entire particles. The peaks in the wide-angle XRD pattern are assignable to Au, α-Fe2O3, and γ-Fe2O3 (Figure S3in Supporting Information). This material exhibits peroxidase-like activity for the oxidation TMB in the presence of H2O2 at room temperature. Figure 1(a), represents the mechanism of the catalysis of TMB (in presence of H2O2) oxidation reaction by Au-NPFe2O3NC.

To assess peroxidase-mimetics of nanocubes, a set of control experiments were conducted. TMB substrate solution in the presence (positive control) and absence (negative control) of nanocubes was incubated in dark. After 10 min of incubation, positive control sample generated a clear blue coloured solution, while negative control was colourless. Positive control gave an absorbance of 0.96 at 652 nm which is 15-times higher than that of negative control (abs. 0.96 *versus* 0.053) samples (Figure 1b). Addition of 2.0 M HCl into the solution, turned the blue-coloured complex to an electroactive yellow-coloured diimine product. The electrochemical quantification of oxidised product was conducted by placing the reaction mixture onto a screen-printed gold electrode (SPE-Au) *via* of amperometry. Figure 1(c) shows the amperometric signals where positive control generated 86.78 µA cm-2 current density compared to that of negative control (4.59 µA cm-2 ). These experiments (i.e., naked eye observation, colorimetric and amperometric readouts) clearly confirm the peroxidase-like activity of our novel Au-NPFe2O3NC nanocubes. Notably, unlike most of the existing nanomaterials, 7,8,9,10,11,12,13,14,15,16,17,18 which possess the highest peroxidase-like activity at 40 – 45 °C, our Au-NPFe2O3NC nanocubes exhibit relatively enhanced activity at room temperature. The level of peroxidase-like activity of Au-NPFe2O3NC nanocubes at room temperature is sufficient enough to generate approximately 20-times higher response in compare with the negative control sample (Figure 1C). One possible explanation of this enhanced response could be due to (*i*) the large surface of the Au-NPFe2O3NC nanocubes (i.e., highly porous) that facilitates the binding of increased amount of positively charged TMB and hence the TMB/H2O2 reaction, and (ii) the presence of 2% AuNPs in the nanocubes that also catalyse the TMB/H2O2 reaction. In this nanocubes catalysed TMB/H2O2 reaction, ferric ions (from nanocubes) initiate the reaction by generating hydroxyl free radical (.OH) from H2O2 following the Fenton reaction. 42,43TMB is then oxidised by the generated .OH, as shown below

$$Fe^{3+} + H_2O_2 \rightarrow FeOOH^{2+} + H^+ \tag{1}$$

$$FeOOH^{2+} \rightarrow Fe^{2+} + HO_2\cdot \tag{2}$$

$$Fe^{2+} + H_2O_2 \rightarrow Fe^{3+} + OH^- + \cdot OH \tag{3}$$

$$\cdot \cdot OH + TMB \rightarrow TMB_{ox} \left(Blue \right) \tag{4}$$

Similar to HRP, the activity of Au-NPFe2O3NC is also dependent on the solution pH and amount of nanocubes. In order to check the effect of pH, we studied the peroxidase-like activity of nanocubes using different solution pH ranging from 2.5 to 5.5. We observed that with increasing pH of the solution the peroxidase-like activity of Au-NPFe2O3NC decrease (Figure S4a1 in Supporting Information). This is because addition of nanocubes may accelerate the processes (eqn. 1) and (eqn. 2) (see above) and produce excessive amount of *FeOOH* and *HO*2 . At higher pH, *HO*2 can be ionized to O2 - , as shown by equation (eqn. 5).44 The *HO*2 can also instantly react with hydroxyl radicals and produce oxygen (eqn. 6).

$$HO_2. \to H^+ + O_2^- \tag{5}$$

$$
\cdot OH + HO_2 \cdot / O_2^- \to H_2O + O_2 \tag{6}
$$

#### **Analytical Chemistry**

Among all studied pH values, pH 2.5 resulted the highest responses both in colorimetry and amperometric readouts. As the iron could be leached from the nanocubes in the solution pH of <3,7 we selected pH 3.5 as the optimal pH for conducting subsequent experiments in our study. To optimize the amount of nanocubes in our assay, 5 μL of designated concentrations (i.e., 2.5 (0.5 μg/μL), 5 (0.5 μg/μL), 10, (2 μg/μL) and 20 μg (4 μg/μL)) of nanocubes were used. As can be seen in Figure S4b1 (in Supplementary Information); 5, 10 and 20 μg of nanocubes produced almost similar responses both in colorimetry and amperometric readouts, and therefore we chose 5 μg as the optimal nanocube amount for subsequent experiments.

**Steady-State Kinetic for Au-NPFe2O3NC.** To investigate the peroxidase-like activity of nanocubes, apparent steady-state kinetic parameters for TMB oxidation were determined by varying the concentration of H2O2 and TMB (Figure S5 in Supporting Information), a similar phenomenon commonly used for HRP enzymes.2 The experiments were carried out using 5 μg nanocubes in a reaction volume of 60 µL (0.2 M NaAc buffer, pH 3.5) at room temperature. The kinetic parameters were estimated by initial rate method.7,45 The absorbance data were converted to corresponding concentration by the Beer-Lambert Law using the value of ɛ = 39,000 M-1 cm-1 (at 652 nm) for the oxidized product of TMB.46 Typical Michaelis-Mentenlike curve was obtained within the suitable concentration range for both H2O2 (Figure 2a) and TMB (Figure 2b). To obtain the catalytic parameters (Michaelis-Menten constant (*K*m) and maximum velocity (*V*max)), the data were fitted to Michaelis-Menten- kinetic model using a nonlinear least square fitting.39 All kinetic parameters were also calculated from the Lineweaver-Burk double reciprocal plot (1/ velocity [Vo] *versus* 1/substrate concentration [S]) (inset of Figure 2),40 and compared with that for previously reported peroxidase-mimetic nanoparticles (Table S1 in Supporting Information). *K*m is an indicator of enzyme affinity towards its substrate and a lower *K*m indicates the stronger affinity between enzymes and substrates. The apparent *K*m value for Au-NPFe2O3NC with TMB was lower than HRP, suggesting that the nanocubes has higher affinity with TMB in compare to the HRP.4Moreover, *K*m value with both TMB and H2O2 is also higher than that of non-porous Fe3O4 NPs.4 The enhanced peroxidase-activity of our nanocubes at room temperature can be related to the highly porous ferric oxide moiety with high surface area (exposure of more Fe(III) ions) and large pore volume that facilitates the increased mass transfer as well as enhances the kinetics of the reaction. Additionally, as outlined earlier for PB-Fe2O3, nanoporous structure of Au-NPFe2O3NC could be beneficial for increasing electron transfer from the top of the valence bond of Fe2O3 to the lowest unoccupied molecular orbital (LUMO) of H2O2. Moreover, transfer of lone-pairs electron density (charge transfer) from the amino group of TMB to vacant *d*-orbital of Fe3+ may also enhance the electron density and mobility of Au-NPFe2O3NC nanocubes.

**Colorimetric and amperometric detection of autoantibody.** Our assay for the detection of p53-specific autoantibody using peroxidase-mimetic Au-NPFe2O3NC nanocubes is schematically represented in **Figure 3**. Here, p53 antigen was used to selectively recognise and capture the p53-specific autoantibody present in serum and plasma samples. In this proof-ofconcept assay, we have chosen p53 autoantibody, because mutation in TP53 proteins is an early indicator of cancer and also found to be present in almost 80% of all carcinogenesis.34 In response to the expression and mutation of this protein, corresponding amount of p53-tumor antigen-associated autoantibodies (TAAb) are generated, which has been considered as a potential early diagnosis biomarker for ovarian (type-II) cancer.9 In our assay, first, neuravidinmodified screen-printed carbon electrode (SPCE) was modified with biotinylated p53 antigen through standard biotin-avidin chemistry. Bovine serum albumin (BSA) was then used to block the unreacted sites to reduce non-specific bindings of biomolecules followed by the incubation of serum or plasma samples containing target p53 autoantibody. As protein has the strong

#### **Analytical Chemistry**

affinity towards gold surface, we functionalized Au-NPFe2O3NC with α-human IgG with nanocube to form IgG/Au-NPFe2O3NC nanocatalysts. 50,51 These nanocatalysts were then added to the electrode surface to form immunocomplex with the target p53 autoantibody. To achieve the readout signals, the electrode surface was incubated with the freshly prepared TMB/H2O2 solution. The nanocatalysts initiate the oxidation of TMB, thereby producing a blue-coloured charged-transfer complex (one electron). After the addition of stop solution, the blue coloured product was converted to a stable, electroactive yellow coloured (diimine) product. The naked-eye observation of the generation of blue and subsequent yellow colours, demonstrated the presence of p53 positive autoantibody present in analytes. The intensity of the TMBOx is directly linked to the amount of nanocubes as well as amount of p53 autoantibody present onto the electrode surface. Qualitative evaluation was observed by naked-eyes. Colorimetric readout (semi-quantitative) was conducted by measuring absorbance of diimine product at 452 nm. However, the diimine product is electroactive, which allows the further quantification of autoantibody by chronoamperometry.

To evaluate the assay specificity and functionality, we performed our assay in both p53 positive and negative samples. Diluted serum samples from commercial ELISA kit (ELISAkit, Dianova GmbH, Germany) containing p53 autoantibody was used as a positive sample and serum samples without p53 autoantibody was taken as negative sample.52 The p53 autoantibody concentration in diluted human plasma sample is 14 U/mL, where 1.0 U represents the p53 binding activity of 100 µL undiluted calibrator. We found that, positive samples containing 7.0 U/mL (1:1 Dilution) of p53 autoantibody gave an intense blue colour, while stoichiometric amount of negative samples remained colourless. As can be seen in Figure 4a, a 10-times higher absorbance (abs@452 nm) was observed for positive sample compared to that of negative sample (0.616 *versus* 0.0526). Chronoamperometric measurement of positive sample was found to be 16-times higher than that of negative one (36 *versus* 2.116 µA

#### **Analytical Chemistry**

cm-2 ) (Figure 4b). Control experiment without IgG/Au-NPFe2O3NC nanocatalysts gave negligible responses in both absorbance (Abs@452 nm = 0.0526) and subsequent amperometric (1.9 µA cm-2 ) measurements. This can be explained by the fact that in the absence of nanocatalysts, TMB (in presence of H2O2) oxidation reaction does not occur thereby resulting negligible response. In another control experiment, we used only phosphate buffer instead of serum with p53 autoantibody sample. This experiment resulted slightly higher response than that of the control without nanocatalysts (Abs@452 nm. 0.0625 *versus* 0.0526, and current 3.63 *versus* 1.9 µA cm-2 ). This may be due to a level of nonspecific interaction of nanocatalysts with surface attached p53 antigen. All these control experiments clearly demonstrated the good level of specificity of our assay towards the detection of p53 autoantibody from serum samples with negligible background response.

To evaluate the sensitivity of our assay, a series of diluted positive samples obtained *via* serial dilution (1:1 to 1:80; 7 U/mL to 0.0875 U/mL) was tested. We observed an increasing trend in both the absorbance and current response with the increasing concentration of target autoantibody (Figure 4). This is because, the higher amount of target p53 autoantibody could bound an increasing amount of nanocatalysts on the electrode surface which subsequently enhance the nanocatalysts mediated oxidation of TMB (in presence of H2O2) system. As shown in Figure 5a, the colorimetric responses increase linearly with the increasing concentration of serum samples, and the linear regression equation was estimated to be y = 0.04741x – 0.0226, with the correlation coefficient (*r* ) of 0.9684. The detection limit (LOD) was estimated by corresponding signal-to-noise ratio of 2.5,52 and was found to be 0.12 U/mL for the colorimetric readout. On the other hand, the linear regression equation for amperometric readout was estimated as y = 5.201x – 1.4849, with the *r* of 0.9961, confirming the relatively better sensitivity (LOD of 0.08 U/mL, Figure 5b) in compare to the colorimetric readout. A relative standard deviation (%RSD) of three different sensors for both the colorimetric and

#### **Analytical Chemistry**

electrochemical readouts was estimated to be <5.0%, suggesting the good reproducibility of electrode surface modification, isolation of p53 autoantibody from serum samples, incubation of nanocatalysts onto the p53 autoantibody-attached electrode surface and nanocatalysts induced signal transduction protocols. This level of LOD and reproducibility of our colorimetric and electrochemical assay over a wide range of serum concentration clearly demonstrates that the peroxidase-like activity of Au-NPFe2O3NC nanocatalysts is sensitive and specific enough to detect autoantibody in p53 positive serum samples. Moreover, LOD for both readout systems are better than that of the conventional p53-ELISA kit (0.08 versus ~0.3 U/mL).52 These LODs are also better than that of a recently reported Halotag-fusion protein modification based electrochemical platform (0.08 versus 0.34 U/mL).38 Therefore, our methods can detect much lower concentration of p53 autoantibody than above reported methods. It is also important to note that the sensitivity of our recently reported HRP-based method21 is slightly better than that of the current method (i.e., 0.02 versus 0.08 U/mL) than that of the current method. However, our current method avoids the use of expensive HRPbased reaction system.

We further checked the applicability of our novel platform for the analysis of complex human plasma samples. The plasma samples were obtained from women with epithelial ovarian cancer high-grade serous subtype (stage I and III, P3 and P4 respectively) and controls (P1 and P2) (benign). Ovarian cancer in one of the leading causes of cancer-related death of woman from gynaecologic malignancy.9 It has been reported that, in response to the overexpression or mutation of protein (TP53) in ovarian cancers, p53-antigen specific autoantibodies are generated.53 TP53 mutation occurs early in high grade ovarian cancer and strongly attendant with the p53 autoantibodies.35 Thus, development of an early diagnosis platform for ovarian cancers via p53-autoantibody analysis can potentially decrease the disease burden as well as increase the overall survival. In this study, all clinical samples were diluted

#### **Analytical Chemistry**

(1:100) prior performing the assay. As projected, both colorimetric and electrochemical methods response were higher in stage III patients (P4) sample than stage I (P3) (Figure 6). However, the assay can also differentiate the stage I response from the two non-cancerous healthy controls. Both of these healthy controls (P1 and P2) produced negligible signal suggesting the absence of p53 autoantibody. These clinical data showed a very good inter-assay reproducibility (RSD <5%, for *n* = 3) for the analysis of differential expression pattern of p53 autoantibodies in different stages of ovarian cancers.

The naked-eye discrimination of the autoantibodies described here hold huge potential for the development of a user-friendly and inexpensive bioassay in resource-limited settings, where sophisticated scientific equipment is unavailable. In particular, this approach can be exploited as a rapid first-pass screening (yes/no) tool to detect clinically relevant autoantibodies in large population followed by more accurate and sensitive quantification of autoantibody *via* amperometric readout. The use of disposable SPE-Au successfully eliminates the need of a time-consuming electrode cleaning process typically used in conventional disk electrodes. The assay also replaces natural enzymes for TMB oxidation, and thus reduces the cost, handling and storage facilities generally required for natural enzymes. Overall, the assay platform is relatively inexpensive and portable (*i.e*., use of disposable and inexpensive SPE; replaces of relatively expensive HRP; avoids tedious cleaning of conventional disk electrodes). Importantly, the application of this method is not limited to autoantibody detection, it could potentially be applied as an ideal alternative for conventional ELISA assays for the detection of many other clinically relevant protein biomarkers by changing the relevant antibodies in the antibody functionalisation steps of the assay. Taken together these benefits, we expect that this peroxidase-like activity of Au-NPFe2O3NC nanocubes and their subsequent translation to p53 autoantibody detection assay may have wide application in human cancers or chronic disease.

#### 

## **CONCLUSIONS**

We have introduced the peroxidase mimetics of a new class of Au-NPFe2O3NC nanocubes. We have shown that Au-NPFe2O3NC resulted the enhanced peroxidase-like activity and followed the Michaelis-Menten and Lineweaver-Burk models for the enzyme catalysed TMB/H2O2 reaction at room temperature (25 °C). The enhanced peroxidase-like activity was mainly due to the large surface of the Au-NPFe2O3NC nanocubes (i.e., highly porous) that facilitated the binding of increased amount of positively charged TMB and hence the TMB/H2O2 reaction. The presence of 2% AuNPs within the nanocube framework also contributed towards the catalysis of the TMB/H2O2 reaction. This intrinsic feature was further used to develop a new proof-of-concept platform for autoantibody detection body fluids samples using both colorimetric and electrochemical readout. This platform successfully detected the p53 autoantibodies in diluted serum and a small cohort of patients' plasma samples with high sensitivity and specificity.

## **ASSOCIATED CONTENT**

*Supporting Information

The Supporting Information is available free of charge on the ACS Publications website at DOI:

Table S1, detailed experimental section, and Figures S1-S5 (PDF)

## **AUTHOR INFORMATION**

Corresponding Authors

*****Email (M.J.A.S.): [m.shiddiky@griffith.edu.au;](mailto:m.shiddiky@griffith.edu.au)

*Email (M.S.A.H.): [shahriar@uow.edu.au](mailto:shahriar@uow.edu.au)

*****Email (Y.Y.): [yusuke@uow.edu.au](mailto:yusuke@uow.edu.au)

## **Notes**

The authors declare no competing financial interest.

## **ACKNOWLEDGMENT**

This work was supported by the NHMRC CDF (APP1088966) to M.J.A.S.; HDR scholarships to M.K.M., S.Y., M.N.I. from University of Wollongong and Griffith University. Y.Y and Z.A.A. are grateful to the Deanship of Scientific Research, King Saud University for funding through Vice Deanship of Scientific Research Chairs. The authors would like to thank Dr Macs Bio-Pharma Private Limited for preparation of iron oxide samples.

#### 

## **REFERENCES**

- (1) Urbanova, V.; Magro, M.; Gedanken, A.; Baratella, D.; Vianello, F.; Zboril, R. *Chem. Mater.* **2014**, *26*, 6653-6673.
- (2) Pankhurst, Q. A.; Thanh, N. T. K.; Jones, S. K.; Dobson, J. *J. Phys. D: Appl. Phys.* **2009,** *42*, 224001.
- (3) Nguyen, N.T. *Microfluid. Nanofluidics* **2012**, *12*, 1-16.
- (4) Gao, L.; Zhuang, J.; Nie, L.; Zhang, J.; Zhang, Y.; Gu, N.; Wang, T.; Feng, J.; Yang, D.; Perrett, S.; Yan, X. *Nat. Nanotechnol.* **2007**, *2*, 577-583.
- (5) Wei, H.; Wang, E. *Chem. Soc. Rev.* **2013**, *42*, 6060-6093.
- (6) Liu, Y.; Yu, F. *Nanotechnology* **2011**, *22*, 145704.
- (7) Dutta, A. K.; Maji, S. K.; Srivastava, D. N.; Mondal, A.; Biswas, P.; Paul, P.; Adhikary, B. *J. Mol. Catal. A: Chem.* **2012**, *360*, 71-77.
- (8) Xing, Z.; Tian, J.; Asiri, A. M.; Qusti, A. H.; Al-Youbi, A. O.; Sun, X. *Biosens. Bioelectron.* **2014**, *52*, 452-457.
- (9) Pandey, P. C.; Pandey, A. K.; Chauhan, D. S. *Electrochim. Acta.* **2012**, *74*, 23-31.
- (10)Kim, M. I.; Kim, M. S.; Woo, M. A.; Ye, Y.; Kang, K. S.; Lee, J.; Park, H. G. Nanoscale, 2014, 6, 1529-1536.
- (11) Su, L.; Feng, J.; Zhou, X.; Ren, C.; Li, H.; Chen, X. *Anal. Chem.* **2012**, *84*, 5753-5758.
- (12)Ghosh, A. B.; Saha, N.; Sarkar, A.; Dutta, A. K.; Biswas, P.; Nag, K.; Adhikary, B. *New J. Chem.* **2016**, *40*, 1595-1604.
- (13)Chen, W.; Chen, J.; Liu, A. L.; Wang, L. M.; Li, G. W.; Lin, X. H. *ChemCatChem* , *3*, 1151-1154.
- (14)Wang, G. L.; Xu, X. F.; Qiu, L.; Dong, Y. M.; Li, Z. J.; Zhang, C. *ACS Appl. Mater. Interfaces* **2014**, *6*, 6434-6442.

- (15)Kim, M.; Kim, M. S.; Kweon, S. H.; Jeong, S.; Kang, M. H.; Kim, M. I.; Lee, J.; Doh, J. *Adv. Healthc. Mater.* **2015**, *4*, 1311-1316.
  - (16) Song, Y.; Wang, X.; Zhao, C.; Qu, K.; Ren, J.; Qu X. *Chem. Eur. J.* **2010**, *16*, 3617- 3621.
- (17)Cui, R.; Han, Z.; Zhu, J. J. *Chem. Eur. J.* **2011**, *17*, 9377-9384.
- (18) Shi, W.; Wang, Q.; Long, Y.; Cheng, Z.; Chen, S.; Zheng, H.; Huang, Y. *Chem. Commun.* **2011**, *47*, 6695-6697.
- (19)Wang, S., Chen, W., Liu, A. L., Hong, L., Deng, H. H.; Lin, X. H. *ChemPhysChem* **2012**, *13*, 1199-1204.
- (20)Zheng, T.; Zhang, Q.; Feng, S.; Zhu, J. J.; Wang, Q.; Wang, H. *J. Am. Chem. Soc.* **2014**, , 2288-2291.
- (21)Yadav, S.; Masud, M. K.; Islam, M. N.; Gopalan, V.; Lam, A.K.; Tanaka, S.; Nguyen, N.T.; Hossain, M.S.; Li, C.; Yamauchi, Y.; Shiddiky, M. J. *Nanoscale* **2017**, *9*, 8805- 8814.
- (22)Masud, M. K.; Islam, M. N.; Haque, M. H.; Tanaka, S.; Gopalan, V.; Alici, G.; Nguyen, N. T.; Lam, A. K. Y.; Hossain, M. S.; Yamauchi, Y.; Shiddiky, M. J. *Chem. Commun.*  **2017,** *53*, 8231-8234
- (23)Koo, K. M.; Sina, A. A.; Carrascosa, L. G.; Shiddiky, M. J.; Trau, M. *Anal. Methods* **2015**, *7*, 7042-7054.
- (24)Islam, M. N.; Gopalan, V.; Haque, M. H.; Masud, M. K.; Al Hossain, M. S.; Yamauchi, Y.; Nguyen, N.T.; Lam, A .K. Y.; Shiddiky, M. J. *Biosens. Bioelectron.* **2017**, *98*, 227- 233.
- (25)Haque, M. H.; Gopalan, V.; Islam, M. N.; Masud, M. K.; Bhattacharjee, R.; Al Hossain, M. S.; Nguyen, N. T.; Lam, A. K.; Shiddiky, M. J. *Anal. Chim. Acta*, **2017**, *976*, 84-93.

- (26)Hossain, T.; Mahmudunnabi, G.; Masud, M. K.; Islam, M. N.; Ooi, L.; Konstantinov, K.; Al Hossain, M. S.; Martinac, B.; Alici, G.; Nguyen, N. T.; Shiddiky, M. J. *Biosens. Bioelectron.* **2017**, *94*, 63-73.
- (27) Pedersen, J. W.; Gentry-Maharaj, A.; Fourkala, E. O.; Dawnay, A.; Burnell, M.; Zaikin, A.; Pedersen, A. E.; Jacobs, I.; Menon, U.; Wandall, H. H. *Br. J. Cancer* **2013**, *108*, 107-114.
- (28)Barderas, R.; Villar-Vázquez, R.; Fernández-Aceñero, M. J.; Babel, I.; Peláez-García, A.; Torres, S.; Casal, J. I*Sci. Rep.* **2013**, *3*, 2938.
- (29)Cho-Chung, Y. S. Autoantibody Biomarkers in the Detection of Cancer. *BBA-Mol. Basis Dis.* **2006**, *1762*, 587-591.
- (30)Chapman, C.; Murray, A.; Chakrabarti, J.; Thorpe, A.; Woolston, C.; Sahin, U.; Barnes, A.; Robertson, J. *Ann. Oncol.* **2007**, *18*, 868-873.
- (31) Soler, M.; Estevez, M. C.; Villar-Vazquez, R.; Casal, J. I.; Lechuga, L. M. *Anal. Chim. Acta* **2016**, *930*, 31-38.
- (32)Anderson, K. S.; Cramer, D. W.; Sibani, S.; Wallstrom, G.; Wong, J.; Park, J.; Qiu, J.; Vitonis, A.; LaBaer, J. *J. Proteome Res.* **2014**, *14*, 578-586.
- (33)Qiu, J.; Choi, G.; Li, L.; Wang, H.; Pitteri, S. J.; Pereira-Faca, S. R.; Krasnoselsky, A. L.; Randolph, T. W.; Omenn, G. S.; Edelstein, C.; Barnett, M. J. *J. Clin. Oncol.* **2008**, , 5060-5066.
- (34) Soussi T. *Cancer Res.* **2000**, *60*, 1777-1788.
- (35)Katchman, B. A.; Chowell, D.; Wallstrom, G.; Vitonis, A. F.; LaBaer, J.; Cramer, D. W.; Anderson, K. S. *Gynecol. Oncol.* **2017** [(doi.org/10.1016/j.ygyno.2017.04.005)](https://doi.org/10.1016/j.ygyno.2017.04.005).
- (36)Ramachandran, S.; Fu, E.; Lutz, B.; Yager, P. *Analyst* **2014**, *139*, 1456-1462.
- (37)Yan, G.; Xing, D.; Tan, S.; Chen, Q. *J. Immunol. Methods* **2004**, *288*, 47-54.

- (38)Garranzo-Asensio, M.; Guzmán-Aránguez, A.; Povés, C.; Fernández-Aceñero, M. J.; Torrente-Rodríguez, R. M.; Ruiz-Valdepeñas Montiel, V.; Domínguez, G.; Frutos, L. S.; Rodríguez, N.; Villalba, M.; Pingarrón, J. M. *Anal. Chem.* **2016**, *88*, 12339-12345.
- (39)Lehninger, A. L.; Nelson, D. L.; Cox, M. M. Lehninger Principles of Biochemistry, New York, **2005**.
- (40)Lineweaver H.; Burk, D. *J. Am. Chem. Soc.* **1934**, *56*, 658-666.
- (41)Josephy, P. D.; Eling, T.; Mason, R. P. *J. Biol. Chem.* **1982**, *257*, 3669-3675.
- (42)Chen Z.; Yin J. J.; Zhou, Y. T.; Zhang, Y.; Song, L.; Song, M.; Hu, S.; Gu, N. *Acs Nano* , *6*, 4001-4012.
- (43)Dalui, A.; Pradhan, B.; Thupakula, U.; Khan, A. H.; Kumar, G. S.; Ghosh, T.; Satpati, B.; Acharya, S. *Nanoscale* **2015**, *7*, 9062-9074.
- (44)Gurol, M. D.; Lin, S. S. *J. Adv. Oxid. Technol.* **2002**, *5*, 147-154.
- (45)Wei, H.; Wang, E. *Anal. Chem.* **2008**, *80*, 2250-2254.
- (46)Karaseva, E. I.; Losev, Y. P.; Metelitsa, D. I. *Russ. J. Bioorganic Chem.* **2002**, *28*, 128- 135.
- (47) Show, B.; Mukherjee, N.; Mondal, A. *RSC Adv.* **2016**, *6*, 75347-75358.
- (48)Mansour, A. M. *RSC Adv.* **2015**, *5*, 62052-62061.
- (49)Tsai-Turton, M.; Santillan, A.; Lu, D.; Bristow, R. E.; Chan, K. C.; Shih, I. M.; Roden, R.B. *Gynecol. Oncol.* **2009**, *114*, 12-17.
- (50)Lacerda, S. H.; Park, J. J.; Meuse, C.; Pristinski, D.; Becker, M. L.; Karim, A.; Douglas, J. F. *ACS Nano* **2009**, *4*, 365-379.
- (51)Yadav, S.; Carrascosa, L. G.; Sina, A. A.; Shiddiky, M. J.; Hill, M. M.; Trau, M. *Analyst* , *141*, 2356-2361
- (52) p53- Autoantibodies ELISA Plus, Product Description and Data Sheet, Cat. No. DIA 0302I.

D. *Cancer Epidemiol Biomarkers Prev.* **2010**, *19*, 859-868.

**Figure 1.** (a) Schematic illustration of peroxidase-mimicking activity of Au-NPFe2O3NC for the oxidation of TMB in the presence of H2O2. Mean values of (b) absorbance (UV-vis) and (c) amperometric current signals for the negative and positive control samples (inset in (b) and (c) are the corresponding photos for the naked eye evaluation and *i*-*t* curves respectively).

**Figure 2.** Steady-state kinetic analyses using Michaelis-Menten model (main panel) and Lineweaver-Burk model (inset panel) for the Au-NPFe2O3NC nanocubes by varying concentration of (a) H2O2 (0.01 to 1.1 M) and (b) TMB (0.01 to 1.0 mM) with fixed amount of (a) TMB (800 µM) and (b) H2O2 (700 mM).

**Figure 3.** Schematic representation of the assay for the detection of tumor-associated plasma (and serum) p53 auntoantibody. Extravidin modified screen-printed carbon electrode was functionlized with biotinylated p53. Serum/plasma samples containing p53-specific autoantibody was then incubated onto the electrode surface followed by the incubation with IgG/Au-NPFe2O3NC nanocatalysts. The surface attached Au-NPFe2O3NC nanocatalysts catalyzed the oxidation of TMB in the presence of H2O2 and produced a blue-colored complex product (naked-eye), which turned yellow after the addition of an acid to the reaction media. The level of p53 autoantibody was detected *via* measuring the intensity (UV-visible) and amperometric current generated by the yellow product.

**Figure 4.** Mean responses of (a) absorbance and (b) steady-state amperometric current obtained for the assay with one positive (presence of p53 autoantibodies in serum) with three

#### **Analytical Chemistry**

negative control samples (no target represents PBS instead of positive serum; negative control represents serum without p53 autoantibodies; and no secondary antibody represents the no IgG/ Au-NPFe2O3NC. Insets, corresponding photos for the naked eye evaluation and *i*-*t* curves.

**Figure 5.** Concentration dependent curve for p53 autoantibody standards provided in the commercial p53 autoantibody ELISA kit. Mean responses of (a) absorbance and (b) steadystate amperometric currents obtained for the designated concentration of standard samples. Inset shows the corresponding linear regression curves.

**Figure 6.** Mean responses of (a) absorbance and (b) steady-state amperometric current obtained p53-specific autoantibodies present in plasma samples obtained from patients with epithelial ovarian cancer high-grade serous subtype (EOCHGS, P4 = stage III and P3 = stage I) and their non-cancerous healthy patients (benign, P1 and 2).

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image simply contains the text "FIGURES" in large, bold, uppercase letters. It appears to be a header or title for a section of a document, likely introducing a series of figures or illustrations that follow. This type of heading does not convey specific scientific or chemical information in the context of applied chemistry or science, so it falls under the category of an abstract image as per the given instructions.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image contains three parts labeled (a), (b), and (c), describing a chemical reaction and its analysis.

(a) Depicts a chemical reaction mechanism:
1. Starting compound: 3,3',5,5'-tetramethylbenzidine (TMB)
SMILES: CC1=CC(=C(C=C1N)C2=CC(=C(C=C2N)C)C)C
2. Reaction with H2O2 and loss of an electron
3. Formation of a charge-transfer complex
4. Final product: diimine
SMILES: CC1=CC(=C(C=C1N=C2C=C(C(=CC2=N)C)C)C)C

The reaction proceeds from a colorless starting material to a blue charge-transfer complex, and finally to a yellow diimine product.

(b) Shows absorbance measurements at 652 nm for negative and positive nanocube samples:
- Negative sample: low absorbance (approximately 0.05)
- Positive sample: high absorbance (approximately 0.95)
Inset images show test tubes with clear (negative) and blue (positive) solutions.

(c) Displays current density measurements for negative and positive nanocube samples:
- Negative sample: low current density (approximately 5 μA cm^-2)
- Positive sample: high current density (approximately 90 μA cm^-2)
Inset graph shows current density vs. time:
- X-axis: Time (0-120 s)
- Y-axis: Current Density (0-200 μA cm^-2)
- Red line (with nanocube): starts at ~200 μA cm^-2, decreases rapidly, then stabilizes around 80 μA cm^-2
- Black line (without nanocube): remains close to 0 μA cm^-2 throughout

This image illustrates the chemical reaction of TMB and its use in detecting the presence of nanocubes through absorbance and current density measurements.</DESCRIPTION_FROM_IMAGE>

**Figure 1.**

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (a) and (b), both showing enzyme kinetics data.

Graph (a):
Main plot: Velocity (V0) vs H2O2 Concentration (S)
- X-axis: H2O2 Concentration (S) in M, ranging from 0 to 1.2 M
- Y-axis: Velocity (V0) in MS-1, ranging from 0 to 5x10-8 MS-1
- The plot shows a typical Michaelis-Menten kinetics curve, starting near zero and increasing to a plateau around 4.5x10-8 MS-1
- Error bars are present on each data point

Inset plot for (a):
- Shows a linear relationship
- X-axis: 1/S, ranging from 0 to 10
- Y-axis: 1/V0, ranging from 2x107 to 5x107
- This appears to be a Lineweaver-Burk plot

Graph (b):
Main plot: Velocity (V0) vs TMB Concentration (S)
- X-axis: TMB Concentration (S) in M, ranging from 0 to 1.0x10-3 M
- Y-axis: Velocity (V0) in MS-1, ranging from 0 to 5x10-8 MS-1
- The plot shows a similar Michaelis-Menten kinetics curve, plateauing around 4.5x10-8 MS-1
- Error bars are present on each data point

Inset plot for (b):
- Shows a linear relationship
- X-axis: 1/S, ranging from 0 to 9.0x103
- Y-axis: 1/V0, ranging from 2x107 to 1x108
- This appears to be a Lineweaver-Burk plot

Both graphs demonstrate enzyme kinetics for different substrates (H2O2 and TMB) with their respective Michaelis-Menten plots and Lineweaver-Burk linearizations. The main differences are in the concentration ranges of the substrates, with H2O2 being used at much higher concentrations than TMB.</DESCRIPTION_FROM_IMAGE>

**Figure 2.**

<DESCRIPTION_FROM_IMAGE>This image depicts a schematic representation of an immunoassay process for detecting p53 autoantibodies using a neutravidin-modified screen-printed carbon electrode (SPCE) and gold nanoparticle-based signal amplification. The process is illustrated in several steps:

1. A neutravidin-modified SPCE is shown, onto which p53 antigen is immobilized.

2. The p53 antigen binds to neutravidin on the electrode surface.

3. α-p53 autoantibody from plasma is added, which binds to the immobilized p53 antigen.

4. α-human IgG attached to Au-NPFe2O3NC (gold nanoparticles with iron oxide nanocubes) is introduced, binding to the α-p53 autoantibody.

5. After 30 minutes of incubation, a TMB (3,3',5,5'-tetramethylbenzidine) solution is added.

6. The reaction product is then analyzed through three detection methods:
   a. Naked-eye detection: A visual color change is observed.
   b. UV-readout: Using a UV-Vis spectrophotometer for quantitative analysis.
   c. Electrochemical detection: Using the SPCE for amperometric measurements.

7. A graph showing the electrochemical detection results is included, plotting Current Density (μA/cm2) against Time (s). Two curves are shown:
   - Positive (with p53 autoantibody): Starting at about 80 μA/cm2 and decreasing over time.
   - Negative (without p53 autoantibody): Showing a much lower and relatively constant current density.

This immunoassay setup demonstrates a multi-modal approach to detecting p53 autoantibodies, combining visual, spectrophotometric, and electrochemical methods for comprehensive analysis. The use of gold nanoparticles with iron oxide nanocubes (Au-NPFe2O3NC) serves as a signal amplification strategy to enhance detection sensitivity.</DESCRIPTION_FROM_IMAGE>

**Figure 3.**

<DESCRIPTION_FROM_IMAGE>The image contains two parts, labeled (a) and (b), presenting data related to autoantibody detection.

(a) This part shows a bar graph and images of test tubes. The y-axis represents Absorbance (452 nm), ranging from 0 to 0.8. The x-axis shows four categories of Autoantibody: Pos. Control, No Target, Neg. Control, and No Sec. Abs. The bar graph displays the following approximate values:
- Pos. Control: 0.64
- No Target: 0.06
- Neg. Control: 0.05
- No Sec. Abs.: 0.04

Above the graph are images of four test tubes corresponding to each category, showing varying levels of blue coloration, with the Pos. Control tube having the most intense blue color.

(b) This part presents a bar graph and an inset line graph. The main y-axis shows Current Density (μA cm⁻²), ranging from 0 to 40. The x-axis categories are the same as in part (a). The bar graph displays the following approximate values:
- Pos. Control: 37
- No Target: 4
- Neg. Control: 2
- No Sec. Abs.: 1.5

The inset graph shows Current Density (μA cm⁻²) vs Time (s) for 0-120 seconds. It includes four lines:
- Pos. Control: Starting at about 75 μA cm⁻², rapidly decreasing and leveling off around 35 μA cm⁻² by 120 s.
- No Target: Relatively flat line slightly above 0 μA cm⁻².
- Neg. Control: Flat line at approximately 0 μA cm⁻².
- No Sec. Abs: Flat line slightly below 0 μA cm⁻².

Both parts of the image demonstrate a significant difference between the Positive Control and the other three conditions, suggesting successful detection of the target autoantibody.</DESCRIPTION_FROM_IMAGE>

**Figure 4.**

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (a) and (b), both showing the relationship between different dilutions of positive serum and measured parameters.

Graph (a):
- Title: Absorbance (452 nm) vs Dilution of Positive Serum
- X-axis: Dilution of Positive Serum (Cont., 1:80, 1:40, 1:20, 1:10, 1:5, 1:1)
- Y-axis: Absorbance (452 nm), ranging from 0.0 to 0.6
- Bar graph showing increasing absorbance with decreasing dilution
- Inset: Linear regression plot
  - Equation: y = 0.0741x - 0.0226
  - R² = 0.9684

Graph (b):
- Title: Current Density (μA cm⁻²) vs Dilution of Positive Serum
- X-axis: Dilution of Positive Serum (Cont., 1:80, 1:40, 1:20, 1:10, 1:5, 1:1)
- Y-axis: Current Density (μA cm⁻²), ranging from 0 to 40
- Bar graph showing increasing current density with decreasing dilution
- Inset: Linear regression plot
  - Equation: y = 5.201x - 1.4849
  - R² = 0.9961

Both graphs demonstrate a clear trend of increasing measured values (absorbance or current density) as the dilution of positive serum decreases. The control (Cont.) shows the lowest values in both cases. The linear regression plots in the insets indicate strong correlations between the dilution and the measured parameters, with R² values close to 1, suggesting good linearity in the relationships.

The error bars on each data point suggest multiple measurements were taken for each dilution, providing information on the variability of the results.

These graphs likely represent the results of an immunoassay or similar analytical technique, where the concentration of a specific analyte in the serum is being measured using either spectrophotometric (absorbance) or electrochemical (current density) methods.</DESCRIPTION_FROM_IMAGE>

**Figure 5.**

<DESCRIPTION_FROM_IMAGE>The image contains two bar graphs labeled (a) and (b), both showing data for patient samples including a control and four patients labeled P1, P2, P3, and P4.

Graph (a):
Title: Absorbance (452 nm) vs Patient Samples
X-axis: Patient Samples (Control, P1, P2, P3, P4)
Y-axis: Absorbance (452 nm), ranging from 0.00 to 0.20
Results:
- Control: ~0.06
- P1: ~0.07
- P2: ~0.08
- P3: ~0.10
- P4: ~0.19
The graph shows a general increasing trend in absorbance from Control to P4, with P4 having a significantly higher absorbance than the other samples.

Graph (b):
Title: Current Density (μA cm⁻²) vs Patient Samples
X-axis: Patient Samples (Control, P1, P2, P3, P4)
Y-axis: Current Density (μA cm⁻²), ranging from 0 to 20
Results:
- Control: ~4
- P1: ~5
- P2: ~6
- P3: ~13
- P4: ~18
This graph also shows an increasing trend in current density from Control to P4, with a notable jump in values for P3 and P4.

Both graphs include error bars on each data point, indicating the precision of the measurements. The trends in both graphs are similar, suggesting a correlation between absorbance and current density across the patient samples. P4 consistently shows the highest values in both measurements, while the control sample shows the lowest values.</DESCRIPTION_FROM_IMAGE>

**Figure 6.**

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a detection method for p53 autoantibodies using a combination of naked-eye and electrochemical detection techniques. The process is divided into several steps:

1. Immunoassay setup:
   - A Neuravidin-SPCE (Screen-Printed Carbon Electrode) serves as the base.
   - p53-antigen is immobilized on the electrode surface.
   - p53 autoantibody is shown binding to the antigen.
   - IgG/Au-NPFe2O3NC (likely gold-doped iron oxide nanoparticles conjugated with immunoglobulin G) is used as a label.

2. TMB Substrate Solution:
   - A test tube containing a blue solution is shown, representing the TMB (3,3',5,5'-Tetramethylbenzidine) substrate solution.

3. Detection methods:
   a. Naked-eye Detection:
      - Represented by an illustration of a human eye, indicating visual observation of color change.
   
   b. Electrochemical Detection:
      - A graph showing current density (μA cm^-2) vs. Time (s) is presented.
      - Two curves are shown:
        1. "With autoantibody": Starting at approximately 80 μA cm^-2 at 0 s, decreasing rapidly initially and then more gradually, reaching about 40 μA cm^-2 at 120 s.
        2. "Without autoantibody": Starting near 0 μA cm^-2 and remaining close to baseline throughout the 120 s.

The graph demonstrates a significant difference in electrochemical response between samples with and without the p53 autoantibody, indicating the method's ability to detect the presence of the autoantibody.

This image illustrates a dual-detection approach for p53 autoantibodies, combining colorimetric (naked-eye) and electrochemical methods, potentially offering both qualitative and quantitative analysis capabilities.</DESCRIPTION_FROM_IMAGE>

TOC