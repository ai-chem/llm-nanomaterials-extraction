This image depicts a schematic representation of an immunoassay process for detecting p53 autoantibodies using a neutravidin-modified screen-printed carbon electrode (SPCE) and gold nanoparticle-based signal amplification. The process is illustrated in several steps:

1. A neutravidin-modified SPCE is shown, onto which p53 antigen is immobilized.

2. The p53 antigen binds to neutravidin on the electrode surface.

3. α-p53 autoantibody from plasma is added, which binds to the immobilized p53 antigen.

4. α-human IgG attached to Au-NPFe2O3NC (gold nanoparticles with iron oxide nanocubes) is introduced, binding to the α-p53 autoantibody.

5. After 30 minutes of incubation, a TMB (3,3',5,5'-tetramethylbenzidine) solution is added.

6. The reaction product is then analyzed through three detection methods:
   a. Naked-eye detection: A visual color change is observed.
   b. UV-readout: Using a UV-Vis spectrophotometer for quantitative analysis.
   c. Electrochemical detection: Using the SPCE for amperometric measurements.

7. A graph showing the electrochemical detection results is included, plotting Current Density (μA/cm2) against Time (s). Two curves are shown:
   - Positive (with p53 autoantibody): Starting at about 80 μA/cm2 and decreasing over time.
   - Negative (without p53 autoantibody): Showing a much lower and relatively constant current density.

This immunoassay setup demonstrates a multi-modal approach to detecting p53 autoantibodies, combining visual, spectrophotometric, and electrochemical methods for comprehensive analysis. The use of gold nanoparticles with iron oxide nanocubes (Au-NPFe2O3NC) serves as a signal amplification strategy to enhance detection sensitivity.