<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Combining Chemistry and Biology

01/2020

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a decorative or abstract pattern rather than a scientific diagram or chemical structure. It does not contain any specific chemical or scientific information relevant to applied chemistry or scientific analysis. The image shows a repeating geometric pattern of curved lines and circles, which is likely used for aesthetic or design purposes rather than conveying technical information.</DESCRIPTION_FROM_IMAGE>

# **Accepted Article**

**Title:** Size Effect in Pd-Ir Core-Shell Nanoparticles as Nanozymes

**Authors:** Zheng Xi, Weiwei Gao, and Xiaohu Xia

This manuscript has been accepted after peer review and appears as an Accepted Article online prior to editing, proofing, and formal publication of the final Version of Record (VoR). This work is currently citable by using the Digital Object Identifier (DOI) given below. The VoR will be published online in Early View as soon as possible and may be different to this Accepted Article as a result of editing. Readers should obtain the VoR from the journal website shown below when it is published to ensure accuracy of information. The authors are responsible for the content of this Accepted Article.

**To be cited as:** *ChemBioChem* 10.1002/cbic.202000147

**Link to VoR:** https://doi.org/10.1002/cbic.202000147

## **Size Effect in Pd-Ir Core-Shell Nanoparticles as Nanozymes**

Dr. Zheng Xi,[a] Weiwei Gao,[a] and Prof. Dr. Xiaohu Xia*[a,b]

[a]*Department of Chemistry and* [b]*NanoScience Technology Center*, *University of Central Florida, Orlando, Florida 32816, United States* 

* *Corresponding author. E-mail: Xiaohu.Xia@ucf.edu* 

Accepted Manuscript

#### **Abstract**

Comprehensive study on the size effect in nanozyme (i.e., nanomaterial with enzyme-like activities) based catalysis has rarely been reported. In this work, we systematically investigate the size effect in nanozyme using Pd-Ir core-shell nanoparticles with peroxidase-like activities as a model system. Pd-Ir nanoparticles with four different sizes (3.3, 5.9, 9.8 and 13.0 nm), but identical shapes and surface structures, were designed and synthesized. We found the catalytic activity for individual nanozymes increased with particle size. The area-specific catalytic activity was similar for nanoparticles of 3.3-9.8 nm but was slightly decreased when particle size reached to 13.0 nm. Using enzyme-linked immunosorbent assay (ELISA) as a model platform, size effect of Pd-Ir nanoparticles in biosensing applications was investigated, where smaller nanoparticles were found to offer lower detection limits. This work not only demonstrates the size effect, but also provides an effective strategy to enhance the performance of nanozymes in certain applications.

### **Table of Contents**

<DESCRIPTION_FROM_IMAGE>The image consists of two parts:

1. Left side: A high-resolution transmission electron microscopy (TEM) image of a Pd-Ir nanoparticle (NP). The NP appears to have a rhombic or diamond-shaped structure with clear lattice fringes visible, indicating its crystalline nature. The scale bar indicates 2 nm, providing a reference for the particle size. An inset in the top-left corner shows a schematic representation of the Pd-Ir NP structure, with Pd forming the core and Ir on the surface.

2. Right side: A bar graph showing the relationship between the size of Pd-Ir NPs and their limit of detection for a biomarker. The x-axis represents the "Size of Pd-Ir NPs" and the y-axis shows the "Limit of Detection (pg/mL)". Four different NP sizes are presented:

   - 3.3 nm: Limit of detection approximately 3.5 pg/mL
   - 5.9 nm: Limit of detection approximately 5 pg/mL
   - 9.8 nm: Limit of detection approximately 8.5 pg/mL
   - 13.0 nm: Limit of detection approximately 9.5 pg/mL

Each bar includes error bars, likely representing standard deviation or error.

A schematic illustration above the graph depicts the experimental setup, showing a Pd-Ir NP attached to a biomarker on a microtiter plate.

The graph demonstrates that as the size of the Pd-Ir NPs increases, the limit of detection for the biomarker also increases, suggesting that smaller NPs have better detection sensitivity.

This image illustrates the size-dependent performance of Pd-Ir nanoparticles in a biomarker detection assay, combining structural characterization (TEM) with functional analysis (detection limits).</DESCRIPTION_FROM_IMAGE>

**Size matters:** Size effect in nanozyme was studied by using Pd-Ir core-shell nanoparticles of different sizes that possess peroxidase-like properties as a model system. In size range of 3.3- 13.0 nm, the nanoparticles showed size-dependent catalytic activities. Their performance in immunoassay was also found to have a dependence on particle size.

**Keywords:** Nanostructure • size effect • nanozyme • catalytic activity • immunoassay

This article is protected by copyright. All rights reserved.

Accepted Manuscript

Artificial enzymes aiming to mimic the unique catalytic activities of natural enzymes have drawn enormous attention in recent years owning to their higher stabilities, easier storage and lower costs compared with the natural counterparts.[1] Among various kinds of artificial enzymes, nanozymes composed of functional nanomaterials with enzyme-like catalytic activities have emerged as a promising category due to their distinct advantages such as superior tunability for catalytic activity and flexibility for surface functionalization.[2,3] In the niche field of nanozyme research, understanding the roles played by physicochemical parameters of nanozymes is of great interest and significance because it allows one to effectively tune the catalytic activities of nanozymes and thus enhance their performance in various applications.[4-6]

It's well-known that particle size plays a vital role in determining the catalytic activities of nanostructures in conventional catalytic reactions such as electrochemical based oxygen or carbon dioxide reduction reactions,[7,8] thermal based hydrogenation reactions[9] and organic solution-based biomass conversion reactions.[10] For instance, with the change of the nanoparticle size, especially within the range of sub-10 nm, the ratio of surface atoms including face, edge and corner to inner bulk atoms alters dramatically, which therefore significantly changes the catalytic activities.[11-15] Nevertheless, to the best of our knowledge, comprehensive study on the size effect in nanozyme-based catalysis has rarely been reported so far. It should be mentioned that, although various nanozymes of different sizes have been demonstrated in previous work,[16- 19] the impacts of size effect on catalytic efficiencies and applications of nanozymes have not been systematically studied. The major difficulty in comprehensive study of the size effect might be ascribed to the challenge of engineering nanozymes that have different sizes, but the same morphologies and surface properties. In this work, we systematically study the size effect by using Pd-Ir core-shell nanoparticles (NPs) of different sizes as models. The major reasons why we chose to focus on the Pd-Ir NPs are: *i*) sizes of the NPs could be conveniently and precisely controlled in the range of 3.3-13.0 nm by using pre-formed Pd nanoparticles as the seeds;[20] *ii*) all the Pd-Ir NPs have identical shapes and surface structures (e.g., the same capping agents and thickness of Ir shells), which rules out the factors of other physicochemical parameters; *iii*) As demonstrated in our previous studies, the Pd-Ir NPs display highly active peroxidase-like activities along with great stabilities and can be used as sensitive labels for biosensing applications.[21,22] These characters make it straightforward to investigate the size effect in both catalytic activities of nanozymes and their applications.

We started with the synthesis of Pd-Ir NPs. The synthesis was achieved through a two-step, seed-mediated growth method previously published by our group.[21] In the first step, Pd NPs of different sizes as seeds were synthesized in one-pot synthesis. In the second step, the Pd NPs were coated with Ir shells of roughly the same thicknesses (2-3 atomic layers in this study). Taking the synthesis of 5.9 nm Pd-Ir NPs as an example, monodispersed Pd NPs (see Figure S1) were first synthesized. The Pd NPs had a slightly truncated octahedral shape and displayed a great uniformity. The sizes of the Pd NPs (Note, in this study, particle size is defined as the distance between two parallel {111} facets of a truncated octahedron, see Figure S2) was measured to be 4.8 േ 0.6 nm. Then, the Pd NPs were coated with Ir, where an ethylene glycol solution of Na3IrCl6 as Ir precursor was slowly introduced into a mixture containing the 4.8 nm Pd NPs as seeds, L-ascorbic acid as reductant and poly(vinylpyrrolidone) (PVP55000) as stabilizer (see experimental details in Supporting Information, SI). As shown by Figure 1A, the resultant Pd-Ir NPs as products maintained the truncated octahedral shape, implying a conformal coating of Ir on Pd NPs. The sizes of the Pd-Ir NPs was measured to be 5.9 േ 0.7 nm (Figure 1B). The increase of overall particles size of 1.1 nm indicated the Ir shell thickness was about 0.55 nm, corresponding to approximately 2-3 Ir atomic layers.[22] High resolution transmission electron microscopy (HR-TEM) image of representative Pd-Ir NPs (see Figure 1C) clearly showed the continuous lattice fringes along the <111> directions and the smooth surfaces, suggesting Ir was epitaxially grown on Pd seeds and the Pd-Ir NPs were primarily covered by Ir(111) facets. The energy-dispersive X-ray (EDX) mapping image of an individual NP (Figure 1D) confirmed the elemental distributions of Pd core and Ir shell, which is consistent with the characterization data of our previous studies.[21-23] The molar ratio of Ir to Pd for this sample was determined to be about 1:3.5 by using inductively coupled plasma atomic emission spectroscopy (ICP-AES).

Size control of the Pd-Ir NPs can be conveniently achieved by using Pd seeds of different sizes.[20] During the synthesis, the thickness of Ir shells can be tuned by varying the amounts of Pd seeds and Ir precursor (details are provided in the SI). Pd-Ir NPs of 3.3 േ 0.5 nm, 9.8 േ 0.9 nm and 13.0 േ 1.0 nm, respectively (see Figure 2A, 2C and 2E), were synthesized when Pd NPs of 2.3 േ 0.3 nm, 8.7 േ 1.0 nm and 12.1 േ 1.2 nm were used as seeds (Figures S3 to S5). It should be noted that the thickness of Ir shell for all these Pd-Ir NPs was controlled to be roughly the same (*ca.* 0.5 nm), which can be estimated by measuring the increase of particle size after Ir growth.[22] As shown by the HR-TEM images in Figure 2B, 2D and 2F, all the Pd-Ir NPs display

ChemBioChem

Accepted Manuscript

an overall truncated octahedral shape and a continuous lattice fringes along the <111> direction, which was similar to what was observed from the 5.9 nm Pd-Ir NPs. Notably, Ir shells with a darker contrast could be clearly revealed from the HR-TEM images of larger Pd-Ir NPs (see Figure 2D and 2F).

The as-synthesized Pd-Ir NPs of four different sizes were further characterized by X-ray diffraction (XRD). As shown by Figure 3A, Scherrer peak broadening effect was observed with the decrease of particle size.[24] This observation indicates the smaller ordered crystalline domains, which is consistent with the electron microscope results. Using the Scherrer formula, the average crystallite sizes for the Pd-Ir NPs of 13.0, 9.8, 5.9 and 3.3 nm as measured by TEM were estimated to be 7.7, 6.5, 4.4 and 2.9 nm, respectively.[8] A similar trend of particle size reduction was observed from both XRD analysis and TEM imaging. The XRD patterns demonstrated that all the four types of Pd-Ir NPs displayed a face-centered cubic (*fcc*) structure. The diffraction peak at 39.4o can be assigned to the Pd (111), which is consistent with the HR-TEM imaging data.[25] Interestingly, the symmetry of this peak was found to be gradually perturbed with the decrease of particle size. This might be caused by the increased Ir/Pd ratios with the size reduction, given that Ir shell thickness was kept the same for Pd-Ir NPs of different sizes.[26] X-ray photoelectron spectroscopy (XPS) was also applied to characterize the surface properties of the Pd-Ir NPs. Figure 3B shows the survey spectra of the Pd-Ir NPs of four different sizes, from which the peaks for Ir, Pd, C, O and N can be clearly observed. The observations of O 1s, N 1s, and C1s demonstrated that the four types of Pd-Ir NPs were covered by the same capping agent – PVP molecule – on the surface.[27] The high resolution XPS spectra of the Ir 4f and Pd 3d regions (Figure 3C and 3D, respectively) were carefully analysed. The XPS spectra for Ir 4f show the doublet peaks at 60.9 and 63.9 eV that can be assigned to the 4f7/2 and 4f5/2 peaks for Ir(0), suggesting the shells were primarily made of pure metal Ir. Detailed examinations on the peaks confirmed the existence of the oxidation state of Ir, the proportion of which was increased with the reduction of the particle size.[28] The XPS spectra for Pd 3d also showed doublet peaks at 335.5 and 340.8 eV that can be assigned to the 3d5/2 and 3d3/2 peaks for Pd(0).[28] The co-existence of oxidation state of Pd after the peak deconvolution was also observed. Collectively, these four types of Pd-Ir NPs, which have different sizes, but the same Ir(111) facet exposure and capping agent on the surface, could serve as an ideal system to investigate the size effect in nanozyme catalysis.

ChemBioChem

We then evaluated the peroxidase-like activities of the four types of Pd-Ir NPs with the different sizes through the oxidation of 3,3',5,5'-tetramethylbenzidine (TMB, a typical peroxidase substrate[29]) by H2O2 as a model catalytic reaction. To quantify the catalytic activities, apparent steady-state kinetic assay was performed (see details in the SI). By plotting the initial reaction velocities against TMB concentrations, Michaelis−Menten equation curves (Figure S6) were obtained. Afterwards, these curves were fitted to the double-reciprocal linear plots (Figure S7), from which the kinetic parameters for all the four Pd-Ir NPs were derived (see Table S1 for details).[30] The catalytic activity in terms of *K*cat, which is defined as the maximum number of substrate conversions per second per catalyst,[16,21] was summarized in Figure 4A. With the increase of the Pd-Ir NP size from 3.3 nm to 13.0 nm, the catalytic activity *K*cat was continuously increased from 9.4 ൈ 104 to 1.2 ൈ 106 s-1. To better understand the catalytic activities, we also derived and compared the area-specific catalytic activities (*K*cat-specific, which was derived by normalizing *K*cat against the geometric surface area of an individual catalyst[21]) for the Pd-Ir NPs. As shown in Figure 4B, the *K*cat-specific values for Pd-Ir NPs of 3.3, 5.9 and 9.8 nm were similar, but the value was slightly decreased when particle size reached to 13.0 nm. These results suggest that the increased *K*cat for the larger sized Pd-Ir NPs (Figure 4A) is mainly ascribed to the enlarged catalytic surface areas that enable individual NPs to interact with more substrates.

Finally, to demonstrate the size effect of nanozymes in biosensing applications, we applied the Pd-Ir NPs of four different sizes to enzyme-linked immunosorbent assay (ELISA, a widely used *in vitro* diagnostic technique[31]). In this application, Pd-Ir NPs were conjugated with antibodies and specifically catalyse the formation of colored products for quantification.[21] Herein, carcinoembryonic antigen (CEA) as a model disease biomarker is detected.[32] The principle of Pd-Ir NPs based ELISA of CEA was shown in Figure S8. Detailed assay procedures are provided in the SI. For comparison, Pd-Ir NPs of the same weight amount were used in the ELISAs of CEA standards. In the assays, Pd-Ir NPs catalysed reaction was quenched by H2SO4, resulting in the formation of yellow-colored product (*i.e.*, diamine) in 96-well microtiter plates (Figure 5A).[29] The wells were then monitored by a microtiter plate reader at λmax = 450 nm, from which calibration curves for CEA standards were obtained (see Figure 5B). It can be seen that all the four ELISAs using Pd-Ir NPs of different sizes displayed broad linear detection ranges from 10 to 2000 pg/mL. Significantly, the limit of detection (LOD, which was defined by the 3SD

method[33]) for the ELISAs were lowered from 9.3, to 8.2, 4.6, and 3.7 pg/mL when the size of Pd-Ir NPs was reduced from 13.0 to 9.8, 5.9, and 3.3 nm, respectively. In other words, the detection sensitivity of ELISA can be effectively enhanced by reducing the size of Pd-Ir NPs as labels. It is worth noting that this finding has never been reported before. Since smaller Pd-Ir NPs have lower *K*cat but similar *K*cat-specific values compared to larger ones (Figure 4), we assume the enhanced detection sensitivities of smaller Pd-Ir NPs based ELISAs can be ascribed to the capture of a great larger number of Pd-Ir NPs during the detection. This assumption is consistent with previous reports that smaller NPs have greater diffusivities and reduced steric effect that make them easier to bind to analytes *via* the antibody-antigen interaction.[34,35]

In summary, we have investigated size effect in nanozymes by using Pd-Ir NPs of 3.3-13.0 nm in size that possess peroxidase-like activities as a model system. Catalytic activity of individual Pd-Ir NPs increases as particle size increases. Area-specific catalytic activity is similar for Pd-Ir NPs of 3.3-9.8 nm, but is slightly decreased when particle size reached to 13.0 nm. The Pd-Ir NPs show size-dependent performance in ELISA of biomarkers, where smaller Pd-Ir NPs offer higher detection sensitivities. This work demonstrates particle size is an effective knob to tune the catalytic efficiencies of nanozymes and optimize their performance in certain applications.

### **Acknowledgments**

This work was supported by grants from the National Science Foundation (CBET-1804525 and CHE-1834874) and the startup funds from the University of Central Florida (UCF). Z. Xi was partially supported by the UCF Preeminent Postdoctoral Program.

### **Conflict of Interest**

The authors declare no conflict of interest.

#### **References**

- [1] H. Wei, E. Wang, *Chem. Soc. Rev.*, **2013**, *42*, 6060-6093.
- [2] J. Wu, X. Wang, Q. Wang, Z. Lou, S. Li, Y. Zhu, L. Qin, H. Wei, *Chem. Soc. Rev.* **2019**, *48*, 1004-1076.
- [3] R. Das, R. F. Landis, G. Y. Tonga, R. Cao-Milán, D. C. Luther, V. M. Rotello, *ACS Nano*

This article is protected by copyright. All rights reserved.

**2019**, *13*, 229-235.

- [4] H. Ye, Z. Xi, K. Magloire, X. Xia, *ChemNanoMat* **2019**, *5*, 860-868.
- [5] C. Ge, G. Fang, X. Shen, Y. Chong, W. G. Wamer, X. Gao, Z. Chai, C. Chen, J. Yin, *ACS Nano* **2016**, *10*, 10436-10445.
- [6] Z. Xi, X. Cheng, Z. Gao, M. Wang, T. Cai, M. Muzzio, E. Davidson, O. Chen, Y. Jung, S. Sun, Y. Xu, X. Xia, *Nano Lett.* **2020**, *20*, 272-277.
- [7] M. Nesselberger, S. Ashton, J. C. Meier, I. Katsounaros, K. J. J. Mayrhofer, M. Arenz, *J. Am. Chem. Soc.* **2011**, *133*, 17428-17433.
- [8] W. Zhu, R. Michalsky, O. Metin, H. Lv, S. Guo, C. J. Wright, X. Sun, A. A. Peterson, S. Sun, *J. Am. Chem. Soc.* **2013**, *135*, 16833-16836.
- [9] L. Bai, X. Wang, Q. Chen, Y. Ye, H. Zheng, J. Guo, Y. Yin, C. Gao, *Angew. Chem. Int. Ed.* **2016**, *55*, 15656-15661.
- [10] Y. Wang, S. De, N. Yan, *Chem. Commun.* **2016**, *52*, 6210-6224.
- [11] M. Shao, A. Peles, K. Shoemaker, *Nano Lett.* **2011**, *11*, 3714-3719.
- [12] H. Ataee-Esfahani, Y. Nemoto, L. Wang, Y. Yamauchi, *Chem. Commun.* **2011**, *47*, 3885- 3887.
- [13] C. Li, M. Iqbal, B. Jiang, Z. Wang, J. Kim, A. K. Nanjundan, A. E. Whitten, K. Wood, Y. Yamauchi, *Chem. Sci.* **2019**, *10*, 4054-4061.
- [14] C. Li, H. Tan, J. Lin, X. Luo, S. Wang, J. You, Y. Kang, Y. Bando, Y. Yamauchi, J. Kim, *Nano Today* **2018**, *21*, 91-105.
- [15] C. Li, M. Iqbal, J. Lin, X. Luo, B. Jiang, V. Malgras, K. C.-W. Wu, J. Kim, Y. Yamauchi, *Acc. Chem. Res.* **2018**, *51*, 1764-1773.
- [16] L. Gao, J. Zhuang, L. Nie, J. Zhang, Y. Zhang, N. Gu, T. Wang, J. Feng, D. Yang, S. Perrett, X. Yan, *Nat. Nanotechnol.* **2007**, *2*, 577-583.
- [17] A.-L. Hu, H.-H. Deng, X.-Q. Zheng, Y.-Y. Wu, X.-L. Lin, A.-L. Liu, X.-H. Xia, H.-P. Peng, W. Chen, G.-L. Hong, *Biosens. Bioelectron.* **2017**, *97*, 21-25.
- [18] M. Wang, M.-F. Wang, Y.-M. Wang, J.-W. Shen, Z.-Y. Wang, H. Gao, L.-L. Wang, X. Ouyang, *CrystEngComm* **2018**, *20*, 4075-4079.
- [19] Q. W. Shu, C. M. Li, P. F. Gao, M. X. Gao, C. Z. Huang, *RSC Adv.* **2015**, *5*, 17458-17465.
- [20] Y. Wang, A. Biby, Z. Xi, B. Liu, Q. Rao, X. Xia, *ACS Appl. Nano Mater.* **2019**, *2*, 4605-4612.
- [21] X. Xia, J. Zhang, N. Lu, M. J. Kim, K. Ghale, Y. Xu, E. Mckenzie, J. Liu, H. Ye, *ACS Nano*

**2015**, *9*, 9994-10004.

- [22] H. Ye, K. Yang, J. Tao, Y. Liu, Q. Zhang, S. Habibi, Z. Nie, X. Xia, *ACS Nano* **2017**, *11*, 2052-2059.
- [23] X. Xia, L. Figueroa-Cosme, J. Tao, H. Peng, G. Niu, Y. Zhu, Y. Xia, *J. Am. Chem. Soc.* **2014**, *136*, 10878-10881.
- [24] U. Holzwarth, N. Gibson, *Nat. Nanotech.* **2011**, *6*, 534.
- [25] X. Wang, Y. Tang, Y. Gao, T. Lu, *J. Power Sources* **2008**, *175*, 784-788.
- [26] Y. Nakagawa, K. Takada, M. Tamura, K. Tomishige, *ACS Catal.* **2014**, *4*, 2718-2726.
- [27] C. Aliaga, J. Y. Park, Y. Yamada, H. S. Lee, C. Tsung, P. Yang, G. A. Somorjai, *J. Phys. Chem. C* **2009**, *113*, 6150-6155.
- [28] J. Zhu, Z. Lyu, Z. Chen, M. Xie, M. Chi, W. Jin, Y. Xia, *Chem. Mater.* **2019**, *31*, 5867-5875.
- [29] P. D. Josephy, T. E. Eling, R. P. Mason, *J. Biol. Chem.* **1982**, *257*, 3669-3675.
- [30] H. Lineweaver, D. Burk, *J. Am. Chem. Soc.* **1934**, *56*, 658-666.
- [31] R. M. Lequin, *Clin. Chem.* **2005**, *51*, 2415-2418.
- [32] S.Benchimol, A. Fuks, S. Jothy, N. Beauchemin, K. Shirota, C. P. Stanners, *Cell*, **1989**, *57*, 327-334.
- [33] D. A. Armbruster, M. D. Tillman, L. M. Hubbs, *Clin. Chem.* **1994**, *40*, 1233-1238.
- [34] C. N. Loynachan, M. R. Thomas, E. R. Gray, D. A. Richards, J. Kim, B. S. Miller, J. C. Brookes, S. Agarwal, V. Chudasama, R. A. McKendry, M. M. Stevens, *ACS Nano* **2018**, *12*, 279-288.
- [35] L. Zhan, S. Guo, F. Song, Y. Gong, F. Xu, D. R. Boulware, M. C. McAlpine, W. C. W. Chan, J. C. Bischof, *Nano Lett.* **2017**, *17*, 7207-7212.

<DESCRIPTION_FROM_IMAGE>This image is a composite of four panels labeled A, B, C, and D, each providing different information about nanoparticles.

Panel A: Transmission Electron Microscopy (TEM) image showing a distribution of nanoparticles. The scale bar indicates 20 nm. The particles appear to be relatively uniform in size and shape, dispersed across the field of view.

Panel B: Size distribution histogram of the nanoparticles. The x-axis shows the size in nanometers, ranging from 4 to 8 nm. The y-axis represents frequency. The distribution appears to be roughly normal, with the peak frequency occurring around 6 nm. The histogram bars are red and white striped, overlaid with a gray curve representing the normal distribution.

Panel C: High-resolution TEM image of individual nanoparticles. The scale bar indicates 2 nm. Lattice fringes are visible, indicating crystallinity. Four measurements of lattice spacing are shown, all indicating 0.22 nm, which corresponds to the (111) plane of face-centered cubic (fcc) metals.

Panel D: Energy-dispersive X-ray spectroscopy (EDS) elemental mapping of a single nanoparticle. The panel is divided into four sub-images:
1. Top-left: High-angle annular dark-field (HAADF) image of a single particle, scale bar 2 nm.
2. Top-right: Palladium (Pd) distribution map, showing Pd throughout the particle.
3. Bottom-left: Iridium (Ir) distribution map, showing Ir primarily at the particle's periphery.
4. Bottom-right: Overlay of Pd and Ir maps, confirming a core-shell structure with Pd core and Ir shell.

This composite image provides comprehensive characterization of Pd-Ir core-shell nanoparticles, including their size distribution, crystalline structure, and elemental composition.</DESCRIPTION_FROM_IMAGE>

**Figure 1.** Characterizations of 5.9 nm Pd-Ir NPs. (A) TEM image. (B) Size distribution. (C) HR-TEM image. (D) EDX mapping image of an individual particle.

<DESCRIPTION_FROM_IMAGE>The image consists of six panels labeled A through F, showing transmission electron microscopy (TEM) images and size distribution histograms of nanoparticles.

Panel A: TEM image of small nanoparticles with a scale bar of 20 nm. Inset shows a size distribution histogram with particle sizes ranging from approximately 2 to 5 nm, peaking around 3.5 nm.

Panel B: High-resolution TEM image with a scale bar of 2 nm, showing lattice fringes of a nanoparticle. The lattice spacing is measured as 0.22 nm.

Panel C: TEM image of larger nanoparticles with a scale bar of 20 nm. Inset shows a size distribution histogram with particle sizes ranging from approximately 6 to 14 nm, peaking around 9-10 nm.

Panel D: High-resolution TEM image with a scale bar of 2 nm, showing a single nanoparticle with clear lattice fringes. The lattice spacing is measured as 0.22 nm, and the particle size is approximately 5 nm.

Panel E: TEM image of nanoparticles with a scale bar of 20 nm. Inset shows a size distribution histogram with particle sizes ranging from approximately 10 to 16 nm, peaking around 12-13 nm.

Panel F: High-resolution TEM image with a scale bar of 2 nm, showing a single nanoparticle with clear lattice fringes. The lattice spacing is measured as 0.22 nm, and the particle size is approximately 7 nm.

The consistent lattice spacing of 0.22 nm observed in panels B, D, and F suggests that these nanoparticles likely have the same crystal structure, despite their different sizes. The progression from panels A to C to E shows an increase in average particle size, indicating different synthesis conditions or growth stages of the nanoparticles.</DESCRIPTION_FROM_IMAGE>

**Figure 2.** TEM and HR-TEM images of Pd-Ir NPs of three different sizes. (A, B) 3.3 nm Pd-Ir NPs. (C, D) 9.8 nm Pd-Ir NPs. (E, F) 13.0 nm Pd-Ir NPs. The insets in (A, C, E) show the corresponding size distributions of the nanoparticles.

This article is protected by copyright. All rights reserved.

<DESCRIPTION_FROM_IMAGE>This image contains four panels (A, B, C, and D) showing different analytical results for nanoparticles of varying sizes (13.0 nm, 9.8 nm, 5.9 nm, and 3.3 nm).

Panel A: X-ray diffraction (XRD) patterns
- Shows intensity vs. 2θ (degree) from 30° to 90°
- Peaks labeled with Miller indices: (111), (200), (220), (311), (222)
- Two reference patterns: Pd (87-643) and Ir (46-1044)
- Intensity of peaks increases with particle size
- (111) peak is the most prominent for all sizes

Panel B: X-ray photoelectron spectroscopy (XPS) survey spectra
- Shows intensity vs. binding energy (eV) from 0 to 1200 eV
- Peaks labeled: Ir 4f, Pd 3d, C 1s, N 1s, O 1s
- Intensity of peaks increases with particle size
- Ir and Pd peaks are the most prominent

Panel C: High-resolution XPS spectra of Ir 4f region
- Shows intensity vs. binding energy (eV) from 58 to 72 eV
- Two peaks visible for each particle size: 4f7/2 and 4f5/2
- Peak intensity and definition increase with particle size
- Peaks shift slightly to higher binding energies as size decreases

Panel D: High-resolution XPS spectra of Pd 3d region
- Shows intensity vs. binding energy (eV) from 330 to 346 eV
- Two peaks visible for each particle size: 3d5/2 and 3d3/2
- Peak intensity and definition increase with particle size
- Peaks shift slightly to higher binding energies as size decreases

The image demonstrates the size-dependent properties of Ir-Pd nanoparticles, showing how their crystalline structure and electronic properties change with particle size. The analysis techniques used (XRD and XPS) provide complementary information about the particles' structure and composition.</DESCRIPTION_FROM_IMAGE>

**Figure 3.** (A) XRD, (B) XPS survey spectra, (C) XPS 4f spectra, and (D) XPS 3d spectra recorded from Pd-Ir NPs of four different sizes. In (C) and (D), peaks of darker colors indicate metallic states and peaks of lighter colors indicate oxidation states. Particle sizes of Pd-Ir NPs were labeled on the spectra.

<DESCRIPTION_FROM_IMAGE>The image contains two bar graphs labeled A and B, both showing data related to the size of Pd-Ir NPs (Palladium-Iridium Nanoparticles) and their catalytic properties.

Graph A:
Title: Not explicitly stated, but shows Kcat values
X-axis: Size of Pd-Ir NPs (nm)
Y-axis: Kcat (×10⁴ s⁻¹)
Data points:
- 3.3 nm: ~10 ×10⁴ s⁻¹
- 5.9 nm: ~35 ×10⁴ s⁻¹
- 9.8 nm: ~95 ×10⁴ s⁻¹
- 13.0 nm: ~120 ×10⁴ s⁻¹

The graph shows a clear increasing trend in Kcat values as the size of Pd-Ir NPs increases.

Graph B:
Title: Not explicitly stated, but shows Kcat_specific values
X-axis: Size of Pd-Ir NPs (nm)
Y-axis: Kcat_specific (×10⁻³ s⁻¹ nm⁻²)
Data points:
- 3.3 nm: ~1.9 ×10⁻³ s⁻¹ nm⁻²
- 5.9 nm: ~2.2 ×10⁻³ s⁻¹ nm⁻²
- 9.8 nm: ~2.3 ×10⁻³ s⁻¹ nm⁻²
- 13.0 nm: ~1.6 ×10⁻³ s⁻¹ nm⁻²

This graph shows a slight increase in Kcat_specific values from 3.3 nm to 9.8 nm, followed by a decrease at 13.0 nm.

Both graphs include error bars for each data point. Above each bar in both graphs, there is a schematic representation of the nanoparticle structure, increasing in size from left to right.

The graphs demonstrate the relationship between the size of Pd-Ir nanoparticles and their catalytic activity, both in terms of absolute catalytic rate (Kcat) and specific catalytic rate normalized by surface area (Kcat_specific).</DESCRIPTION_FROM_IMAGE>

**Figure 4.** Histograms comparing (A) *K*cat and (B) *K*cat-specific values of Pd-Ir NPs of four different sizes. Error bars indicate the standard deviations of three independent measurements.

<DESCRIPTION_FROM_IMAGE>The image consists of two parts, labeled A and B.

Part A:
This section shows four rows of small circular wells, each row containing 12 wells. The rows are labeled with different nanoparticle sizes: 3.3 nm, 5.9 nm, 9.8 nm, and 13.0 nm. The x-axis is labeled "CEA Concentration (pg/mL)" with values ranging from 0 to 2K (2000). The wells show a gradual color change from left to right, indicating an increase in concentration or reaction intensity.

Part B:
This is a logarithmic plot showing the relationship between CEA (Carcinoembryonic Antigen) concentration and absorbance at 450 nm for different nanoparticle sizes.

X-axis: CEA Concentration (pg/mL), logarithmic scale from 1 to 10^4
Y-axis: Absorbance at 450 nm (a.u.), logarithmic scale from 0.01 to 10

The plot contains four curves corresponding to different nanoparticle sizes:
- 3.3 nm (blue squares)
- 5.9 nm (green squares)
- 9.8 nm (orange squares)
- 13.0 nm (red squares)

Each curve shows a sigmoidal shape characteristic of dose-response relationships.

Equations for each curve are provided:
- 3.3 nm: lgy = 0.46lgx - 1.41
- 5.9 nm: lgy = 0.45lgx - 1.42
- 9.8 nm: lgy = 0.51lgx - 1.61
- 13.0 nm: lgy = 0.50lgx - 1.71

Limit of Detection (LOD) values are given for each nanoparticle size:
- 3.3 nm: LOD = 3.7 pg/mL
- 5.9 nm: LOD = 4.6 pg/mL
- 9.8 nm: LOD = 8.2 pg/mL
- 13.0 nm: LOD = 9.3 pg/mL

The plot demonstrates that smaller nanoparticle sizes generally result in lower LOD values and higher sensitivity for CEA detection.</DESCRIPTION_FROM_IMAGE>

**Figure 5.** Pd-Ir NPs based ELISA of carcinoembryonic antigen (CEA), where Pd-Ir NPs of four different sizes were used as labels. (A) Representative photographs taken from the ELISAs of CEA standards. (B) Corresponding calibration curves and the linear ranges (inset) of the assay results shown in (A). LOD: limit of detection. Error bars indicate the standard deviations of eight independent measurements.