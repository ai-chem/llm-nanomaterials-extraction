The image contains two graphs labeled 'a' and 'b', both showing the relationship between reaction velocity and substrate concentration.

Graph a:
- X-axis: Substrate concentration in μM, ranging from 0.0 to 3.0 μM
- Y-axis: Reaction velocity, ranging from 0.000 to 0.085
- The graph shows a typical Michaelis-Menten kinetics curve
- Data points are represented by small squares
- The curve rises sharply initially, then begins to level off around 1.5 μM substrate concentration
- The curve appears to approach a maximum reaction velocity of approximately 0.080

Graph b:
- X-axis: Substrate concentration in μM, ranging from 0 to 900 μM
- Y-axis: Reaction velocity, ranging from 0.000 to 0.130
- This graph also shows Michaelis-Menten kinetics, but over a much wider range of substrate concentrations
- Data points are represented by small circles and crosses
- The curve rises sharply up to about 360 μM substrate concentration, then begins to level off
- The curve appears to approach a maximum reaction velocity of approximately 0.120

Both graphs demonstrate enzyme kinetics, showing how reaction velocity increases with substrate concentration until it reaches a maximum rate (Vmax) where the enzyme is saturated. Graph 'b' shows this relationship over a much wider range of substrate concentrations than graph 'a'.