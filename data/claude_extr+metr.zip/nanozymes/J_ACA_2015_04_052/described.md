Contents lists available at [ScienceDirect](http://www.sciencedirect.com/science/journal/00032670)

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be the logo of Elsevier, a major academic publishing company. While it contains stylized imagery, it does not convey specific scientific or chemical information relevant to the context of applied chemistry or scientific research. The logo itself is not a chemical structure, graph, or diagram that requires technical interpretation.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image appears to be the cover of a scientific journal titled "Analytica Chimica Acta". The cover features a composite image related to analytical chemistry:

1. A laboratory balance or scale is depicted, suggesting precise measurements.

2. A sample of what appears to be a granular or powdered substance is shown, likely representing a chemical sample for analysis.

3. A molecular structure diagram is included, indicating the journal's focus on chemical analysis at the molecular level.

The journal cover also includes standard publication information such as volume number, issue details, and publisher logo (Elsevier).

This image represents the scope of the journal, which likely covers various aspects of analytical chemistry including instrumentation, sample preparation, and molecular analysis techniques. The combination of elements suggests a focus on precise quantitative and qualitative chemical analysis methods.

While this image doesn't contain specific scientific data to interpret or chemical structures to convert to SMILES format, it effectively communicates the journal's subject matter and relevance to analytical chemistry.</DESCRIPTION_FROM_IMAGE>

# Analytica Chimica Acta

journal homepage: <www.elsevier.com/locate/aca>

# Evaluation of the oxidase like activity of nanoceria and its application in colorimetric assays

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

#### Akhtar Hayata,b , Jessica Cunninghama , Gonca Bulbula , Silvana Andreescua, *

aDepartment of Chemistry and Biomolecular Science, Clarkson University, Potsdam, NY, USA b Interdisciplinary Research Centre in Biomedical Materials (IRCBM), COMSATS Institute of Information Technology (CIIT), Lahore, Pakistan

# H I G H L I G H T S G R A P H I C A L A B S T R A C T

- The oxidase mimetic properties of nanoceria against phenolics are demonstrated.
- Colorimetric detection using a nanoceria assay is demonstrated.
- Detection limits were determined for catechol and dopamine.
- Recommendations on the selection of the particle system were provided.

# A R T I C L E I N F O

Article history: Received 25 January 2015 Received in revised form 16 April 2015 Accepted 23 April 2015 Available online 5 June 2015

Keywords: Nanoceria particles Oxidase mimic Dopamine Catechol Colorimetric assay

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a chemical reaction and its corresponding spectroscopic analysis. The diagram consists of three main components:

1. Reaction Scheme:
   - Two beakers are shown: one containing "ox Dopamine or Catechol" (oxidized form) and another containing "Dopamine or Catechol" (reduced form).
   - Arrows indicate a reversible reaction between these two forms.
   - The oxidation process is associated with the formation of Ce3+ ions (represented as red spheres).
   - The reduction process is associated with Ce4+ ions (represented as yellow spheres).

2. Chemical Structures:
   - Dopamine SMILES: C(CCN)c1ccc(O)c(O)c1
   - Catechol SMILES: c1ccc(O)c(O)c1
   - Note: The image doesn't show the full structures, so both possibilities are provided.

3. Spectroscopic Analysis:
   - A graph is presented showing absorbance vs. wavelength.
   - X-axis: Wavelength (nm), ranging from approximately 400 to 800 nm.
   - Y-axis: Absorbance, ranging from 0 to 0.5.
   - Two curves are shown:
     a. "Test" curve (red): Shows a peak around 500-550 nm with maximum absorbance of about 0.45, then decreases towards longer wavelengths.
     b. "Control" curve (purple): Shows consistently low absorbance (close to 0) across all wavelengths.

This image illustrates the redox reaction of dopamine or catechol, likely catalyzed by cerium ions, and the corresponding spectroscopic changes observed during the reaction. The "Test" curve likely represents the oxidized form, while the "Control" curve represents the reduced form or a blank sample.</DESCRIPTION_FROM_IMAGE>

# A B S T R A C T

Nanomaterial-based enzyme mimics have attracted considerable interest in chemical analysis as alternative catalysts to natural enzymes. However, the conditions in which such particles can replace biological catalysts and their selectivity and reactivity profiles are not well defined. This work explored the oxidase like properties of nanoceria particles in the development of colorimetric assays for the detection of dopamine and catechol. Selectivity of the system with respect to several phenolic compounds, the effect of interferences and real sample analysis are discussed. The conditions of use such as buffer composition, selectivity, pH, reaction time and particle type are defined. Detection limits of 1.5 and 0.2mM were obtained with nanoceria for dopamine and catechol. The same assay could be used as a general sensing platform for the detection of other phenolics. However, the sensitivity of the method varies significantly with the particle type, buffer composition, pH and with the structure of the phenolic compound. The results demonstrate that nanoceria particles can be used for the development of cost effective and sensitive methods for the detection of these compounds. However, the selection of the particle system and experimental conditions is critical for achieving high sensitivity. Recommendations are provided on the selection of the particle system and reaction conditions to maximize the oxidase like activity of nanoceria.

ã2015 Elsevier B.V. All rights reserved.

# 1. Introduction

Natural enzymes have been extensively studied, due to their high enzyme substrate specificity and improved efficiency under mild conditions [\[1\]](#page-7-0). They play vital roles in medicine, chemical

E-mail address: [eandrees@clarkson.edu](mailto:eandrees@clarkson.edu) (S. Andreescu).

industry, and agriculture fields. All natural enzymes are proteins except for some catalytic RNA molecules, and are therefore subjected to several intrinsic drawbacks. For example, they can be digested by protease, and can degrade upon exposure to variable environmental conditions. Other disadvantages include a time consuming preparation and purification process, a relatively high cost and the need for specific storage conditions [\[2\]](#page-7-0). Therefore, significant interest has been shown for exploration of new and efficient enzyme mimetics. Some level of success has been

<sup>*</sup> Corresponding author. Fax: +1 3152686610.

<http://dx.doi.org/10.1016/j.aca.2015.04.052> 0003-2670/ã 2015 Elsevier B.V. All rights reserved.

achieved in this direction with the help of chemically synthesized alternatives [\[3\]](#page-7-0). Among enzyme mimetics, non-natural ribosomes and deoxyribosomes have been developed through in vitro selection processes [\[4\]](#page-7-0). Other enzyme mimetics including cytochrome P450 mimetic [\[5\]](#page-7-0), serine proteases mimetics [\[6\]](#page-7-0), dioxygenase [\[7\]](#page-7-0), phosphodiesterase [\[8\]](#page-7-0), ligase [\[9\]](#page-7-0), nuclease [\[10\]](#page-7-0) and methanogenesis [\[11\]](#page-7-0) have been explored.

Recently, inorganic nanomaterials mimicking traditional biological catalysts have received significant interest for their potential application as artificial enzymes [\[12,13\]](#page-7-0). Their high surface to volume ratio, catalytic activity and abundance of reactive groups on their surface makes these materials powerful candidates as alternatives to biological catalysts. Several types of engineered nanoparticles (NPs) have shown 'enzyme-like' activity, mostly as oxidase, peroxidase and catalase mimetics. Some of these have been used as active materials in bioassays, biotechnology and in the biomedical field [\[12,14,15\]](#page-7-0). NP-based enzyme mimetics offer advantages in terms of cost, stability, ease of production and tenability of catalytic activity. Examples of NP systems with enzyme like activityinclude:nano-gold[\[16\]](#page-7-0),ferromagneticmaterials suchas Fe3O4 [\[17\]](#page-7-0), Co3O4 [\[18\]](#page-7-0), sheet like-FeS nanostructures, CeO2 [\[19\]](#page-7-0), AgM (silver supported metallic nanoparticles), mesoporous silica encapsulated Pt [\[13\]](#page-7-0) and metallic NPs supported graphene oxide [\[12,20\].](#page-7-0) Implementation of these materials in analytical and bioanalytical platforms could rouse development of a new generation of devices with significantly enhanced performances in stability and robustness compared to their enzyme counterparts. However, the conditions in which biomimetic NPs can replace enzymes, their kinetic features and reactivity profiles are highly variable among different types of particles and are generally poorly defined. Whether these NP systems can truly replace natural enzymes and provide the same level of sensitivity and selectivity in analytical assays requires better understanding of their reactivity. It is known thatthe size, shape, concentrationanddispersionmediumoftheNPs have a significant effect on their reactivity. For example, the peroxidase mimetic activity of rod type Fe3O4 dominated over the spheres that were much smaller in size [\[21\]](#page-7-0). In order for analytical assays based on biomimetic NPs to be developed, it is essential to understand how NP type and environmental conditions affect their reactivity.

In this paper, we provide a comparative investigation of the oxidase mimetic activity of cerium oxide NPs (nanoceria) and define conditions of use (buffer composition, pH and reaction time) in the design of analytical assays for the detection of phenolic compounds. We compare the kinetic and analytical performance of this particle system versus a model oxidase enzyme, tyrosinase that is commonly used in bioanalytical assays for the detection of these substrates [\[22](#page-7-0)–25]. Nanoceria is a redox active inorganic catalyst possessing two oxidation states (Ce3+/Ce4+) and has a highly mobile lattice oxygen located on its surface which facilitates the interchangeable conversion of Ce4+ and Ce3+ [\[26\]](#page-7-0). Its unique chemical and electronic configuration confers interesting catalytic and optical properties [\[27\]](#page-7-0). These particles have been reported to exhibit catalase and superoxide dismutase like activity [\[19\]](#page-7-0) and have been used for neurodegenerative disease therapy [\[28](#page-7-0)–30]. The use of nanoceria particles as a superoxide scavenger [\[31\]](#page-7-0), protector against photoreceptor degeneration [\[32\]](#page-7-0), and for the healing of dermal wounds [\[33\]](#page-7-0) has also been demonstrated. Additionally, they have been used as color indicators and as oxygen sources in oxidase enzyme assays for the detection of glucose [\[34\]](#page-7-0), dopamine and glutamate [\[35\]](#page-7-0). The comparative study reported in this work provides a correlation between the oxidase mimetic activity, the particle size and buffer composition of the NPs that is essential for their future use in analytical assays. It also establishes the optimal pH range, ionic strength, kinetic parameters and analytical performance metrics of the nanoceria based method.

# 2. Experimental

# 2.1. Chemicals and biochemicals

Cerium oxide(IV), 20 wt.% colloidal dispersion in 2.5% acetic acid, cerium oxide(IV) nano powder; cerium oxide(IV)-20 gadolinium doped nano powder; cerium oxide(IV)-15-samaria doped nano powder and cerium(IV) oxide, nanoparticles, 10 wt. dispersion in H2O were from Aldrich. Cerium oxide(IV), 20 wt.% in water colloidal dispersion was from Alfa Aesar, while CeO2 powder was from Sky spring. Dopamine hydrochloride was obtained from Sigma, while catechol (99%) was from Acros. Tyrosinase (E.C.1.14.18.1, from mushroom, 4276 units/mg as per supplier information) was prepared in phosphate buffer solution (PBS). Buffer components for PBS including sodium phosphate and potassium phosphate were from ACROS and Sigma–Aldrich, respectively.

# 2.2. Solutions and buffer

The PBS was prepared from 0.1 M sodium phosphate and 0.1 M potassium phosphate in distilled water. The Enzyme stock solution (1313 mU/mL) was prepared in PBS. Dopamine and catechol were first dissolved in methanol at a concentration of 250 and 19 mM, respectively, depending on their solubility in the solvent. Dilutions were prepared from the stock solution in distilled deionized water and PBS of various pH and ionic strengths, depending upon the nature of experiments. The NP dispersion was diluted in distilled deionized water and PBS, and sonicated for 5 min prior to all experiments. Distilled, deionized water (Millipore, Direct-Qsystem) with a resistivity of 18.2Vcmwas used for the preparation of the buffer solutions.

# 2.3. Instrumentation

UV–vis spectrophotometric measurements were performed with a Schimadzu P2041 spectrophotometer equipped with a 1-cm path length cell. Measurement of zeta potential to evaluate surface charge of the nanoceria particles in various ionic strength solutions was investigated by using a Zeta PALS from Brookhaven Instruments Corporation.

# 2.4. Experimental procedures

To investigate the oxidase like activity of nanoceria, particle dispersions were exposed to varying concentrations of dopamine and catechol. Dopamine and catechol were added to the particle dispersions at concentrations of 0.8 and 0.35 mM, respectively. The optical properties of the oxidation products were measured spectrophotometrically. The effect of the type and concentration of particles, the pH and ionic strength for seven types of commercially available nanoceria were compared to those of a tyrosinase enzyme for these substrates. The effect of nanoceria concentration was investigated in the concentration range of 0.125–1 103 mg/L using 1 mM dopamine and 0.35 mM catechol. The concentration of nanoceria particles used in the optimization tests of pH and ionic strength was 1 103 mg/L with a concentration of 0.8 mM dopamine. The effect of pH was studied in PBS solutions with a pH range of 6–8. The effect of ionic strength was studied in PBS solutions of ionic strength compositions varying from 0.06 mM to 1 M. The change in the surface charge of the nanoceria particles was assessed by DLS and zeta potential measurements. Analytical measurements to determine dopamine and catechol and to establish method performance were performed in the concentration range of 0.4–850mM using 1 103 mg/L nanoceria dispersion. The absorbance was measured at 480 nm, corresponding to the nanoceria generated quinone complex.

Comparative enzymatic experiments were performed using the tyrosinase enzyme. Enzymatic tests to optimize conditions were performed by varying enzyme activity in the range of 0.625– 15 mU/mL in PBS at a pH of 6.5 in the presence of 1.4 mM dopamine and 0.75 mM catechol. Effect of the pH was assessed in PBS in the pH range from 6 to 8 using 1 mM dopamine and 0.65 mM catechol. Optimal concentrations were determined based on absorbance values corresponding to the enzymatically generated quinones. Detection of dopamine and catechol was performed in the concentration range of 0.075–2 mM. Substrates were added to tyrosinase in PBS at a pH of 6.5 and the absorbance at 476 nm for dopamine and at 388 nm for catechol were measured to determine kinetic and analytical parameters.

### 3. Results and discussion

# 3.1. Oxidase like activity of nanoceria: proof of concept for nanoceria based detection

The dual (Ce4+/Ce3+) oxidation state and the high mobility of surface oxygen are responsible for the oxidase like activity of nanoceria. To demonstrate this activity, we have selected two phenolic compounds, dopamine and catechol, and have studied their catalytic oxidation by nanoceria. Scheme 1 illustrates the oxidation of dopamine and catechol by nanoceria and the corresponding absorption spectra for a 20–25 nm nanoceria dispersion (1 103mg/L). The color of the particle dispersion changed instantaneously from transparent/light yellow to brown upon addition of dopamine and catechol. The intensity of the color is dependent on the concentration of dopamine and catechol, and varies with the type of nanoceria particle used. The color change is due to the oxidation of the phenolic compounds by nanoceria and formation of strongly absorbing charge transfer complexes. Oxidation and formation of charge transfer complexes between ceria and dopamine were demonstrated previously with FTIR spectroscopy, XPS and UV–vis spectroscopy [\[36\]](#page-7-0). The extent of change in optical properties of nanoceria particles upon exposure to phenolic compounds is associated to the ratio of Ce4+ and Ce3+ in the nanoparticle system and formation of charge transfer complexes. The resulting change in optical properties of the reaction mixture indicates that these particles can be used as an oxidation catalyst to replace the commonly used tyrosinase enzyme, and as a new colorimetric probe for the quantitative detection of phenolic compounds.

# 3.1.1. Effect of particle type

Itis known that NPs with different physical properties may have different chemical reactivity [\[37,38\].](#page-7-0) We used changes in the optical properties of nanoceria upon incubation with dopamine and catechol to assess the 'oxidase like activity' of different types of commercially available nanoceria. To demonstrate whether this colorimetric change is a common feature of nanoceria, we tested different types of nanoceria particles from seven different suppliers, both dry powders and colloidal dispersions of pure and doped particles. In addition to pure ceria, sammaria and gandolinium doped ceria were tested because these particles are known to have enhanced oxygen vacancies at their surface and potentially higher oxidation ability. Table S1 in the Supporting information (SI) provides detailed information on the seven different types of commercially available particles used in this study, including: supplier, particle size, particle size distribution as determined from dynamic light scattering (DLS) and surface charge (zeta potential value). Screening tests were performed with a particle concentration of 1 103 mg/L. [Fig. 1](#page-3-0) shows optical images of vials containing nanoceria dispersion of the seven types of particles in the presence of 1 mM dopamine in water. In the absence of dopamine, all particle dispersions are colorless at the concentration tested (control vials are shown in Fig. S1 in SI). As a common feature, all particle types showed absorbance changes when exposed to dopamine and catechol, but with varying intensity (Fig. S2). This suggests that the oxidase like activity is a common feature of nanoceria regardless of the synthesis procedure, but as expected, this varies with particle size and agglomeration status. These experiments demonstrate the variability of the oxidase like activity of these particles on the surface and physicochemical properties, as discussed.

The highest intensity was observed for aqueous dispersions containing particles of <30 nm, as determined by PSD (particle size distribution)/DLS measurements. The particles dispersed in acetic acid showed higher absorbance values as compared to the other types of particles. By comparison, the nanoceria powders showed significantly lower changes in optical properties. This behavior can be related to the PSD values of the particles, which were higher in the case of nanoceria and doped nanoceria powders

<DESCRIPTION_FROM_IMAGE>The image illustrates a chemical reaction and its corresponding spectroscopic analysis. It consists of two main parts: a schematic representation of a redox reaction and an absorption spectrum graph.

1. Redox Reaction Schematic:
The left side shows two beakers:
- Upper beaker: Contains oxidized Dopamine or Catechol (labeled "ox Dopamine or Catechol")
- Lower beaker: Contains reduced Dopamine or Catechol (labeled "Dopamine or Catechol")

The schematic demonstrates a redox reaction between Dopamine/Catechol and Cerium ions:
- Reduced Dopamine/Catechol oxidizes to ox Dopamine/Catechol (black arrow)
- Simultaneously, Ce⁴⁺ ions (represented by yellow circles) are reduced to Ce³⁺ ions (represented by darker circles) (red arrow)

2. Absorption Spectrum:
The right side shows an absorption spectrum graph with the following features:
- X-axis: Wavelength (nm), ranging from 500 to 800 nm
- Y-axis: Absorbance, ranging from 0 to 0.7
- Two main curves:
  a) Test curve (black and red lines): Shows high absorbance peaking around 0.68 at 500 nm, gradually decreasing to about 0.1 at 800 nm
  b) Control curve (purple and blue lines): Shows very low, nearly constant absorbance (close to 0) across the entire wavelength range

The graph indicates a significant difference in absorbance between the test sample (likely containing the products of the redox reaction) and the control sample.

This image demonstrates the use of spectroscopic analysis to monitor a redox reaction between Dopamine/Catechol and Cerium ions, showing how the oxidation state change of both the organic compound and the metal ions affects the absorption spectrum.</DESCRIPTION_FROM_IMAGE>

Scheme 1. The principle of nanoceria based detection of dopamine/catechol. Absorption spectra of dopamine and catechol oxidation by nanoceria (Test) and control spectra for the same concentration of dopamine and catechol without particles.

<DESCRIPTION_FROM_IMAGE>The image shows a series of eight test tubes or vials labeled from 'a' to 'h' from left to right. Each container appears to contain a liquid or solution at different concentrations or compositions:

a) Contains a light-colored solution, possibly dilute.
b) Contains a dark-colored solution, appearing more concentrated than 'a'.
c) Contains a dark-colored solution, similar in appearance to 'b'.
d) Contains a clear or very light-colored solution, less concentrated than 'a'.
e) Contains a clear or very light-colored solution, similar to 'd'.
f) Contains a clear or very light-colored solution, similar to 'd' and 'e'.
g) Contains a clear or very light-colored solution, possibly with some particulate matter visible.
h) Contains a clear or very light-colored solution, similar to 'g'.

The solutions in tubes 'b' and 'c' appear to be the most concentrated or contain the most solute, while tubes 'd' through 'h' appear to contain very dilute solutions or possibly pure solvent. This image likely represents a dilution series or a comparison of different solution concentrations in a chemical experiment. The gradual change in appearance from left to right suggests a systematic variation in composition or concentration across the series of samples.</DESCRIPTION_FROM_IMAGE>

Fig. 1. Interaction of seven types of nanoceria particles with 1 mM dopamine in water for the following commercially available particles: (a) cerium(IV) oxide nano particles, 10 wt. dispersion in H2O, Aldrich; (b) cerium(IV) oxide dispersion 20 wt.% colloidal dispersion in 2.5% acetic acid, Aldrich; (c) cerium oxide, 20% in H2O, colloidal dispersion Alfa Aesar; (d) cerium(IV) oxide-15-samaria-doped, nanopowder, Aldrich; (e) cerium(IV) oxide nanopowder (BET) Aldrich; (f) cerium(IV) oxide-20-gadolinium doped, Sigma, nanopowder; (g) CeO2 powder Sky Spring; and (h) control containing only dopamine in water.

e.g. (137–850 8–60 nm) as compared to those of nanoceria dispersions (18.9–78.7 1.5–5 nm); see Table S1. Similarly, a decreased zeta potential value was observed in the case of nanoceria and doped nanoceria powders, (8.49–12 1.5 mV) indicating that these particles have a higher tendency to aggregate. By comparison, the nanoceria dispersions were characterized by high zeta potential values (25–35 2 mV). This explains the high stability of the dispersion because they conserve their surface reactivity at the nano scale. The different sizes and particle types can also have varying ratios of Ce3+/4+ on the surface, and can contain surface ligands that may affect reactivity. The maximum change in color was observed for the nanoceria dispersion in acetic acid, which could be attributed to their lower particle diameter (18.9 1.5 nm) and the high positive zeta potential (+35 2 nm). This indicates good colloidal stability, probably due to the chelating effect of acetate on ceria. This analysis demonstrates that reactivity varies significantly among different types of particles.

## 3.1.2. Effect of pH, ionic strength and buffer composition

Since the catalytic properties of NPs are highly dependent on the pH of the reaction medium and buffer anions [\[39\]](#page-7-0), it was important to investigate the effect of these parameters. Fig. S3 shows the effect of pH on dopamine oxidation for a nanoceria dispersion in the pH range from 6 to 8 in PBS. The pH effect for the six other types of particles is provided in Fig. S4 (SI). The highest activity quantified from the optical changes was observed with nanoceria dispersions with PSD values lower than 30 nm. For these particles, a significant color change was observed over the entire pH range tested from 6 to 8 in PBS. The highest intensity was observed at pH 8. To further determine the effect of ionic strength, we have tested the oxidation behavior of these particles in PBS solutions with a concentration range from 0.00625 to 0.1 M at a pH of 8 (Fig. 2). Control experiments showing spectra of dopamine and catechol (in the absence of particles) and nanoceria particles without phenolics show no absorption wave in the wavelength range tested (400–800 nm). This indicates that neither dopamine, nor catechol or nanoceria absorb in that range (Fig. S5, SI). The maximum absorption was achieved with phosphate concentrations lower than 0.05 M. Higher concentrations induced significant particle aggregation and increased the baseline, and therefore were not used in the assay. The absorbance decreases with the increase in ionic strength in the concentration range tested. This demonstrates that the presence of phosphate anions has a damaging effect on the oxidase activity of these particles. This is evident from the comparison of the absorption spectra of nanoceria in the presence of dopamine in water and in PBS, showing significantly higher absorption characteristics in water. These results indicate that water is a better solvent for achieving enhanced oxidase ability of nanoceria particles.

The reduced reactivity in the buffer can be attributed to the formation of cerium phosphate on the particle surface [\[40\]](#page-7-0), resulting in a partial inactivation of the surface. This prevents the reaction with the phenolic compounds by blocking the interconversion between Ce4+/Ce3+. In order to confirm this hypothesis, DLS and zeta potential experiments were performed to analyze the formation of cerium phosphate and its effect on the aggregation

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled A and B, both showing absorbance spectra as a function of wavelength.

Graph A:
This graph shows absorbance versus wavelength for five different samples labeled a, b, c, d, and e. The wavelength range is from 400 nm to 800 nm. The absorbance scale ranges from 0 to 0.270.

Sample a (top line) shows the highest absorbance, starting at about 0.270 at 400 nm and decreasing gradually to about 0.162 at 800 nm.
Sample e (second from top) starts at about 0.216 absorbance at 400 nm and decreases more rapidly than sample a, reaching about 0.054 at 800 nm.
Sample d follows a similar trend to e but with slightly lower absorbance values.
Sample c has a lower initial absorbance of about 0.162 at 400 nm and decreases to near zero at 800 nm.
Sample b (bottom line) shows the lowest absorbance, starting at about 0.108 at 400 nm and decreasing to near zero at 800 nm.

All samples show a general trend of decreasing absorbance as wavelength increases, with varying rates of decrease.

Graph B:
This graph shows absorbance versus wavelength for two samples labeled a and b. The wavelength range is from 450 nm to 780 nm. The absorbance scale ranges from 0 to 0.7.

Sample b (top line) shows significantly higher absorbance than sample a. It starts at about 0.67 absorbance at 450 nm, maintains a relatively constant absorbance until about 520 nm, then shows a sharp decrease to about 0.07 absorbance at 780 nm.

Sample a (bottom line) shows a much lower and more gradual decrease in absorbance. It starts at about 0.22 absorbance at 450 nm and decreases slowly to about 0.07 absorbance at 780 nm.

The two samples converge to similar absorbance values at higher wavelengths (around 780 nm).

These graphs likely represent absorption spectra of different chemical compounds or materials, showing how they interact with light at various wavelengths in the visible to near-infrared range.</DESCRIPTION_FROM_IMAGE>

Fig. 2. Effect of buffer ionic strength on nanoceria interaction with 0.8 mM dopamine. (A) (a) 0.05 M, (b) 0.025 M, (c) 0.0125 M and (d) 0.00625 M. (B) UV–vis spectra obtained with nanoceria (1 103mg/L) and dopamine (0.8 mM) in: (a) PBS (0.00625 M, pH 8.0) and (b) deionized water.

behavior of nanoceria particles (1 103 mg/L). An increase in particle size from 70 5 nm to 1154.87 50 nm, and change of the zeta potential values from 33 2 mV to 50.27 5 was observed with increasing concentration of PBS (0.00625–0.1 M). The change in the zeta potential value clearly indicates a change in the surface properties of these particles and can be indicative of formation of cerium phosphate. The detailed DLS/zeta potential results are provided in the Supplementary Table S2 (SI).

To assess the effect of other anions, dopamine reactivity tests were also performed with citrate and acetate buffers under a varying pH. Nanoceria reactivity was observed to decrease with decreasing pH for both types of buffers (Figs. S6 and S7). As compared to phosphate, the color intensity in acetate and citrate was more strongly dependent on the pH. The acetate was more reactive against dopamine than citrate and both showed lower reactivity at lower pH values. We note, however, that the reactivity in buffers is lower than that measured for the same particle type and dopamine concentration in water. This indicates the high variability of this reaction on the physicochemical properties of these particles as well as on the reaction conditions and buffer environment.

# 3.1.3. Effect of particle concentration

The oxidase like activity is strongly dependent on the available reactive surface of the NPs. To determine the effect of nanoceria concentration, fixed concentrations of dopamine and catechol were incubated with varying concentrations of nanoceria particles ranging from 0.125 to 1 103 mg/L. Fig. 3 shows the absorption spectra of different concentrations of water dispersed nanoceria in the presence of dopamine and catechol. It can be seen that the absorption peak increases with increasing the particle concentration for both of the analytes. However, the color intensity for the same particle concentration is different when the same concentration of catechol and dopamine was used. This can be due to the different chemical structure and redox potential which favors catechol oxidation. It should be noted, however, that while higher particle concentrations may lead to an elevated signal, this can also result in increased background absorption and light scattering. A concentration of 1 103 mg/L was selected to prevent aggregation and light scattering for the analytical characterization of the method.

# 3.2. Kinetic analysis and comparison with the enzyme based reaction

The oxidation of dopamine and catechol by nanoceria is initiated almost instantaneously and can be seen by the immediate appearance of the brown color and the strong absorbance band. A similar behavior for varying concentrations of particles further confirmed the fast reactivity of nanoceria for catechol and dopamine oxidation (Fig. S8). The reaction rate for an incubation period of 1 h is shown in Fig. S9. The oxidase like activity was fitted by the classical Michaelis–Menten model ([Fig.](#page-5-0) 4). A plot of V against [S] was used to determine the kinetic parameters. The Km values derived from the slope and intercept of the line were 0.25mM for dopamine and 180mM for catechol. By comparison, the Km values of the optimized enzymatic reaction using tyrosinase in the same reaction conditions were 0.3mM and 200mM for dopamine and catechol, respectively. Optimization and characterization of the tyrosinase catalyzed enzyme assay and the corresponding absorption spectra and kinetic analysis are summarized in SI (Figs. S10–S13).

# 3.3. Nanoceria based detection of dopamine and catechol

The rapid color change and the strong absorbance characteristics of the oxidation of dopamine and catechol by nanoceria indicate that these particles can be used for oxidation and as color indicator reagents for the detection of these compounds. Characterization of the analytical assay was performed in optimized conditions with water as the solvent, with the aqueous nanoceria dispersion in acetic acid and with a concentration of particles of 1 103 mg/L. [Fig.](#page-5-0) 5 displays the calibration curves for dopamine and catechol detection by nanoceria. The spectroscopic response increases linearly with the increasing concentration of dopamine and catechol, with a linearity range between 1 and 400mM for catechol and between 1 and 800mM for dopamine. The limits of detection (LOD) for dopamine and catechol were 1.5 and 0.2mM, respectively, according to the 3s criteria. The graphs in [Fig.](#page-5-0) 5 show replicate analysis from three independent trials. This method showed excellent reproducibility with a coefficient of variability of less than 1% (see [Table](#page-6-0) 2 for a comparative analysis). By comparison, the LODs for dopamine and catechol for the corresponding enzymatic reaction were 50 and 30mM. This shows that the nanoceria detection is several times more sensitive than the conventional tyrosinase assay (in optimized conditions). The

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled A and B, both showing absorbance spectra as a function of wavelength.

Graph A:
This graph shows absorbance on the y-axis ranging from 0 to 1.0, and wavelength on the x-axis ranging from 400 to 800 nm. There are five curves labeled a through e.

Curve a (lowest): Shows the lowest absorbance, peaking around 0.3 at 500 nm.
Curve b: Has a higher absorbance, peaking around 0.6 at 500 nm.
Curve c: Shows slightly higher absorbance than b, peaking around 0.7 at 500 nm.
Curve d: Has a higher absorbance than c, peaking around 0.75 at 500 nm.
Curve e (highest): Shows the highest absorbance, peaking around 1.0 at 400 nm.

All curves show a general decrease in absorbance as wavelength increases, with the most rapid decrease occurring between 500-700 nm. The curves converge as they approach 800 nm, where absorbance is close to zero for all.

Graph B:
This graph shows absorbance on the y-axis ranging from 0 to 0.8, and wavelength on the x-axis ranging from 400 to 800 nm. There are five curves labeled a through e.

Curve a (lowest): Shows the lowest absorbance, peaking around 0.3 at 500 nm.
Curve b: Has a higher absorbance, peaking around 0.5 at 500 nm.
Curve c: Shows slightly higher absorbance than b, peaking around 0.6 at 450 nm.
Curve d: Has a similar peak absorbance to c, also around 0.6 at 450 nm.
Curve e (highest): Shows the highest absorbance, peaking around 0.7 at 450 nm.

Similar to Graph A, all curves in Graph B show a general decrease in absorbance as wavelength increases, with the most rapid decrease occurring between 500-700 nm. The curves converge as they approach 800 nm, where absorbance is close to zero for all.

The main differences between Graph A and B are the overall lower absorbance values in Graph B and the slightly different shapes of the curves, particularly in the 400-500 nm range.</DESCRIPTION_FROM_IMAGE>

Fig. 3. Absorption spectra with different concentrations of nanoceria in the presence of 1 mM dopamine (A) and 0.35 mM catechol (B) for (a) 0.125, (b) 0.25, (c) 0.5, (d) 0.75 and (e) 1 (103 mg/L) particles.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled 'a' and 'b', both showing the relationship between reaction velocity and substrate concentration.

Graph a:
- X-axis: Substrate concentration in μM, ranging from 0.0 to 3.0 μM
- Y-axis: Reaction velocity, ranging from 0.000 to 0.085
- The graph shows a typical Michaelis-Menten kinetics curve
- Data points are represented by small squares
- The curve rises sharply initially, then begins to level off around 1.5 μM substrate concentration
- The curve appears to approach a maximum reaction velocity of approximately 0.080

Graph b:
- X-axis: Substrate concentration in μM, ranging from 0 to 900 μM
- Y-axis: Reaction velocity, ranging from 0.000 to 0.130
- This graph also shows Michaelis-Menten kinetics, but over a much wider range of substrate concentrations
- Data points are represented by small circles and crosses
- The curve rises sharply up to about 360 μM substrate concentration, then begins to level off
- The curve appears to approach a maximum reaction velocity of approximately 0.120

Both graphs demonstrate enzyme kinetics, showing how reaction velocity increases with substrate concentration until it reaches a maximum rate (Vmax) where the enzyme is saturated. Graph 'b' shows this relationship over a much wider range of substrate concentrations than graph 'a'.</DESCRIPTION_FROM_IMAGE>

Fig. 4. Non-linear fits to Michaelis–Menten data for dopamine (a) and catechol (b).

<DESCRIPTION_FROM_IMAGE>The image presents a graph showing the relationship between Concentration (μM) on the x-axis and Absorbance on the y-axis. The graph contains two linear plots, labeled 'a' and 'b'.

Plot 'b' (black line):
- Equation: Y = 0.0023x + 0.00167
- Steeper slope compared to plot 'a'
- Data points range from approximately 0 to 400 μM
- Maximum absorbance reached is about 0.8
- Error bars are visible on the data points

Plot 'a' (orange line):
- Equation: Y = 0.0009x + 0.004
- Less steep slope compared to plot 'b'
- Data points range from approximately 0 to 800 μM
- Maximum absorbance reached is about 0.75
- Error bars are visible on the data points

Both plots show a linear relationship between concentration and absorbance, indicating they likely represent calibration curves or concentration-dependent measurements. The difference in slopes suggests different sensitivities or extinction coefficients for the measured species.

The x-axis (Concentration) ranges from 0 to 800 μM, while the y-axis (Absorbance) ranges from 0 to approximately 0.8. The graph includes error bars on the data points, suggesting multiple measurements were taken for each concentration.

The linear relationships and the use of absorbance suggest this graph might be related to spectrophotometric analysis, possibly for quantifying the concentration of two different species or the same species under different conditions.</DESCRIPTION_FROM_IMAGE>

Fig. 5. Calibration curves of the nanoceria assay for (a) dopamine and (b) catechol (error bars correspond to n = 3 independent experiments.

calibration curves of the enzyme assay for dopamine and catechol are shown in Fig. S14.

### 3.4. Interferences study and real sample analysis

To investigate the specificity and selectivity of the proposed assay, the reactivity of possible interfering compounds including glucose, glycine, histidine, L-glutamic acid, phenylalanine, K and Na ions were tested under similar experimental conditions as those described for dopamine and catechol. Changes in the optical properties of the reaction mixture and UV–vis study were performed to characterize the reaction. As seen in Fig. 6A, these compounds did not show any reaction with the nanoceria particles, and no absorption peaks were observed for these compounds. We further studied the selectivity of the nanoceria assay against different types of phenolic compounds. Fig. 6B shows the changes in optical properties and absorption spectra obtained with phenolic compounds. A variation in the nanoceria reactivity was observed depending on the type of phenolic compound tested. The highest intensity was obtained for catechol and dopamine while the other phenolics tested do not show immediate color changes. The reaction is dependent on the chemical structure of these compounds and is favored for o-substituted phenols like dopamine and catechol. While the other phenolics tested (quercetin, hydroquinone, bisphenol A and even phenol) do react with nanoceria, the oxidation is slower than that of dopamine and catechol; the sensitivity of the assay for these compounds is limited (a color change is observed for higher concentrations and longer incubation times). We should state that tyrosinase is a general oxidative enzyme for phenolic compounds [\[25,41](#page-7-0)–43] and has limited specificity. In this respect, the results suggest that the nanoceria assay is more selective as compared to tyrosinase detection methods.

The method was further applied to determine presence of dopamine and catechol in real samples. Human serum samples were spiked with varying concentrations of dopamine, while tap

<DESCRIPTION_FROM_IMAGE>The image consists of two parts, labeled A and B, each showing UV-Vis absorption spectra and corresponding sample vials.

Part A:
The graph shows UV-Vis absorption spectra with wavelength (nm) on the x-axis ranging from 380 to 780 nm, and absorbance on the y-axis ranging from -0.1 to 1.1. There are multiple spectral lines labeled a, b, and c,d,e,f,g,h,i.

Line a (blue) shows the highest absorbance, peaking around 1.1 at 380 nm, then decreasing to about 0.7 at 480 nm, followed by a gradual decline to about 0.1 at 780 nm.

Line b (red) follows a similar pattern but with lower absorbance, peaking at about 0.9 at 380 nm, decreasing to about 0.5 at 480 nm, then gradually declining to about 0.1 at 780 nm.

Lines c,d,e,f,g,h,i are clustered together near the bottom of the graph, showing very low absorbance (close to 0) across the entire wavelength range.

The inset image shows 9 vials labeled a to i. Vials a and b contain dark-colored solutions, while vials c to i appear to contain clear or very lightly colored solutions.

Part B:
This graph shows UV-Vis spectra with wavelength (nm) on the x-axis ranging from 400 to 760 nm, and absorbance on the y-axis ranging from 0 to 1.

Line a (red) shows high absorbance, starting at about 0.8 at 400 nm, increasing to a peak of about 0.9 at 450 nm, then gradually decreasing to about 0.1 at 760 nm.

Line b (green) starts at the highest absorbance of about 1.0 at 400 nm, then rapidly decreases to about 0.4 at 520 nm, followed by a more gradual decline to about 0.1 at 760 nm.

Lines c, d, and e show very low absorbance (close to 0) across the entire wavelength range.

The inset image shows 5 vials labeled a to e. Vials a and b contain colored solutions (likely corresponding to the higher absorbance spectra), while vials c, d, and e appear to contain clear or very lightly colored solutions.

These spectra and corresponding vial images likely represent the absorption characteristics of different solutions or nanoparticle suspensions, possibly demonstrating the effect of synthesis conditions or treatments on the optical properties of the samples.</DESCRIPTION_FROM_IMAGE>

Fig. 6. Absorption spectra of 1000 ppm nanoceria in the presence of (A) (a) 0.35mM catechol and 0.5 mM, (b) dopamine, (c) glucose, (d) glycine, (e) histidine, (f) K, (g) L-glutamic acid, (h) Na and (i) phenylalanine. (B) (a) 0.25 mM gallic acid, (b) 0.25 mM quercetin, (c) 1 mM hydroquinone, (d) 0.25 mM bisphenol A and (e) 1 mM phenol.

<span id="page-6-0"></span>water was spiked to detect catechol. No significant difference in spiked and obtained values was observed (Table 1). The precision of the assay was evaluated by the relative standard deviation (%RSD) for triplicate measurements. The accuracy (%R.E.) of analyte determination was examined by comparing the real and measured values. The change in the optical properties of the reaction mixture and their respective UV–vis spectra are provided in Fig. S15. The results show a good agreement between the spiked and determined concentration with % recovery between 95 and 101.6% for the three concentrations tested. This demonstrates the suitability and potential of the method for real sample analysis.

# 3.5. Comparison between the nanoceria and tyrosinase assays

One of the objectives of this work was to comparatively establish the characteristics of this method versus that of an oxidative enzyme that is commonly used for the detection of phenolics. We have selected for this purpose tyrosinase, a copper protein that is widely used in bioanalytical assays for the detection of phenolic compounds, including dopamine and catechol. We first performed kinetic analysis and optimization tests for the enzyme with the two substrates. The results are included in the SI (Figs. S10–S13). The oxidation products of the enzymatic reaction, dopaquinone and quinone show characteristic peaks at 476 nm and 388 nm, respectively. By comparison, the peaks of the oxidation products by nanoceria are red shifted to 520 and 500 nm for dopamine and catechol, respectively. We attribute the enhanced spectral features to formation of charge transfer complexes, which could provide increased detection characteristics and higher sensitivity for the nanoceria assay.

Table 2 provides a comparison of the analytical performance of the nanoceria and the enzyme based detection of dopamine and catechol. The analytical parameters obtained from kinetic data and fitted calibration curves were used to compare the enzymatic and nanoceria based assays. The comparison of Km values demonstrates a fast reaction rate and high affinity of the two substrates for the inorganic material. The nanoceria assay exhibits low limits of detection for the two substrates. The sensitivity of the method was 3 folds higher than that of the enzyme assay for the optimized amounts of enzyme and particles that were used. Based on the absorbance values, we estimate that 1 mU/mL tyrosinase corresponds to 28.3 mg/mL nanoceria. Tyrosinase oxidation of dopamine and catechol requires a specific pH medium, while nanoceria particles show maximum reactivity in deionized distilled water. Tyrosinase is a more expensive catalyst, while nanoceria particles can be purchased relatively inexpensively or can be synthesized in the laboratory in large quantities. Moreover, the particles are stable at room temperature and conserve their 'oxidase activity' for years. This is a significant advancement over the enzyme catalyst that is sensitive to changes in temperature and pH, and can lose its activity overtime and requires refrigeration. All of these merits make nanoceria particles promising candidates for

#### Table 2

Analytical performance characteristics of the nanoceria assays as compared to the tyrosinase based detection of dopamine and catechol using optimized nanoceria and tyrosinase concentrations.

|                   | Dopamine   |           | Catechol   |             |  |
|-------------------|------------|-----------|------------|-------------|--|
|                   | Tyrosinase | Nanoceria | Tyrosinase | Nanoceria   |  |
| Sensitivity (mM)1 | 0.00029    | 0.0009    | 0.00076    | 0.0023      |  |
| LOD (mM)          | 50         | 1.5       | 30         | 0.2<br>0.01 |  |
| SD                | 2.5        | 0.075     | 1.5        |             |  |
| R2                | 0.99       | 0.99      | 0.97       | 0.983       |  |

the development of analytical assays for the detection of phenolic compounds.

#### 4. Conclusion

In summary, this work explored the oxidase like properties of nanoceria particles and established the optimum operational parameters and reaction conditions in the development of colorimetric assays for the detection of phenolic substrates. Several types of particles and reaction conditions were tested to establish conditions of use that maximize the oxidase like activity. All particle types showed absorbance changes when exposed to dopamine and catechol in water, but with varying intensity. This suggests that the oxidase like activity is a common feature for nanoceria regardless of the synthesis procedure, but this varies with particle size and agglomeration status. The use of phosphate buffer was found to reduce assay sensitivity due to formation of cerium phosphate on the particle surface. The comparative study with the enzyme counterpart indicated that the nanoceria assay is more sensitive than the tyrosinase assay for detection of dopamine and catechol. The same assay could be used as a general sensing platform for the detection of other phenolics. However, the sensitivity of the method varies significantly with the structure of the phenolic compound and seems to be favored for o-substituted hydroxylated phenols like dopamine and catechol. Further work is needed to establish the structural determinants of the oxidase activity for a larger class of phenolics.

Based on this study, the following general recommendations are provided when considering nanoceria as an oxidation catalyst for the development of analytical assays: (1) the use of water as solvent, (2) the use of stable NP dispersions that show high zeta potential values and low agglomeration status, (3) avoid the use of solutions with high ionic strengths, (4) smaller size NPs (<30 nm) have higher oxidation activity; however, this can change with the aggregation status in the measurement environment, (5) high NP concentrations provide higher signals; however, the concentration of the particles needs to be optimized to prevent light scattering and precipitation. This study demonstrates that nanoceria provides significant advantages in terms of sensitivity and stability, versus the enzyme assay, but the assay requires careful selection of the particles and reaction conditions, in particular ionic

Table 1

Recovery percentages using the nanoceria assay for the analysis of dopamine in spiked human serum and catechol in tap water.

| Dopamine    |                 |        |       | Catechol    |                 |        |       |  |
|-------------|-----------------|--------|-------|-------------|-----------------|--------|-------|--|
| Spiked (mM) | Determined (mM) | R.E.%a | R%b   | Spiked (mM) | Determined (mM) | R.E.%a | R%b   |  |
| 250         | 240             | 4      | 96    | 100         | 95              | 5      | 95    |  |
| 400         | 392             | 2      | 98    | 200         | 187             | 6.5    | 93.5  |  |
| 500         | 508             | 1.6    | 101.6 | 350         | 335             | 4.29   | 95.71 |  |

a Relative % error.

b % Recovery.

<span id="page-7-0"></span>composition, particle concentration, surface charge and agglomeration status in the measurement environment.

#### Acknowledgements

The authors gratefully acknowledge a David A. Walsh Fellowship to JC. This material is based upon work supported by the National Science Foundation under Grant No. 0954919. Any opinions, findings, and conclusions or recommendations expressed in this material are those of the author(s) and do not necessarily reflect the views of the National Science Foundation.

#### Appendix A. Supplementary data

Supplementary data associated with this article can be found, in the online version, at <http://dx.doi.org/10.1016/j.aca.2015.04.052>.

## References

- [1] H. Wei, E. Wang, Fe3O4 magnetic [nanoparticles](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0005) as peroxidase mimetics and their [applications](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0005) in H2O2 and glucose detection, Anal. Chem. 80 (2008) 2250– [2254.](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0005)
- [2] J.S. Mu, Y. Wang, M. Zhao, L. Zhang, Intrinsic [peroxidase-like](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0010) activity and catalase-like activity of Co3O4 [nanoparticles,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0010) Chem. Commun. 48 (2012) 2540– [2542.](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0010)
- [3] K.N. [Chaudhari,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0015) N.K. Chaudhari, J.-S. Yu, Peroxidase mimic activity of hematite iron oxides (a-Fe2O3) with different [nanostructures,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0015) Catal. Sci. Technol. 2 [(2012)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0015) 119–124.
- [4] R. [Fiammengo,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0020) A. Jaschke, Nucleic acid enzymes, Curr. Opin. Biotech. 16 (2005) 614–[621.](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0020)
- [5] H. Volz, M. Holzbecher, A bridged [porphyrinato(thiolato)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0025) iron(III) complex as a model of the active center of the [cytochrome](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0025) P-450 isozyme, Angew. Chem. Int. Ed. 36 [(1997)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0025) 1442–1445.
- [6] M. Ghosh, J.L. Conroy, C.T. Seto, [Hydrolysis](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0030) of amides catalyzed by [4-heterocyclohexanones:](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0030) small molecule mimics of serine proteases, Angew. Chem. Int. Ed. 38 [(1999)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0030) 514–516.
- [7] T. Funabiki, T. Yamazaki, A. Fukui, T. Tanaka, S. Yoshida, [Oxygenative](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0035) cleavage of [chlorocatechols](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0035) with molecular oxygen catalyzed by non-heme iron(III) complexes and its relevance to [chlorocatechol](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0035) dioxygenases, Angew. Chem. Int. Ed. 37 [(1998)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0035) 513–515.
- [8] P. Molenveld, J.F.J. Engbersen, D.N. Reinhoudt, Specific RNA [dinucleotide](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0040) cleavage by a synthetic calix[4] [arene-based](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0040) trinuclear metallo(II) [phosphodiesterase,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0040) Angew. Chem. Int. Ed. 38 (1999) 3189–3192.
- [9] M.J. Han, K.S. Yoo, J.Y. Chang, T.K. Ha, [5-(Beta-cyclodextrinylamino)-5-deoxy](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0045)[alpha-D-riboses](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0045) as models for nuclease, ligase, phosphatase, and [phosphorylase,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0045) Angew. Chem. Int. Ed. 39 (2000) 347.
- [10] M.S. Muche, M.W. Gobel, [Bis(guanidinium)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0050) alcohols as models of [staphylococcal](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0050) nuclease: substrate binding through ion pair complexes and fast [phosphoryltransfer](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0050) reactions, Angew. Chem. Int. Ed. 35 (1996) 2126–2129.
- [11] L. Signor, C. Knuppe, R. Hug, B. [Schweizer,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0055) A. Pfaltz, B. Jaun, Methane formation by reaction of a methyl thioether with a [photo-excited](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0055) nickel thiolate—a process mimicking [methanogenesis](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0055) in archaea, Chem. Eur. J. 6 (2000) 3508– [3516.](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0055)
- [12] H. Wei, E.K. Wang, [Nanomaterials](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0060) with enzyme-like characteristics (nanozymes): [next-generation](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0060) artificial enzymes, Chem. Soc. Rev. 42 (2013) [6060](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0060)–6093.
- [13] Z. Wang, X. Yang, J. Yang, Y. Jiang, N. He, [Peroxidase-like](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0065) activity of mesoporous silica [encapsulated](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0065) Pt nanoparticle and its application in colorimetric [immunoassay,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0065) Anal. Chim. Acta 862 (2015) 53–63.
- [14] C.I. Wang, W.T. Chen, H.T. Chang, Enzyme mimics of Au/Ag [nanoparticles](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0070) for fluorescent detection of [acetylcholine,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0070) Anal. Chem. 84 (2012) 9706–9712.
- [15] Z.W. Tang, H. Wu, Y.Y. Zhang, Z.H. Li, Y.H. Lin, [Enzyme-mimic](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0075) activity of ferric nano-core residing in ferritin and its biosensing [applications,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0075) Anal. Chem. 83 [(2011)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0075) 8611–8616.
- [16] Y.H. Lin, J.S. Ren, X.G. Qu, [Nano-gold](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0080) as artificial enzymes: hidden talents, Adv. Mater. 26 [(2014)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0080) 4200–4217.
- [17] L.Z. Gao, J. Zhuang, L. Nie, J.B. Zhang, Y. Zhang, N. Gu, et al., Intrinsic [peroxidase](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0085)like activity of [ferromagnetic](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0085) nanoparticles, Nat. Nanotechnol. 2 (2007) 577– [583](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0085).
- [18] J.S. Mu, L. Zhang, G.Y. Zhao, Y. Wang, The crystal plane effect on the [peroxidase](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0090)like catalytic properties of Co3O4 [nanomaterials,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0090) Phys. Chem. Chem. Phys. 16 [(2014)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0090) 15709–15716.

- [19] A. Asati, S. Santra, C. Kaittanis, S. Nath, J.M. Perez, [Oxidase-like](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0095) activity of [polymer-coated](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0095) cerium oxide nanoparticles, Angew. Chem. Int. Ed. 48 (2009) [2308](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0095)–2312.
- [20] X.M. Chen, X.T. Tian, B.Y. Su, Z.Y. Huang, X. Chen, M. Oyama, Au [nanoparticles](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0100) on [citrate-functionalized](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0100) graphene nanosheets with a high peroxidase-like [performance,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0100) Dalton Trans. 43 (2014) 7449–7454.
- [21] S. Nath, C. Kaittanis, V. [Ramachandran,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0105) N.S. Dalal, J.M. Perez, Synthesis, magnetic [characterization,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0105) and sensing applications of novel dextran-coated iron oxide [nanorods,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0105) Chem. Mater. 21 (2009) 1761–1767.
- [22] S. Tembe, M. Karve, S. Inamdar, S. Haram, J. Melo, S.F. D'Souza, [Development](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0110) of [electrochemical](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0110) biosensor based on tyrosinase immobilized in composite [biopolymeric](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0110) film, Anal. Biochem. 349 (2006) 72–77.
- [23] S. Tembe, S. Inamdar, S. Haram, M. Karve, S.F. D'Souza, [Electrochemical](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0115) biosensor for catechol using [agarose-guar](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0115) gum entrapped tyrosinase, J. [Biotechnol.](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0115) 128 (2007) 80–85.
- [24] R.S.J. Alkasir, M. Ganesana, Y.H. Won, L. Stanciu, S. [Andreescu,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0120) Enzyme functionalized nanoparticles for [electrochemical](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0120) biosensors: a comparative study with [applications](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0120) for the detection of bisphenol A, Biosens. Bioelectron. 26 [(2010)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0120) 43–49.
- [25] S. Andreescu, O.A. Sadik, [Correlation](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0125) of analyte structures with biosensor [responses](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0125) using the detection of phenolic estrogens as a model, Anal. Chem. 76 [(2004)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0125) 552–560.
- [26] T. [Pirmohamed,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0130) J.M. Dowding, S. Singh, B. Wasserman, E. Heckert, A.S. Karakoti, et al., Nanoceria exhibit redox [state-dependent](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0130) catalase mimetic activity, Chem. [Commun.](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0130) 46 (2010) 2736–2738.
- [27] D. Andreescu, G. Bulbul, R.E. Ozel, N. Sardesai, A. Hayat, S. [Andreescu,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0135) Applications and implications of nanoceria reactivity: [measurement](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0135) tools and [environmental](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0135) impact, Environ. Sci. Nano (2014) .
- [28] A.Y. Estevez, J.S. Erlichman, The potential of cerium oxide [nanoparticles](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0140) (nanoceria) for [neurodegenerative](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0140) disease therapy, Nanomedicine 9 (2014) 1437–[1440](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0140).
- [29] A.Y. Estevez, S. [Pritchard,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0145) K. Harper, J.W. Aston, A. Lynch, J.J. Lucky, et al., [Neuroprotective](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0145) mechanisms of cerium oxide nanoparticles in a mouse [hippocampal](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0145) brain slice model of ischemia, Free Rad. Biol. Med. 51 (2011) 1155–[1163](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0145).
- [30] K.L. Heckman, W. [DeCoteau,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0150) A. Estevez, K.J. Reed, W. Costanzo, D. Sanford, et al., Custom cerium oxide [nanoparticles](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0150) protect against a free radical mediated autoimmune [degenerative](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0150) disease in the brain, ACS Nano 7 (2013) [10582](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0150)–10596.
- [31] Y. Li, X. He, J.-J. Yin, Y. Ma, P. Zhang, J. Li, et al., Acquired [superoxide-scavenging](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0155) ability of ceria [nanoparticles,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0155) Angew. Chem. Int. Ed. 54 (2015) 1832–1835.
- [32] X. Cai, S.A. Sezate, S. Seal, J.F. McGinnis, Sustained [protection](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0160) against [photoreceptor](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0160) degeneration in tubby mice by intravitreal injection of nanoceria, [Biomaterials](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0160) 33 (2012) 8771–8781.
- [33] S. [Chigurupati,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0165) M.R. Mughal, E. Okun, S. Das, A. Kumar, M. McCaffery, et al., Effects of cerium oxide nanoparticles on the growth of [keratinocytes,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0165) fibroblasts and vascular [endothelial](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0165) cells in cutaneous wound healing, [Biomaterials](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0165) 34 (2013) 2194–2201.
- [34] M. Ornatska, E. Sharpe, D. [Andreescu,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0170) S. Andreescu, Paper bioassay based on ceria [nanoparticles](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0170) as colorimetric probes, Anal. Chem. 83 (2011) 4273–4280.
- [35] R.E. Ozel, C. Ispas, M. Ganesana, J.C. Leiter, S. [Andreescu,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0175) Glutamate oxidase biosensor based on mixed ceria and titania [nanoparticles](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0175) for the detection of glutamate in hypoxic [environments,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0175) Biosens. Bioelectron. 52 (2014) 397–402.
- [36] A. Hayat, D. [Andreescu,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0180) G. Bulbul, S. Andreescu, Redox reactivity of cerium oxide [nanoparticles](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0180) against dopamine, J. Colloid Interface Sci. 418 (2014) 240– [245.](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0180)
- [37] X.G. Peng, L. Manna, W.D. Yang, J. Wickham, E. Scher, A. [Kadavanich,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0185) et al., Shape control of CdSe [nanocrystals,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0185) Nature 404 (2000) 59–61.
- [38] B.Z. Fang, M.S. Kim, J.H. Kim, M.Y. Song, Y.J. [Wang,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0190) H.J. Wang, et al., High Pt loading on [functionalized](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0190) multiwall carbon nanotubes as a highly efficient cathode [electrocatalyst](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0190) for proton exchange membrane fuel cells, J. Mater. Chem. 21 [(2011)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0190) 8066–8073.
- [39] Y. Xue, Y.W. Zhai, K.B. Zhou, L. [Wang,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0195) H.N. Tan, Q.F. Luan, et al., The vital role of buffer anions in the antioxidant activity of CeO2 [nanoparticles,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0195) Chem. Eur. J. 18 [(2012)](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0195) 11115–11122.
- [40] S. Singh, T. Dosani, A.S. Karakoti, A. Kumar, S. Seal, W.T. Self, A [phosphate](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0200)dependent shift in redox state of cerium oxide [nanoparticles](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0200) and its effects on catalytic properties, [Biomaterials](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0200) 32 (2011) 6745–6753.
- [41] C. Apetrei, M.L. [Rodríguez-Méndez,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0205) J.A. De Saja, Amperometric tyrosinase based biosensor using an [electropolymerized](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0205) phosphate-doped polypyrrole film as an [immobilization](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0205) support. Application for detection of phenolic compounds, [Electrochim.](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0205) Acta 56 (2011) 8919–8925.
- [42] Şenyurt Ö, F. [Eyidogan,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0210) R. Yılmaz, M.T. Öz, V.C. Özalp, Y. Arıca, et al., [Development](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0210) of a paper-type tyrosinase biosensor for detection of phenolic [compounds,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0210) Biotechnol. Appl. Biochem. (2014) n/a–n/a.
- [43] Y. Qu, M. Ma, Z. Wang, G. Zhan, B. Li, X. Wang, et al., Sensitive [amperometric](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0215) biosensor for phenolic compounds based on graphene–silk [peptide/tyrosinase](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0215) composite [nanointerface,](http://refhub.elsevier.com/S0003-2670(15)00562-0/sbref0215) Biosens. Bioelectron. 44 (2013) 85–88.