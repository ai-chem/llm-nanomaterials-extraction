<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Subscriber access provided by UNIV OF LETHBRIDGE

## Article

## **Single Nanoparticle to 3D Supercage: Framing for an Artificial Enzyme System**

Ren Cai, Dan Yang, Shengjie Peng, Xigao Chen, Yun Huang, Yuan Liu, Weijia Hou, Shengyuan Yang, Zhenbao Liu, and Weihong Tan J. Am. Chem. Soc., **Just Accepted Manuscript** • DOI: 10.1021/jacs.5b09337 • Publication Date (Web): 13 Oct 2015

**Downloaded from http://pubs.acs.org on October 14, 2015**

### **Just Accepted**

"Just Accepted" manuscripts have been peer-reviewed and accepted for publication. They are posted online prior to technical editing, formatting for publication and author proofing. The American Chemical Society provides "Just Accepted" as a free service to the research community to expedite the dissemination of scientific material as soon as possible after acceptance. "Just Accepted" manuscripts appear in full in PDF format accompanied by an HTML abstract. "Just Accepted" manuscripts have been fully peer reviewed, but should not be considered the official version of record. They are accessible to all readers and citable by the Digital Object Identifier (DOI®). "Just Accepted" is an optional service offered to authors. Therefore, the "Just Accepted" Web site may not include all articles that will be published in the journal. After a manuscript is technically edited and formatted, it will be removed from the "Just Accepted" Web site and published as an ASAP article. Note that technical editing may introduce minor changes to the manuscript text and/or graphics which could affect content, and all legal disclaimers and ethical guidelines that apply to the journal pertain. ACS cannot be held responsible for errors or consequences arising from the use of information contained in these "Just Accepted" manuscripts.

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Journal of the American Chemical Society is published by the American Chemical Society. 1155 Sixteenth Street N.W., Washington, DC 20036 Published by American Chemical Society. Copyright © American Chemical Society.

However, no copyright claim is made to original U.S. Government works, or works produced by employees of any Commonwealth realm Crown government in the course of their duties.

# **Single Nanoparticle to 3D Supercage: Framing for an Artificial Enzyme System**

Ren Cai,† Dan Yang,# Shengjie Peng,# Xigao Chen,† Yun Huang,† Yuan Liu,† Weijia Hou,† ShengYuan Yang,† § Zhenbao Liu,† and Weihong Tan†,‡*

† Center for Research at Bio/Nano Interface, Department of Chemistry and Department of Physiology and Functional Genomics, Health Cancer Center, UF Genetics Institute and McKnight Brain Institute, University of Florida, Gainesville, Florida 32611-7200, United States

‡Molecular Science and Biomedicine Laboratory, State Key Laboratory for Chemo/Bio Sensing and Chemometrics, College of Chemistry and Chemical Engineering, College of Biology, and Collaborative Research Center of Molecular Engineering for Theranostics, Hunan University, Changsha 410082, China

# School of Materials Science and Engineering, Nanyang Technological University, 50 Nanyang Avenue, Singapore 639798, Singapore

§College of Public Health, University of South China, Hengyang 421001, China

Supporting Information

**ABSTRACT:** A facile strategy has been developed to fabricate Cu(OH)2 supercages (SCs) as an artificial enzyme system with intrinsic peroxidase mimic activities (PMA). SCs with high catalytic activity and excellent recyclability were generated via direct conversion of amorphous Cu(OH)2 nanoparticles (NPs) at room temperature. More specifically, the process that takes a single nanoparticle to a three-dimensional (3D) supercage involves two basic steps. First, with addition of a copper-ammonia complex, the Cu2+ ions, which located on the surface of amorphous Cu(OH)2 NPs, would evolve into a fine lamellar structure by coordination and migration, and eventually converts to 1D nanoribbons around the NPs. Second, accompanied by the migration of Cu2+, a hollow cavity is generated in the inner NPs, such that a single nanoparticle eventually becomes a nanoribbon-assembled 3D hollow cage. These Cu(OH)2 SCs were then engineered as an artificial enzymatic system with higher efficiency for intrinsic PMA than that of a natural enzyme - horseradish peroxidase.

#### **Introduction**

It is well established that the self-assembly of nanoparticle building blocks into highly ordered superstructures results in properties superior to those of the individual building blocks, making such well-defined superstructures ideal in a wide range of technological applications, such as photonics,1 catalysis,2 biomedical diagnosis,3 sensors, 4 magnetic resonance imaging,5 plasmonics,6 and surface-enhanced Raman spectroscopy.7 Up to now, colloidal assembly of nanoparticles (NPs) into designed superstructures with various geometries, such as belts, spheres, cubes and rods, has been achieved with excellent control.8 For example, quantum belts were obtained through lamellar assembly of cadmium selenide nanoclusters.9 Three-dimensional plasmonic Au nanoclusters were prepared through a polymer-assisted assemble approach.10 An assembled superstructure was obtained from anisotropic Pt nanocubes using a home-built evaporation-controlled system.11 Despite of the enormous pioneering attempts, most of these superstructures have been formed by a time-consuming "bottom-up" approach, during which the uniformity in particle size, the properties of the solvent, as well as inter-particle interactions, must all be carefully controlled to avoid disintegration or deformation of the superstructures. 12

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of the transformation of Cu(OH)2 nanoparticles into Cu(OH)2 supercages. The process is shown in three stages, connected by arrows indicating the progression:

1. Cu(OH)2 Nanoparticles: The initial stage shows a cluster of nanoparticles represented as a dense, elliptical arrangement of vertical structures.

2. Intermediate stage: The second image shows the nanoparticles beginning to align and form more organized, parallel structures. The individual components are more distinct and separated compared to the initial nanoparticle cluster.

3. Cu(OH)2 Supercages: The final stage displays a highly organized structure of intersecting vertical and horizontal components, forming a cage-like arrangement. This represents the supercage structure formed by the Cu(OH)2 nanoparticles.

The transformation process illustrates the self-assembly of Cu(OH)2 nanoparticles into a more complex, ordered supercage structure. This type of transformation is significant in materials science and nanotechnology, as it demonstrates the ability to create larger, organized structures from smaller nanoparticles, potentially leading to materials with unique properties or applications.

The chemical formula Cu(OH)2 represents copper(II) hydroxide. In SMILES notation, this would be written as [Cu](O)(O), though it's important to note that this doesn't capture the polymeric nature of the actual structure in the nanoparticles or supercages.</DESCRIPTION_FROM_IMAGE>

**Scheme 1.** Schematic illustration of the synthesis process of Cu(OH)2 supercages.

In contrast, we developed a facile top-down process for the preparation of Cu(OH)2 supercages (SCs). These Cu(OH)2 SCs, which are packed by 1D nanoribbons, are prepared by transformation of a single nanoparticle with the assistance of NH3 ·H2O (**Scheme 1)**. The process that takes a single nanoparticle to a three-dimensional (3D) supercage involves two basic steps. First, with addition of a copper-ammonia complex, the Cu2+ ions, which located on the surface of amorphous Cu(OH)2 NPs, would evolve into a fine lamellar structure by coordination and migration, and eventually converts to 1D nanoribbons around the NPs. Second, accompanied by the migration of Cu2+, a hollow cavity is generated in the inner NPs, such that a single nanoparticle eventually becomes a nanoribbon-assembled 3D hollow cage. Both formation and decomposition of SCs can be tuned simply by changing the concentration of NH3 ·H2O. More significantly, high catalytic activity can be expected from an artificial enzymatic system constructed by such SCs, as 1) a large surface area results from the small size of the nanoribbons; and 2) the collision probability of the active molecules can be increased when they are trapped in the "cages".

#### **Experimental Section**

**Synthesis of amorphous Cu(OH)2 nanoparticles.** The synthesis of amorphous Cu(OH)2 nanoparticles (**Figure 3a**) followed the approach developed by our group based on a previous strategy,13 which involves reacting CuCl2 with NaBH4 in ethanol. In our experiment (**Scheme S1**), CuCl2 ·2H2O (17 mg), polyvinylpyrrolidone (PVP) (molecular weight 55,000) (130.5 mg), and ethanol (40 mL) were added into a 100 mL flat bottom flask one by one. After 10 min ultrasonication and 30 min stirring, 7.7 mg NaBH4 were dissolved in 10 mL ethanol and quickly added to the solution under vigorous stirring. After 72h, the products were collected by centrifugation and washed with ethanol three times.

**Synthesis of 3D Cu(OH)2 supercages.** In a typical experiment, amorphous Cu(OH)2 nanoparticles (9.7 mg) and PVP (molecular weight 1,300,000) (20 mg) were dispersed in 20 mL DI-water by ultrasonication for 15 min in a 100 mL flat bottom flask. The solution was vigorously stirred for 15 min. A copper-ammonia complex solution was prepared from 5 mL Cu(NO3)2 ·3H2O (24.16 mg) aqueous solution plus 15 mL NH3 ·H2O solution (400 µL NH3 ·H2O (29 %) plus 14.6 mL DIwater). Then, 20 mL of copper-ammonia complex solution were added to the above mixture of amorphous Cu(OH)2 nanoparticles in 1 minute and stirred for 10 minutes. The products were collected by centrifugation and washed with acetone and methanol three times.

Using the same strategy, Cu(OH)2 supercages were disassembled by the addition of 200 µL, 600 µL and 800 µL NH3 ·H2O (29 %) to form a solution of copper-ammonia complex.

**Catalyzed oxidation:** Unless otherwise stated, steady-state kinetic assays were carried out at 25 oC in a 1.5-mL tube with 30 µg Cu(OH)2 SCs (3.5 x 109 supercages) or 300 ng HRP (4.1 x 1012 enzyme molecules) in 500 µL of reaction buffer (0.2 M NaAc, pH 4.5) in the presence of 530 µM H2O2 for Cu(OH)2 SCs or HPR, using 800 µM TMB as the substrate. For experiments at different pH (1~12) at 25 oC, 30 µL H2O2 (30 %) were added to 400 µL reaction buffer and vortexed for 4 min. Then, 40 µL TMB (10 mM) were added into the mixture and vortexed for another 4 min. Finally, 30 µL Cu(OH)2 SCs (1 mg/mL) were quickly added to the mixture. Immediately after addition of Cu(OH)2 SCs, color changes were observed. All reactions were monitored in time scan mode at 652 nm using a Cary Bio-100 UV/Vis spectrometer (Varian).

To study the effect of different temperature (22 oC ~ 65 oC) at pH=4.5, 400 µL of reaction buffer were held at the desired temperature for 5 min. Then, 30 µL H2O2 (30%) were added to the reaction buffer and vortexed for 1 min, and the mixture was held at that temperature for 4 min. Then, 40 µL TMB (10 mM) were added to the mixture and vortexed for 1 min, and the mixture was held at that temperature for another 4 min. Finally, 30 µL Cu(OH)2 SCs (1 mg/mL) were quickly added to the mixture. The reaction was monitored in time scan mode at 652 nm using a Cary Bio-100 UV/Vis spectrometer (Varian).

**Results and Discussion** 

<DESCRIPTION_FROM_IMAGE>This image is a composite of three transmission electron microscopy (TEM) images labeled a, b, and c, showing nanostructures at different magnifications.

Image a:
This is a low-magnification TEM image showing a large number of square-shaped nanoparticles dispersed across the field of view. The particles appear to be uniformly sized and randomly oriented. The scale bar indicates 1 μm.

Image b:
This is a higher magnification TEM image focusing on a smaller group of the square-shaped nanoparticles. The particles are more clearly visible, revealing their hollow cube-like structure. The edges of the cubes appear darker, suggesting a higher material density at the edges. The scale bar indicates 200 nm.

Image c:
This is a high-resolution TEM image showing the atomic lattice structure of a single nanoparticle. The image reveals a regular pattern of atomic planes. A measurement is indicated on the image, showing a lattice spacing of 0.221 nm. In the top right corner, there is an inset showing the electron diffraction pattern, which appears as a series of concentric rings, indicating the crystalline nature of the material.

The images collectively demonstrate the hierarchical structure of these nanomaterials, from the ensemble of particles to the atomic-scale details. The square shape and hollow structure suggest these could be metal-organic framework (MOF) nanoparticles or similar porous nanomaterials. The uniform size and shape distribution in image a indicates a well-controlled synthesis process.

No chemical structures or SMILES notations are present in this image. The image does not contain any graphs requiring detailed interpretation. The captions within the image are limited to scale bars and the lattice spacing measurement, which have been described in the context of each sub-image.</DESCRIPTION_FROM_IMAGE>

**Figure 1.** Characterization of Cu(OH)2 supercages (SCs): a) lowmagnification and b) high-magnification TEM images; c) HRTEM image (the inset is SAED).

In a typical procedure, Cu(OH)2 NPs (**Figure S1** and **S2a** in Supporting Information (SI)) was employed as a starting materials in a top-down process. The Cu(OH)2 SCs obtained after a copper-ammonia complex ([Cu(NH3)n](NO3)2) was added to the mixture of Cu(OH)2 NPs and PVP with vigorous stirring at room temperature. The resulting products were collected by centrifugation after stirring for 10 minutes. Lowmagnification transmission electron microscopy (TEM) showed that uniform hollow nanocages with an average edge length of ~200 nm were formed (**Figure 1a**). Highmagnification TEM (**Figure 1b**) images further revealed that

these hollow nanocages were composed of packed nanoribbons. The wall thickness of the hollow supercages was about 30 nm, and the length of the nanoribbons ranged from 150 to 250 nm. The crystal phase of the hollow nanocages was determined to be orthorhombic Cu(OH)2 (JCPDS card no. 13- 0420) from the corresponding powder X-ray diffraction (XRD) pattern shown in **Figure 3b**. The observed lattice fringe of 0.221 nm in the high-resolution TEM (HRTEM) image (**Figure 1c**) corresponds to the d spacing of the (130) lattice planes in Cu(OH)2 . The ring-type selected-area electron diffraction (SAED) pattern (inset in **Figure 1c**) indicates the polycrystalline nature of these Cu(OH)2 SCs. To determine the specific surface area, full nitrogen sorption isotherms of these supercages were measured. According to the Brunauer-Emmett-Teller (BET) model and the data in **Figure S3**, the specific surface area of the supercages was measured to be 172 m 2 g -1 .

<DESCRIPTION_FROM_IMAGE>This image is a compilation of eight transmission electron microscopy (TEM) micrographs labeled from (a) to (h), showing nanostructures at different magnifications. The micrographs are arranged in four rows with two images per row.

(a) Scale bar: 1 μm. Shows numerous small, elongated structures dispersed randomly across the field of view. These appear to be nanorods or nanowhiskers.

(b) Scale bar: 200 nm. Displays larger square-shaped structures with sharp edges and corners, along with some elongated structures. These could be nanosheets or nanoplatelet structures.

(c) Scale bar: 1 μm. Reveals a high density of small square or rectangular structures distributed across the image. These are likely nanosheet structures viewed from the top.

(d) Scale bar: 200 nm. Shows several larger square-shaped structures, similar to those in (b) but at a lower density. Some elongated structures are also visible.

(e) Scale bar: 1 μm. Displays a mixture of small square structures and elongated structures, similar to a combination of (a) and (c) but at a different magnification.

(f) Scale bar: 200 nm. Shows larger square structures along with some elongated structures. The square structures appear to have more irregular edges compared to (b) and (d).

(g) Scale bar: 1 μm. Reveals a high density of small, predominantly elongated structures distributed across the image, similar to (a) but with some variations in size and shape.

(h) Scale bar: 200 nm. Displays a mixture of elongated structures and some square structures. The elongated structures appear to be bundled or aggregated in some areas.

These micrographs likely represent different synthesis conditions or treatments of nanostructured materials, possibly metal oxides or layered double hydroxides. The variations in structure (rods vs. sheets) and size distribution across the different images suggest systematic changes in synthesis parameters or post-synthesis treatments.</DESCRIPTION_FROM_IMAGE>

**Figure 2.** TEM images of nanoribbon assembly for Cu(OH)2 supercages. Samples prepared from synthesis using different amounts of NH3 in copper-ammonia complex: a) and b) 200 µL; c) and d) 400 µL; e) and f) 600 µL; g) and h) 800 µL.

To investigate the growth process of the supercages, aliquot reaction products were prepared by adding different amounts of 29% NH3 ·H2O (200 µL, 400 µL, 600 µL and 800 µL) to the copper-ammonia complex. As revealed by TEM images in **Figure 2**, relatively dense "cages" were formed in the aliquot with 200 µL NH3 ·H2O added (**Figure 2a-b**). They were piled up by 1D nanoribbons with length in the range of 200 ~250 nm, and, importantly, cavities were faintly visible at the center of the "cages". When the amount of NH3 ·H2O was increased to 400 µL, nearly-perfect supercages with side length around 200 nm could be observed (**Figure 2c-d**). However, further increase of NH3 ·H2O solution to 600 µL caused slight disassembly of the supercages, in which some nanoribbons were dissociated (**Figure 2e-f**). Full disintegration of the supercages was observed when 800 µL NH3 ·H2O was added, leaving well-dispersed nanoribbons (**Figure 2g-h**). It is worth mentioning that the entire process was also monitored by XRD, which displayed (**Figure 3**) that all the above products are orthorhombic Cu(OH)2 .

<DESCRIPTION_FROM_IMAGE>The image shows a series of X-ray diffraction (XRD) patterns labeled from 'a' to 'e'. The x-axis represents the 2θ angle in degrees, ranging from 10 to 80 degrees. The y-axis represents intensity in arbitrary units (a.u.).

Pattern 'a' appears to be a baseline or background measurement, showing minimal peaks.

Pattern 'b' is the most detailed, with clearly labeled peaks corresponding to different crystal planes. The peaks are labeled with Miller indices: (020), (021), (200), (111), (022), (130), (131), (150), (200), and (152). This pattern also includes red vertical lines at the bottom, which likely correspond to the reference pattern JSCPD No.: 13-0420.

Patterns 'c', 'd', and 'e' show similar peak positions to pattern 'b', but with varying intensities and slight shifts in peak positions. These variations could indicate different sample preparations, treatments, or compositions of the same basic material.

The most prominent peaks across all patterns occur around 2θ values of:
- 15 degrees
- 22 degrees
- 35-40 degrees (a cluster of peaks)
- 50 degrees

The overall pattern suggests a crystalline material, likely a metal oxide or similar inorganic compound. The presence of multiple patterns (a-e) suggests a comparative study, possibly examining the effects of different synthesis conditions, doping, or heat treatments on the crystal structure of the material.</DESCRIPTION_FROM_IMAGE>

**Figure 3.** XRD patterns of the corresponding samples from the synthesis with different amounts of NH3 reacted in copperammonia complex: a) 0 µL; b) 400 µL; c) 200 µL; d) 600 µL; e) 800 µL.

<DESCRIPTION_FROM_IMAGE>The image depicts a three-part (a, b, c) schematic representation of chemical reactions and structural transformations involving copper complexes.

a) This section shows the conversion of a copper hexahydrate complex [Cu(H2O)6]2+ to a copper hexaammine complex [Cu(NH3)6]2+ upon reaction with ammonia (NH3·H2O). The reaction is represented by an arrow. The complexes are depicted as stylized structures surrounded by ligands.

b) This part illustrates a more detailed transformation process:
1. Starting with a copper tetraammine complex [Cu(NH3)4]2+
2. Conversion to copper tetrahydroxide [Cu(OH)4]2-
3. Formation of a polymeric copper hydroxide structure

The chemical structures are shown in skeletal form. The copper tetraammine complex is represented as a stylized structure similar to part (a). The polymeric copper hydroxide is depicted as a repeating unit of Cu-OH-Cu bridges.

SMILES for copper tetraammine: [Cu](N)(N)(N)N
SMILES for copper tetrahydroxide: [Cu](O)(O)(O)O
SMILES for polymeric copper hydroxide: [Cu]([OH])([OH])[Cu]([OH])([OH])

c) This section demonstrates the further transformation of the polymeric copper hydroxide structure:
1. Starting from the polymeric structure shown in (b)
2. Progressing through intermediate stages of aggregation and alignment
3. Ending with a highly ordered, stacked structure

The transformation is represented by a series of arrows, showing the gradual organization of the polymeric units into a more compact and aligned configuration.

Throughout the image, dotted arrows are used to indicate the progression of reactions or structural changes. The schematic nature of the representation emphasizes the key structural features and transformations without detailed atomic-level accuracy.</DESCRIPTION_FROM_IMAGE>

**Figure 4.** Schematic of (a) [Cu(HO2 )6 ] 2+ coordinating with NH3 ·H2O to generate [Cu(NH3 )n ] 2+; (b) coordination growth of the lamellar structure; (c) formation of nanoribbons and Cu(OH)2 supercage.

Based on the above results, a scheme can be proposed for the formation of SCs (**Scheme 1** and **Figure 4)**. Before the reaction, a protective layer of PVP is generated by mixing PVP with Cu(OH)2 NPs in order to control the reaction rate.14 With addition of the copper-ammonia complex ([Cu(H2O)6] 2+ + n NH3 ·H2O ⇌ [Cu(NH3)n] 2+ + (n+6) H2O, NH3 ·H2O ⇌ NH4 + + OH- ), Cu2+ ions ([Cu(H2O)6] 2+) on the surface of the amorphous Cu(OH)2 NPs (**Figure S1**) first coordinate with NH3 ·H2O to generate [Cu(NH3)n] 2+ (**Figure 4a**). [Cu(NH3)n] 2+ tends to coordinate in a square planar manner with OH- , 15 leading to an extended complex chain structure on the particle surface, i.e., [Cu(NH3)n] 2+ → [Cu(NH3)n-1(OH)]+ → [Cu(NH3)n-2(OH)2] →.....→ [Cu(OH)n] (n-2)- (**Figure 4b**).16 These chains can be connected through the coordination of OH and Cu2+ , growing to a lamellar structure (nanoribbons) on the surface of the original NPs (**Figure 4b**).17 As a result, Cu2+ migrates from the inner NPs to the tips of nanoribbons in the form of [Cu(NH3)n-m(OH)m] (2-m)+ , 16 generating, in turn, a hollow cavity in the original NPs (**Figure 2a-b** and **Figure 4c**). Since nanoribbons are stacked around the particles through hydrogen bonds,18 3D hollow cages are eventually formed (**Figure 2c-d** and **Figure 4c**). It's interesting that the obtained SCs have similar size with amorphous Cu(OH)2 NPs (200 nm ~250 nm, **Figure S1**). Further addition of NH3 ·H2O was shown to weaken the hydrogen bonds between the nanoribbons thus causing partial breakdown of the cages (NH3 ·H2O ⇌ NH4 + + OH- , Cu(OH)2 + 2OH- ⇌ [Cu(OH)4] 2-) (**Figure 2e-f**). Finally, by increasing the concentration of NH3 ·H2O, the supercages can be fully disassembled into well-dispersed nanoribbons (**Figure 2g-h**). It is worth noting that all assembly and disassembly processes occur at room temperature, indicating that this is a green procedure with low energy cost.

<DESCRIPTION_FROM_IMAGE>The image consists of three parts labeled a, b, and c.

Part a: Graph of Cu(OH)2 SC's absorbance spectra
- X-axis: Wavelength (nm) from 580 to 720 nm
- Y-axis: Absorbance from 0 to 1.1
- Multiple spectra shown, labeled with numbers: 1, 2.5, 3.5, 4.8, 5.5
- Peak absorbance occurs around 660-680 nm
- Absorbance intensity increases with increasing number label

Part b: Graph of HRP absorbance spectra
- X-axis: Wavelength (nm) from 580 to 720 nm
- Y-axis: Absorbance from 0 to 1.0
- Multiple spectra shown, labeled with numbers: 0, 1, 2.5, 4, 8, 9, 9.5
- Peak absorbance occurs around 660-680 nm
- Absorbance intensity increases with increasing number label

Part c: Time-lapse image of reaction progression
- Shows 6 test tubes with liquid
- Time points labeled: 0 min, 0.5 min, 1 min, 2.5 min, 3.5 min, 4.5 min, 5.5 min
- Liquid appears to change in intensity from left to right

The graphs demonstrate the change in absorbance spectra for Cu(OH)2 SC's and HRP over time or with changing conditions. The time-lapse image likely corresponds to the spectral changes observed in the graphs, showing the visual progression of the reaction over 5.5 minutes.</DESCRIPTION_FROM_IMAGE>

**Figure 5.** The absorption spectra for the oxidation catalysis process (min) of a) Cu(OH)2 SCs and b) HRP, where TMB was used as the substrate in the presence of H2O2 ; pH was 4.5, and temperature was 25 oC. c) Photographs of Cu(OH)2 SCs catalyzed oxidation of TMB in the presence of H2O2 at different times.

<DESCRIPTION_FROM_IMAGE>The image contains six graphs labeled a through f, each showing different relationships and measurements related to enzyme activity and kinetics.

Graph a: Shows the relative activity (%) of Cu(OH)2 SCs and HRP as a function of pH. Both enzymes show a bell-shaped curve with peak activity around pH 5. Cu(OH)2 SCs have a higher maximum activity (near 100%) compared to HRP (about 85%). The activity for both enzymes drops sharply below pH 3 and above pH 7.

Graph b: Depicts the relative activity (%) of Cu(OH)2 SCs and HRP versus temperature (°C). Cu(OH)2 SCs maintain high activity (>80%) up to about 45°C, then decline. HRP shows peak activity around 30°C, then decreases steadily with increasing temperature. At 60°C, HRP activity is about 20% while Cu(OH)2 SCs retain about 60% activity.

Graph c: Shows velocity (10^-8 M s^-1) versus TMB concentration (μM). The curve suggests Michaelis-Menten kinetics, with velocity increasing rapidly at low substrate concentrations and approaching a maximum at high concentrations. The maximum velocity appears to be around 45 x 10^-8 M s^-1 at 900 μM TMB.

Graph d: Similar to graph c, but for H2O2 concentration (μM) instead of TMB. The curve also follows Michaelis-Menten kinetics, with a maximum velocity of about 40 x 10^-8 M s^-1 at 800 μM H2O2.

Graph e: Lineweaver-Burk plot (double reciprocal plot) for TMB, showing 1/Velocity (10^8 M^-1 s) versus 1/TMB concentration (mM^-1). The linear relationship indicates adherence to Michaelis-Menten kinetics.

Graph f: Lineweaver-Burk plot for H2O2, showing 1/Velocity (10^8 M^-1 s) versus 1/H2O2 concentration (mM^-1). Again, the linear relationship confirms Michaelis-Menten kinetics for the H2O2 substrate.

These graphs collectively provide information on the pH and temperature optima for the enzymes, as well as their kinetic parameters with respect to two different substrates (TMB and H2O2).</DESCRIPTION_FROM_IMAGE>

**Figure 6.** a) and b) pH- and temperature-dependent peroxidase mimic activity of Cu(OH)2 SCs and HRP. a) Cu(OH)2 SCs and HRP show an optimal pH of 4.5; b) Cu(OH)2 SCs and HRP show an optimal temperature around 25 oC and 32 oC, respectively. Experiments were carried out using 30 µg SCs or 300 ng HRP in a reaction volume of 0.5 mL, in 0.2 M NaAc buffer, with 800 µM TMB as substrate. H2O2 concentration was 530 µM for SCs and HRP. The maximum point in each curve (a-b) was set as 100%. Steady-state kinetic assays and catalytic mechanism of Cu(OH)2 SCs: c) The concentration of H2O2 was 530 µM, and TMB concentration was varied. d) The concentration of TMB was 800 µM, and H2O2 concentration was varied. e) and f) Double reciprocal plots for Cu(OH)2 SCs with the concentration of e) H2O2 fixed and TMB varied and f) TMB fixed and H2O2 varied.

Artificial enzymes are very important components of biomimetic chemistry, which aims to imitate the general principles of natural enzymes using alternative materials.19 Compared with natural enzymes, artificial enzyme systems display high operational stability, low cost, facile preparation and tunable catalytic activity,19,20 and they are promising in such applications as biosensors, immunoassays, cancer diagnostics, neuroprotection, stem cell growth, and pollutant removal.19,21 For our first set of experiments, we investigated if Cu(OH)2 SCs would exhibit peroxidase mimic activities (PMA) for the substrate 3,3',5,5'-tetramethylbenzidine (TMB). For comparison, the activity of horseradish peroxidase (HRP), which is one of the most utilized natural enzymes for

biocatalysis,22 was also investigated. After addition of Cu(OH)2 SCs into the TMB-H2O2 solution (pH 4.5) (**Figure S4-S5**), the solution changed from colorless to a deep blue within 5 minutes at room temperature, as shown by the photo and UV/Vis absorption curves (**Figure 5**). This indicates that the reaction of H2O2 and TMB could be catalyzed by Cu(OH)2 SCs (**Figure S6**). The characteristic absorption peak at 652 nm was chosen as the parameter to monitor the catalysis process. 23 However, for HRP, a relatively slow reaction rate was observed (**Figure 5b**), even though the concentration of HRP was 2000 times higher than that of Cu(OH)2 SCs (Please see the Calculation Section in SI). In addition, the catalytic ability of Cu(OH)2 SCs is better than that of amorphous Cu(OH)2 NPs (**Figure S7**). This experiment confirmed that Cu(OH)2 SCs could serve as an efficient artificial enzymatic system for intrinsic PMA.21

Next, the catalytic activity of Cu(OH)2 SCs was systematically investigated at different pHs and temperatures. To accomplish this, PMA of Cu(OH)2 SCs was measured while varying the pH from 1 to 12 and the temperature from 22 oC to 65 oC. For comparison, the activity of HRP using the same parameters was also studied. The results in **Figure 6a**  show the high PMA of Cu(OH)2 SCs in the pH range of 3 to 5, with catalytic efficiency reaching above 90%. Cu(OH)2 SCs also exhibited excellent peroxidase catalytic activity over a broad range of temperatures (**Figure 6b**). The optimum pH and temperature for Cu(OH)2 SCs catalysis are approximately 4.5 and 25 oC, respectively, which are very close to those of HRP (**Figure 6a-b**). To test the reusability of the SCs, we used fresh and recovered Cu(OH)2 SCs (artificial enzyme, 1.5 mg) to catalyze the oxidation of TMB (800 µM TMB) by H2O2 (530 µM) in 25 mL NaAc buffer (0.2 M NaAc, pH 4.5). The absorbance was measured after 4.5 minutes reaction (round 1). The recovered Cu(OH)2 SCs were separated from the reaction mixture by centrifuging, then washed with 20 mL ethanol 2 times and with 20 mL ether solvent 1 time to remove the product. The recycled Cu(OH)2 SCs were mixed with a fresh reaction mixture and the absorbance at 4.5 min was measured (round 2). The procedure was repeated once more (round 3). The results (**Figure S8**) show that the catalytic efficiency (ratio of the absorbance at 4.5 min to the absorbance of the fresh SCs at 4.5 min) was 87.6% for round 2 and 75.2% for round 3.

|             | [E] (M)       | Substrate | Km (mM) | Vmax (M S-1) | Kcat (s-1) |
|-------------|---------------|-----------|---------|--------------|------------|
| Cu(OH)2 SCs | 11.63 x 10-12 | TMB       | 2.448   | 44.83 x 10-8 | 3.83 x 104 |
| Cu(OH)2 SCs | 11.63 x 10-12 | H2O2      | 0.199   | 42.51 x 10-8 | 3.66 x 104 |
| HRP26       | 2.5 x 10-11   | TMB       | 0.434   | 10 x 10-8    | 4.00 x 104 |
| HRP26       | 2.5 x 10-11   | H2O2      | 3.700   | 8.71 x 10-8  | 3.48 x 104 |

**Table 1** Comparison of the kinetic parameters of Cu(OH)2 SCs and HRP. [E] is the enzyme (or SCs) concentration, *Km* is the Michaelis constant, Vmax is the maximal reaction velocity, and *kcat* is the catalytic constant, where *kcat* = Vmax /[E].

#### **Journal of the American Chemical Society**

**Page 6 of 8**

To provide further insight, the catalytic activity of the Cu(OH)2 SCs was studied by enzyme kinetics theory and methods.23,24 Typical Michaelis-Menten curves (**Figure 6c-d**) were obtained for a range of TMB or H2O2 concentrations, and fitted by the Lineweaver-Burk equation (**Figure 6e-f**).22 Important enzyme kinetic parameters, such as the Michaelis-Menten constant (Km) and maximum initial velocity (Vmax), were obtained and are listed in **Table 1**. Km is an indicator of enzyme affinity to substrate,25 with a high Km value representing a weak affinity and vice versa. Although the apparent Km value of Cu(OH)2 SCs with TMB as the substrate was significantly higher than that of HRP,26 the apparent Km value of Cu(OH)2 SCs with H2O2 as the substrate was about 20 times lower than that of HRP. Thus Cu(OH)2 SCs showed better affinity to H2O2 compared to HRP. This is ascribed to the high surface area-to-volume ratio in Cu(OH)2 SCs, leading to more active sites for H2O2 , which, in turn, results in a lower Km and a higher Vmax, giving an overall *kcat* (Vmax/[E]) of approximately the same value for SCs and HRP, which are around 2 times higher than the values of irregular-shaped platinum nanoparticles in the previous report.27 In addition, Cu(OH)2 SCs would have strong ability to convert H2O2 into hydroxyl radical (·OH) and thus exhibit excellent peroxidaselike activity.28

#### **Conclusion**

We have developed a facile strategy to fabricate 3D Cu(OH)2 SCs via direct conversion of amorphous Cu(OH)2 NPs at room temperature. The SCs displayed lengths in the range of 150~200 nm and an average wall thickness of around 30 nm. To further understand the mechanism of SCs formation, an assembly/disassembly process for the specific shape was also studied. The artificial enzyme system composed of these SCs exhibited high catalytic activity and excellent reusability as mimics of HRP. By leveraging the color changes caused by the artificial enzymatic system, these SCs can also be utilized for the detection of biomolecules. The successful demonstration of this work may offer researchers engaged in materials science guidelines toward the construction of various superstructures into organized functional systems.

#### **ASSOCIATED CONTENT**

#### **Supporting Information**

Detailed experimental procedures and supplementary data. This material is available free of charge via the internet at http://pubs.acs.org.

#### **AUTHOR INFORMATION**

**Corresponding Author** 

tan@chem.ufl.edu

#### **Notes**

The authors declare no competing financial interests.

#### **ACKNOWLEDGMENT**

This work is supported by grants awarded by the National Institutes of Health (GM079359, GM111386 and CA133086), by the National Key Scientific Program of China (2011CB911000), NSFC grants (NSFC 21221003 and NSFC 21327009) and China National Instrumentation Program 2011YQ03012412.

#### **REFERENCES**

(1) Talapin, D. V.; Lee, J. S.; Kovalenko, M. V.; Shevchenko, E. V. *Chem. Rev.* **2010,** *110*, 389-458.

(2) Chen, C. Nan, C.; Wang, D.; Su, Q.; Duan, H.; Liu, X.; Zhang, L.; Chu, D.; Song, W.; Peng, Q.; Li, Y. *Angew. Chem. Int. Ed.,* **2011,** *50*, 3725-3729.

(3) Zhu, G.; Hu, R.; Zhao, Z.; Chen, Z.; Zhang, X.; Tan, W. *J. Am. Chem. Soc.*, **2013,** *135*, 16438-16445.

(4) Zheng, Y.; Thai, T.; Reineck, P.; Qiu, L.; Guo, Y.; Bach, U. *Adv. Funct. Mater.,* **2013,** *23*, 1519-1526.

(5) Chen, O.; **Riedemann**, L.; Etoc, F.; Herrmann, H.; Coppey, M.; Barch, M.; Farrar, C. T.; Zhao, J.; Bruns, O. T.; Wei, H.; Guo, P.; Cui, J.; Jensen, R.; Chen, Y.; Harris, D. K.; Cordero, J. M.; Wang, Z.; Jasanoff, A.; Fukumura, D.; Reimer, R.; Dahan, M.; Jain, R. K.; Bawendi, M. G. *Nat. Commun.,* **2014**, *5*, 5093–5105.

(6) Chen, H.; Shao, **L**.; Li, Q.; Wang, J. *Chem. Soc. Rev.,* **2013,** *42*, 2679-2724.

(7) Lee, A.; Andrade, G. F. S.; Ahmed, A.; Souza, M. L.; Coombs, N.; Tumarkin, E.; Liu, K.; Gordon, R.; Brolo, A. G.; Kumacheva, E. *J. Am. Chem. Soc.*, **2011,** *133*, 7563-7570.

(8) (a) Wang, T.; LaMontagne, D.; Lynch, J.; Zhuang, J.; Cao, Y. C. *Chem. Soc. Rev.* **2013,** *42*, 2804-2823; (b) Zhang, S.-Y.; Regulacio, M. D.; Han, M.-Y. *Chem. Soc. Rev.* **2014,** *43*, 2301-2323; (c) Singh, G.; Chan, H.; Baskin, A.; Gelman, E.; Repnin, N.; Král, P.; Klajn, R. *Science* **2014,** *345*, 1149-1153; (d) Wang, T.; Wang, X.; LaMontagne, D.; Wang, Z.; Cao, Y. C. *J. Am. Chem. Soc.*, **2013,** *135*, 6022-6025.

(9) Liu, Y.-H.; Wang, F.; Wang, Y.; Gibbons, P. C.; Buhro, W. E. *J. Am. Chem. Soc.*, **2011,** *133,* 17005-17013.

(10) Urban, A. S.; Shen, X.; Wang, Y.; Large, N.; Wang, H.; Knight, M. W.; Nordlander, P.; Chen, H.; Halas, N. J. *Nano lett.,* **2013,** *13*, 4399-4403.

(11) Quan, Z.; Xu, H.; Wang, C.; Wen, X.; Wang, Y.; Zhu, J.; Li, R.; Sheehan, C. J.; Wang, Z.; Smilgies, D.-M.; Luo, Z.; Fang, J. *J. Am. Chem. Soc.*, **2014,** *136*, 1352-1359.

(12) (a) Ross, M. B.; Ku, J. C.; Vaccarezza, V. M.; Schatz, G. C.; Mirkin, C. A. *Nat. Nanotech.,* **2015,** *10*, 453-458; (b) Wang, Y.; Chen, G.; Yang, M.; Silber, G.; Xing, S.; Tan, L. H.; Wang, F.; Feng, Y.; Liu, X.; Li, S.; Chen, H. *Nat. Commun.,* **2010,** *1*, 87; (c) Zhang, J.; Luo, Z.; Martens, B.; Quan, Z.; Kumbhar, A.; Porter, N.; Wang, Y.; Smilgies, D.-M.; Fang, J. *J. Am. Chem. Soc.*, **2013,** *134*, 14043- 14049.

| 1  |
|----|
| 2  |
| 3  |
| 4  |
| 5  |
|    |
| 6  |
| 7  |
| 8  |
| 9  |
| 10 |
| 11 |
| 12 |
|    |
| 13 |
| 14 |
| 15 |
| 16 |
| 17 |
| 18 |
| 19 |
|    |
| 20 |
| 21 |
| 22 |
| 23 |
| 24 |
| 25 |
| 26 |
|    |
| 27 |
| 28 |
| 29 |
| 30 |
| 31 |
| 32 |
| 33 |
|    |
| 34 |
| 35 |
| 36 |
| 37 |
| 38 |
| 39 |
| 40 |
|    |
| 41 |
| 42 |
| 43 |
| 44 |
| 45 |
| 46 |
| 47 |
|    |
| 48 |
| 49 |
| 50 |
| 51 |
| 52 |
| 53 |
| 54 |
|    |
| 55 |
| 56 |
| 57 |
| 58 |

(13) LaGrow, A. P.; Sinatra, L.; Elshewy, A.; Huang, K.-W.; Katsiev, K.; Kirmani, A. R.; Amassian, A.; Anjum, D. H.; Bakr, O. M. *J. Phys. Chem. C* **2014,** *118*, 19374-19379. (14) Shahmiri, M.; Ibrahim, N. A.; Shayesteh, F.; Asim, N.; Motallebi, N. *J. Mater. Res.* **2013***, 28*, 3109-3118. (15) Hou, H.; Zhu, Y.; Hu, Q. *J. Nanomater.,* **2013,** *2013*, 8. (16) Wen, X.; Zhang, W.; Yang, S.; Dai, Z. R.; Wang, Z. L. *Nano lett.* **2012,** *2*, 1397-1401. (17) Gao, P.; Zhang, M.; Niu, Z.; Xiao, Q. *Chem. Commun.,* **2007,** 5197-5199. (18) Wang, W.; Varghese, O. K.; Ruan, C.; Paulose, M.; Grimes, C. A. *J. Mater. Res.,* **2003,** *18*, 2756-2759. (19) Fu, Y.; Zhao, X. Y.; Zhang, J. L.; Li, W. *J. Phys. Chem. C,*  **2014,** *118*, 18116-18125. (20) Lin, Y.; Ren, J.; Qu, X. *Acc. Chem. Res.,* **2014,** *47*, 1097- 1105. (21) Wei, H.; Wang, E. *Chem. Soc. Rev.* **2013,** *42*, 6060-6093. (22) Deng, H.; Shen, W.; Peng, Y.; Chen, X.; Yi, G.; Gao, Z. *Chem.* 

- *Eur. J.,* **2012,** *18*, 8906-8911. (23) Marquez, L. A.; Dunford, H. B. *Biochemistry,* **1997,** *36*, 9349-
- 9355. (24) Tao, Y.; Ju, E.; Ren, J.; Qu, X. *Adv. Mater.,* **2015,** *27*, 1097-
  - 1104. (25) Guo, Y.; Deng, L.; Li, J.; Guo, S.; Wang, E.; Dong, S. *ACS Nano,* **2011,** *5*, 1282-1290.
  - (26) Gao, L.; Zhuang, J.; Nie, L.; Zhang, J.; Zhang, Y.; Gu, N.; Wang, T.; Feng, J.; Yang, D.; Perrett, S.; Yan, X. *Nat. Nanotech.,*  **2007,** *2*, 577-583.
  - (27) Gao, Z.; Xu, M.; Hou, L.; Chen, G.; Tang, D. *Anal. Chim. Acta* **2013,** *776*, 79-86.
- (28) (a) Sun, H.; Zhao, A.; Gao, N.; Li, K.; Ren, J.; Qu, X. *Angew. Chem. Int. Ed.,* **2015,** *54*, 7176-7180; (b) Sun, H.; Gao, N.; Dong, K.; Ren, J.; Qu, X. *ACS Nano* **2014,** *8*, 6202-6210; (c) Lin, S.-S.; Gurol, M. D. *Environ. Sci. Technol.* **1998,** *32*, 1417-1423.

## Table of Contents

<DESCRIPTION_FROM_IMAGE>The image depicts a microscopic view of a material composition, likely captured through electron microscopy. The main features of the image are:

1. Background: A light-colored field covering most of the image area.

2. Dispersed particles: Numerous small, dark-colored particles scattered across the background. These particles appear to have a rectangular or square shape and are distributed randomly throughout the image. They vary in size but are generally small compared to the overall image scale.

3. Larger structure: In the upper right corner of the image, there is a distinct, larger structure. This structure appears as a collection of elongated, parallel elements arranged in a bundle or array. It stands out from the dispersed particles due to its size, organization, and different appearance.

The dispersed particles likely represent individual molecules, nanoparticles, or small crystalline structures of a chemical compound. Their uniform shape suggests they may be crystallites or self-assembled structures.

The larger structure in the corner could represent a different phase or organization of the same material, or it could be a separate component in the sample. Its ordered arrangement suggests it might be a crystalline or liquid crystalline phase, or possibly a bundle of nanotubes or nanorods.

This image likely illustrates a composite material or a system with multiple phases, demonstrating the coexistence of dispersed nanostructures with larger, more organized assemblies. Such images are common in materials science and nanotechnology research, where understanding the distribution and organization of components at the nanoscale is crucial for developing new materials with specific properties.</DESCRIPTION_FROM_IMAGE>
