The image presents a TOC (Table of Contents) Graphic illustrating different methods for detecting DNA methylation. The graphic is divided into three main sections:

1. Electrochemical detection:
This section shows a graph of current density (μA cm⁻²) versus time (sec). Two curves are presented:
- A higher curve labeled "Methylated DNA" that starts at a high point and decreases over time.
- A lower, relatively flat curve labeled "Unmethylated DNA".
This graph demonstrates the electrochemical difference between methylated and unmethylated DNA.

2. Naked eye evaluation:
This section shows a representation of a test tube containing a blue solution, suggesting a colorimetric assay for DNA methylation detection visible to the naked eye.

3. TMB-based detection:
This part illustrates a more complex detection method using TMB (3,3',5,5'-Tetramethylbenzidine) and antibodies:
- TMB_red and TMB_ox are shown, indicating the redox reaction of TMB (H₂O₂ is shown as the oxidizing agent).
- A material labeled "MIO" is depicted, likely referring to a magnetic iron oxide nanoparticle.
- An antibody labeled "5mC ab" is shown, which likely binds to 5-methylcytosine (5mC), a common form of DNA methylation.
- SPGE is mentioned, possibly referring to Screen-Printed Gold Electrodes.

The image suggests a multi-step process where methylated DNA is captured by the MIO particles, then detected using the 5mC antibody, followed by a TMB-based color change reaction that can be measured electrochemically or visually.

This graphic summarizes various approaches to detecting DNA methylation, ranging from sophisticated electrochemical methods to simple colorimetric assays observable by the naked eye, highlighting the versatility of detection methods in epigenetic research.