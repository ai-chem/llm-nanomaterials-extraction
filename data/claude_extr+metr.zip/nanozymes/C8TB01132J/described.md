[View Article Online](http://dx.doi.org/10.1039/c8tb01132j) [View Journal](http://pubs.rsc.org/en/journals/journal/TB)

# Journal of Materials Chemistry B

## Accepted Manuscript Materials for biology and medicine

This article can be cited before page numbers have been issued, to do this please use: R. Bhattacharjee, S. Tanaka, S. Moriam, M. K. Masud, J. Lin, S. M. Alshehri, T. Ahamad, R. R. Salunkhe, N. Nguyen, Y. Yamauchi, M. S. Hossain and M. J. A. Shiddiky*, J. Mater. Chem. B*, 2018, DOI: 10.1039/C8TB01132J.

<DESCRIPTION_FROM_IMAGE>This image is the cover of the Journal of Materials Chemistry B, Volume 4, Number 1, from January 2016, pages 1-178. The journal focuses on materials for biology and medicine.

The cover image depicts a conceptual representation of a microarray or lab-on-a-chip device. It shows a grid-like pattern with various shapes including triangles and circles arranged in rows and columns. Above this grid, there is a large spherical structure, possibly representing a cell or a droplet, interacting with the surface of the array.

This cover art likely represents the journal's focus on materials chemistry applied to biological and medical fields, showcasing technologies like microarrays or biosensors that interface between synthetic materials and biological systems.

The bottom of the cover includes the Royal Society of Chemistry logo and mentions that this is the 175th year of the society.

While this image doesn't contain specific chemical structures or graphs to analyze in detail, it visually communicates the journal's scope in combining materials chemistry with biological applications.</DESCRIPTION_FROM_IMAGE>

This is an Accepted Manuscript, which has been through the Royal Society of Chemistry peer review process and has been accepted for publication.

Accepted Manuscripts are published online shortly after acceptance, before technical editing, formatting and proof reading. Using this free service, authors can make their results available to the community, in citable form, before we publish the edited article. We will replace this Accepted Manuscript with the edited and formatted Advance Article as soon as it is available.

You can find more information about Accepted Manuscripts in the [author guidelines](http://www.rsc.org/Publishing/Journals/guidelines/AuthorGuidelines/JournalPolicy/accepted_manuscripts.asp).

Please note that technical editing may introduce minor changes to the text and/or graphics, which may alter content. The journal's standard [Terms & Conditions](http://www.rsc.org/help/termsconditions.asp) and the ethical guidelines, outlined in our [author and reviewer resource centre](http://www.rsc.org/publishing/journals/guidelines/), still apply. In no event shall the Royal Society of Chemistry be held responsible for any errors or omissions in this Accepted Manuscript or any consequences arising from the use of any information it contains.

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

rsc.li/materials-b

# **TOC Text**

[View Article Online](http://dx.doi.org/10.1039/c8tb01132j) DOI: 10.1039/C8TB01132J

Peroxidase-mimetic activity of mesoporous Fe2O3 nanomaterials in global DNA methylation detection using naked eye and electrochemical readout.

# **TOC Graphic**

<DESCRIPTION_FROM_IMAGE>The image presents a TOC (Table of Contents) Graphic illustrating different methods for detecting DNA methylation. The graphic is divided into three main sections:

1. Electrochemical detection:
This section shows a graph of current density (μA cm⁻²) versus time (sec). Two curves are presented:
- A higher curve labeled "Methylated DNA" that starts at a high point and decreases over time.
- A lower, relatively flat curve labeled "Unmethylated DNA".
This graph demonstrates the electrochemical difference between methylated and unmethylated DNA.

2. Naked eye evaluation:
This section shows a representation of a test tube containing a blue solution, suggesting a colorimetric assay for DNA methylation detection visible to the naked eye.

3. TMB-based detection:
This part illustrates a more complex detection method using TMB (3,3',5,5'-Tetramethylbenzidine) and antibodies:
- TMB_red and TMB_ox are shown, indicating the redox reaction of TMB (H₂O₂ is shown as the oxidizing agent).
- A material labeled "MIO" is depicted, likely referring to a magnetic iron oxide nanoparticle.
- An antibody labeled "5mC ab" is shown, which likely binds to 5-methylcytosine (5mC), a common form of DNA methylation.
- SPGE is mentioned, possibly referring to Screen-Printed Gold Electrodes.

The image suggests a multi-step process where methylated DNA is captured by the MIO particles, then detected using the 5mC antibody, followed by a TMB-based color change reaction that can be measured electrochemically or visually.

This graphic summarizes various approaches to detecting DNA methylation, ranging from sophisticated electrochemical methods to simple colorimetric assays observable by the naked eye, highlighting the versatility of detection methods in epigenetic research.</DESCRIPTION_FROM_IMAGE>

#### **---  - ---- ---------  -**

-
  - - !" "# \$\$ "%  & % # % **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

'(
)* !
"#+
 ,* +-.
/(
#
+
*01222

- +"+
  # '""*" /(
  # "#*" 344513+
6
6(
(
 ,66-/(
#7""8 7 # 
7"" 73955

0 
+
#+"" /(
#-# 22192

6

+

 
, -
6

 , 6-2!2 6  :59!5511

- + '"" "'""  6
  ""
  "#,6 -/(
  # *  *015;3
- *-*0 
  <
  )'(
  =-#"&/(
  #2;:3 0"#"! .""\$"!.#""!114!;52

%+"
! >

## ?8 @ ?8 @#?"

A'

#
,'6- (

## 

B !
 , C#- (=#"
 =!

(#
( "

(
 C#& =
#
B !
(
# B,6D-
" 0
#

 "
0 = B


"
0 = #

  !
"
,<.'-9!
##
# ,9+-
C
 ,6D!9+- =
" ##
" 
<.' 6D!9+
"
#

#" B
"(

 , !# (
-

0
#
# #
= 25E  " 0
#
( # =
"
#
#,E-0FG9EF:-

"# (
 C#  B ,&-<-

<+-

(" # # (
0
#
# 7 ( "
 # "# =!
  "!= 0
#
#
!!  **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

**-**    B
"# B !
(
# " 0
#

#### **!"--**

7
  (
"#

 , <- ( 
"# #
"
# 2 " <B < ( "
 "
#=
B
#B
# !  "
"

# 
(# # ! C
,

#

" #- 3!1 6 =
 B <
 C#! ," &-<-
(
# = 
B
C#

::H99H!

#C,-! # ,D<0- C C,0-9 (B < 
(&-< #" (
"
=" 
B( ##


( &-<"
4!I/"B
B <(  ( (   4 J &=(


 B !
(
#
"

 ,15K19L+- =
#

(
  ! 

 <=
B !

  "# " 
( " " "# 

 "( " B !
 
 

 "
#

( 
 ! " "
#
 B
"
(
# (
#
#

# " 8
#

C

"25!236

= ("  M3D:==B
B !
 **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

0
#
# "
=
#

#
,+9
- 0 #
N" ,+.-
#

 " " 2: 
#
  
"*-*#"
(  
= #" "
#
 

!"
( "2129M

  ( "
=
"
# 0
#

(
  "
#

 (#  

 =
D(
= (

" "! 8 
" # ,&<+-

# ,+!N- "! #

0 = #  8" ( 
 " 0
# 24 2; 2I
"
 "# 8
( 
# 

8

(# "
0

!" #
C
" <+-
#8"
#
!
( 

#
0
# ((
!"  (
B( 

C# ,"6 & 66- 0
#
#82J6

35

# 32 # ( (  0
# # D


(
" "
#
(
#
# =
B"
C 35 33 

"
 (" ( 
0
#
#<(#=3:
"25 ( =
 #"0
#
6 **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM. #&-<
"
9+
#
#!+.!" ,0- (
# "C
#

"
0 "
(
 #


# (
#
# # &-<! C#

= # < ,B ! - (
"
 
" "

(
# B

(
&-< 4
 =" B !
B ((0
#
#

6
# = (
"
B !
! #
C 6D 
(

  0 #
# (( (
@*- -* C
6D = 9+
# ,6D!9+
"
- *-* 
B

 0 ,
 "
 "
#
"6D!9+
"

6D , 
=
#
9+
#6D!9+
"
-
C B
&3D3"
"" " , "- = ( 8
# " 
# ! 
# ,- **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

## **#!\$**

#### *-*

<# ,
# "#-
#
 ,1!# !1!
#


- =   "  , - <'.!+ 33O! C ,31!
# ( 
- =   7 < + , - = = 
 
33O!C ,
#
- ,6 -
 7 <

+ = #
C 

21!0B # ,PJI5E-
#,PJJ5E-=  7 <+ 
    #"  #
 # ,&M- ,666-
 #
,M, D:-:QJ&3D JJJJE- #B , D& JJJE-
,JJ9E-=  8, -/
 <0 N- ! =
 =
 6(
" ,+  + /-  
"
 ,<.'- ,335@
F1"
!
 #
,
 
-= 80,
 - **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

#### *-*

7 ( #
C

  B " # ="  
 31 "


= #
! 


(#=

 &

  B = 
:95 L+  1 =
"
2L+!2
B

#### *-*

" (
 B =
" "
 ,'- ,&
/!I555- 

" (
" 25 R

  ,'- ,'D '!3255M- 

"(
"355R
= #C" S! #

# ,S<- =
<&6 *
 S ,/R+!<&6- 
" !TS! #

#### *-*

B !
(
M3D:= (
"
"
# B
&3D3  "
 B 
=  53
, - ,&:9-" I55 U #   , ( 0D- ;55 &3D3 

=
 
493 " 
 ,
 B- 
,
 B- = 8 # " 35 U
,35 &+- = " ( #=  
+
#,
193-=

#
#= 
 
 
=
V295 R
"
 "
45 **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

#!
B
=  " 9W" 6D  &3D3

&3D3
=
,;55-= 
= (  ""552!25 #
= &3D3

= "
6D=
B
 ,I55 W- ( #"

&3D3 ,552!25 -
# C#
#



@

$$\mathbf{E} + \mathbf{S} \xleftarrow{\mathbf{K}_{\parallel}} \mathbf{E} \xleftarrow{\mathbf{K}_{\parallel}} \mathbf{E} \xleftarrow{\mathbf{K}_{2}} \mathbf{E} + \mathbf{P}$$

& ' ' < 
C# ,M3D:-

,N&3D3- C#! 
B 

(#

=
X
8
= (!8 39

$$\mathbf{V} = \mathbf{V_{max}} \begin{array}{c} \text{[S]} \\ \text{[S]} + \text{K}_{\text{m}} \end{array} \quad \begin{array}{c} \text{[S]} \\ \text{[J]} + \text{K}_{\text{m}} \end{array} \quad \begin{array}{c} \text{(J)} \\ \text{(J)} \end{array} \quad \begin{array}{c} \text{(J)} \\ \text{(J)} \end{array} \quad \begin{array}{c} \text{(J)} \\ \text{(J)} \end{array} \quad \begin{array}{c} \text{(J)} \\ \text{(J)} \end{array} \quad \begin{array}{c} \text{(J)} \\ \text{(J)} \end{array}$$

6
8  
( ,(
#-*-*  B 
( YZ


= 8(

=

(  *-* 
#
C#

  "
8
,3-"( 
= (!8
C#
 R B

$$\frac{1}{\text{V}} = \frac{\text{K}_{\text{m}}}{\text{V}_{\text{max}}\,\text{[S]}} \frac{1}{\text{[S]}} + \frac{\text{K}_{\text{m}}}{\text{V}_{\text{max}}} \qquad \text{ } \qquad \text{ } \qquad \text{ } \qquad \text{ } \qquad \text{ } \qquad \text{ } \qquad \text{ } \qquad (3)$$

#### *-!"  #\$%*

=
,&+!2247!1I-  ,M&+! -=   #+
+
,++-/
 0
,* "&. #-=
B

#
0  
,255E
#
- = " 0 ,7.-
=   ='" .0 =

J9+25 "
"
 0 7"
0 =  #=" 
-'<6!" = "
,* " & . #- ="

0 #)
,* "- **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

#### *-&  '  (*

<
"
 M3D:=
9+
#
6D = 
C =
B
 ="(#  9343;625W3"NB
 ,  59 D&
- 25 W 25 W"NW6D =
"# B

B,:55
("
6D= 
 B
 " B
 "
6 
# 35 W ,3 "N- 6D1 =
B
 ! 6D =#35
:;+
"
==

=
53 ,&19-
(
6D=
=
;9"NW
#
1 +("
&1=
" 
6D!9+
# "
== =
<
" B
 "
M #<=
355"NW6D!9+
#
"

1 +
" 8
B
B
  #  " 

,
#""- =
(
#= #
9+
# 3I 6
"

" =
"
"""
M3D: B
 3; BC" " 6D1=

 #
B

#
# 
 3J M # 
" &1
" 

M3D:
"
9+
# &1 (

(
## "
M3V 
# :5

"
 M3D: =
9+
#= (
/R!( 
 
=
6DB
 ! B
 N9!+
#!6D ,M" 3-

 :45 
 ( =
B
 ,-
,-
"

"
=
6D:2:3 **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

#### *-)*  (#\$%*

[View Article Online](http://dx.doi.org/10.1039/c8tb01132j) DOI: 10.1039/C8TB01132J

35 U
"0 =

J9 + = #
=
9B

,+-
25"NU0 9U
0 =

!
"
,<.'- = 259W6D!9+
#,355"NW-=
"   =
 :5

 =
" " ,
=
-
"
6D!9+
# "
=
"
# #
0

 = = =
25 < ,& ;1-
( #  6D!9+
#
"

  45 W #  

=
"
 

  25 6D 0 6D!9+
# "
#

 &3D3 "
 "!
  B
"  "
!# (
" 0
#
6D
# B
, #
"
-= 8
3W35&+  ( #== 
193 "
 !(
,/R-! (

 B 
!
( =   8
"
( :: 
 
+&2515+
,+& 6

S /- = + 
 
=
# " 95 W #= , BC 
-
<.'  =
V295 R 
( "
15 =  8
( #
 
=  
N
=

 "

=

 **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

#### *-+# % ,*

(=" 
 =
# "


#(
!
 
YM,+ -4Z :! Y35 < ,59 +-Z # "
- !( 8
,8
1-

$$i_p = (2.69 \times 10^5) n^{3/2} A D^{1/2} \mathcal{C} \nu^{1/2} \dots \dots \dots \dots \text{ (4)}$$

=

,

 ,M:V[M3V F 2
( 
 ,3 -0
YM,+ -4Z :!
;45\25!93 !2-+

,!:-]

,R!2-

#### **%!&-**

#### *-**

"#
!    B = ( " "
  ,'- "

 ,'- ' ' " ,M" 2,- ,-- =

 #
C B 
#


""
(
31   
,'0-


##
 ^!M3D:  = ,M" 2,+- M
" 
' " 
" =
! " 53J =  = 
,335- ^!M3D:#
,M"2,0--:1 **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

B
:95 5+ = #C#S< # =M"2MD +
= #
(#
,M"2,--

"MD +# S<  3J3;9 4J4
E "
 " 
 " 
#(
+2 B
+F++!D +FD
 " # ,M" 2 ,-- (
D2 
9:5R 

#
B,M" 2 ,+--
 
+!D D!&  =
 :9 (
M3
" "# ;25 R ;31 R =

M3:N3 M32N3
"

M:V,M"2,0--:4M5 M3V=
"
BM3D:

#### *- ./*

(
"
B
(
#6D= #
CM3D: 
B

 "
6 ==
B ,&-<-
#
 &3D3 "
 "!
 B7 (
 M3D:"
B !
(
#

7(
" B
(
# 6D ="  (#  : :; 6 
=
B
= 
==
6D=
( =
6D= "
(

15
"
#= ( (
 
"
(
,594(5521 ?193-,M"3- 
35&+
, "
 B
#=  ,
=!
 B
- 
=

(
&
##=B
8
( /RK( ,!8
( 
#- 
# #
  :I  M"3=
23:W!3
= "
 **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM. ( =
19
"
"
(
,53;:W! 3 - B

# (

 
 
# 
B ! 
6D  
6DB
=# =!
M

=  , M3D: 
"
#" B
 ! ,D&-:J 15  8
#B

#!
 " 

&3D3 = B
=

, &:9

-=#( :;6
#= (

 8
B
(  " 6D ,255 "
25 U"- 6
= ( ,M" :- (#
   355 " 6D  =
 " 6D 8
# M "  
,M":-9U" 25U"6D,594(542-=
, ?193-= (9U"6D
 8

6

=
(

 B

M" 3+ 30 =
# K
(

 " 
&3D3 
(#
=
X
" 
8 
" 
#

 "( 2  =
 (# 
(  6 B

 = (

= (X !
,2NR ( 2N- = " ( "( ,
M"3+ 0-  ( 6D=
= =
=
&-< ""
"
 6D ( "
# = 
&-<( ( 6D =
**Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM. 6 B 6D B
(
#   6D B #
"
#
B
#=
"  YB  M,666- Z "  (
   =

(
  !  
# , "
 - 
"
(

M:V #

#
#M3D: 12

#### *-*   (#\$%*

M" :
# 
((
# "  #" " 0
#

 6
# 9+
#=
(# "
#
#
0 8
" 0
=
##
"

8

 C#
(# 0 13 7 ( 9+
#
(# "
##
" # +. " 6
# " 0 = B

  
,
'B

- = #

,
J9 L+  25 -
"
0 <(# =
 ( #

0
# = 
" 
"
(
#
 1:11
 0 = 
# 
<.'  25 6D!9+
# =
 :5
<.'  "C"
#
0
 ("
6D!9+
#
" = "

=
  ! 6D
#
B
"
! B = #=

#  

# 
 6D!+
# "
=

(
#

**Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM. (
C#
# "
B =   
 ## #"
V295R
<.'

#### *-%*

#
# =   # "
9+
#
(,
- "
(,7.- M"1 "
"  , ?193-= (

7. ,51JI ( 5542-   =

  ,:3:1(5121W!3-,M"1-M

#(
"
=  =
B
=#<=
"
0 , -
( =
9+
# M3D:,
-
 = "" 

  
&=( B
"
#"
,552I(5521 ?193- #
!  6D

(
#

"(
#  #
= 
0
#
=
"" " " #!"9+
# **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

#### *-!%*

(
( B

&0
#

(
 #
C<(#= (
( 

 
&
0
"
 =
 
#
#
0
" 3:1:19 6

# = (

 ,
=

- 95 " 0 ,
9B +  & ;1-
0 8
#

 <.'  25
 
  #
"
(
#
+.
#
9+
# 
# 6D!9+
#
"
8
+
   

=  9+
#

,25X255"NU-=
B
6D,9 W" M3D:-  "
 ,
#- = ( =
 "
#

= M" 1 ;95 "NU 2555 "NU
#  "
# "  

#

# ;9"NU
#=
(# 
255"NU;9"NU =
#

 #7 (
8 
#
(
B 
(   
#
=
#
#
M"1+25;9"NU
# =""
( &=( 

 
:5

#
19
 
= (;9"NU9+ ,
"
=
6D-
# :5
"
# **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

#### *-&#\$%*

7 (
#  #
# 0
#
B "

8
" "!= 0 #
( "


" "  B
"
#
"!= 0 #
( 
" =   # B"  #
,255E- 7.,5E-0 8
"
5E25E39E95E ;9EJ5E 255E
#
7(  "
  ,- =
 "
#
( ,M" 9-

#
# 6D,6D!9+
"
-
#B

#
9+
# =
9+
 6
 "
5E
#
,
 
-= #  
25E
#
,"
- = 
 ## !#(
= 25E
#
(

M" 9+  
=
 " ( #
= (
/R!R  ,- 
= =
 ( =
 " 8
# ,?195- F 55I B ,E #
- V 551 =

,-3 - 5JI4 M

 
,D0- =
= 25E
# ,5I2?193- #
"8
 

=
#F55:BV534=
-35JJ"
#
(
#,D0 25EM" 40- 
(
 (
,E-0- 

 =
G95E""
"
"
# #
= 
# (
8
(D0 
#

 #( = "
#
(=
=0
,
95 "- #

B !
(
# 6D
# = 25E
#
B 0 ( = ( 
 #
=
&-<N&3D3#
 M" 9
=

&-<N&3D3 #
=
9E #
=
= 25E
#

6DN&3D3 #
" (
# 

&-<N&3D3 #
 ( (
"<B !
(
#B "#B(

( **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM. B , &-<- 
"


C# 
=== 6D
= 
(
!#
 0
#
#

#### *-0#\$%*

6

# #B" #
= B
 # 
""!=0
#
,&+!2247!1I M+&! -
#
(
= =

7.M"4+ 0=
&+!224, - "
#
( ,  I1E- 
7.
 = 
# (#
14 D

 

#,M+&! - 
(#= #
(,
2IE
#
- 


= "
# "
=
B
"

 1; &=(  # (
#
(
#
(# #@ !
#
(
=



#
= 25E
#
" 0 8  95 " 0
<+-   
#
=
# M #6D " (  
( B( &-< C# #
"=
( **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

!# 
0
#
#
 "

(
B( !#  !
" 6 

 B
 
! " ,#N-
#
#
"
0 = # 
( 
8
#  
 
<.'
(#
 " ,
!" (
### # (

#
# 
 C#  B

"
 "
" # 8 
 C# D(
#
 
(# B( <+-


#0

#### **'!(--**

7 (#(
"
B
(
#!#
C B6D=#
(
=!
!! # 
" 0
#

 6D = B
(
# 
M3D: 8"# 


&-<C#= 6D
= 25E
#
B #
=
" 
# ,E-0FG9E F:-  95 "
0  # 8 <+- "0
B( &-< C# , # 6D-
(
= = #
( 
(#  B(
 0
#
=
B !
  B
 8
0
#
# #
=
" **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

#### **(--**

#### **)-**

= = 
#
&-+ +0M ,<<25IIJ44-
&0- 
-  .
/(
# = = 
# 
#  -  + ,-+- M
 M= ,M2952551;J- < ' &6 .
2;&59:J: ,+
#
#-
B
  6

< 
<" ,6<<-
" /(
#,/- "
 =
"6<<!55J; **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

**!** #
 ,'6-

#### **-**

- 2 _ " - .# . R R  *-*  352; ***** 23J13!2:5:I
- 3 R/ ( ". 0 
  MR -_*-*  3521**#+**449:!44;:
- : \$ ( 6 R. "# & +\$\$ #352;**,**II59!II21
- 1 SS_ "&7 "&_"\$& " S*--* 3523**%,** 221!23J
- 9 . _ " _ "\$_ " .7 "M"0\$ "< S\$ *-* 355;**#**9;;!9I:
- 4 &7 '7 "*--* 352:**'#**4545!45J:
- ; \$M 7S_ " \$& " *---*3521**#**31I3!31I4
- I 7S_ "& \$& "*-!*3522**'***25;I9!25;I;

- J . M S\$ 352;*****:35;!:33;
- 25 '7& "  *-"#*3529*****49
- 22 6 && 8 R. . "# & \$\$ #*-!*352;**-%** I3:2!I3:1
- 23 M-S" _*\$*3522 *****435!439
- 2: 0- *--%*3559**+**9J;!425
- 21 '*&*3553**#** 9155!912:
- 29 ""<."& <& *-* 2JJJ**-,**1:4!112
- 24 + - ++7 .-"
  '*!--*  2JI5**.**1;4:!1;;4
- 2; "7+
  '(#+7 0-""*-'*2J;J **,'**3J;!:52
- 2I <7 *(!
  --%*3559 **'/-** -49!;4
- 2J
  7D  C=0<. .+
   "*)*-&*352:**.**;J511
- 35 6 \$ (&& 8 CM6 & R. "# #*'-'*352;**,#**44I!4;I
- 32 & . 6 D
  ( & 
  . "# #*'-'* 352;**,'**4:!;:
- 33 D#+ 0-7
  -M 6 "( '& " *-* 3521**,**J4J!JI5
- 3: && 8-
  
  6 R. "# #*\$*352; **'#**2J55!2J5I
- 31 \$R
  -
  
  6 -
  6\$ "# # \$ \$ & *- ##- -+,*352I **0**25:J!251J **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.
  - 39 "0@+B**-)#-,-'
    \$*7&M + #3559
  - 34 \$& "\$ +#*+- --* 3523 **%**9991!99;5
  - 3; +
    D
    !" S_ < .C`C!+ a- < -C!+ R
    !R " *\$* 3551 **-** 291! 29J
  - 3I < < 
    R
    !R " .C C!+  +  *\$- ##- - - ##- ,-
    - #* '( 
     3554

- 3J \$ *-* 3529 **-**29J;!2432
- :5 . &
  "
  8 ,
   352: >NNB"N252524NJ;I!5!23!:I33:J!555535!5
- :2 \$\$* 7*\$*3523 **%***22;1!22I2
- :3 \$b & *-* 352;*****1J:I4!1J15:
- :: '<0 (# - <  *-'-* 2JI3**#-***:44J!:4;9
- :1 & S*0\$S  *-* 3529**#0 -**2!J
- :9 - 0
  <=  -# +<
   *--* 355J **,**4I25
- :4 - .( ' M'   'DcC M
   *##-!,-* 3524**%.,**;32!;:1
- :; \$ ( 6 "#+ -&- _ \$\$ & #*-* 352;**.,** 22559!2252: **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.
  - :I <0#'" -<  *-'-* 2JI3**#-***:44J!:4;9
  - :J _+ \$\$_\$_ """& .*-* 3523**+**1552!1523
  - 15 M<C! *- -)\$--*3551 **0.**1I9:!1I9I
  - 12 _S" &*
    D!\$ S*'-'* 3521**-#**193!19;
  - 13   -
    *-*352;**,**29:;!291J
  - 1: .+  -< #- #  *-* 3521**.+**252;J!252I9
  - 11 6 .+  #  *-* 3529*****;513!;591
  - 19 .+  #  *\$*3521 **%,** 42;I!42I1
  - 14 < . "\$+ _S"<7  <*&*3555 **,** J1:!J93
  - 1; \$ "-'
    0\$'&
     < 6 *!--* 3551**%#**:I

## **1"23&\$(4"5/**

**1 !** ,- ' " #
C   B@ ,-
# ' "@ ,+ 
 
,'0-
 ,0- " 
' ,&-'- "

**1 #!** (  ,- ,/R!(- ,+- 
  # 
"
( ,6D-
( ,=
6D- ,6
M" + 
" # (
( 
(#-
#!
# "
K
, - = (K ,
- 
M3D: # ( #"

,+- &3D3 ,552K2- ,0- ,552K25 - =
B
,+- ,I55 U- ,0- &3D3 ,;55 - 
(# **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

**1%!**

#
" 0
# 
0  
"


6
# ="= B

"
0 =  <.'  = # "
#
0 "
6D! 9+
# 8
" 0
#
 = 
" " 
M3D: =
N&3D3 B
<.' ( !# /R!(  
# 6
> # 
6D
C
9+
#
"

**1 '!**  ,-  ,-
#!

  "

# =
( ,
#
0 - =
 "
(
 ,7. 
#

<
(
 
=
0 M3D:!9+
- 6
>"

!#(
*.*(

**1 -!** 0
0
#
" ,- = "
"
" 5E 25E 39E 95E ;9E J5E 255E
#
,- =  "  + 
 "
#
 ( ,+-  ,/R!(- ,0-  
 
# '
,- ,+- 
( "

  
( 
=
B
,E-0FG9EF:-

**1 +!**- - ,- = 
(

!#
# " 0 ,/-- 
 ,7!1I &+!224 M+&! - 7. ( ,+-  ,/R!(- ,0-  
 
# " ,- =
 
   " '
,+- ,0- 
( " 
  
(

,E-0 FG9EF:- **Journal of Materials Chemistry B Accepted Manuscript** Published on 22 June 2018. Downloaded on 6/23/2018 2:17:57 AM.

## Journal of Materials Chemistry B Page 26 of 32

# **1"23&\$/**

<DESCRIPTION_FROM_IMAGE>This image, labeled as Fig. 1, contains four separate micrographs labeled (A), (B), (C), and (D), each providing different information about the structure and composition of a nanomaterial, likely iron oxide nanoparticles.

(A) Transmission Electron Microscopy (TEM) image showing a porous structure with interconnected particles. The scale bar indicates 100 nm, allowing for estimation of particle and pore sizes.

(B) Higher magnification TEM image (scale bar 50 nm) revealing the detailed morphology of the nanoparticles, showing their aggregated and irregular shape.

(C) Selected Area Electron Diffraction (SAED) pattern, with a scale bar of 2 1/nm. The pattern shows concentric rings characteristic of polycrystalline materials. The rings are indexed with Miller indices (hkl) for cubic crystal structures: (111), (220), (311), (400), (422), (511), and (440). This pattern is consistent with the crystal structure of maghemite (γ-Fe2O3) or magnetite (Fe3O4).

(D) High-Resolution TEM (HRTEM) image with a scale bar of 2.5 nm. It shows lattice fringes of the nanoparticles. The image is labeled to indicate a d-spacing of 0.29 nm, corresponding to the (220) plane of γ-Fe2O3 (maghemite).

These images collectively provide evidence of the nanostructure, crystallinity, and phase identification of iron oxide nanoparticles, specifically suggesting the presence of maghemite (γ-Fe2O3). The porous structure seen in (A) and (B) indicates a high surface area material, while the diffraction pattern in (C) and lattice fringes in (D) confirm the crystalline nature and help identify the specific iron oxide phase.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image contains only text that reads "Fig. 1." This appears to be a figure label or caption typically found in scientific articles or papers to denote the first figure in a document. Without any accompanying graphical content, chemical structures, or scientific data, this text alone does not convey any specific chemical or scientific information. Therefore, I would classify this as:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image contains four panels labeled (A), (B), (C), and (D), presenting various experimental results.

(A) This panel shows a bar graph comparing absorbance at 452 nm for negative (Neg) and positive (Pos) samples. The negative sample has a very low absorbance (close to 0), while the positive sample has an absorbance of approximately 0.56. An inset image shows two vials, with the negative sample appearing colorless and the positive sample having a blue color.

(B) This panel displays a bar graph comparing current density (μA cm⁻²) between negative and positive samples. The negative sample shows a very low current density (close to 0), while the positive sample exhibits a current density of about 12 μA cm⁻². An inset graph shows the change in current density over time (0-60 seconds), with an initial rapid decrease followed by stabilization.

(C) This panel presents a graph of velocity (V) in Ms⁻¹ against H₂O₂ concentration (S) in M. The velocity increases with H₂O₂ concentration, showing a typical enzyme kinetics curve that approaches saturation at higher concentrations. The maximum velocity is approximately 5.8 × 10⁻⁸ Ms⁻¹. An inset graph shows a linear relationship when plotting 1/V against 1/S, indicating Michaelis-Menten kinetics.

(D) This panel shows a graph similar to (C), but with TMB concentration (S) in M on the x-axis instead of H₂O₂. The velocity (V) in Ms⁻¹ increases with TMB concentration, again showing enzyme kinetics behavior. The maximum velocity is about 5.8 × 10⁻⁸ Ms⁻¹. As in (C), an inset graph displays a linear relationship between 1/V and 1/S, confirming Michaelis-Menten kinetics.

All graphs include error bars, indicating multiple measurements were taken. The figure is labeled as Fig. 2, suggesting it is part of a larger set of experimental results in a scientific paper.</DESCRIPTION_FROM_IMAGE>

**1!#!**

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a process for detecting DNA methylation using colorimetric and electrochemical methods. The process is divided into several steps:

1. Cell Culture: Represented by a petri dish containing cells.

2. DNA Extraction: Illustrated as a four-step process:
   a. Sample collection
   b. DNA binding
   c. Wash
   d. Elution

3. Denaturation: Shows the separation of double-stranded DNA into single strands. The original DNA is depicted with methylated cytosines (mC), which after denaturation results in single strands with mC and unmethylated cytosines (C).

4. Colorimetric and Electrochemical Detection:
   a. A chemical structure is shown, likely representing a DNA strand with a 5mC antibody (5mC ab) attached.
   b. The process involves a Screen-Printed Gold Electrode (SPGE) for detection.
   c. Two scenarios are presented:
      - Unmethylated DNA: Leads to a colorimetric change (TMB_ox)
      - Methylated DNA: Results in a different colorimetric outcome (TMB_red)
   d. An electrochemical detection graph is included, showing the current density over time for methylated and unmethylated DNA.
   e. The process also includes a "naked eye evaluation" step.

The image emphasizes the distinction between methylated and unmethylated DNA in the detection process, showcasing how the method can be used to identify DNA methylation patterns.

No SMILES notation is required as there are no specific chemical structures to convert.</DESCRIPTION_FROM_IMAGE>

**1!%!**

<DESCRIPTION_FROM_IMAGE>The image, labeled as Fig. 4, contains two panels (A) and (B) presenting data on different measurements for four sample types: JURKAT, WGA, NoT, and Control.

Panel (A) shows a bar graph and inset images of sample vials. The y-axis represents "Abs @ 452 nm" (Absorbance at 452 nanometers) ranging from 0 to 0.6. The bar graph shows:
- JURKAT: highest absorbance, approximately 0.5
- WGA: much lower absorbance, around 0.07
- NoT: very low absorbance, about 0.02
- Control: similar to NoT, about 0.02

The inset images show vials with varying intensities of blue color, corresponding to the absorbance values.

Panel (B) presents a bar graph and an inset line graph. The main y-axis shows "Current density (μA cm⁻²)" ranging from 0 to 4. The bar graph indicates:
- JURKAT: highest current density, about 3.2 μA cm⁻²
- WGA: much lower, approximately 0.4 μA cm⁻²
- NoT: slightly lower than WGA, about 0.3 μA cm⁻²
- Control: similar to NoT, about 0.3 μA cm⁻²

The inset graph plots "Current density (μA cm⁻²)" against "Time (Sec)" from 0 to 40 seconds. It shows:
- JURKAT: starting around 5.5 μA cm⁻², decreasing rapidly and leveling off at about 3 μA cm⁻²
- WGA, NoT, and Control: all starting below 1 μA cm⁻² and remaining relatively constant over time

These results suggest that the JURKAT sample exhibits significantly higher absorbance and current density compared to the other samples, indicating a distinct difference in its properties or composition.</DESCRIPTION_FROM_IMAGE>

**1!'!**

<DESCRIPTION_FROM_IMAGE>The image, labeled as Fig. 5, consists of four panels (A, B, C, and D) showing different aspects of a methylation study.

Panel A: This panel displays a series of seven test tubes containing solutions with varying degrees of methylation, ranging from 0% to 100%. The solutions show a gradual increase in intensity from left to right, corresponding to the increasing methylation percentages.

Panel B: This graph shows current density (μA cm⁻²) versus time (sec) for different methylation percentages. The x-axis ranges from 0 to 40 seconds, while the y-axis ranges from 0 to 6 μA cm⁻². Nine curves are plotted, representing control and methylation percentages of 0%, 10%, 25%, 50%, 75%, 90%, and 100%. The curves show a general trend of decreasing current density over time, with higher methylation percentages corresponding to higher current densities.

Panel C: This graph displays the relationship between absorbance at 452 nm and methylation percentage. The x-axis represents methylation percentage from 0% to 100%, while the y-axis shows absorbance values from 0 to 0.6. The data points form a linear relationship, with the equation y = 0.08X + 0.04 and an R² value of 0.986. Error bars are included for each data point.

Panel D: This graph shows the relationship between current density (μA cm⁻²) and methylation percentage. The x-axis represents methylation percentage from 0% to 100%, while the y-axis shows current density values from 0 to 4 μA cm⁻². The data points form a linear relationship, with the equation y = 0.03X + 0.26 and an R² value of 0.99. Error bars are included for each data point.

Overall, the figure demonstrates a clear correlation between methylation percentage and various measurable parameters such as solution intensity, current density, and absorbance, suggesting a quantitative method for assessing methylation levels.</DESCRIPTION_FROM_IMAGE>

**1!-!**

<DESCRIPTION_FROM_IMAGE>This image, labeled as Figure 6, contains four panels (A, B, C, and D) presenting data on different cell lines:

(A) Shows five test tubes containing solutions for different cell lines: JURKAT, HCT-116, SW-48, FCH-N, and WGA. The solutions appear to have varying intensities of blue color.

(B) A graph showing current density (μA cm⁻²) over time (Sec) for different cell lines and a control. The graph shows:
- JURKAT, HCT-116, and SW-48 have the highest current densities, starting around 6-7 μA cm⁻² and decreasing to about 3 μA cm⁻² over 40 seconds.
- FCH-N has a lower current density, starting at about 2 μA cm⁻² and decreasing slightly over time.
- WGA and Control have the lowest current densities, remaining close to 0 μA cm⁻² throughout the 40 seconds.

(C) A bar graph showing absorbance at 425 nm for different cell lines:
- JURKAT: ~0.51
- HCT-116: ~0.42
- SW-48: ~0.35
- FCH-N: ~0.17
- WGA: ~0.05

(D) A bar graph showing current density (μA cm⁻²) for different cell lines:
- JURKAT: ~2.9
- HCT-116: ~2.5
- SW-48: ~2.2
- FCH-N: ~0.8
- WGA: ~0.2

The data consistently shows a trend across all panels: JURKAT cells exhibit the highest values, followed by HCT-116, SW-48, FCH-N, and WGA, which consistently shows the lowest values. This suggests a correlation between the cell type and the measured parameters (absorbance and current density).</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image appears to be a figure caption or label, rather than a substantive scientific diagram or chemical structure. It simply contains the text "Fig. 6." which likely indicates that this is the label for Figure 6 in a scientific document or publication. As this does not convey any specific chemical or scientific information on its own, I would classify this as:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>
