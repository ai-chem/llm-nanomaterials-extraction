The image contains four graphs labeled A, B, C, and D, each presenting different aspects of an experiment involving iridium nanoparticles (Ir NPs).

Graph A: UV-Vis absorption spectra
- X-axis: Wavelength (nm), range 500-800 nm
- Y-axis: Absorbance, range 0-1.2
- Three spectra labeled a, b, and c
- Spectrum c shows a peak at around 650 nm with absorbance of 0.8
- Spectra a and b show minimal absorbance across the range
- Inset image shows three test tubes labeled a, b, and c, with c containing a blue solution

Graph B: Time-dependent absorbance
- X-axis: Time (min), range 0-5 min
- Y-axis: Absorbance, range 0-1.6
- Six curves representing different concentrations of Ir NPs (0.05-0.25 μg/mL)
- Absorbance increases with time for all concentrations
- Higher concentrations show steeper increases in absorbance

Graph C: Time-dependent absorbance decay
- X-axis: Time (min), range 0-10 min
- Y-axis: Absorbance, range 0.4-0.9
- Four curves representing blank and three Ir NP concentrations (0.5, 1.25, 5.0 μg/mL)
- Higher Ir NP concentrations show faster decay in absorbance
- Inset image shows four vials with varying shades of dark solutions

Graph D: Fluorescence spectra
- X-axis: Wavelength (nm), range 350-550 nm
- Y-axis: Intensity (a.u.), range 0-120
- Eight curves representing blank and seven Ir NP concentrations (0.1-2.5 μg/mL)
- All curves show a peak around 440 nm
- Peak intensity decreases with increasing Ir NP concentration

This image demonstrates the optical properties and catalytic activity of Ir NPs at various concentrations, showing their effects on absorption and fluorescence spectra, as well as time-dependent changes in absorbance.