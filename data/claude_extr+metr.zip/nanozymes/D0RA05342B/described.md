# RSC Advances

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

**[View Article Online](https://doi.org/10.1039/d0ra05342b) [View Journal](https://pubs.rsc.org/en/journals/journal/RA) [| View Issue](https://pubs.rsc.org/en/journals/journal/RA?issueid=RA010042)**

#### PAPER

Cite this: RSC Adv., 2020, 10, 25209

## Dual enzyme-like activity of iridium nanoparticles and their applications for the detection of glucose and glutathione†

Qingqing Wang, *a Guanghui Hong,b Yang Liu,a Jia Haoa and Shaoqin Li[u](http://orcid.org/0000-0001-6990-8728) a

Received 18th June 2020 Accepted 29th June 2020

DOI: 10.1039/d0ra05342b

rsc.li/rsc-advances

Here we show that iridium nanoparticles (Ir NPs) functionally mimic peroxidase and catalase. The possible mechanism of intrinsic dual-enzyme mimetic activity of Ir NPs was investigated. Based on the excellent peroxidase-like activity of Ir NPs, a new colorimetric detection method for reduced glutathione (GSH) and glucose was proposed.

Recently, nanomaterials with inherent enzyme-like activity have attracted considerable attention due to their simple preparation, storage, and separation, as well as the low cost as compared with natural enzymes. Various nanomaterials have been shown to mimic the activity of oxidase, peroxidase, catalase or superoxide dismutase (SOD), ranging from metals,1–10 metal oxides,11–15 and metal coordination complexes16–21 to carbon-based nanomaterials.22–26 The ability of these nanomaterials to replace specic enzymes may offer new opportunities for enzyme-based applications. For example, nanozymes with oxidase-like or peroxidase-like activity have shown potential applications in biosensing and immunoassay, such as the detection of H2O2, glucose, antioxidants, antigens, antibodies and so on.27 By using nanozymes with peroxidase-like activities, Wei and co-workers recently have developed novel sensor arrays to detect biothiols and proteins as well as discriminate cancer cells owing to the differential nonspecic interactions between the components of the sensor arrays and the analytes, providing a potential approach to discriminate versatile analytes.8 Nanomaterials with SOD-like or catalase-like activity have exhibited antioxidant activity, thus could protect aerobic cells from oxidative stress, showing potential application in inammation therapy.6,28–31 Also, nanozymes with high catalase-like activity was able to produce O2 at the hypoxic tumor site, serving as efficient agents for cancer therapy.23,32,33 Very recently, Zhang' group has developed a simple and biocompatible platform to elevate O2 for improving photodynamic therapeutic efficacy by combining the photosensitizer with Prussian blue nanomaterials.34 Prussian blue could catalyze H2O2 to generate O2, and then the photosensitizer transforms the O2 to produce singlet oxygen (1 O2) upon laser irradiation for cancer therapy. Besides, Qu et al. have found the porous platinum nanoparticles with catalase-like activity, which greatly enhanced radiotherapy efficacy and overcame the hypoxic tumor microenvironment.35

In this work, we demonstrate that Ir NPs exhibited both peroxidase-like and catalase-like activities. As shown in Scheme 1, Ir NPs can catalyze the decomposition reaction of H2O2 into oxygen and water, possessing potential applications in the cancer therapy as catalase mimics. On the other hand, the tiny Ir NPs with the average diameter of 2.4 nm exhibited high peroxidase-like catalytic activity. Furthermore, by using H2O2 as an intermediary, a simple and sensitive colorimetric detection method for GSH and glucose has been designed.

Synthesis of Ir NPs were carried out by a simple chemical reduction process, in which sodium hexachloroiridate(III) hydrate was used as precursor with ascorbic acid as a protecting agent and sodium borohydride as the reducing agent (see Experimental section in ESI†). Aer heating and stirring at 95 C for 15 min, the resulting homogeneous light brown Ir NPs dispersion was obtained with good stability and reproducibility.

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a catalytic system involving iridium nanoparticles (Ir NPs) and enzyme-like structures. The system is shown to catalyze the oxidation of 3,3',5,5'-tetramethylbenzidine (TMB) in the presence of hydrogen peroxide (H2O2).

Key components of the system:

1. Ir NPs: Iridium nanoparticles are represented as small spheres at the center of the image.

2. Catalase-like activity: A protein structure is shown above the Ir NPs, representing the catalase-like activity of the system. This structure is involved in the decomposition of H2O2 into O2 and H2O.

3. Peroxidase-like activity: Another protein structure is shown below the Ir NPs, representing the peroxidase-like activity of the system. This structure is involved in the oxidation of TMB.

4. Reactants and products:
   - H2O2 (hydrogen peroxide): Shown as an input on the left side
   - O2 (oxygen) and H2O (water): Shown as products on the right side, resulting from the catalase-like activity
   - TMB: Shown as an input on the left side
   - TMBox (oxidized TMB): Shown as a product on the right side, resulting from the peroxidase-like activity

The image illustrates the dual functionality of the Ir NPs system, mimicking both catalase and peroxidase enzymes. The catalase-like activity decomposes H2O2 into O2 and H2O, while the peroxidase-like activity oxidizes TMB in the presence of H2O2.

This schematic representation demonstrates the potential application of Ir NPs as artificial enzymes or nanozymes in catalytic systems, combining multiple enzymatic functions in a single nanostructure.</DESCRIPTION_FROM_IMAGE>

Scheme 1 Schematic presentation for dual-enzyme mimetic activity of Ir NPs.

a School of Chemistry and Chemical Engineering, Key Laboratory of Microsystems and Microstructures Manufacturing (Ministry of Education), Harbin Institute of Technology, Harbin 150001, China. E-mail: qq8wang@hit.edu.cn; Fax: +86 451 86403483; Tel: +86 451 86403493

b Center of Analysis Measurement, Harbin Institute of Technology, Harbin 150001, China

<sup>†</sup> Electronic supplementary information (ESI) available. See DOI: 10.1039/d0ra05342b

The obtained Ir NPs was thoroughly characterized by various methods. Transmission electron microscopy (TEM) images indicated that the as-prepared Ir NPs showed a narrow size distribution with the average diameter of 2.4 nm (Fig. 1A–C). UV-vis spectrum of Ir NPs showed an absorption peak at 280 nm (Fig. 1D), in agreement with the value reported earlier,28 indicating the formation of Ir NPs. XPS spectra of Ir 4f in Ir NPs were presented in the Fig. S1.† A pair of doublet peaks at 61.0 and 64.0 eV were observed, revealing that Ir in Ir NPs is mostly metallic Ir(0).36 Furthermore, inductively coupled plasma-optical emission spectroscopy (ICP-OES) disclosed that the exact concentration of Ir NPs is 25 mg mL1 . **[View Article Online](https://doi.org/10.1039/d0ra05342b)**

To investigate the peroxidase-like activity of Ir NPs, the peroxidase coupled assay was employed and the change in absorbance of reaction was monitored using a UV-vis absorbance spectrophotometer. As shown in Fig. 2A, exposure of Ir NPs to a colorless peroxidase substrate 3,30 ,5,50 -tetramethylbenzidine (TMB) in the presence of H2O2 resulted in the fast oxidation of TMB to a blue product. However, no color change of the TMB substrate was observed only with Ir NPs or H2O2, indicating the intrinsic peroxidase-like activity of Ir NPs. Similar to HRP, the catalytic activity of Ir NPs is dependent on the pH, temperature and catalyst dosage. Fig. S2† showed that the catalytic activity of Ir NPs was much higher in weakly acidic solution and reached its highest at pH 4.0, consistent with those reported for peroxidase-like NPs and HRP.37–40 In the range of 20–80 C, the maximum catalytic activity was obtained under 50 C. For simplicity, we adopted pH 4.0 and room temperature (20 C) for subsequent analysis of peroxidase-like activity of Ir NPs. When increasing the dosage of Ir NPs, the catalytic activities of Ir NPs clearly increased as shown in Fig. 2B. Interestingly, some small gas bubbles were observed in the tubes at the same time.

In order to conrm which gas was produced and whether Ir NPs had the intrinsic catalase-like activity, the decomposition

<DESCRIPTION_FROM_IMAGE>This image is a composite of four panels labeled A, B, C, and D, presenting different aspects of a study on iridium nanoparticles (Ir NPs).

Panel A: Transmission electron microscopy (TEM) image showing the distribution of Ir NPs. The particles appear as dark spots against a lighter background. The scale bar indicates 20 nm.

Panel B: High-resolution TEM image focusing on a single or few Ir NPs, showing their atomic structure. The scale bar indicates 5 nm.

Panel C: Histogram representing the size distribution of Ir NPs. The x-axis shows the diameter in nm, ranging from 1.0 to 4.0 nm. The y-axis shows the frequency count in percentage, ranging from 0 to 25%. The distribution appears to be roughly normal, with the peak frequency occurring around 2.0-2.5 nm diameter.

Panel D: UV-Vis absorption spectrum of Ir NPs. The x-axis shows the wavelength in nm, ranging from 200 to 800 nm. The y-axis shows absorbance, ranging from 0 to 4. The spectrum shows a strong absorption peak at around 220 nm, followed by a rapid decrease in absorbance as the wavelength increases. The absorbance becomes relatively constant above 400 nm. 

Inset in Panel D: A photograph of a vial containing a colloidal suspension of Ir NPs, appearing as a dark liquid.

This composite image provides comprehensive information about the morphology, size distribution, and optical properties of the synthesized Ir NPs.</DESCRIPTION_FROM_IMAGE>

Fig. 1 (A and B) TEM images of Ir NPs at different magnification. (C) Size distribution histogram of Ir NPs. (D) UV-vis absorption spectrum of Ir NPs. The inset shows the photograph of Ir NPs dispersed in the aqueous solution.

of H2O2 was further investigated by monitoring the changes of UV-vis absorbance at 240 nm under the basic conditions. As shown in Fig. 2C, the absorbance was obviously decreased as the dosage of Ir NPs increased, and many gas bubbles could be observed in the cuvette, indicating Ir NPs could catalyze the decomposition of H2O2 into O2. Temperature and pH can also make a big effect on the catalase-like activity of Ir NPs. Under the basic conditions or higher temperature, much more and bigger gas bubbles were produced (Fig. S3†), suggesting higher catalase-like activity of Ir NPs. Obviously, Ir NPs possessed intrinsic catalase-like activity, which could be regulated by adjusting the temperature and pH.

The formation of cOH during the reactions was assessed to better understand the mechanism for the dual enzyme-like activity of Ir NPs. Terephthalic acid was adopted here as a uorescence probe to trap cOH. As shown in Fig. 2D, in the absence of Ir NPs, terephthalic acid emitted blue. However, the uorescence intensity was gradually decreased as the concentration of Ir NPs increased, suggesting that Ir NPs could consume cOH radicals rather than generate ones. The reactivity of Ir NPs appears to be different from that of the other peroxidase mimics, where cOH mediates the oxidation of organic substrate.

As Ir NPs exhibited the peroxidase-like activity, we monitored the reaction of Ir NPs with H2O2 and TMB. The apparent steadystate kinetic parameters were determined by changing one substrate concentration while keeping the other substrate concentration constant. The value 3 ¼ 39 000 M1 cm1 (at 652 nm) for the oxidized product of TMB was used here to obtain the corresponding concentration term from the absorbance data. As shown in Fig. S4,† we observed that the oxidation reaction catalyzed by Ir NPs followed the typical Michaelis– Menten behavior toward both substrates. The Michaelis– Menten constant (Km) and the maximum initial velocity (Vm) given in Table S1† were obtained by using Lineweaver–Burk plot (Fig. S4B and D†). Compared with the Pd–Ir cubes,38 Ir NPs presented a similar Km for TMB and a very low Km for H2O2, suggesting that Ir NPs have a higher affinity to H2O2. Moreover, Ir NPs presented larger Vm for both of TMB and H2O2, indicating the strong catalytic activity of Ir NPs. What is more important is that Ir NPs showed high stability aer long-term storage. Aer ve months of storage at room temperature, the peroxidase-like catalytic activity of Ir NPs maintained 96% (Fig. S5†), signicantly expanding their practical applications.

On the basis of the high affinity and catalytic activity of Ir NPs to H2O2, the analytes that could consume or produce H2O2 could be detected indirectly by using the TMB as substrate.27 Therefore, a simple colorimetric method was developed to detect GSH and glucose using Ir NPs. GSH, which plays an important role in many cellular processes including redox activities, signal transduction, detoxication, and gene regulation,41,42 can consume H2O2 and result in the shallowing color of the Ir NPs-TMB-H2O2 system. As presented in Fig. 3A, the absorbance dropped sharply with the addition of GSH. And a linear relationship between the absorbance and logarithmic values of GSH's concentrations was obtained in the range from 200 nM to 100 mM (Fig. 3B). The level changes of GSH have been linked to varieties of diseases, such as diabetes, psoriasis, liver

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled A, B, C, and D, each presenting different aspects of an experiment involving iridium nanoparticles (Ir NPs).

Graph A: UV-Vis absorption spectra
- X-axis: Wavelength (nm), range 500-800 nm
- Y-axis: Absorbance, range 0-1.2
- Three spectra labeled a, b, and c
- Spectrum c shows a peak at around 650 nm with absorbance of 0.8
- Spectra a and b show minimal absorbance across the range
- Inset image shows three test tubes labeled a, b, and c, with c containing a blue solution

Graph B: Time-dependent absorbance
- X-axis: Time (min), range 0-5 min
- Y-axis: Absorbance, range 0-1.6
- Six curves representing different concentrations of Ir NPs (0.05-0.25 μg/mL)
- Absorbance increases with time for all concentrations
- Higher concentrations show steeper increases in absorbance

Graph C: Time-dependent absorbance decay
- X-axis: Time (min), range 0-10 min
- Y-axis: Absorbance, range 0.4-0.9
- Four curves representing blank and three Ir NP concentrations (0.5, 1.25, 5.0 μg/mL)
- Higher Ir NP concentrations show faster decay in absorbance
- Inset image shows four vials with varying shades of dark solutions

Graph D: Fluorescence spectra
- X-axis: Wavelength (nm), range 350-550 nm
- Y-axis: Intensity (a.u.), range 0-120
- Eight curves representing blank and seven Ir NP concentrations (0.1-2.5 μg/mL)
- All curves show a peak around 440 nm
- Peak intensity decreases with increasing Ir NP concentration

This image demonstrates the optical properties and catalytic activity of Ir NPs at various concentrations, showing their effects on absorption and fluorescence spectra, as well as time-dependent changes in absorbance.</DESCRIPTION_FROM_IMAGE>

Fig. 2 (A) The absorption spectra and digital photos of different colorimetric reaction systems: (a) TMB + H2O2, (b) TMB + Ir NPs, and (c) TMB + H2O2+Ir NPs. (B) Time-dependent absorbance changes at 652 nm of TMB reaction solutions catalyzed by the different concentrations of Ir NPs. (C) Time-dependent absorbance changes at 240 nm of 20 mM H2O2 catalyzed by the different concentrations of Ir NPs incubated in 0.1 M HAc– NaAc buffer (pH 9.0). (D) The effect of concentration of Ir NPs on the formation of hydroxyl radical with terephthalic acid as a fluorescence probe. Reaction condition: 0.1 M HAc–NaAc buffer (pH 6.0).

<DESCRIPTION_FROM_IMAGE>This image contains four separate graphs labeled A, B, C, and D, each presenting different data related to absorbance measurements.

Graph A:
This graph shows the relationship between absorbance and glutathione (GSH) concentration. The x-axis represents GSH concentration in nM, ranging from 0 to 5x10^5 nM. The y-axis shows absorbance values from 0 to 3. The data points follow a steep decline in absorbance as GSH concentration increases, with the curve leveling off at higher concentrations.

Graph B:
This graph presents a linear relationship between absorbance and the logarithm of GSH concentration. The x-axis shows Log[GSH] values from 2 to 6, while the y-axis represents absorbance from 0 to 3. The graph includes an equation for the linear fit: A=5.41-1.05 Log[GSH], with an R² value of 0.992, indicating a strong correlation.

Graph C:
This graph demonstrates a linear relationship between absorbance and glucose concentration. The x-axis shows glucose concentration in mM, ranging from 0 to 4 mM. The y-axis represents absorbance from 0 to 3. The linear fit equation is provided: A=0.088+1.55 [Glucose], with an R² value of 0.996, suggesting a very strong correlation.

Graph D:
This graph is a bar chart comparing the absorbance values for different sugar compounds. The x-axis lists various sugars (Blank, Glucose, Fructose, Maltose, Lactose, and Sucrose), while the y-axis shows absorbance values from 0 to 0.8. Glucose shows the highest absorbance, followed by maltose. The other sugars and the blank have relatively low absorbance values.

Additionally, Graph D includes an inset image showing six test tubes numbered 1 to 6, containing solutions of varying shades of blue, likely corresponding to the different sugar solutions tested.

These graphs collectively present data on the detection and quantification of glutathione and various sugars using an absorbance-based method, demonstrating the specificity and sensitivity of the assay for different analytes.</DESCRIPTION_FROM_IMAGE>

Fig. 3 (A) Dose–response curve for GSH detection at 652 nm. (B) Linear relationship between the absorbance and logarithmic values of GSH's concentrations in the range from 200 nM to 100 mM. (C) Dose– response curve for glucose detection at 652 nm. (D) Determination of the selectivity of glucose detection (from left to right: blank, 0.3 mM glucose, 3 mM fructose, 3 mM maltose, 3 mM lactose and 3 mM sucrose). Inset: the color change with the different solutions. The error bars represents the standard deviation of four measurements.

damage and Parkinsons.43,44 The proposed colorimetric biosensor provided a sensitive method to monitor GSH. Furthermore, because H2O2 is the main product of the glucose oxidase (GOx)-catalyzed reaction; glucose could be detected based on the combination of GOx. Fig. 3C shows typical glucose concentration–response curves with the linear range of 10 mM to 2 mM. According to the principle of S/N ¼ 3, the calculated detection limit was 5.8 mM. Table S2† was listed to compare the sensing performance of Ir NPs with other nanomaterials. Ir NPs are superior to other nanomaterials in lower detection limit and wider detection range for colorimetric determination of glucose.

To explore the selectivity of above glucose sensor, 10 times concentration of control samples including fructose, maltose, lactose and sucrose were tested as shown in Fig. 3D. The color difference could be distinguished by the naked eye, suggesting the high selectivity of the biosensing system for glucose detection. Using this method, we detected glucose in 50-fold dilution fetal bovine serum to demonstrate the feasibility of this biosensor for practical applications, and the results are listed in Table S3.† As can be seen, the recoveries of glucose fall in the range of 93.3–104% by using the standard addition method. The proposed biosensor was also applied for determining glucose concentrations in blood samples donated by healthy and diabetic persons (Fig. S6†). According to the calibration curve, the concentration of glucose from different samples was 7.0 mM and 14.4 mM, which agrees well with that measured in the local hospital, 6.8 mM and 14.4 mM. Therefore, this colorimetric method is suitable and satisfactory for glucose analysis of real samples with high sensitivity and selectivity.

In summary, Ir NPs synthesized by a simple chemical reduction process exhibited both of peroxidase-like and catalase-like activity. Moreover, the dual enzyme-like activity could be regulated by adjusting the temperature and pH. On the one hand, Ir NPs could consume cOH radicals exhibiting potential applications in the antioxidant therapeutics as antioxidant nanozymes. On the other hand, as peroxidase mimics, Ir NPs were successfully applied in the construction of colorimetric biosensors to detect GSH and glucose. This work will facilitate the utilization of intrinsic dual-enzyme activity and other catalytic properties of Ir NPs in analytical chemistry, biotechnology, and medicine. **[View Article Online](https://doi.org/10.1039/d0ra05342b)**

### Conflicts of interest

There are no conicts to declare.

#### Acknowledgements

This work is supported by the National Postdoctoral Program for Innovative Talents (No. BX20180090), China Postdoctoral Science Foundation funded project (2019M661262), Heilongjiang Postdoctoral Financial Assistance (No. LBH-Z18095) and Key Laboratory of Microsystems and Microstructures Manufacturing (Ministry of Education) (No. 2019KM004).

#### Notes and references

- 1 O. Adeniyi, S. Sicwetsha and P. Mashazi, ACS Appl. Mater. Interfaces, 2020, 12, 1973–1987.
- 2 Y.-W. Bao, X.-W. Hua, H.-H. Ran, J. Zeng and F.-G. Wu, J. Mater. Chem. B, 2019, 7, 296–304.
- 3 S. Gao, H. Lin, H. Zhang, H. Yao, Y. Chen and J. Shi, Adv. Sci., 2019, 6, 1801733.
- 4 X. Mu, J. Wang, Y. Li, F. Xu, W. Long, L. Ouyang, H. Liu, Y. Jing, J. Wang, H. Dai, Q. Liu, Y. Sun, C. Liu and X. D. Zhang, ACS Nano, 2019, 13, 1870–1884.
- 5 Q. Zhang, S. Chen, H. Wang and H. Yu, ACS Appl. Mater. Interfaces, 2018, 10, 8666–8675.
- 6 Y. Huang, Z. Liu, C. Liu, Y. Zhang, J. Ren and X. Qu, Chem.– Eur. J., 2018, 24, 10224–10230.
- 7 H. Zhang, X. Liang, L. Han and F. Li, Small, 2018, 14, 1803256.
- 8 X. Wang, L. Qin, M. Zhou, Z. Lou and H. Wei, Anal. Chem., 2018, 90, 11696–11702.
- 9 Q. Wang, X. Zhang, L. Huang, Z. Zhang and S. Dong, Angew. Chem., Int. Ed., 2017, 56, 16082–16085.
- 10 Z. Zhang, Z. Chen, F. Cheng, Y. Zhang and L. Chen, Biosens. Bioelectron., 2017, 89, 932–936.
- 11 X. Wang, X. J. Gao, L. Qin, C. Wang, L. Song, Y.-N. Zhou, G. Zhu, W. Cao, S. Lin, L. Zhou, K. Wang, H. Zhang, Z. Jin, P. Wang, X. Gao and H. Wei, Nat. Commun., 2019, 10, 704.
- 12 Q. Wang, J. Chen, H. Zhang, W. Wu, Z. Zhang and S. Dong, Nanoscale, 2018, 10, 19140–19146.
- 13 S. Ghosh, P. Roy, N. Karmodak, E. D. Jemmis and G. Mugesh, Angew. Chem., Int. Ed., 2018, 57, 4510–4515.

- 14 L. Han, H. Zhang, D. Chen and F. Li, Adv. Funct. Mater., 2018, 28, 1800018.
- 15 D. Li, B. Liu, P.-J. J. Huang, Z. Zhang and J. Liu, Chem. Commun., 2018, 54, 12519–12522.
- 16 X. Liu, Z. Yan, Y. Zhang, Z. Liu, Y. Sun, J. Ren and X. Qu, ACS Nano, 2019, 13, 5222–5230.
- 17 L. Huang, J. Chen, L. Gan, J. Wang and S. Dong, Sci. Adv., 2019, 5, 5490.
- 18 K. Zhang, M. Tu, W. Gao, X. Cai, F. Song, Z. Chen, Q. Zhang, J. Wang, C. Jin, J. Shi, X. Yang, Y. Zhu, W. Gu, B. Hu, Y. Zheng, H. Zhang and M. Tian, Nano Lett., 2019, 19, 2812–2823.
- 19 B. Xu, H. Wang, W. Wang, L. Gao, S. Li, X. Pan, H. Wang, H. Yang, X. Meng, Q. Wu, L. Zheng, S. Chen, X. Shi, K. Fan, X. Yan and H. Liu, Angew. Chem., Int. Ed., 2019, 58, 4911–4916.
- 20 S. Li, X. Liu, H. Chai and Y. Huang, TrAC, Trends Anal. Chem., 2018, 105, 391–403.
- 21 J. Chen, Q. Wang, L. Huang, H. Zhang, K. Rong, H. Zhang and S. Dong, Nano Res., 2018, 11, 4905–4913.
- 22 H. Ding, Y. Cai, L. Gao, M. Liang, B. Miao, H. Wu, Y. Liu, N. Xie, A. Tang, K. Fan, X. Yan and G. Nie, Nano Lett., 2019, 19, 203–209.
- 23 K. Fan, J. Xi, L. Fan, P. Wang, C. Zhu, Y. Tang, X. Xu, M. Liang, B. Jiang, X. Yan and L. Gao, Nat. Commun., 2018, 9, 1440.
- 24 H. Wang, P. Li, D. Yu, Y. Zhang, Z. Wang, C. Liu, H. Qiu, Z. Liu, J. Ren and X. Qu, Nano Lett., 2018, 18, 3344–3351.
- 25 J. Zhang, X. Lu, D. Tang, S. Wu, X. Hou, J. Liu and P. Wu, ACS Appl. Mater. Interfaces, 2018, 10, 40808–40814.
- 26 H. Qiu, F. Pu, X. Ran, C. Liu, J. Ren and X. Qu, Anal. Chem., 2018, 90, 11775–11779.
- 27 Q. Wang, H. Wei, Z. Zhang, E. Wang and S. Dong, TrAC, Trends Anal. Chem., 2018, 105, 218–224.
- 28 H. Su, D.-D. Liu, M. Zhao, W.-L. Hu, S.-S. Xue, Q. Cao, X.-Y. Le, L.-N. Ji and Z.-W. Mao, ACS Appl. Mater. Interfaces, 2015, 7, 8233–8242.
- 29 T. Chen, H. Zou, X. Wu, C. Liu, B. Situ, L. Zheng and G. Yang, ACS Appl. Mater. Interfaces, 2018, 10, 12453–12462.
- 30 Y. Huang, Z. Liu, C. Liu, E. Ju, Y. Zhang, J. Ren and X. Qu, Angew. Chem., Int. Ed., 2016, 55, 6646–6650.
- 31 N. Singh, M. A. Savanur, S. Srivastava, P. D'Silva and G. Mugesh, Angew. Chem., Int. Ed., 2017, 56, 14267–14271.
- 32 L. Feng, Z. Dong, C. Liang, M. Chen, D. Tao, L. Cheng, K. Yang and Z. Liu, Biomaterials, 2018, 181, 81–91.
- 33 Y. Zhang, F. Wang, C. Liu, Z. Wang, L. Kang, Y. Huang, K. Dong, J. Ren and X. Qu, ACS Nano, 2018, 12, 651–661.
- 34 Z. L. Yang, W. Tian, Q. Wang, Y. Zhao, Y. L. Zhang, Y. Tian, Y. X. Tang, S. J. Wang, Y. Liu, Q. Q. Ni, G. M. Lu, Z. G. Teng and L. J. Zhang, Adv. Sci., 2018, 5, 1700847.
- 35 Y. Zhang, F. Wang, C. Liu, Z. Wang, L. Kang, Y. Huang, K. Dong, J. Ren and X. Qu, ACS Nano, 2018, 12, 651–661.
- 36 X. Xia, L. Figueroa-Cosme, J. Tao, H.-C. Peng, G. Niu, Y. Zhu and Y. Xia, J. Am. Chem. Soc., 2014, 136, 10878–10881.
- 37 L. Zhang, L. Han, P. Hu, L. Wang and S. Dong, Chem. Commun., 2013, 49, 10480–10482.

- 38 X. Xia, J. Zhang, N. Lu, M. J. Kim, K. Ghale, Y. Xu, E. McKenzie, J. Liu and H. Yet, ACS Nano, 2015, 9, 9994– 10004. **[View Article Online](https://doi.org/10.1039/d0ra05342b)**
  - 39 Q. Wang, X. Zhang, L. Huang, Z. Zhang and S. Dong, ACS Appl. Mater. Interfaces, 2017, 9, 7465–7471.
  - 40 L. Z. Gao, J. Zhuang, L. Nie, J. B. Zhang, Y. Zhang, N. Gu, T. H. Wang, J. Feng, D. L. Yang, S. Perrett and X. Yan, Nat. Nanotechnol., 2007, 2, 577–583.
- 41 J. Liu, L. Meng, Z. Fei, P. J. Dyson, X. Jing and X. Liu, Biosens. Bioelectron., 2017, 90, 69–74.
- 42 J. Li, L. Chen, T. Lou and Y. Wang, ACS Appl. Mater. Interfaces, 2011, 3, 3936–3941.
- 43 Z.-Z. Dong, L. Lu, C.-N. Ko, C. Yang, S. Li, M.-Y. Lee, C.-H. Leung and D.-L. Ma, Nanoscale, 2017, 9, 4677–4682.
- 44 D. Fan, C. Shang, W. Gu, E. Wang and S. Dong, ACS Appl. Mater. Interfaces, 2017, 9, 25870–25877.