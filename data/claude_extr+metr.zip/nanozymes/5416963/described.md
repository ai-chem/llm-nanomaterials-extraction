<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

# *Research Article*

# **Oxidase-Like Catalytic Performance of Nano-MnO2 and Its Potential Application for Metal Ions Detection in Water**

**Kai Sun , 1 Qingzhu Liu,1 Rui Zhu,1 Qi Liu,1 Shunyao Li,2 Youbin Si , 1 and Qingguo Huang 3**

*1 Anhui Province Key Laboratory of Farmland Ecological Conservation and Pollution Prevention, School of Resources and Environment, Anhui Agricultural University, 130 Changjiang West Road, Hefei, 230036 Anhui, China 2 College of Resources and Environmental Sciences, Nanjing Agricultural University, Nanjing 210095, China 3 Department of Crop and Soil Sciences, University of Georgia, Griffin, GA 30223, USA*

Correspondence should be addressed to Youbin Si; [youbinsi@ahau.edu.cn](mailto:youbinsi@ahau.edu.cn) and Qingguo Huang; [qhuang@uga.edu](mailto:qhuang@uga.edu)

Received 3 June 2019; Revised 15 August 2019; Accepted 5 September 2019; Published 3 November 2019

Academic Editor: Gu¨nther K. Bonn

Copyright © 2019 Kai Sun et al. -is is an open access article distributed under the [Creative Commons Attribution License](https://creativecommons.org/licenses/by/4.0/), which permits unrestricted use, distribution, and reproduction in any medium, provided the original work is properly cited.

Certain nano-scale metal oxides exhibiting the intrinsic enzyme-like reactivity had been used for environment monitoring. Herein, we evaluated the oxidase-mimicking activity of environmentally relevant nano-MnO2 and its sensitivity to the presence of metal ions, and particularly, the use of MnO2 nanozyme to potentially detect Cu2+, Zn2+, Mn2+, and Fe2+ in water. -e results indicated the oxidase-like activity of nano-MnO2 at acidic pH-driven oxidation of 2,6-dimethoxyphenol (2,6-DMP) via a singleelectron transfer process, leading to the formation of a yellow product. Notably, the presence of Cu2+ and Mn2+ heightened the oxidase-mimicking activity of nano-MnO2 at 25°C and pH 3.8, showing that Cu2+ and Mn2+ could modify the reactive sites of nano-MnO2 surface to ameliorate its catalytic activity, while the activity of MnO2 nanozyme in systems with Zn2+ and Fe2+ was impeded probably because of the strong affinity of Zn2+ and Fe2+ toward nano-MnO2 surface. Based on these effects, we designed a procedure to use MnO2 nanozyme to, respectively, detect Cu2+, Zn2+, Mn2+, and Fe2+ in the real water samples. MnO2 nanozymebased detecting systems achieved high accuracy (relative errors: 2.2–26.1%) and recovery (93.0–124.0%) for detection of the four metal ions, respectively. Such cost-effective detecting systems may provide a potential application for quantitative determination of metal ions in real water environmental samples.

# **1. Introduction**

In recent years, considerable attention has been paid to the applications of artificial nanomaterials as nanozymes in mimicking the intrinsic catalytic function of natural enzymes due to their unique structural, electrical, and optical properties, as well as remarkable catalytic activities [\[1–3](#page-9-0)]. Compared with the natural enzymes, the artificial nanozymes exhibited higher robustness and stability under harsh conditions, lower production cost, simpler storage conditions, and more effective catalytic activity [\[4–6\]](#page-9-0). At present, nanozymes are primarily composed of artificial metal and metal oxide nanomaterials that can mimic the catalytic activities of natural peroxidases and/or oxidases [[3, 7](#page-9-0)]. For instance, the intrinsic peroxidase-/oxidase-like activities of Au-Ag, CeO2, MnFe2O4, NiO, and V2O5 nanoparticles have been used in various applications ranging from biosensing and immunoassay to environment monitoring [[3, 7](#page-9-0)–[10\]](#page-9-0). Liu et al. reported the oxidase-mimicking activity of CeO2 nanoparticles by fluoride capping, such nanozymes could detect micromolar levels of F− in water and toothpastes [\[11\]](#page-9-0).

It is well documented that MnO2 nanomaterial had the intrinsic enzyme-like activity to catalyze the chromogenic reaction of substrates, which could be used as a nanozyme indicator for bioimaging, biosensing, and delivery of singlestranded DNA and drugs [[3](#page-9-0), [12, 13\]](#page-9-0). In particular, chromogenic reactions by nano-MnO2 have been developed using dissolved O2 as the oxidant, avoiding the use of H2O2 [[14](#page-9-0)], thus providing easy and rapid detecting systems for quantitative analysis of any substances that can serve either as the accelerator or inhibitor of the chromogenic reactions [[15](#page-9-0), [16\]](#page-9-0). Such systems could be used for real environmental water samples, but their potential application for quantitative determination of metal ions has been rarely explored.

-e contamination of metal ions has always been a focus of concern [[17](#page-9-0)]. Toxic metal ions (such as Cu2+, Zn2+, Pb2+, and Fe2+) having toxicity level greater than safety levels can cause acute toxicities to most aquatic biota [\[18\]](#page-9-0). -us, having ways that can easily and rapidly detect these metal ions in water matrices is vital to protect wild species and human health. A instrumental method can be used to directly detect these metal ions in water samples, such as inductively coupled plasma mass spectrometry (ICPMS), but such methods are usually expensive and time-consuming and require expertise to operate [\[19, 20](#page-9-0)].

Recently, the enzyme-like activity of environmentally relevant nano-MnO2 has proven to be highly effective for sensing applications [\[16, 21](#page-9-0), [22](#page-9-0)]. In this study, nano-MnO2 was chosen as the natural oxidase mimic owing to its outstanding redox chemistry, stability, and biocompatibility properties [\[23](#page-9-0)–[25](#page-9-0)]. We systematically evaluated the oxidaselike activity of nano-MnO2 in catalyzing the chromogenic reaction of 2,6-dimethoxyphenol (2,6-DMP), and identified the influence of Cu2+, Zn2+, Mn2+, and Fe2+, based on which methods were developed to, respectively, detect these metal ions in environmental water samples using MnO2 nanozyme-2,6-DMP detecting systems.

#### **2. Materials and Methods**

*2.1. Chemicals and Materials.* Nano-scale MnO2 (≥99.9%) was obtained from DK Nano Technology Co., Ltd. (Beijing, China). -e characteristics of nano-MnO2 are shown in Figure 1. -e size and morphology of the nano-MnO2 were analyzed using a transmission electron microscope (TEM, JEM-200CX). -e spectral characteristics of nano-MnO2 were investigated using a UV-Vis spectroscope (Shimadzu, UV-2550) and a Fourier-transform infrared spectroscope (-ermo Scientific, NICOLET iS50 FTIR). -e phase of the nano-MnO2 was measured over the 2*θ* range from 5 to 85 degrees using an X-ray diffractometer (XRD, -ermo X'TRA).

2,6-DMP (CAS: 91-10-1) was purchased from Energy Chemical Technology Co., Ltd (Shanghai, China). Metal sulfates (*i.e.*, MgSO4, CuSO4, Al2(SO4)3, ZnSO4, MnSO4·H2O, FeSO4·7H2O, and PbSO4) were obtained from Shanghai Aladdin Bio-Chem Technology Co., Ltd. Stock solutions of metal ions (100 mmol·L− 1 ) were prepared in Milli-Q ultrapure water (18.2 MΩ·cm) and stored at 4°C. We had previously evaluated the effects of K+ , Na+ , Ag+ , Co2+, Hg2+, Ca2+, Cd2+, and Fe3+ on the oxidase-like activity of nano-MnO2. -e buffer used in this study was a citratephosphate buffer solution (C-PBS: 10 mmol·L− 1 citric acid and 10 mmol·L− 1 Na2HPO4, pH 3.8) adjusted with HCl and NaOH. All the other chemicals were of analytical reagent grade and used as received.

*2.2. Assessment of the Enzyme-Like Activity of Nano-MnO2.* To assess the enzyme-like activity of nano-MnO2, MnO2 nanoparticles were tested in 10 mL of a C-PBS (10 mmol·L− 1 , pH 3.8) buffer at room temperature (25° C) containing 1.0 mmol·L− 1 2,6-DMP as the chromogenic substrate and naturally dissolved O2 as the cofactor [[14, 26](#page-9-0)]. After the nano-MnO2 (0.1 mg·mL− 1 ) had been mixed thoroughly with the 2,6-DMP reaction solution, the absorbance was immediately measured at 468 nm using a UV-Vis spectrophotometer (Shanghai Lengguang 722S) in a quartz cuvette with a 1 cm light path. -e solution was monitored every 20 s for 3 min by recording the change of absorbance value at 468 nm. One unit of nano-MnO2 activity (U·mL− 1 ) is defined as the amount of nanozyme that causes one unit of absorbance change per minute at 468 nm in C-PBS (10 mmol·L− 1 , pH 3.8) buffer containing 1.0 mmol·L− 1 2,6- DMP. -erefore, the oxidase-mimicking activity of nano-MnO2 can be calculated through the rate of absorbance change. -e same solution free of nano-MnO2 was used as the blank control. All experiments were performed in triplicate.

*2.3. Effect of Different Factors on the Enzyme-Like Activity of Nano-MnO2.* To evaluate the influence of nano-MnO2 dosage on 2,6-DMP oxidation, the reaction was conducted in a 50 mL flask containing 1.0 mmol·L− 1 2,6-DMP and nano-MnO2 varying between 0.005 and 0.32 mg·mL− 1 in 10 mL C-PBS (10 mmol·L− 1 ) at 25°C and pH 3.8. -e effect of the substrate concentration on the chromogenic reaction was also performed in a 50 mL flask containing 0.1 mg·mL− 1 nano-MnO2 and 2,6-DMP at a concentration varying between 0.005 and 1.0 mmol·L− 1 in 10 mL C-PBS. -e reaction kinetics parameters *K*m and *v*max were calculated by the Lineweaver–Burk plot of the Michaelis–Menten kinetics equation:

$$\frac{1}{\nu} = \left(\frac{K_{\rm m} + [S]}{\nu_{\rm max} \cdot [S]}\right),\tag{1}$$

where *v* is the reaction velocity, [*S*] is the substrate concentration, *K*m is the Michaelis constant, and *v*max is the maximal reaction velocity.

Experimental procedures similar to those described above were used to explore the effects of pH and temperature on the enzyme-like activity of nano-MnO2. -e reactions were carried at different pH and a wide range of temperature. For studying the pH effect, 10 mL of 10 mmol·L− 1 C-PBS (pH 2.0–10.0) buffer containing 1.0 mmol·L− 1 2,6- DMP was mixed with 0.1 mg·mL− 1 nano-MnO2 at room temperature (25° C). For studying the effect of temperature, 10 mL of 10 mmol·L− 1 C-PBS (pH 3.8) buffer containing 1.0 mmol·L− 1 2,6-DMP was mixed with 0.1 mg·mL− 1 nano-MnO2 at a temperature ranging from 10°C to 90° C. Absorbance was recorded at 468 nm at 20 s intervals. All experiments were performed in triplicate.

*2.4. Enzyme-Like Activity of Nano-MnO2 for Detecting Metal Ions in Water.* A series of mixtures containing different metal ions (*i.e*., Mg2+, Cu2+, Al3+, Zn2+, Mn2+, Fe2+, and Pb2+) and nano-MnO2 (0.1 mg·mL− 1 ) in 10 mL of C-PBS buffer (pH 3.8) were equilibrated at room temperature

<DESCRIPTION_FROM_IMAGE>The image contains four separate panels labeled (a), (b), (c), and (d), each presenting different analytical data:

(a) Transmission Electron Microscopy (TEM) image:
This panel shows a TEM micrograph of nanoparticles or nanostructures. The scale bar indicates 50 nm. The structures appear to be aggregated or clustered, with irregular shapes and varying sizes. The particles seem to have a rough surface texture and are not uniformly distributed.

(b) UV-Visible Absorption Spectrum:
This graph shows the absorbance of a sample as a function of wavelength from 200 to 700 nm. The spectrum exhibits a sharp increase in absorbance below 250 nm, reaching a maximum absorbance of about 5. There is a rapid decrease in absorbance between 250 and 300 nm, followed by a plateau with very low absorbance (close to 0) from 300 to 700 nm.

(c) Fourier Transform Infrared (FTIR) Spectrum:
This panel presents an FTIR spectrum showing transmittance (%) versus wavenumbers (cm^-1) from 500 to 4000 cm^-1. Several characteristic peaks are labeled:
- 596.65 cm^-1
- 1034.03 cm^-1
- 1633.69 cm^-1
- 3441.26 cm^-1
The spectrum shows a complex pattern of absorption bands, with the most prominent dip in transmittance occurring around 3441.26 cm^-1.

(d) X-ray Diffraction (XRD) Pattern:
This graph shows the XRD pattern of the sample, plotting intensity (in arbitrary units, a.u.) versus the diffraction angle 2θ (in degrees) from 10° to 80°. The pattern displays multiple sharp peaks of varying intensities, indicating a crystalline structure. The most intense peak is observed around 30°, with other significant peaks at approximately 35°, 43°, 57°, and 63°.

These four analytical techniques together provide information about the morphology (TEM), optical properties (UV-Vis), chemical composition and bonding (FTIR), and crystal structure (XRD) of the studied material, likely a nanostructured compound or composite.</DESCRIPTION_FROM_IMAGE>

Figure 1: MnO2 nanomaterial was characterized by (a) TEM imaging, (b) UV-Vis spectra, (c) FTIR spectra, and (d) XRD pattern to determine the size, morphology, group, and crystalline structure of nano-MnO2.

(25°C), and then C-PBS containing 1.0 mmol·L− 1 2,6-DMP was added to each of the mixtures and then monitored using a UV-Vis spectrophotometer at 468 nm. All experiments were performed in triplicate.

Based on the above results, MnO2 nanozyme-2,6-DMP reaction systems for, respectively, detecting Cu2+, Zn2+, Mn2+, and Fe2+ in real environmental water matrices were also assessed. 10-fold dilution of real samples (pond water 1 and 2 from Anhui Agricultural University campus) in C-PBS buer (10 mmol·L− 1 , pH 3.8) were spiked with Cu2+, Zn2+, Mn2+, or Fe2+ (0.002, 0.01, 0.05, and 0.25 mmol·L− 1 ) and were then detected using the described MnO2 nanozyme-2,6- DMP-sensing systems following the same process described above. Additionally, these samples were also determined by ICPMS (6300 Series, ermo Fourier, USA) for comparison. All experiments were performed in quintuplicate.

2.5. Statistical Analysis. All data were processed with Excel 2010 (Microsoft, Redmond, WA). Each data point in the gures and tables represents an average value. e standard deviation of replicate samples is shown in the gures as an error bar.

#### 3. Results and Discussions

3.1. Oxidase-Like Activity of Nano-MnO2. To assess the intrinsic enzyme-mimicking activity of nano-MnO2, 2,6-DMP was chosen as the chromogenic substrate in the standard oxidation reaction, and the reaction kinetics was tested at 468 nm corresponding to the oxidized 2,6-DMP. e change of absorbance over time by the oxidation of 2,6-DMP in C-PBS buer at 25°C and pH 3.8 is shown in Figure 2. Nano-MnO2 could catalyze the colorless 2,6-DMP to form a chromogenic product (a yellow product, i.e., 3,3′,5,5′-tetramethyl-4,4′-diphenoquinone) with a change in absorbance via the radical-based C-C self-coupling mechanism, like laccase-mediated oxidative coupling reactions of 2,6- DMP under the same conditions [[26, 27](#page-9-0)]. e absorbance changes linearly with time under the tested conditions (R2 > 0.99), and the oxidase-like activity of nano-MnO2 was calculated to be 0.047 U·mL− 1 . e oxidative coupling of 2,6- DMP catalyzed by nano-MnO2 was described as follows: rst, 2,6-DMP was adsorbed onto the reactive sites of nano-MnO2 surface, followed by the single-electron oxidation of 2,6-DMP by nano-MnO2, leading to the formation of chromogenic product and the release of Mn2+ from the nanoparticle surface [[14](#page-9-0), [28\]](#page-9-0).

e role of dissolved O2 in the oxidation of 2,6-DMP was evaluated by purging the reaction solution with N2, resulting in a decrease on the oxidase-like activity of nano-MnO2. is revealed that dissolved O2 acted as an electron acceptor in the catalytic reactions [[14](#page-9-0), [29](#page-9-0)]. is result is in agreement with an earlier report that indicated the oxidation of a substrate in the absence of H2O2 via bovine

<DESCRIPTION_FROM_IMAGE>The image presents a graph showing the relationship between Absorbance (468 nm) and Time (min). The graph is a linear plot with the following characteristics:

1. X-axis: Time (min), ranging from 0.4 to 3.2 minutes
2. Y-axis: Absorbance (468 nm), ranging from 0.10 to 0.26

The graph shows a clear linear trend with data points represented by red triangles. Each data point has error bars, indicating the uncertainty in the measurements.

The linear regression equation is provided:
y = 0.0467x + 0.0915

The coefficient of determination (R²) is also given:
R² = 0.9989

This extremely high R² value indicates a very strong linear correlation between time and absorbance.

There are 8 data points visible on the graph, approximately at the following coordinates:
(0.4, 0.12), (1.1, 0.14), (1.4, 0.15), (1.8, 0.17), (2.1, 0.18), (2.5, 0.20), (2.8, 0.22), (3.2, 0.23)

The graph suggests that the absorbance at 468 nm increases linearly with time, which could indicate a chemical reaction progressing or the formation of a colored product over time.

In the bottom right corner of the image, there is an inset photograph of a glass container holding a yellow-orange liquid. This likely represents the sample being measured in the spectrophotometric analysis, corresponding to the absorbance data in the graph.

The presence of this graph and the spectrophotometric data suggests that this image is from a kinetics study, possibly monitoring the progress of a reaction by measuring the absorbance of a colored product or reactant over time.</DESCRIPTION_FROM_IMAGE>

Figure 2: Oxidase-like activity of nano-MnO2 for catalyzing the chromogenic reaction of 2,6-DMP in C-PBS buer at 25°C and pH 3.8. Reaction conditions: Nano-MnO2 0.1 mg·mL− 1 ; 2,6- DMP 1.0 mmol·L− 1 . Error bars represent the standard deviation (n 3).

serum albumin- (BSA-) stabilized MnO2 nanoparticles [[30](#page-10-0)]. Additionally, the stability of nano-MnO2 in the reaction system was also studied over a one-month storage period. With the increase in storage time, the release of Mn2+ increased mildly, but no signicant dierence in the oxidation of 2,6-DMP was detected, implying that the capacity of nano-MnO2 to oxidize 2,6-DMP exhibits a high stability. ese results demonstrated that nano-MnO2 possessed a stable oxidase-like activity to catalyze the chromogenic reaction of 2,6-DMP at 25° C and pH 3.8 in the absence of H2O2.

3.2. Eects of Nano-MnO2 and Substrate Concentration on 2,6-DMP Oxidation. We further assessed the in¥uence of nano-MnO2 concentration on 2,6-DMP oxidation catalyzed by MnO2 nanozyme by UV-Vis spectrophotometry. As shown in Figure 3, the oxidation of 2,6-DMP catalyzed by MnO2 nanozyme showed a distinct absorbance peak at the wavelength of 468 nm, and the increase of this absorbance over time was obvious resulting from 2,6-DMP oxidation (Figure 2). e variation of the absorbance peak was observed by adding dierent concentrations of MnO2 nanozyme (Figure 3). Increasing the concentration of nano-MnO2 from 0.005 to 0.3 mg·mL− 1 resulted in a liner increase in the oxidase-like activity of nano-MnO2 (0.002–0.126 U·mL− 1 ) in oxidizing 2,6-DMP (Figure 4). According to the correlation of the nano-MnO2 concentration and its oxidase-like activity, the apparent pseudosecond-order rate constant was determined to be 0.445 U·mg− 1 (R2 0.992). ese results demonstrated that increasing the concentration of nano-MnO2 facilitated the oxidase-like activity of nano-MnO2 to catalyze the oxidation of 2,6-DMP.

For discussing the catalytic mechanism and obtaining the steady-state kinetic parameters, the initial reaction rate (1 min) of 2,6-DMP oxidation catalyzed by nano-MnO2 was

<DESCRIPTION_FROM_IMAGE>The image presents a UV-Visible absorption spectrum for Nano-MnO2 (manganese dioxide nanoparticles) at various concentrations ranging from 0.005 to 0.32 mg·mL^-1. The graph displays absorbance on the y-axis, ranging from 0 to 1.5, and wavelength on the x-axis, spanning from 250 to 600 nm.

Key features of the spectrum:

1. Two distinct absorption peaks are observed:
   a. A sharp peak at approximately 270-280 nm
   b. A broader peak centered at 468 nm (as indicated by the vertical dashed line)

2. The intensity of both peaks increases with increasing concentration of Nano-MnO2.

3. The peak at 270-280 nm shows higher absorbance values (maximum around 1.2) compared to the peak at 468 nm (maximum around 0.9).

4. Between the two main peaks (from about 300 to 390 nm), there is a region of relatively low, stable absorbance.

5. The spectrum shows a gradual decrease in absorbance beyond 468 nm towards 600 nm.

6. Multiple curves are presented, likely corresponding to different concentrations of Nano-MnO2. The highest concentration shows the most intense peaks, while the lowest concentration exhibits the least intense peaks.

7. The curves maintain similar overall shapes across all concentrations, indicating consistent spectral characteristics of the Nano-MnO2 particles regardless of concentration.

This UV-Vis spectrum provides information about the optical properties and electronic transitions of Nano-MnO2 particles in the given concentration range. The peak at 468 nm is specifically highlighted, suggesting it may be of particular interest or importance in the characterization or application of these nanoparticles.</DESCRIPTION_FROM_IMAGE>

Figure 3: UV-Vis absorption spectra of 2,6-DMP reacted with dierent nano-MnO2 concentrations at the wavelength of 250– 600 nm. Reaction conditions: Nano-MnO2 0.005–0.32 mg·mL− 1 ; 2,6-DMP 1.0 mmol·L− 1 .

<DESCRIPTION_FROM_IMAGE>The image presents a scatter plot with a linear regression analysis of nano-MnO2 activity versus nano-MnO2 concentration. The x-axis represents the concentration of nano-MnO2 in mg·mL^-1, ranging from 0.00 to 0.32. The y-axis shows the nano-MnO2 activity in U·mL^-1, spanning from 0.000 to 0.135.

The data points are represented by red triangles, and a red line indicates the linear fit. The plot shows a clear positive linear correlation between nano-MnO2 concentration and its activity.

The linear regression equation is provided in the top left corner of the graph:
y = 0.4448x
This equation describes the relationship between the nano-MnO2 concentration (x) and its activity (y). The slope of 0.4448 indicates that for every unit increase in nano-MnO2 concentration, there is a 0.4448 unit increase in activity.

The coefficient of determination (R^2) is also given:
R^2 = 0.9916
This high R^2 value (very close to 1) suggests that the linear model fits the data extremely well, explaining 99.16% of the variability in the nano-MnO2 activity.

The data points appear to be tightly clustered around the regression line, with only minor deviations. There is one visible error bar on a data point near the beginning of the plot, suggesting that some measurements may have associated uncertainties, though these are not shown for most points.

The graph demonstrates that the activity of nano-MnO2 increases proportionally with its concentration in the studied range, which could be important for applications or further studies involving this nanomaterial.</DESCRIPTION_FROM_IMAGE>

Figure 4: Concentration-dependent kinetic study of the oxidase-like activity of nano-MnO2 for a 3 min reaction. Reaction conditions: [Nano-MnO2] 0.005–0.3 mg·mL− 1 , [2,6-DMP] 1.0 mmol·L− 1 . Error bars represent the standard deviation (n 3).

investigated with the initial 2,6-DMP concentration varying between 0.005 and 0.2 mmol·L− 1 . A hyperbolic relationship between the substrate concentration and the rate of reaction (*v*) was revealed in Figure 5(a), like the typical Michaelis– Menten curve. e apparent enzyme kinetic parameters such as Km and *v*max values could be calculated by Lineweaver–Burk plot (Figure 5(b)). From the kinetic analysis, it was found that MnO2 nanozyme showed a high a§nity towards 2,6-DMP. e Km and *v*max values were 0.005 and 0.155 (R2 0.999), respectively. Combining with previous studies on articial metal oxide-based nanozymes [[24,](#page-9-0) [31, 32\]](#page-10-0), MnO2 nanoparticles are promising nanomimetics for oxidase. It is noted that the oxidase-like activity of nano-MnO2 and the steady-state kinetic parameter values were investigated at an acidic pH (pH 3.8) because of its limited oxidase-like activity at physiological or basic pH.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs side by side, labeled (a) and (b), representing different aspects of a chemical kinetics study involving 2,6-DMP (2,6-dimethylphenol).

Graph (a):
This graph shows the relationship between the initial reaction rate (v) and the concentration of 2,6-DMP. The x-axis represents the concentration of 2,6-DMP in mmol·L⁻¹, ranging from 0 to 0.20. The y-axis represents the initial reaction rate (v) in ΔA·min⁻¹, ranging from 0.06 to 0.18. The data points are shown as red squares with error bars. The curve appears to be hyperbolic, characteristic of enzyme kinetics or saturation kinetics. The reaction rate increases rapidly at low concentrations of 2,6-DMP and then begins to level off at higher concentrations, approaching a maximum rate.

Graph (b):
This graph is a linear transformation of the data in graph (a), likely a Lineweaver-Burk plot or double reciprocal plot. The x-axis represents the reciprocal of 2,6-DMP concentration (1/[2,6-DMP]) in L·mmol⁻¹, ranging from 0 to 200. The y-axis represents the reciprocal of the initial reaction rate (1/v) in min·ΔA⁻¹, ranging from 6 to 14. The data points are shown as red squares with error bars.

A linear regression line is fitted to the data points, with the equation of the line given as:
y = 0.0342x + 6.4611

The coefficient of determination (R²) is provided:
R² = 0.9985

This high R² value indicates a very good fit of the linear model to the data.

The linear nature of this plot confirms that the reaction follows Michaelis-Menten kinetics. From this plot, kinetic parameters can be derived:
- The y-intercept (6.4611) is equal to 1/Vmax, where Vmax is the maximum reaction rate.
- The slope (0.0342) is equal to Km/Vmax, where Km is the Michaelis constant.

These graphs together provide a comprehensive view of the enzyme kinetics or similar saturation kinetics for the reaction involving 2,6-DMP, allowing for the determination of important kinetic parameters.</DESCRIPTION_FROM_IMAGE>

Figure 5: Studies of kinetic reaction parameters Km and *v*max. (a) e Michaelis–Menten curve for the oxidase-like activity of nano-MnO2. (b) Lineweaver–Burk plot of 2,6-DMP oxidation was made from the Michaelis–Menten curve. Reaction conditions: Nao-MnO2 0.1 mg·mL− 1 ; 2,6-DMP 0.005–0.2 mmol·L− 1 . Error bars represent the standard deviation (n 3).

3.3. Eects of pH and Temperature on 2,6-DMP Oxidation. Similar to the natural oxidase, the catalytic activity of MnO2 nanozyme is also dependent on pH and temperature. As shown in Figure 6, the catalytic activity of MnO2 nanozyme decreased with the rise of reaction pH from 2.0 to 7.0, whereas the oxidase-like activity of MnO2 nanozyme increased with the rise of reaction temperature from 10° C to 90° C. It was found that only 0.022 U·mL− 1 of nano-MnO2 activity was retained at pH 7.0, while 0.205 U·mL− 1 of activity was retained even at 90°C. As the reaction pH increasing from 7.0 to 10.0, the oxidase-like activity of nano-MnO2 had not exhibited an obvious variation. As the temperature increased from 10°C to 25°C, the catalytic activity of nano-MnO2 was mildly enhanced. It was noted that as the temperature increased from 30°C to 90°C, the catalytic activity rapidly increased. Temperature varying in the range of 10–25°C had little impact on the nal colorimetric signal. Change in pH and temperature had not resulted in inactivation of MnO2 nanozyme. ese results indicated that the oxidase-like activity of nano-MnO2 exhibited a wide range of pH and thermal stability, unlike the natural oxidase [\[33](#page-10-0), [34\]](#page-10-0).

3.4.Metal Ions Induced the Eect of MnO2Nanozyme Activity. Simply and accurately detecting metal ions is of great signicance in the aqueous environment. Several nanozymes had been used to detect metal ions (i.e., Hg2+ and Pb2+) due to their intrinsic advantages and high stability under harsh conditions [[35](#page-10-0)–[37\]](#page-10-0). In this study, the selectivity of MnO2 nanozyme activity was evaluated in the presence of various metal ions including Mg2+, Cu2+, Al3+, Zn2+, Mn2+, Fe2+, and Pb2+ in 10 mL C-PBS buer at 25°C and pH 3.8. As shown in Figure 7, the oxidase-like activity of nano-MnO2 was 0.045 U·mL− 1 in the blank control (BC, i.e., metal ionfree) samples. Compared with BC, the activity of MnO2 nanozyme was signicantly enhanced in the presence of Cu2+ and Mn2+ (*P* < 0*.*01), whereas the presence of Zn2+ and Fe2+ obviously suppressed the activity of MnO2 nanozyme (*P* < 0*.*05). Interestingly, there was no signicant interference on the activity of MnO2 nanozyme in aqueous solution by other metal ions. ese results implied that MnO2 nanozyme might be used to, respectively, detect Cu2+, Mn2+, Zn2+, and Fe2+ in aquatic environment. However, the selectivity of MnO2 nanozyme toward Cu2+, Mn2+, Zn2+, and Fe2+ against other ions needs further studies due to the complexity of valence states of metal elements in the nanoparticles.

Previous studies had also indicated that certain metal ions could eectively upregulate/downregulate the activity of nanozymes through surface deposition and metallophilic interactions [\[38–40](#page-10-0)]. For MnO2 nanozyme detecting systems, the substrate (2,6-DMP) was transformed into a chromogenic product, serving as a signal amplier. e presence of Cu2+ and Mn2+ enhanced the activity of MnO2 nanozyme, likely because these metal ions modied the reactive sites of nano-MnO2 surface [[41](#page-10-0), [42\]](#page-10-0). First, Cu2+ and/ or Mn2+ ions reacted with citrate to form metal ion-citrate complex, subsequently the complex dispersed onto the surface of nano-MnO2, and thus changed the surface properties of nano-MnO2, thereby enhancing its oxidaselike activity [\[43](#page-10-0), [44\]](#page-10-0). On the contrary, the suppressive activity on MnO2 nanozyme in the presence of Zn2+ and Fe2+ occurred probably owing to the strong a§nity of Zn2+ and Fe2+ toward the nano-MnO2 surface via the electrostatic attractions or metal ion-multivalent Mn interactions [[36, 39, 40\]](#page-10-0). e binding a§nity of MnO2 nanozyme for Zn2+ and Fe2+ was very high. e adsorption of Zn2+ and Fe2+ onto the MnO2 nanozyme impeded the electron transfer to 2,6-DMP, thus diminishing the oxidase-like activity of nano-MnO2 [[39\]](#page-10-0). Additionally, the control samples free of MnO2 nanozyme with the metal ion present did not show the oxidase-like activity towards O2-2,6-DMP during the incubation period.

3.5. MnO2 Nanozyme-Based Reaction Systems for Detecting Cu2+, Zn2+, Mn2+, or Fe2+. As shown in Figure 8, MnO2 nanozyme-sensing systems were carried out by, respectively,

<DESCRIPTION_FROM_IMAGE>The image contains two graphs showing the activity of nano-MnO2 under different conditions:

Graph (a):
- X-axis: pH, ranging from 2 to 10
- Y-axis: Nano-MnO2 activity (U·mL^-1), ranging from 0 to 0.10
- The graph shows a decreasing trend in activity as pH increases from 2 to about 7
- There's a vertical dashed line at pH 7.0
- After pH 7, the activity slightly increases and then plateaus
- The lowest activity point is around pH 7.0 at approximately 0.02 U·mL^-1
- The highest activity is observed at the lowest pH (2) with about 0.07 U·mL^-1
- Error bars are present for each data point

Graph (b):
- X-axis: Temperature (°C), ranging from 10 to 90
- Y-axis: Nano-MnO2 activity (U·mL^-1), ranging from 0.02 to 0.22
- The graph shows an overall increasing trend in activity as temperature increases
- The increase is more pronounced after about 30°C
- The lowest activity is at 10°C (about 0.03 U·mL^-1)
- The highest activity is at 90°C (about 0.20 U·mL^-1)
- The curve appears to be sigmoidal, with a steeper increase in the middle temperature range
- Error bars are present for each data point, but they are smaller compared to graph (a)

These graphs demonstrate the dependence of nano-MnO2 activity on pH and temperature. The enzyme shows optimal activity at low pH values and high temperatures, with a notable pH-dependent behavior around neutral pH and a temperature-dependent increase in activity, especially above 30°C.</DESCRIPTION_FROM_IMAGE>

Figure 6: pH and temperature dependent the oxidase-like activity of nano-MnO2 for catalyzing the oxidation of 2,6-DMP. (a) Reaction conditions: Nano-MnO2 0.1 mg·mL− 1 ; 2,6-DMP 1.0 mmol·L− 1 , pH 2.0–10.0. (b) Reaction conditions: Nano-MnO2 0.1 mg·mL− 1 ; 2,6- DMP 1.0 mmol·L− 1 ; Temperature 10–90°C. Error bars represent the standard deviation (n 3).

<DESCRIPTION_FROM_IMAGE>The image presents a bar graph showing the nano-MnO2 activity (U·mL^-1) for various metal ions. The y-axis represents the nano-MnO2 activity ranging from 0.00 to 0.08 U·mL^-1, while the x-axis lists different metal ions: BC (blank control), Mg2+, Cu2+, Al3+, Zn2+, Mn2+, Fe2+, and Pb2+.

The graph displays the following approximate values for each metal ion:

1. BC (Blank Control): 0.045 U·mL^-1
2. Mg2+: 0.046 U·mL^-1
3. Cu2+: 0.070 U·mL^-1
4. Al3+: 0.043 U·mL^-1
5. Zn2+: 0.035 U·mL^-1
6. Mn2+: 0.078 U·mL^-1
7. Fe2+: 0.042 U·mL^-1
8. Pb2+: 0.045 U·mL^-1

A horizontal dashed line is drawn at approximately 0.045 U·mL^-1, which appears to represent the baseline or control level.

The graph shows that Mn2+ has the highest nano-MnO2 activity, followed by Cu2+. Both of these metal ions show significantly higher activity compared to the blank control. Zn2+ shows the lowest activity among all tested metal ions. The activities of Mg2+, Al3+, Fe2+, and Pb2+ are close to the blank control level.

Error bars are visible for each data point, indicating the variability or uncertainty in the measurements.

This graph provides information on how different metal ions affect the activity of nano-MnO2, which could be relevant for studies involving catalytic properties, environmental remediation, or other applications of manganese dioxide nanoparticles.</DESCRIPTION_FROM_IMAGE>

Figure 7: Role of metal ions (i.e., Mg2+, Cu2+, Al3+, Zn2+, Mn2+, Fe2+, and Pb2+) on the oxidase-like activity of nano-MnO2 for catalyzing the oxidation of 2,6-DMP. Reaction conditions: Nano-MnO2 0.1 mg·mL− 1 ; 2,6-DMP 1.0 mmol·L− 1 ; Metal ion 0.01 mmol·L− 1 . Error bars represent the standard deviation (n 3).

<DESCRIPTION_FROM_IMAGE>This image contains two graphs labeled as Figure 8: Continued, with parts (a) and (b). Both graphs show the relationship between the negative logarithm of metal ion concentration and the activity of nano-MnO2.

Graph (a):
- X-axis: -Log CCu2+ (ranging from 0.4 to 2.8)
- Y-axis: Nano-MnO2 activity (U·mL-1) (ranging from 0.05 to 0.11)
- Data points are represented by red squares with error bars
- Linear regression equation: y = -0.0212x + 0.1183
- R² value: 0.9924
- The graph shows a negative linear correlation between -Log CCu2+ and nano-MnO2 activity
- The concentration range for Cu2+ is given as 0-0.3 mmol·L-1 in the top banner

Graph (b):
- X-axis: -Log CZn2+ (ranging from 0.4 to 2.8)
- Y-axis: Nano-MnO2 activity (U·mL-1) (ranging from 0.01 to 0.06)
- Data points are represented by red diamonds with error bars
- Linear regression equation: y = 0.0188x + 0.0031
- R² value: 0.9937
- The graph shows a positive linear correlation between -Log CZn2+ and nano-MnO2 activity
- The concentration range for Zn2+ is given as 0-0.3 mmol·L-1 in the top banner

Both graphs demonstrate high R² values, indicating strong correlations between the variables. The nano-MnO2 activity decreases with increasing Cu2+ concentration (graph a), while it increases with increasing Zn2+ concentration (graph b). This suggests that Cu2+ ions inhibit nano-MnO2 activity, while Zn2+ ions enhance it within the given concentration range.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (c) and (d), both showing the relationship between the activity of Nano-MnO2 and the negative logarithm of metal ion concentration.

Graph (c):
- Title: 0-0.3 mmol·L^-1 Mn^2+
- X-axis: -Log C_Mn^2+ (ranging from 0.4 to 2.8)
- Y-axis: Nano-MnO2 activity (U·mL^-1) (ranging from 0.05 to 0.15)
- Data points are represented by red triangles with error bars
- Linear regression equation: y = -0.0312x + 0.153
- R^2 value: 0.9979
- The graph shows a negative linear correlation between Nano-MnO2 activity and -Log C_Mn^2+

Graph (d):
- Title: 0-0.2 mmol·L^-1 Fe^2+
- X-axis: -Log C_Fe^2+ (ranging from 0.5 to 2.0)
- Y-axis: Nano-MnO2 activity (U·mL^-1) (ranging from 0.00 to 0.05)
- Data points are represented by red circles with error bars
- Linear regression equation: y = 0.0353x - 0.0219
- R^2 value: 0.9956
- The graph shows a positive linear correlation between Nano-MnO2 activity and -Log C_Fe^2+

Both graphs demonstrate high R^2 values, indicating strong linear relationships between the variables. The Mn^2+ graph shows a decrease in Nano-MnO2 activity as the negative logarithm of Mn^2+ concentration increases, while the Fe^2+ graph shows an increase in Nano-MnO2 activity as the negative logarithm of Fe^2+ concentration increases.</DESCRIPTION_FROM_IMAGE>

Figure 8: Linear correlation between the oxidase-like activity of nano-MnO2 and the logarithmic value of metal ion concentration (Log C). Reaction conditions: Nano-MnO2 0.1 mg·mL− 1 ; 2,6-DMP 1.0 mmol·L− 1 ; Metal ion 0.002–0.3 mmol·L− 1 . Error bars represent the standard deviation (n 3).

<DESCRIPTION_FROM_IMAGE>The image presents four graphs (a, b, c, d) showing differential absorbance spectra across a wavelength range of 250-600 nm. Each graph represents a different experimental condition or sample, but all share similar features and concentration ranges.

Common features across all graphs:
1. X-axis: Wavelength (nm), ranging from 250 to 600 nm
2. Y-axis: Differential absorbance
3. Concentration range: 0-0.25 mmol·L^-1
4. Multiple spectral lines representing different concentrations within the stated range

Graph (a):
- Main peak at 468 nm (marked with an upward arrow)
- Secondary peaks at 272 nm and 320 nm (marked with vertical lines)
- Differential absorbance ranges from approximately 0 to 0.52
- The intensity of the main peak increases with concentration

Graph (b):
- Main peak at approximately 468 nm (marked with a downward arrow)
- Differential absorbance ranges from approximately -0.02 to 0.24
- The intensity of the main peak decreases with concentration

Graph (c):
- Main peak at approximately 468 nm (marked with an upward arrow)
- Differential absorbance ranges from approximately -0.04 to 0.54
- The intensity of the main peak increases with concentration
- Similar overall shape to graph (a), but with slightly higher maximum absorbance

Graph (d):
- Main peak at approximately 468 nm (marked with a downward arrow)
- Differential absorbance ranges from approximately -0.02 to 0.24
- The intensity of the main peak decreases with concentration
- Similar overall shape to graph (b)

All graphs show a consistent main peak around 468 nm, with varying intensities and directions of change with concentration. Graphs (a) and (c) show increasing absorbance with concentration, while graphs (b) and (d) show decreasing absorbance with concentration. This suggests that the experiments may be investigating different aspects or conditions of the same chemical system, possibly examining both absorption and depletion of a specific compound or comparing different sample preparations.</DESCRIPTION_FROM_IMAGE>

Figure 9: UV-Vis dierential absorbance spectra (DAS) calculated on the basis of the data recorded at dierent metal ion concentrations (0, 0.002, 0.01, 0.05, and 0.25 mmol·L− 1 ). Reaction conditions: Nano-MnO2 0.1 mg·mL− 1 ; 2,6-DMP 1.0 mmol·L− 1 ; metal ion 0–0.25 mmol·L− 1 . Error bars represent the standard deviation (n 3). (a) Cu2+, (b) Zn2+, (c) Mn2+, and (d) Fe2+.

<span id="page-7-0"></span>

|                                 | 1:<br>Table                        | results<br>Analytical | for                  | detection<br>the                | metal<br>of                        | ion-contaminated |                      | samples<br>water                | MnO2<br>by                         | nanozyme-2,6-D | MP                   | detecting                       | systems.                           |          |                      |
|---------------------------------|------------------------------------|-----------------------|----------------------|---------------------------------|------------------------------------|------------------|----------------------|---------------------------------|------------------------------------|----------------|----------------------|---------------------------------|------------------------------------|----------|----------------------|
| 1)<br>(mmol·L−<br>Added<br>Cu2+ | Cu2+<br>1)<br>(mmol·L−<br>Detected | Recovery              | 5)<br>RSD<br>�<br>(n | 1)<br>(mmol·L−<br>Added<br>Zn2+ | 1)<br>Detected<br>(mmol·L−<br>Zn2+ | Recovery         | 5)<br>RSD<br>�<br>(n | 1)<br>(mmol·L−<br>Added<br>Mn2+ | 1)<br>Detected<br>(mmol·L−<br>Mn2+ | Recovery       | 5)<br>RSD<br>�<br>(n | Fe2+<br>1)<br>(mmol·L−<br>Added | 1)<br>Detected<br>(mmol·L−<br>Fe2+ | Recovery | 5)<br>RSD<br>�<br>(n |
| 0.002                           | 0.002                              | 104.8%                | 6.9%                 | 0.002                           | 0.002                              | 108.6%           | 7.3%                 | 0.002                           | 0.002                              | 106.7%         | 5.4%                 | 0.002                           | 0.002                              | 116.5%   | 13.2%                |
| 0.01                            | 0.010                              | 101.1%                | 3.7%                 | 0.01                            | 0.013                              | 111.2%           | 10.5%                | 0.01                            | 0.009                              | 98.6%          | 6.3%                 | 0.01                            | 0.011                              | 114.9%   | 8.8%                 |
| 0.05                            | 0.052                              | 105.8%                | 5.4%                 | 0.05                            | 0.051                              | 102.7%           | 3.8%                 | 0.05                            | 0.053                              | 106.1%         | 7.4%                 | 0.05                            | 0.056                              | 111.9%   | 26.1%                |
| 0.25                            | 0.253                              | 106.6%                | 4.9%                 | 0.25                            | 0.0248                             | 97.8%            | 4.3%                 | 0.25                            | 0.255                              | 112.4%         | 11.2%                | 0.25                            | 0.246                              | 96.6%    | 12.0%                |
| 0.002                           | 0.002                              | 106.9%                | 9.8%                 | 0.002                           | 0.002                              | 95.0%            | 6.7%                 | 0.002                           | 0.002                              | 106.5%         | 6.3%                 | 0.002                           | 0.002                              | 110.5%   | 15.7%                |
| 0.01                            | 0.009                              | 93.0%                 | 11.2%                | 0.01                            | 0.013                              | 111.2%           | 5.3%                 | 0.01                            | 0.012                              | 124.0%         | 11.8%                | 0.01                            | 0.011                              | 114.3%   | 8.6%                 |
| 0.05                            | 0.054                              | 108.6%                | 7.6%                 | 0.05                            | 0.052                              | 104.4%           | 4.2%                 | 0.05                            | 0.047                              | 94.5%          | 4.9%                 | 0.05                            | 0.048                              | 97.2%    | 7.3%                 |
| 0.25                            | 0.248                              | 99.4%                 | 3.3%                 | 0.25                            | 0.246                              | 98.5%            | 3.1%                 | 0.25                            | 0.254                              | 101.7%         | 2.2%                 | 0.25                            | 0.252                              | 100.9%   | 3.5%                 |
|                                 |                                    |                       |                      |                                 |                                    |                  |                      |                                 |                                    |                |                      |                                 |                                    |          |                      |

Table1:Analyticalresultsforthedetectionofmetalion-contaminatedwatersamplesbyMnO2nanozyme-2,6-DMPdetecting detecting Cu2+, Zn2+, Mn2+, and Fe2+ in a concentration range of 0.002–0.3 mmol·L− 1 by the change of MnO2 nanozyme activity in the presence of these metal ions. It was noted that increasing the concentrations of Cu2+ and Mn2+ resulted in a color progression from yellow to deep yellow, while increasing the concentrations of Zn2+ and Fe2+ resulted in a color progression from yellow to colorless. A linear correlation between the activities of MnO2 nanozyme and the logarithmic values of metal ions concentration (0.002–0.3 mmol·L− 1 ) was observed (Figure 8). -e activity of MnO2 nanozyme increased with increasing Cu2+ and Mn2+ concentrations, whereas the activity of MnO2 nanozyme decreased with increasing the concentrations of Zn2+ and Fe2+ ions. -e slopes of the linear regression for the four metal ions (*i.e.*, Cu2+, Zn2+, Mn2+, and Fe2+) were ‒0.021, 0.019, ‒0.031, and 0.035, respectively. MnO2 nanozyme-2,6- DMP-sensing systems showed high sensitivity and a wide dynamic range for, respectively, detection of Cu2+, Zn2+, Mn2+, and Fe2+, allowing for a limit of detection less than 0.002 mmol·L− 1 , which was lower than the maximum levels of Cu2+, Zn2+, Mn2+, and Fe2+ (0.016, 0.015, 0.002, and 0.005 mmol·L− 1 , respectively) in drinking water permitted by the national standards GB 5749-2006 sanitary standard of China.

To further investigate the possible interaction mechanism between metal ions and MnO2 nanozyme, a differential UV-Vis spectrometry approach was performed [[45](#page-10-0)]. -e differential absorbance spectrum (DAS) could be calculated by the following equation:

$$
\Delta A_{\text{DAS}} = \left| A_{\text{mixture}} - A_{\text{2,6-DMP}} - A_{\text{metal ion}} \right. \tag{2}
$$

where *A*mixture, *A*2,6-DMP, and *A*metal ion are, respectively, the absorbance at 250–600 nm wavelength of the mixture solution, and the corresponding reference 2,6-DMP and metal ion solution.

As shown in Figure 9, the DAS of four reaction systems had an intensive negative peak at 272 nm and two intensive positive peaks, respectively, at 320 and 468 nm, implying that the change of electronic density in the molecules caused by the formation of a complex and/or metal ion-multivalent Mn interactions in C-PBS buffer. On the one hand, the formation of complex between Cu2+/Mn2+ and citrate changed the surface properties of MnO2 nanozyme, thus facilitating its oxidase-like activity [[43, 44](#page-10-0), [46\]](#page-10-0). On the other hand, Zn2+ and Fe2+ were bound to the reactive sites of MnO2 nanozyme surface, leading to the hindrance of electron transfer between the MnO2 nanozyme and 2,6- DMP, consequently restraining the activity of MnO2 nanozyme [\[39](#page-10-0), [40\]](#page-10-0).

*3.6. Detection ofMetal Ionsin RealWater Samples.* In order to verify the metal sensing ability of MnO2 nanozyme for real environmental water samples, tests were performed with different concentrations of Cu2+, Zn2+, Mn2+, or Fe2+ spiked to pond water samples 1 and 2 from Anhui Agricultural University. First, samples were diluted 10-fold with C-PBS buffer (pH 3.8) to minimize the matrix effect. Subsequently, Cu2+, Zn2+, Mn2+, or Fe2+ at a concentration of 0.002–0.25 mmol·L− 1 were spiked to the pond water samples. As shown in Table [1](#page-7-0), the recoveries were 93.0–124.0% for 0.002–0.25 mmol·L− 1 metal ions (*i.e.*, Cu2+, Zn2+, Mn2+, and Fe2+) that were spiked to the pond water 1 and 2. -e concentrations of Cu2+, Zn2+, Mn2+, and Fe2+ in the pond water samples 1 and 2 were also determined by ICPMS, which did not show significant difference from that obtained by the MnO2 nanozyme-detecting systems. In addition, the nanozyme-sensing method exhibited stable performance at a broad range of pH and temperature, convenient for experimental applications. It is noteworthy that the response of the MnO2 nanozyme-sensing systems to Zn2+ and Fe2+ at high concentrations can be directly observed with the naked eye. -ese results confirmed that the MnO2 nanozyme-2,6-DMP-sensing systems may be applicable to real water environmental samples for easily and rapidly quantifying Cu2+, Zn2+, Mn2+, or Fe2+. Even so, how to improve the selectivity of MnO2 nanozyme for metal ions detection in water is still crucial. To achieve that, two of the following main issues need to be resolved. One is studying the catalytic performance and steady-state kinetics to uncover the interaction mechanism between MnO2 nanozyme and metal ions, and the other is modifying the surface of MnO2 nanozyme to improve its catalytic activity and environmental application in real water [\[3, 13](#page-9-0), [44, 47](#page-10-0), [48](#page-10-0)].

#### **4. Conclusions**

In this study, nano-MnO2 was used as an oxidase mimetic to catalyze the chromogenic reaction of 2,6-DMP in C-PBS buffer. -e results indicated that nano-MnO2 possessed the oxidaselike activity with the *K*m and *v*max values of 0.005 and 0.155 (*R*2� 0.999), respectively, at 25°C and pH 3.8. Additionally, the effect of metal ions on this colorimetric reaction catalyzed by MnO2 nanozyme was explored, based on which it was found that this reaction system could be used to, respectively, detect Cu2+, Zn2+, Mn2+, and Fe2+ in aqueous solution without significant interference from other factors. -e detection limit for the four metal ions was less than 0.002 mmol·L− 1 and the linear response range was 0.002–0.25 mmol·L− 1 . Use of this detecting system was demonstrated with real environmental water samples, and the results indicated that the MnO2 nanozymebased sensing was simple and rapid for quantitative determination of Cu2+, Zn2+, Mn2+, and Fe2+. It is noted that MnO2 nanozyme was unable to determine ultralow metal ion concentration; thus, a more sensitive detecting assay should be developed in the follow-up study.

# **Data Availability**

-e data used to support the findings of this study are available from the corresponding author upon request.

#### **Conflicts of Interest**

-e authors declare no competing financial interests.

# **Acknowledgments**

We are grateful to D. Xie and S. Wang for assistance with data collection. Research was supported by the National <span id="page-9-0"></span>Science Foundation of China (41907314) and the Natural Science Foundation of Anhui Province (1808085QD104).

# **References**

- [1] M.-C. Daniel and D. Astruc, "Gold nanoparticles: assembly, supramolecular chemistry, quantum-size-related properties, and applications toward biology, catalysis, and nanotechnology," *Chemical Reviews*, vol. 104, no. 1, pp. 293–346, 2004.
- [2] Y. Lin, J. Ren, and X. Qu, "Catalytically active nanomaterials: a promising candidate for artificial enzymes," *Accounts of Chemical Research*, vol. 47, no. 4, pp. 1097–1105, 2014.
- [3] W. Chen, S. Li, J. Wang, K. Sun, and Y. Si, "Metal and metal oxide nanozymes: bioenzymatic characteristic, catalytic mechanism, and eco-environmental applications," *Nanoscale*, vol. 11, no. 34, pp. 15783–15793, 2019.
- [4] H. Y. Shin, T. J. Park, and M. I. Kim, "Recent research trends and future prospects in nanozymes," *Journal of Nanomaterials*, vol. 2015, Article ID 756278, 11 pages, 2015.
- [5] L. Han, P. Liu, H. Zhang, F. Li, and A. Liu, "Phage capsid protein-directed MnO2 nanosheets with peroxidase-like activity for spectrometric biosensing and evaluation of antioxidant behaviour," *Chemical Communications*, vol. 53, no. 37, pp. 5216–5219, 2017.
- [6] L. Han, L. Zeng, M. Wei, C. M. Li, and A. Liu, "A V2O3 ordered mesoporous carbon composite with novel peroxidase-like activity towards the glucose colorimetric assay," *Nanoscale*, vol. 7, no. 27, pp. 11678–11685, 2015.
- [7] L. Han, C. Li, T. Zhang, Q. Lang, and A. Liu, "Au@Ag heterogeneous nanorods as nanozyme interfaces with peroxidase-like activity and their application for one-pot analysis of glucose at nearly neutral pH," *ACS Applied Materials & Interfaces*, vol. 7, no. 26, pp. 14463–14470, 2015.
- [8] X. Niu, K. Ye, Z. Li et al., "Pyrophosphate-mediated on-off-on oxidase-like activity switching of nanosized MnFe2O4 for alkaline phosphatase sensing," *Journal of Analysis and Testing*, vol. 3, no. 3, pp. 228–237, 2019.
- [9] H. Cheng, S. Lin, F. Muhammad, Y.-W. Lin, and H. Wei, "Rationally modulate the oxidase-like activity of nanoceria for self-regulated bioassays," *ACS Sensors*, vol. 1, no. 11, pp. 1336–1343, 2016.
- [10] L. Yan, H. Ren, Y. Guo et al., "Rock salt type NiO assembled on ordered mesoporous carbon as peroxidase mimetic for colorimetric assay of gallic acid," *Talanta*, vol. 201, pp. 406– 412, 2019.
- [11] B. Liu, Z. Huang, and J. Liu, "Boosting the oxidase mimicking activity of nanoceria by fluoride capping: rivaling protein enzymes and ultrasensitive F− detection," *Nanoscale*, vol. 8, no. 28, pp. 13562–13567, 2016.
- [12] F. Chen, M. Bai, K. Cao, Y. Zhao, J. Wei, and Y. Zhao, "Fabricating MnO2 nanozymes as intracellular catalytic DNA circuit generators for versatile imaging of base-excision repair in living cells," *Advanced Functional Materials*, vol. 27, no. 45, Article ID 1702748, 2017.
- [13] L. Han, J. Shi, and A. Liu, "Novel biotemplated MnO2 1D nanozyme with controllable peroxidase-like activity and unique catalytic mechanism and its application for glucose sensing," *Sensors and Actuators B: Chemical*, vol. 252, pp. 919–926, 2017.
- [14] K. Sun, S.-Y. Li, H.-L. Chen, Q.-G. Huang, and Y. Si, "MnO2 nanozyme induced the chromogenic reactions of ABTS and TMB to visual detection of Fe2+ and Pb2+ ions in water," *International Journal of Environmental Analytical Chemistry*, vol. 99, no. 6, pp. 501–514, 2019.

- [15] R. Deng, X. Xie, M. Vendrell, Y.-T. Chang, and X. Liu, "Intracellular glutathione detection using MnO2-nanosheetmodified upconversion nanoparticles," *Journal of the American Chemical Society*, vol. 133, no. 50, pp. 20168–20171, 2011.
- [16] J. Liu, L. Meng, Z. Fei, P. J. Dyson, X. Jing, and X. Liu, "MnO2 nanosheets as an artificial enzyme to mimic oxidase for rapid and sensitive detection of glutathione," *Biosensors and Bioelectronics*, vol. 90, pp. 69–74, 2017.
- [17] F. Fu, D. D. Dionysiou, and H. Liu, "-e use of zero-valent iron for groundwater remediation and wastewater treatment: a review," *Journal of Hazardous Materials*, vol. 267, pp. 194–205, 2014.
- [18] A. Malek, T. -omas, and E. Prasad, "Visual and optical sensing of Hg2+, Cd2+, Cu2+, and Pb2+ in water and its beneficiation via gettering in nanoamalgam form," *ACS Sustainable Chemistry & Engineering*, vol. 4, no. 6, pp. 3497–3503, 2016.
- [19] M. R. Awual, M. Khraisheh, N. H. Alharthi et al., "Efficient detection and adsorption of cadmium(II) ions using innovative nano-composite materials," *Chemical Engineering Journal*, vol. 343, pp. 118–127, 2018.
- [20] R. A. Crane, M. Dickinson, and T. B. Scott, "Nanoscale zerovalent iron particles for the remediation of plutonium and uranium contaminated solutions," *Chemical Engineering Journal*, vol. 262, pp. 319–325, 2015.
- [21] S. Dong, J. Xi, Y. Wu et al., "High loading MnO2 nanowires on graphene paper: facile electrochemical synthesis and use as flexible electrode for tracking hydrogen peroxide secretion in live cells," *Analytica Chimica Acta*, vol. 853, pp. 200–206, 2015.
- [22] L. Guo, P. Qian, and M. Yang, "Determination of immunoglobulin G by a hemin-manganese(IV) oxide-labeled enzyme-linked immunosorbent assay," *Analytical Letters*, vol. 50, no. 11, pp. 1803–1811, 2017.
- [23] D. He, X. Yang, X. He et al., "A sensitive turn-on fluorescent probe for intracellular imaging of glutathione using singlelayer MnO2 nanosheet-quenched fluorescent carbon quantum dots," *Chemical Communications*, vol. 51, no. 79, pp. 14764–14767, 2015.
- [24] L. Wang, Z. Huang, Y. Liu, J. Wu, and J. Liu, "Fluorescent DNA probing nanoscale MnO2: adsorption, dissolution by thiol, and nanozyme activity," *Langmuir*, vol. 34, no. 9, pp. 3094–3101, 2018.
- [25] Y. Yuan, S. Wu, F. Shu, and Z. Liu, "An MnO2 nanosheet as a label-free nanoplatform for homogeneous biosensing," *Chemical Communications*, vol. 50, no. 9, pp. 1095–1097, 2014.
- [26] K. Sun, Q. Luo, Y. Gao, and Q. Huang, "Laccase-catalyzed reactions of 17*β*-estradiol in the presence of humic acid: resolved by high-resolution mass spectrometry in combination with 13C labeling," *Chemosphere*, vol. 145, pp. 394–401, 2016.
- [27] S. K. S. Patel, M. Z. Anwar, A. Kumar et al., "Fe2O3 yolk-shell particle-based laccase biosensor for efficient detection of 2,6 dimethoxyphenol," *Biochemical Engineering Journal*, vol. 132, pp. 1–8, 2018.
- [28] L. Xu, C. Xu, M. Zhao, Y. Qiu, and G. Sheng, "Oxidative removal of aqueous steroid estrogens by manganese oxides," *Water Research*, vol. 42, no. 20, pp. 5038–5044, 2008.
- [29] S. C. Chien, H. L. Chen, M. C. Wang, and K. Seshaiah, "Oxidative degradation and associated mineralization of catechol, hydroquinone and resorcinol catalyzed by birnessite," *Chemosphere*, vol. 74, no. 8, pp. 1125–1133, 2009.

- <span id="page-10-0"></span>[30] X. Liu, Q. Wang, H. Zhao, L. Zhang, Y. Su, and Y. Lv, "BSAtemplated MnO2 nanoparticles as both peroxidase and oxidase mimics," *Be Analyst*, vol. 137, no. 19, pp. 4552–4558, 2012.
- [31] A. B. Ganganboina and R.-A. Doong, "-e biomimic oxidase activity of layered V2O5 nanozyme for rapid and sensitive nanomolar detection of glutathione," *Sensors and Actuators B: Chemical*, vol. 273, pp. 1179–1186, 2018.
- [32] A. A. Vernekar, T. Das, S. Ghosh, and G. Mugesh, "A remarkably efficient MnFe2O4-based oxidase nanozyme," *Chemistry—An Asian Journal*, vol. 11, no. 1, pp. 72–76, 2016.
- [33] E. M. Ko, Y. E. Leem, and H. Choi, "Purification and characterization of laccase isozymes from the white-rot basidiomycete *Ganoderma lucidum*," *Applied Microbiology and Biotechnology*, vol. 57, no. 1-2, pp. 98–102, 2001.
- [34] G. P. Mizobutsi, F. L. Finger, R. A. Ribeiro, R. Puschmann, L. L. D. M. Neves, and W. F. D. Mota, "Effect of pH and temperature on peroxidase and polyphenoloxidase activities of litchi pericarp," *Scientia Agricola*, vol. 67, no. 2, pp. 213– 217, 2010.
- [35] J.-S. Lee, M. S. Han, and C. A. Mirkin, "Colorimetric detection of mercuric ion (Hg2+) in aqueous media using DNA-functionalized gold nanoparticles," *Angewandte Chemie International Edition*, vol. 46, no. 22, pp. 4093–4096, 2007.
- [36] W. Li, B. Chen, H. Zhang et al., "BSA-stabilized Pt nanozyme for peroxidase mimetics and its application on colorimetric detection of mercury(II) ions," *Biosensors and Bioelectronics*, vol. 66, pp. 251–258, 2015.
- [37] H. Wei, B. Li, J. Li, S. Dong, and E. Wang, "DNAzyme-based colorimetric sensing of lead (Pb2+) using unmodified gold nanoparticle probes," *Nanotechnology*, vol. 19, no. 9, Article ID 095501, 2008.
- [38] C.-J. Yu, T.-H. Chen, J.-Y. Jiang, and W.-L. Tseng, "Lysozymedirected synthesis of platinum nanoclusters as a mimic oxidase," *Nanoscale*, vol. 6, no. 16, pp. 9618–9624, 2014.
- [39] B. Liu, X. Han, and J. Liu, "Iron oxide nanozyme catalyzed synthesis of fluorescent polydopamine for light-up Zn2+ detection," *Nanoscale*, vol. 8, no. 28, pp. 13620–13626, 2016.
- [40] C.-L. Hsu, C.-W. Lien, S.-G. Harroun et al., "Metal-deposited bismuth oxyiodide nanonetworks with tunable enzyme-like activity: sensing of mercury and lead ions," *Materials Chemistry Frontiers*, vol. 1, no. 5, pp. 893–899, 2017.
- [41] E. I. Solomon, D. E. Heppner, E. M. Johnston et al., "Copper active sites in biology," *Chemical Reviews*, vol. 114, no. 7, pp. 3659–3853, 2014.
- [42] M. Vazquez-Gonz ´ alez, W.-C. Liao, R. Cazelles et al., ´ "Mimicking horseradish peroxidase functions using Cu2+ modified carbon nitride nanoparticles or Cu2+-modified carbon dots as heterogeneous catalysts," *ACS Nano*, vol. 11, no. 3, pp. 3247–3253, 2017.
- [43] Y. J. Long, Y. F. Li, Y. Liu, J. J. Zheng, J. Tang, and C. Z. Huang, "Visual observation of the mercury-stimulated peroxidase mimetic activity of gold nanoparticles," *Chemical Communications*, vol. 47, no. 43, pp. 11939–11941, 2011.
- [44] S. Zhang, H. Li, Z. Wang et al., "A strongly coupled Au/Fe3O4/ GO hybrid material with enhanced nanozyme activity for highly sensitive colorimetric detection, and rapid and efficient removal of Hg2+ in aqueous solutions," *Nanoscale*, vol. 7, no. 18, pp. 8495–8502, 2015.
- [45] M. Yan, Y. Lu, Y. Gao, M. F. Benedetti, and G. V. Korshin, "In-situ investigation of interactions between magnesium ion and natural organic matter," *Environmental Science & Technology*, vol. 49, no. 14, pp. 8323–8329, 2015.

- [46] C.-W. Lien, B. Unnikrishnan, S. G. Harroun et al., "Visual detection of cyanide ions by membrane-based nanozyme assay," *Biosensors and Bioelectronics*, vol. 102, pp. 510–517, 2018.
- [47] J. Liu, L. Meng, Z. Fei, P. J. Dyson, and L. Zhang, "On the origin of the synergy between the Pt nanoparticles and MnO2 nanosheets in Wonton-like 3D nanozyme oxidase mimics," *Biosensors and Bioelectronics*, vol. 121, pp. 159–165, 2018.
- [48] Q. Yang, L. Li, F. Zhao, Y. Wang, Z. Ye, and X. Guo, "Generation of MnO2 nanozyme in spherical polyelectrolyte brush for colorimetric detection of glutathione," *Materials Letters*, vol. 248, pp. 89–92, 2019.

<DESCRIPTION_FROM_IMAGE>This image appears to be the cover or logo for the "Journal of Nanomaterials". The image consists of the journal title and a grid of small square images showcasing various nanomaterial structures and textures. 

While this image does not contain specific scientific data, graphs, or chemical structures to analyze in detail, it does provide a visual representation of the diverse field of nanomaterials research. The small images likely depict different types of nanostructures, surfaces, and materials studied in nanoscience, such as nanoparticles, nanotubes, thin films, and other nanoscale structures and phenomena.

The variety of colors and textures in the small images suggests the wide range of materials and properties explored in nanomaterials research, from metals and semiconductors to polymers and biomaterials. Some images appear to show ordered structures or patterns, while others depict more random or chaotic arrangements, reflecting the different types of nanoscale organization and self-assembly studied in the field.

This cover image serves to visually communicate the scope and diversity of nanomaterials research published in the journal, rather than conveying specific scientific data. As such, while relevant to the field of nanomaterials, it does not contain detailed chemical or experimental information to analyze further in the context of this task.</DESCRIPTION_FROM_IMAGE>

**www.hindawi.com Volume 2018**

<DESCRIPTION_FROM_IMAGE>The image depicts a molecular structure representation, likely of a complex organic or biochemical compound. It shows a network of interconnected spheres of varying sizes, representing atoms or atomic groups. The spheres are arranged in a three-dimensional structure, suggesting a complex molecular geometry.

The structure appears to be composed of multiple elements, as indicated by the different sizes and shades of the spheres. Larger spheres likely represent heavier atoms or larger atomic groups, while smaller spheres are likely hydrogen atoms or lighter elements.

The arrangement suggests a branched or cyclic structure, with some areas showing denser clustering of atoms and others showing more extended chains. This could indicate the presence of functional groups or specific structural motifs within the molecule.

Without color information, it's not possible to definitively identify specific elements. However, the varying sizes and arrangement of the spheres provide insight into the complexity and potential composition of the molecule.

This type of representation is commonly used in chemistry and biochemistry to visualize the three-dimensional structure of complex molecules, such as proteins, nucleic acids, or synthetic organic compounds. It allows for a clear understanding of the spatial arrangement of atoms within the molecule, which is crucial for understanding its properties and potential functions.

As no SMILES notation can be accurately derived without precise knowledge of the atomic identities and their connections, I cannot provide a SMILES representation for this structure.</DESCRIPTION_FROM_IMAGE>

Hindawi www.hindawi.com [Analytical Methods](https://www.hindawi.com/journals/jamc/)  in Chemistry Journal of Volume 2018

<DESCRIPTION_FROM_IMAGE>This image appears to be a schematic representation of a complex network or system, potentially illustrating molecular interactions, reaction pathways, or a conceptual model in chemistry. The diagram consists of multiple interconnected nodes of varying sizes, connected by curved lines.

Key features of the image include:

1. Nodes: Multiple circular nodes of different sizes are scattered across the image. The variation in size might represent different types of molecules, atoms, or the relative importance/influence of certain elements in the system.

2. Connections: The nodes are connected by curved lines, suggesting relationships or interactions between the elements represented by the nodes. These could represent chemical bonds, reaction pathways, or other types of molecular interactions.

3. Network structure: The overall arrangement forms a complex network without a clear hierarchical structure, implying a system with multiple interconnected components and potentially non-linear relationships.

4. Spatial distribution: The nodes and connections are distributed across the entire image, suggesting a system that operates throughout a given space or environment.

This type of diagram is often used in chemistry to represent:
- Reaction networks in complex chemical systems
- Molecular interactions in biochemical pathways
- Conceptual models of multi-component chemical systems
- Visualization of chemical or molecular dynamics

Without additional context or labels, it's not possible to determine the specific chemical system or concept being represented. However, this type of network diagram is commonly used to illustrate complex relationships and interactions in various areas of chemistry, particularly in systems chemistry, biochemistry, or when studying reaction networks.</DESCRIPTION_FROM_IMAGE>

Hindawi Publishing Corporation http://www.hindawi.com Volume 2013 Hindawi **The Scientifc [World Journal](https://www.hindawi.com/journals/tswj/)**

Volume 2018

Hindawi

www.hindawi.com

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or cover design for the Journal of Applied Chemistry. While it contains stylized representations of molecular structures, it does not convey specific scientific information in the context of applied chemistry research. The image is more decorative in nature, using abstract circular shapes connected by lines to evoke the idea of molecular bonds and chemical structures in an artistic way. As such, it does not require detailed scientific interpretation or conversion to SMILES format.</DESCRIPTION_FROM_IMAGE>

www.hindawi.com Volume 2018

<DESCRIPTION_FROM_IMAGE>The image appears to be a cover or title page for the "International Journal of Photoenergy". It consists of a collage of various scientific and energy-related images arranged in a grid pattern, with the journal title prominently displayed at the bottom.

The collage includes images that are relevant to photoenergy research and applications:

1. Images of what appear to be solar panels or photovoltaic cells
2. Representations of chemical reactions or energy processes, possibly including flames or plasma
3. Images that may represent molecular or atomic structures
4. Pictures that could be depicting laboratory equipment or experimental setups

The layout is designed to visually represent the diverse areas of study within the field of photoenergy, including solar energy conversion, photochemistry, and related technologies.

The journal title "International Journal of Photoenergy" is prominently displayed at the bottom of the image, indicating that this is likely a cover image or logo for the scientific publication.

This image serves as a visual representation of the journal's focus on photoenergy research and its international scope. It does not contain specific scientific data, chemical structures, or graphs that require detailed interpretation or conversion to SMILES format.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image appears to be a cover or title page for a publication titled "Advances in Physical Chemistry". The visual element depicts a stylized representation of a molecular or atomic structure. It shows several spherical objects interconnected by lines, suggesting a three-dimensional arrangement of atoms or particles. This representation is commonly used to illustrate concepts in physical chemistry such as molecular structures, crystal lattices, or atomic interactions. The arrangement is not depicting any specific molecule or compound, but rather serves as a generic visual metaphor for the field of physical chemistry. The overall design suggests a focus on the study of matter at the molecular and atomic level, which is central to the field of physical chemistry. This image effectively conveys the subject matter of the publication without representing any specific chemical structure or formula.</DESCRIPTION_FROM_IMAGE>

**Hindawi**

<DESCRIPTION_FROM_IMAGE>The image depicts a scientific laboratory setting focused on molecular biology and biochemistry. The foreground shows a close-up view of molecular models, likely representing DNA or protein structures. These models are composed of interconnected spheres and rods, symbolizing atoms and chemical bonds in a three-dimensional arrangement.

In the background, there is a partial view of what appears to be a periodic table of elements. The visible portion shows the elements V (Vanadium) and VB (Element 105, now known as Dubnium). This suggests the image is emphasizing the connection between basic chemical elements and complex molecular structures.

The overall composition implies a focus on the relationship between fundamental chemistry and advanced molecular biology, highlighting the interdisciplinary nature of modern scientific research. The image does not contain any specific graphs, diagrams, or chemical structures that can be converted to SMILES format. It serves more as a conceptual representation of molecular biology and chemistry rather than presenting specific scientific data or results.</DESCRIPTION_FROM_IMAGE>

[Bioinorganic Chemistry](https://www.hindawi.com/journals/bca/)  and Applications Hindawi www.hindawi.com Volume 2018

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

[Submit your manuscripts at](https://www.hindawi.com/) www.hindawi.com

<DESCRIPTION_FROM_IMAGE>The image depicts various elements related to pharmaceutical and medical research:

1. Molecular model: A simplified representation of a molecule is shown, likely representing a drug compound. The model appears to be a ball-and-stick representation of a small organic molecule.

2. Laboratory glassware: A graduated cylinder or test tube is visible, indicating volumetric measurements or sample containment in a laboratory setting.

3. Syringe: A medical syringe is present, suggesting the administration of medications or the handling of liquid samples in research.

4. Pills or tablets: Several pharmaceutical pills or tablets are scattered in the foreground, representing medication in solid dosage form.

This composition of elements symbolizes various aspects of drug development, from molecular design to final dosage forms. The presence of both research tools (molecular model, glassware) and end-user products (pills, syringe) illustrates the spectrum of pharmaceutical science from laboratory to patient care.

While I cannot provide a SMILES notation for the molecular structure due to its simplified representation in the image, the overall scene conveys the interconnected nature of chemical structures, laboratory research, and medical applications in the field of pharmaceutical science.</DESCRIPTION_FROM_IMAGE>

www.hindawi.com Volume 2018

Hindawi

[Medicinal Chemistry](https://www.hindawi.com/journals/ijmc/) International Journal of Hindawi www.hindawi.com Volume 2018

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a journal cover or title page for the "Journal of Materials". It features an abstract artistic design that does not convey specific scientific or chemical information relevant to materials science. The colorful, textured pattern likely serves as a visually appealing backdrop for the journal title rather than depicting any particular chemical structures, graphs, or scientific data.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image does not convey specific scientific or chemical information relevant to the context of applied chemistry or scientific research. It appears to be a close-up photograph of mechanical components, likely gears or other machinery parts, which is not directly related to chemical structures, graphs, or scientific diagrams that would require detailed interpretation or conversion to SMILES format.</DESCRIPTION_FROM_IMAGE>

[Tribology](https://www.hindawi.com/journals/at/) Advances in Hindawi

<DESCRIPTION_FROM_IMAGE>The image depicts a microscopic view of what appears to be a molecular or cellular structure. It shows multiple spherical objects of varying sizes interconnected by thin lines or bonds, suggesting a network or lattice-like arrangement. The structures resemble a molecular model or a representation of chemical compounds.

The spheres in the image likely represent atoms, molecules, or particles. They are arranged in a three-dimensional space, with some appearing larger in the foreground and others smaller in the background, giving a sense of depth to the image.

The interconnecting lines between the spheres could represent chemical bonds or interactions between the particles. This arrangement is reminiscent of molecular structures or crystal lattices often seen in chemistry and materials science.

The overall structure appears to be complex and interconnected, suggesting a compound or material with intricate molecular architecture. This type of imagery is commonly used to represent concepts in nanotechnology, polymer science, or molecular chemistry.

While no specific chemical formula or SMILES notation can be derived from this image alone, it serves as a visual representation of molecular or particulate structures that are fundamental to many areas of chemistry and materials science.

The image does not contain any graphs, diagrams, or textual information that would require further interpretation. It appears to be a conceptual or illustrative image rather than data-rich scientific figure.</DESCRIPTION_FROM_IMAGE>

[Analytical Chemistry](https://www.hindawi.com/journals/ijac/) [Spectroscopy](https://www.hindawi.com/journals/jspec/) International Journal of Hindawi www.hindawi.com Volume 2018

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a stylized logo or cover design for the "Journal of Chemistry" rather than a scientific diagram or chemical structure. While it does depict a molecular-like structure, it is not intended to represent any specific chemical compound or convey scientific information. Instead, it serves as a visually appealing graphic representation associated with the chemistry journal.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a stylized cover or logo design for a scientific journal, likely the "Journal of Chemistry" or a similarly titled publication. While it contains abstract shapes and colors that may be inspired by chemical or molecular concepts, it does not convey specific scientific information or data relevant to applied chemistry. Therefore, in accordance with the instructions, this image is classified as an ABSTRACT_IMAGE in the context of providing detailed scientific or chemical analysis.</DESCRIPTION_FROM_IMAGE>

Hindawi www.hindawi.com Volume 2018

<DESCRIPTION_FROM_IMAGE>This image appears to be a close-up microscopic view of a biological structure, likely a pollen grain or spore. The structure has a spherical core with numerous protruding spikes or projections radiating outward in all directions, giving it a star-like or sea urchin-like appearance. These projections appear to be of varying lengths and densities across the surface. The overall morphology suggests this could be a pollen grain from a flowering plant, designed for wind or insect dispersal. The intricate surface structure is characteristic of many pollen types, which often have distinct patterns to aid in species identification. This type of image would typically be obtained using scanning electron microscopy (SEM) or another high-magnification imaging technique to reveal the detailed surface features of microscopic biological specimens. Without additional context or scale information, it's not possible to definitively identify the specific species or type of pollen/spore this represents.</DESCRIPTION_FROM_IMAGE>

Hindawi www.hindawi.com Volume 2018 BioMed

<DESCRIPTION_FROM_IMAGE>This image depicts a molecular structure model of a fullerene, specifically a C60 molecule, also known as a buckyball or buckminsterfullerene. The structure consists of 60 carbon atoms arranged in a spherical shape, forming a truncated icosahedron. The molecular geometry is composed of 20 hexagonal faces and 12 pentagonal faces.

The carbon atoms are represented as nodes in the structure, with single and double bonds connecting them. The arrangement of atoms creates a hollow cage-like structure characteristic of fullerenes. This particular representation emphasizes the three-dimensional nature of the molecule, showing its spherical shape and the interconnected network of carbon atoms.

The C60 fullerene structure can be represented in SMILES notation as follows:

C12=C3C4=C5C1=C1C6=C7C8=C9C1=C1C%10=C%11C(=C23)C3=C2C1=C1C2=C%12C%13=C%14C%15=C%16C%17=C%18C%19=C%20C(=C40)C0=C1C1=C%12C%13=C%14C%15=C%16C%17=C%18C%19=C%20C12C3=C4C5=C6C7=C8C9=C%10C%11=C30

This SMILES notation represents the complete connectivity and structure of the C60 fullerene molecule.</DESCRIPTION_FROM_IMAGE>

[Nanotechnology](https://www.hindawi.com/journals/jnt/) Hindawi www.hindawi.com Volume 2018 Journal of

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or cover design for the "International Journal of" (with the rest of the title cut off). While it contains a visually striking rainbow pattern, it does not convey specific scientific or chemical information relevant to the context of applied chemistry or scientific content. Therefore, as per the instructions, I am responding with ABSTRACT_IMAGE.</DESCRIPTION_FROM_IMAGE>

[Spectroscopy](https://www.hindawi.com/journals/ijs/) Hindawi www.hindawi.com Volume 2018

<DESCRIPTION_FROM_IMAGE>The image appears to be a cover or title page for a publication or section related to "Enzyme Research". The background features an abstract, magnified representation of what could be interpreted as enzyme molecules or protein structures. These structures are depicted as rounded, interconnected forms with a soft, organic appearance. The color scheme uses vibrant blues and oranges, creating a contrast that highlights the three-dimensional nature of the structures. The title "Enzyme Research" is prominently displayed in yellow text at the bottom of the image. This visual representation aims to convey the complex and dynamic nature of enzymes, which are crucial proteins in biochemical processes. The image does not contain any specific chemical structures, graphs, or scientific data that require detailed interpretation or conversion to SMILES format. Instead, it serves as an artistic representation of the subject matter, designed to capture attention and visually represent the field of enzyme research.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image depicts a microscopic view of what appears to be cellular or molecular structures. The structures are spherical and clustered together, with varying sizes visible. The larger spheres have a rough, textured surface, while smaller spheres appear smoother. The arrangement suggests a three-dimensional structure, with some spheres partially obscured by others in the foreground.

This image likely represents a microscopic view of biological cells, possibly cancer cells or other types of cellular aggregates. The varying sizes and textures of the spheres could indicate different stages of cell growth or different types of cells within the sample.

The clustering and three-dimensional arrangement of these structures suggest that this may be a representation of a tissue sample or a cellular culture, rather than individual, isolated cells. The image provides insight into the morphology and spatial organization of these cellular structures at a microscopic level.

This type of image is commonly used in cellular biology, oncology, or related fields to study the characteristics and behavior of cells in various conditions or disease states. It allows researchers to visualize and analyze cellular structures that are not visible to the naked eye, providing valuable information for understanding cellular processes, disease progression, or the effects of various treatments on cellular morphology.</DESCRIPTION_FROM_IMAGE>

[Research International](https://www.hindawi.com/journals/bmri/) [Electrochemistry](https://www.hindawi.com/journals/ijelc/) International Journal of Hindawi www.hindawi.com Volume 2018

<DESCRIPTION_FROM_IMAGE>This image appears to be an artistic representation or visualization related to molecular or atomic structures in a chemical context. While it doesn't contain specific chemical formulas or graphs that require detailed interpretation, I can describe its content semantically:

The image depicts a cluster of spherical objects of varying sizes, which likely represent atoms or molecules. These spheres are arranged in a non-uniform pattern, suggesting a dynamic or reactive environment. The arrangement implies a central focus point where larger spheres are surrounded by smaller ones, potentially illustrating a chemical reaction or molecular interaction.

The distribution and clustering of these sphere-like objects could be interpreted as representing different chemical elements or compounds in proximity, possibly demonstrating concepts such as molecular bonding, atomic interactions, or chemical reactions in progress.

The overall composition suggests movement or energy, which could be indicative of processes like diffusion, reaction kinetics, or molecular dynamics in a chemical system.

While this image doesn't provide quantitative data or specific chemical structures that can be converted to SMILES format, it serves as a conceptual or artistic representation of chemical or molecular phenomena. It could be used to illustrate general concepts in chemistry such as molecular interactions, atomic structure, or chemical reactivity in a visually engaging manner.</DESCRIPTION_FROM_IMAGE>

Hindawi www.hindawi.com Volume 2018 Biochemistry [Research International](https://www.hindawi.com/journals/bri/)