[
  {
    "formula": "MnO2",
    "activity": "oxidase",
    "syngony": "NOT_DETECTED",
    "length": "NOT_DETECTED",
    "width": "NOT_DETECTED",
    "depth": "NOT_DETECTED",
    "surface": "naked",
    "km_value": 0.005,
    "km_unit": "NOT_DETECTED",
    "vmax_value": 0.155,
    "vmax_unit": "NOT_DETECTED",
    "reaction_type": "2,6-DMP + O2",
    "c_min": 0.005,
    "c_max": 1.0,
    "c_const": 0.1,
    "c_const_unit": "mg/mL",
    "ccat_value": 0.1,
    "ccat_unit": "mg/mL",
    "ph": 3.8,
    "temperature": 25
  }
]