<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo for the Journal of the American Chemical Society (JACS), which is a prominent scientific journal in the field of chemistry. While this logo is relevant to chemistry publications, it does not contain specific scientific or chemical information that requires detailed interpretation in the context of applied chemistry or scientific data.</DESCRIPTION_FROM_IMAGE>

[pubs.acs.org/JACS](pubs.acs.org/JACS?ref=pdf) Communication

### Nickel−Platinum Nanoparticles as Peroxidase Mimics with a Record High Catalytic Efficiency

[Zheng Xi,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Zheng+Xi"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [Kecheng Wei,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Kecheng+Wei"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [Qingxiao Wang,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Qingxiao+Wang"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [Moon J. Kim,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Moon+J.+Kim"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [Shouheng Sun,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Shouheng+Sun"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [Victor Fung,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Victor+Fung"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf)[*](#page-3-0) [and Xiaohu Xia](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Xiaohu+Xia"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf)[*](#page-3-0)

| Cite This: J. Am. Chem. Soc. 2021, 143, 2660−2664 |                |  | Read Online             |                            |
|---------------------------------------------------|----------------|--|-------------------------|----------------------------|
| ACCESS                                            | Metrics & More |  | Article Recommendations | *sı Supporting Information |

ABSTRACT: While nanoscale mimics of peroxidase have been extensively developed over the past decade or so, their catalytic efficiency as a key parameter has not been substantially improved in recent years. Herein, we report a class of highly efficient peroxidase mimic−nickel−platinum nanoparticles (Ni−Pt NPs) that consist of nickel-rich cores and platinum-rich shells. The Ni−Pt NPs exhibit a record high catalytic efficiency with a catalytic constant (Kcat) as high as 4.5 × 107 s −1 , which is ∼46- and 104 -fold greater than the Kcat values of conventional Pt nanoparticles and natural peroxidases, respectively. Density functional theory calculations reveal that the unique surface structure of Ni−Pt NPs weakens the adsorption of key intermediates during catalysis, which boosts the catalytic efficiency. The Ni−Pt NPs were applied to an immunoassay of a carcinoembryonic antigen that achieved an ultralow detection limit of 1.1 pg/mL, hundreds of times lower than that of the conventional enzyme-based assay.

Recently, enormous efforts have been devoted to developing peroxidase mimics (or artificial peroxidases) composed of inorganic nanostructures because of their emerging applications ranging from biosensing to imaging, therapy, and environmental protection[.1](#page-3-0)−[4](#page-3-0) Compared with natural peroxidases, peroxidase mimics stand out due to their distinct advantages such as great stability, easy storage, and facile production[.5,6](#page-3-0) In this field, the bottleneck has been the limited catalytic efficiency of peroxidase mimics.[7,8](#page-3-0) It should be emphasized that catalytic efficiency is a key parameter that largely determines the performance of peroxidase mimics in many applications because it measures the rate of signal generation[.8,9](#page-3-0) The catalytic efficiencies, measured in terms of catalytic constant (Kcat, defined as the maximum number of products generated per second per catalyst),[10](#page-4-0) for most known peroxidase mimics of 1−100 nm in dimensions are usually limited to the regime of 104 −105 s −1 , which is only a few orders of magnitude greater than that of natural horseradish peroxidase (HRP), which serves as a benchmark (Kcat = 103 s −1 )[.11](#page-4-0)−[13](#page-4-0) It is therefore imperative, though challenging, to break through such a limitation in catalytic efficiency.

Herein, we report a type of peroxidase mimic−nickel− platinum nanoparticles (Ni−Pt NPs) with Ni-rich cores and Pt-rich shells that possesses a record high catalytic efficiency with Kcat of 107 s −1 . Notably, the Ni−Pt NPs were found to be much more efficient than pure Pt NPs (a well-known type of efficient peroxidase mimics[14,15)](#page-4-0) with similar sizes. As a proofof-concept demonstration, the Ni−Pt NPs were applied to a colorimetric immunoassay of carcinoembryonic antigen (CEA, a cancer biomarker[16](#page-4-0)), which achieved an ultralow detection limit of 1.1 pg/mL, hundreds of times lower than that of a conventional HRP-based assay.

In a standard synthesis of Ni−Pt NPs, Ni(II) acetate and Pt(II) acetylacetonate with the same molar amounts were coreduced by acetaldehyde in tetraethylene glycol (see the [Supporting Information](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf) for experimental details). [Figure 1](#page-1-0)A shows a typical transmission electron microscopy (TEM) image of the Ni−Pt NPs. The size of the Ni−Pt NPs was measured to be 13.9 ± 2.4 nm by randomly analyzing 200 particles [(Figure S1](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf)). It is worth noting that this size is comparable to the size of an HRP molecule (4.03 × 6.75 × 11.71 nm in dimensions[17](#page-4-0),[18](#page-4-0)). The atomic ratio of elemental Ni to Pt in the NPs was determined to be 49/51 (∼1:1) by inductively coupled plasma atomic emission spectroscopy (ICP-AES). [Figure 1](#page-1-0)B shows a typical high-angle annular darkfield scanning TEM (HAADF-STEM) image of the Ni−Pt NPs, from which thin Pt-rich shells (with a brighter contras[t19](#page-4-0)) on the surface of Ni-rich cores can be clearly resolved. The magnified atomic-resolution HAADF-STEM image taken from an individual NP [(Figure 1C](#page-1-0)) indicates the existence of relatively dark spots in the Pt-rich shell, implying that a small portion of Ni atoms diffuse into Pt layers in the shell region.[20](#page-4-0) This observation is consistent with the energy-dispersive X-ray spectroscopy (EDS) analyses ([Figure 1](#page-1-0)D,E), where the core and shell of an individual NP were confirmed to be Ni-rich and Pt-rich, respectively. [Figure S2](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf) shows representative HAADF-STEM images of two additional Ni−Pt NP samples obtained from two different batches of synthesis. The overall particle sizes, morphologies, structures, as well as Ni/Pt ratios (determined by ICP-AES) of these samples were similar to the sample shown in [Figure 1](#page-1-0), indicating good reproducibility of the synthesis. The X-ray diffraction (XRD) pattern of the Ni−Pt NPs [(Figure 1](#page-1-0)F) suggests the NPs take a face-centered cubic (fcc) structure, with the (111) diffraction peak resolved

Received: December 3, 2020 Published: January 27, 2021

<DESCRIPTION_FROM_IMAGE>This image appears to be a cover or featured illustration for the Journal of the American Chemical Society (JACS). The image depicts a conceptual representation of scientific concepts related to chemistry and materials science. Here's a detailed description:

The background shows a deep blue ocean-like environment, suggesting a liquid medium or aqueous solution. 

Floating on this blue background are hexagonal structures resembling a honeycomb lattice, which likely represents graphene or a similar 2D material structure. These hexagonal structures are depicted in red and yellow, creating a contrast with the blue background.

Above the hexagonal lattice, there are several spherical objects of varying sizes. The largest sphere appears to be emitting light, represented by a glowing white color. This could symbolize a nanoparticle or quantum dot with luminescent properties.

Smaller spheres of different sizes are scattered around the larger glowing sphere, possibly representing atoms, molecules, or smaller nanoparticles interacting with the main luminescent particle.

The overall composition suggests a nanoscale environment where 2D materials (represented by the hexagonal lattice) interact with luminescent nanoparticles in a liquid medium. This could be illustrating concepts related to nanomaterials, photophysics, or advanced materials research.

The image effectively combines elements of materials science, nanotechnology, and photochemistry to create a visually striking representation of cutting-edge chemical research topics often covered in JACS.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image does not contain any scientific content related to chemistry or other scientific fields. It appears to be a website URL or logo. Therefore, I will respond with:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image is a composite of several microscopy and spectroscopy results, labeled A through F, showing the characterization of nanoparticles. Here's a detailed description of each panel:

A: Transmission Electron Microscopy (TEM) image of spherical nanoparticles dispersed on a grid. The scale bar indicates 20 nm. Inset shows a vial containing a colloidal suspension of the nanoparticles.

B: Scanning Electron Microscopy (SEM) image of the nanoparticles, revealing their polyhedral shape. The scale bar is 10 nm.

C: High-resolution TEM image showing the lattice structure of a nanoparticle. A yellow dashed box highlights an area of interest, and red circles mark specific lattice points. Scale bars are 2 nm and 1 nm for the main image and inset, respectively.

D: Energy-dispersive X-ray spectroscopy (EDS) mapping of a single nanoparticle. The main image shows the particle morphology with a 2 nm scale bar. Three additional panels show elemental mapping: Ni (orange), Pt (blue), and a composite Ni+Pt map.

E: Line scan analysis graph showing the intensity (in arbitrary units) of Ni (orange) and Pt (blue) across a scan distance of approximately 14 nm. The graph indicates the distribution of these elements within the nanoparticle.

F: X-ray diffraction (XRD) pattern of the nanoparticles. The x-axis shows 2θ (degree) from 30 to 90, and the y-axis shows intensity (a.u.). Peaks are labeled with Miller indices (111), (200), (220), and (311). The graph compares experimental data (gray line) with reference patterns for Ni (4-850, orange) and Pt (4-802, blue).

This comprehensive analysis suggests the nanoparticles are likely bimetallic, composed of nickel and platinum, with a core-shell or alloyed structure. The particles appear to be crystalline with a face-centered cubic (FCC) structure, as indicated by the XRD pattern.</DESCRIPTION_FROM_IMAGE>

Figure 1. Structural and compositional analyses of Ni−Pt NPs. (A) TEM image, along with a photograph (inset) of the Ni−Pt NPs aqueous suspension. (B) HAADF-STEM image. (C) Atomic resolution HAADF-STEM image. Red circles highlight regions containing Ni atoms. (D) EDS mapping image and (E) EDS linescan that were recorded from an individual NP shown in (D) along the direction indicated by the arrow. (F) XRD pattern.

into two separate peaks that were probably caused by the Ptrich shell (40.76°) and Ni-rich core (42.89°)[.21](#page-4-0) To understand the growth mechanism of Ni−Pt NPs with unique Ni-rich cores and Pt-rich shells, we monitored the growth of these NPs at different stages during the synthesis using TEM and ICP-AES (see [Figure S3](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf)). Small nuclei of ∼1 nm and Pt/Ni = 4:96 were observed at the initial stage (180 °C), suggesting the preferential reduction of Ni precursor. Thereafter, coreduction of Ni and Pt precursors promoted the increase of particle size to ∼11.5 nm (at 220 °C), where the Pt/Ni ratio was increased to 13:87. A core−shell structure could be observed when reaction temperature had been elevated to 240 °C. The particle size (ca. 14 nm) and Pt/Ni ratio (ca. 50:50) became stable after the temperature reached 280 °C.

It should be emphasized that the NPs of different Ni/Pt atomic ratios could be obtained by simply varying the amounts of Ni and Pt precursors in a standard synthesis while keeping all other conditions unchanged. For example, NPs with Ni/Pt = 33/67 (Ni−Pt2 NPs) and 62/38 (Ni−Pt0.5 NPs) were obtained when the molar ratio of Ni and Pt precursors were changed from 1:1 in the standard synthesis to 1:2 and 2:1, respectively. If no Ni precursor was added to the synthesis, pure Pt NPs of ∼14.6 ± 3.1 nm as final products were obtained ([Figure S4](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf)). Those Ni−Pt2 and Ni−Pt0.5 NPs were carefully characterized by electron microscopes and XRD, and the results [(Figures S5 and S6](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf)) demonstrated that (i) the sizes of Ni−Pt2 and Ni−Pt0.5 NPs were 12.7 ± 2.1 and 14.9 ± 2.2 nm, respectively; (ii) both NPs had Ni-rich cores and Pt-rich shells, similar to that of Ni−Pt NPs; (iii) compared to Ni−Pt2 NPs, the Ni−Pt0.5 NPs had much thinner Pt-rich shells and a higher Ni content on the surface. An X-ray photoelectron spectroscopy (XPS) analysis [(Figure S7)](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf) shows that Pt 4d and 4f peaks were clearly seen from all the three NPs of different Ni/Pt atomic ratios, while noticeable Ni signals could only be observed from Ni−Pt0.5 NPs. High-resolution XPS spectra indicates that Pt on the surface of all three NPs is primarily in the form of Pt(0) ([Figure S8A)](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf);[22](#page-4-0) and the content of Ni on the surface of Ni−Pt NPs decreases in the order of Ni−Pt0.5 NPs > Ni−Pt NPs > Ni−Pt2 NPs [(Figure S8B)](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf)[.23](#page-4-0) These XPS results are consistent with the HAADF-STEM and EDS data shown in [Figures S5 and S6.](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf)

The peroxidase-like catalytic activities of the three types of NPs were evaluated through the oxidation of 3,3′,5,5′ tetramethylbenzidine (TMB) by H2O2 as a model reaction[.9,](#page-3-0)[13](#page-4-0) This catalytic reaction yields a blue-colored product (i.e., oxTMB with λmax = 653 n[m24)](#page-4-0), which can be conveniently monitored and quantified by a UV−vis spectrophotometer (Figure 2A). For comparison, the catalytic activity of pure Pt

<DESCRIPTION_FROM_IMAGE>This image contains four panels labeled A, B, C, and D, presenting information about nanoparticle catalysts and their activity in the oxidation of TMB (3,3',5,5'-tetramethylbenzidine).

Panel A: 
This panel illustrates the oxidation process of TMB. It shows the chemical structure of TMB (SMILES: CC1=CC(C)=C(C=C1N)N) and its oxidized form oxTMB. The process involves TMB reacting with H2O2 to form oxTMB and H2O. The reaction is catalyzed by nanoparticles (NPs) composed of Ni and Pt atoms arranged on a substrate.

Panel B:
This is a graph showing the velocity of TMB oxidation (Y-axis, units: X10^5 s^-1) against TMB concentration (X-axis, units: mM) for different types of nanoparticle catalysts. The graph compares four types of catalysts:
1. Ni-Pt NPs (red squares)
2. Ni-Pt0.5 NPs (blue circles)
3. Ni-Pt2 NPs (green triangles)
4. Pt NPs (black squares)

The Ni-Pt NPs show the highest catalytic activity, followed by Ni-Pt0.5 NPs, Ni-Pt2 NPs, and Pt NPs. The velocity increases linearly with TMB concentration for all catalysts, with Ni-Pt NPs reaching about 2.5 X10^5 s^-1 at 0.6 mM TMB.

Panel C:
This bar graph shows the catalytic rate constant (kcat) for different nanoparticle compositions. The Y-axis is labeled as kcat (X10^5 s^-1). The order of catalytic activity from highest to lowest is:
1. Ni-Pt
2. Ni-Pt0.5
3. Ni-Pt2
4. Pt

The Ni-Pt nanoparticles show a significantly higher kcat compared to the other compositions.

Panel D:
This bar graph presents the specific catalytic rate constant (kcat_specific) for the same nanoparticle compositions as in Panel C. The Y-axis is labeled as kcat_specific (X10^4 s^-1 mm^-2). The trend is similar to Panel C, with Ni-Pt showing the highest specific catalytic rate constant, followed by Ni-Pt0.5, Ni-Pt2, and Pt.

Overall, this image demonstrates that Ni-Pt nanoparticles have superior catalytic activity for TMB oxidation compared to other Ni-Pt compositions and pure Pt nanoparticles. The data suggest that the synergistic effect between Ni and Pt in the 1:1 ratio (Ni-Pt) provides the optimal catalytic performance for this reaction.</DESCRIPTION_FROM_IMAGE>

Figure 2. Peroxidase-like catalytic efficiencies of NPs with different Ni/Pt ratios. (A) Schematics showing the catalytic oxidation of TMB by H2O2. (B) Plots of initial reaction velocity for different NPs against TMB concentration. Error bars indicate standard deviations of three independent measurements. (C, D) Histograms comparing Kcat (C) and Kcat‑specific (D) values of different NPs.

NPs (sample in [Figure S4)](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf) was also determined. Apparent steady-state kinetic assays were performed to quantify their catalytic efficiencies (see the [Supporting Information](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf) for details).[9](#page-3-0),[13](#page-4-0) By plotting the initial reaction velocities against TMB concentration, typical Michaelis−Menten curves were observed (Figure 2B). These curves were then converted to the double-reciprocal plots [(Figure S9](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf)),[25](#page-4-0) from which the Kcat values (Figure 2C) along with other kinetic parameters ([Table](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf) [S1)](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf) were derived. As shown by Figure 2C, Kcat values of the NPs displayed a volcano-shaped dependence on the Ni content, with the maximum point corresponding to Ni−Pt. Notably, the Kcat value of Ni−Pt NPs is as high as 4.5 × 107 s −1 , which is ∼46- and 104 -fold greater than those of Pt NPs (Kcat = 9.7 × 105 s −1 ) and HRP (Kcat = 4.3 × 103 s −1 )[,9](#page-3-0) respectively. Unlike HRP, all active atoms on the surface layers of a noble-metal peroxidase mimic contribute to its catalytic efficiency.[13,26](#page-4-0),[27](#page-4-0) To better describe the catalytic efficiency of these NPs, we derived their area-specific efficiencies (Kcat‑specific, the normalized Kcat to the surface area of an individual catalyst[8,](#page-3-0)[28)](#page-4-0). As shown by [Figure 2](#page-1-0)D, a similar trend as Kcat was observed for the Kcat‑specific. It is worth emphasizing that the Ni−Pt NPs exhibited a record-high catalytic efficiency, in terms of both Kcat and Kcat‑specific, among all the already reported peroxidase mimics of 1−100 nm in dimension (see [Table S2)](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf). As shown by [Figure S10](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf), no obvious changes of morphologies, structures, and catalytic efficiencies of the Ni− Pt NPs were observed after they had been stored in deionized water at room temperature for 14 d, suggesting a good stability of the NPs.

To elucidate the origin of the excellent peroxidase-like catalytic efficiency for the Ni−Pt NPs, we performed density functional theory (DFT) calculations for H2O2 decomposition on different NiPt surfaces. Previous work postulated that the H2O2 decomposition mechanism on metallic peroxidase mimic surface proceeds via H2O2* → 2HO* → H2O* + O*, with the desorption of HO*/O* and the oxidation of TMB to oxTMB as the key reaction steps (steps IIIb and IV in Figure 3A)[.29](#page-4-0)−[31](#page-4-0)

<DESCRIPTION_FROM_IMAGE>This image contains four panels (A, B, C, and D) related to chemical reactions and structures.

Panel A: Depicts a reaction cycle involving TMB (trimethylborazine) and oxTMB (oxidized trimethylborazine). The cycle shows the following steps:
1. H2O2 reacts with TMB to form oxTMB (step I)
2. oxTMB undergoes a reduction to form TMB (step II)
3. TMB reacts with H2O to form oxTMB (step IIIa)
4. oxTMB undergoes another reduction to form TMB (step IIIb)
5. TMB reacts with H2O2 to form oxTMB (step IV)

Panel B: Shows a free energy diagram for the reaction coordinate of H2O2 decomposition. Three lines represent different catalysts:
- Red line: Ni-Pt
- Blue line: Pt
- Orange line: Ni
The reaction steps shown are: H2O2* → 2HO* → H2O*+O* → *
The Ni-Pt catalyst shows the lowest energy barrier for the reaction.

Panel C: Displays nine different structural configurations (numbered 1-9) of what appears to be catalyst surfaces or interfaces. These structures show varying arrangements of atoms, possibly representing different compositions or surface structures of catalysts.

Panel D: Presents an adsorption energy graph with two data series:
- Black squares: E_ads,OH (OH adsorption energy)
- Blue circles: E_ads,O (O adsorption energy)
The x-axis is numbered 1-9, corresponding to the structures in Panel C. The graph is divided into two regions:
- Yellow region (1-4): labeled "Core Ni increase"
- Pink region (5-9): labeled "Surface Ni increase"
Both adsorption energies show a general decreasing trend as the structure number increases, with some fluctuations.

This image provides a comprehensive view of a catalytic system, including reaction mechanisms, energy profiles, structural configurations, and adsorption energies for different catalyst compositions.</DESCRIPTION_FROM_IMAGE>

Figure 3. DFT calculations. (A) Proposed H2O2 decomposition pathway on a Pt surface. (B) Free-energy diagrams for H2O2 decomposition on Ni−Pt, Pt, and Ni surfaces and optimized adsorption configurations on Ni−Pt surface. (C) Slab models for various NiPt surfaces (red circles highlight the single Ni atom on Pt top layer). (D) Adsorption energies for OH and O on the NiPt slab model surfaces in (C). Blue atoms represent Pt, and orange atoms represent Ni in each slab model.

On the basis of this, we first built three (111) slab models, including four atomic layers of (i) pure Pt, (ii) pure Ni, and (iii) one top Pt atomic layer plus three Ni/Pt 1/1 alloy layers, to simulate the Pt, Ni, and Ni−Pt catalytic surfaces, respectively. The free-energy diagram in Figure 3B compares the reaction steps on Pt, Ni, and Ni−Pt surfaces with the corresponding intermediate adsorption configurations ([Figure](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf) [S11](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf)). The Ni−Pt surface has the weakest HO*/O* adsorption corresponding to a dramatic downshift of the d-band center of the Pt shell ([Figure S12](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf)), indicating the most facile oxidant species transfer to the TMB substrate, and thus is the most reactive peroxidase-like catalyst[.31](#page-4-0) Moreover, to understand the volcano-type trend of the catalytic efficiency with the increase of Ni, we modeled the surfaces based on the characterizations showing the existence of Ni in the Pt surface layers and utilized the adsorption energies (Eads) for OH and O as descriptors[.32](#page-4-0) As demonstrated in Figure 3C,D, the same four-layer (111) slab models with a pure Pt top layer and an increasing Ni ratio from 0 to 0.75 (1−4 slab models in Figure 3C) in the following three sublayers based on the most stable bulk crystal structures for NiPt alloy compositions were used,[33](#page-4-0),[34](#page-4-0) reflecting a larger Ni core and thinner Pt shell. The models used are similar to a previous theoretical study on the reactivity of Ni-containing Pt (111)-skin catalytic surfaces[.35](#page-4-0) The Eads,OH and Eads,O increase monotonically from −1.05 eV (OH)/−1.17 eV (O) to −0.65 eV (OH)/−0.39 eV (O), suggesting that a thinner Pt shell on a Ni core will have better peroxidase-like activity. However, if Ni atoms start to diffuse onto the top Pt surface layer, even single Ni atoms on the surface will lead to an obvious decrease of Eads,OH and Eads,O (5 and 6 slab models compared with 4 and 3 in Figure 3C) and thus lower the catalytic activity. With more Ni on the catalytic surface (7−9 slab models in Figure 3C), the activity will be further deteriorated. While we may not know the exact surface compositions for the catalysts, our models are sufficient to explain and predict the volcano-type activity trend with the increase of the Ni component in such a unique core−shell system, as the Ni−Pt maximizes the Ni core and Pt shell effect while avoiding too much Ni from leaching onto the Pt surface.

Finally, to demonstrate the potential application of the Ni− Pt NPs with maximized catalytic efficiency for biomedicine, a colorimetric enzyme-linked immunosorbent assay (ELISA) of carcinoembryonic antigen (a typical cancer biomarke[r16](#page-4-0)) was performed. For comparison, Pt NPs and HRP were also applied to the ELISA of CEA, where the same set of antibodies and materials were used. As shown by [Figure 4](#page-3-0)A, the principle of Ni−Pt or Pt ELISA is the same as that for conventional HRP ELISA,[36](#page-4-0) except for the substitution of HRP with Ni−Pt or Pt NPs (see the [Supporting Information](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf) for details). CEA standards of various concentrations were detected in a 96-well microtiter plate [(Figure 4B](#page-3-0)). The absorbance of yellow-colored products (i.e., diimine with λmax = 450 nm that was converted from oxTM[B24)](#page-4-0) in the wells was quantified using a plate reader. [Figure 4C](#page-3-0) shows calibration curves of the ELISAs. The Ni−Pt ELISA displayed a quality linear detection range of 5− 500 pg/mL, along with coefficients of variation in 1.3%−7.9%. The limit of detection (LOD, defined by the 3SD metho[d37](#page-4-0)) of Ni−Pt ELISA was determined to be 1.1 pg/mL based on its calibration curve. In comparison, the LODs of Pt and HRP ELISAs were calculated to be 14.3 and 376 pg/mL, respectively, which are ∼13- and 342-fold higher than that of Ni−Pt ELISA. Such a substantial enhancement in the detection sensitivity for the Ni−Pt ELISA can be ascribed to the ultrahigh catalytic efficiency of the Ni−Pt NPs relative to Pt NPs and HRP because all other conditions of the three ELISAs were kept the same.

In summary, we have demonstrated a type of effective peroxidase mimicsNi−Pt NPsthat possess an ultrahigh catalytic efficiency with Kcat of 4.5 × 107 s −1 . DFT calculations reveal that such an outstanding catalytic efficiency of Ni−Pt NPs is ascribed to the unique surface structure of these NPs that weakens the adsorption of key intermediates during

<DESCRIPTION_FROM_IMAGE>The image presents a comprehensive illustration of an ELISA (Enzyme-Linked Immunosorbent Assay) system for detecting CEA (Carcinoembryonic Antigen) using different nanoparticles and enzymes. The image is divided into three parts: A, B, and C.

A. This section shows a schematic representation of two ELISA systems:
   1. Ni-Pt or Pt NP ELISA:
      - Components from bottom to top: Ni-Pt or Pt ELISA plate, Rabbit anti-CEA pAb, CEA, Mouse anti-CEA mAb, Goat anti-mouse IgG, HOOC-PEG3400-SH, Ni-Pt or Pt NP
   2. HRP ELISA:
      - Components from bottom to top: HRP ELISA plate, Rabbit anti-CEA pAb, CEA, Mouse anti-CEA mAb, Goat anti-mouse IgG, HRP
   - Both systems show the formation of a "Colored Product" when TMB/H2O2 is added

B. This section displays a colorimetric assay result for CEA detection:
   - Three rows of wells are shown: Ni-Pt, Pt, and HRP
   - CEA concentrations range from 0 to 2K pg/mL
   - Color intensity increases from left to right, with Ni-Pt showing the most intense color change

C. This section presents quantitative data in the form of a graph and insets:
   - Main graph: Log-log plot of Absorbance at 450 nm vs. CEA Concentration (pg/mL)
   - Three curves: Ni-Pt ELISA (red squares), Pt ELISA (black squares), HRP ELISA (grey squares)
   - X-axis range: 10^0 to 10^5 pg/mL
   - Y-axis range: 0.1 to 10 a.u.
   - Error bars are included for each data point
   - Ni-Pt ELISA shows the highest sensitivity, followed by Pt ELISA, then HRP ELISA

   Insets:
   1. Top right: Linear regression for Ni-Pt ELISA
      - Equation: lgy = 0.59lgx-1.37
      - R^2 = 0.994
      - X-axis range: 10^1 to 10^2
      - Y-axis range: 0.1 to 1
   2. Middle right: Linear regression for Pt ELISA
      - Equation: lgy = 0.60lgx-2.03
      - R^2 = 0.991
      - X-axis range: 10^2 to 10^3
      - Y-axis range: 0.1 to 1
   3. Bottom right: Linear regression for HRP ELISA
      - Equation: lgy = 0.52lgx-2.62
      - R^2 = 0.989
      - X-axis range: 10^3 to 10^4
      - Y-axis range: 0.1 to 1

This image demonstrates the superior sensitivity of the Ni-Pt nanoparticle-based ELISA system compared to traditional Pt nanoparticle and HRP-based systems for CEA detection.</DESCRIPTION_FROM_IMAGE>

Figure 4. Detection of CEA with Ni−Pt NPs-, Pt NPs-, and HRPbased ELISAs. (A) Schematics of the three ELISAs of CEA. (B) Representative photographs taken from the ELISAs of CEA standards. (C) Corresponding calibration curves (left) along with linear range regions (right) of the detection results in (B). Error bars indicate standard deviations of eight independent measurements.

catalysis. The Ni−Pt NPs were applied to the sensitive detection of CEA. The peroxidase mimics presented in this study may find widespread uses in biosensing, imaging, and related fields.

# ■ ASSOCIATED CONTENT

### *sı Supporting Information

The Supporting Information is available free of charge at [https://pubs.acs.org/doi/10.1021/jacs.0c12605](https://pubs.acs.org/doi/10.1021/jacs.0c12605?goto=supporting-info).

> Experimental details including chemicals, materials, instrumentation, and synthesis, discussion of peroxidase-like activity, ELISA of CEA, DFT calculations, size distribution plot of NP data, HAADF-STEM images, plotted data to indicate analysis of products, XRD patterns, XPS spectra, comparison of catalyst kinetic parameters and efficiencies, additional refs ([PDF](http://pubs.acs.org/doi/suppl/10.1021/jacs.0c12605/suppl_file/ja0c12605_si_001.pdf))

# ■ AUTHOR INFORMATION

#### Corresponding Authors

- Xiaohu Xia − Department of Chemistry and Nanoscience Technology Center, University of Central Florida, Orlando, Florida 32816, United States; [orcid.org/0000-0002-](http://orcid.org/0000-0002-6372-7712) [6372-7712;](http://orcid.org/0000-0002-6372-7712) Email: [Xiaohu.Xia@ucf.edu](mailto:Xiaohu.Xia@ucf.edu)
- Victor Fung − Center for Nanophase Materials Sciences, Oak Ridge National Laboratory, Oak Ridge, Tennessee 37831,

United States; [orcid.org/0000-0002-3347-6983](http://orcid.org/0000-0002-3347-6983); Email: [fungv@ornl.gov](mailto:fungv@ornl.gov)

#### Authors

- Zheng Xi − Department of Chemistry, University of Central Florida, Orlando, Florida 32816, United States; [orcid.org/0000-0003-3953-7772](http://orcid.org/0000-0003-3953-7772)
- Kecheng Wei − Department of Chemistry, Brown University, Providence, Rhode Island 02912, United States
- Qingxiao Wang − Department of Materials Science and Engineering, University of Texas at Dallas, Richardson, Texas 75080, United States
- Moon J. Kim − Department of Materials Science and Engineering, University of Texas at Dallas, Richardson, Texas 75080, United States
- Shouheng Sun − Department of Chemistry, Brown University, Providence, Rhode Island 02912, United States; [orcid.org/0000-0002-4051-0430](http://orcid.org/0000-0002-4051-0430)

Complete contact information is available at: [https://pubs.acs.org/10.1021/jacs.0c12605](https://pubs.acs.org/doi/10.1021/jacs.0c12605?ref=pdf)

#### Notes

The authors declare no competing financial interest.

# ■ ACKNOWLEDGMENTS

This work was supported in part by the grants from the National Science Foundation (CHE-1834874 and CBET-1804525), the National Institute of Food and Agriculture, U.S. Department of Agriculture (2020-67021-31257), and the startup funds from University of Central Florida (UCF). M.J.K. was supported in part by the Louis Beecherl, Jr. Endowment Funds.

# ■ REFERENCES

(1) Liu, B.; Sun, Z.; Huang, P.; Liu, J[. Hydrogen Peroxide Displacing](https://dx.doi.org/10.1021/ja511444e) [DNA from Nanoceria: Mechanism and Detection of Glucose in](https://dx.doi.org/10.1021/ja511444e) [Serum.](https://dx.doi.org/10.1021/ja511444e) J. Am. Chem. Soc. 2015, 137, 1290−1295.

(2) Wang, W.; Jiang, X.; Chen, K[. CePO4: Tb, Gd Hollow](https://dx.doi.org/10.1039/c2cc32328a) [Nanospheres as Peroxidase Mimic and Magnetic-Fluorescent Imaging](https://dx.doi.org/10.1039/c2cc32328a) [Agent.](https://dx.doi.org/10.1039/c2cc32328a) Chem. Commun. 2012, 48, 6839−6841.

(3) Xu, B.; Wang, H.; Wang, W.; Gao, L.; Li, S.; Pan, X.; Wang, H.; Yang, H.; Meng, X.; Wu, Q.; Zheng, L.; Chen, S.; Shi, X.; Fan, K.; Yan, X.; Liu, H. [A Single-Atom Nanozyme for Wound Disinfection](https://dx.doi.org/10.1002/anie.201813994) [Applications.](https://dx.doi.org/10.1002/anie.201813994) Angew. Chem., Int. Ed. 2019, 58, 4911−4916.

(4) Herget, K.; Hubach, P.; Pusch, S.; Deglmann, P.; Gotz, H.; Gorelik, T. E.; Gural'skiy, I. A.; Pfitzner, F.; Link, T.; Schenk, S.; Panthofer, M.; Ksenofontov, V.; Kolb, U.; Opatz, T.; Andre, R.; Tremel, W. [Haloperoxidase Mimicry by CeO2](https://dx.doi.org/10.1002/adma.201603823)‑x Nanorods Combats [Biofouling.](https://dx.doi.org/10.1002/adma.201603823) Adv. Mater. 2017, 29, 1603823.

(5) Wu, J.; Wang, X.; Wang, Q.; Lou, Z.; Li, S.; Zhu, Y.; Qin, L.; Wei, H[. Nanomaterials with Enzyme-like Characteristics (Nano](https://dx.doi.org/10.1039/C8CS00457A)[zymes): Next-Generation Artificial Anzymes (II).](https://dx.doi.org/10.1039/C8CS00457A) Chem. Soc. Rev. 2019, 48, 1004−1076.

(6) Jiang, D.; Ni, D.; Rosenkrans, Z. T.; Huang, P.; Yan, X.; Cai, W. [Nanozyme: New Horizons for Responsive Biomedical Applications.](https://dx.doi.org/10.1039/C8CS00718G) Chem. Soc. Rev. 2019, 48, 3683−3704.

(7) Liang, M.; Yan, X. [Nanozymes: From New Concepts,](https://dx.doi.org/10.1021/acs.accounts.9b00140) [Mechanisms, and Standards to Applications.](https://dx.doi.org/10.1021/acs.accounts.9b00140) Acc. Chem. Res. 2019, 52, 2190−2200.

(8) Wei, Z.; Xi, Z.; Vlasov, S.; Ayala, J.; Xia, X. [Nanocrystals of](https://dx.doi.org/10.1039/D0CC06575G) [Platinum-Group Metals as Peroxidase Mimics for](https://dx.doi.org/10.1039/D0CC06575G) in vitro Diagnostics. Chem. Commun. 2020, 56, 14962−14975.

(9) Gao, L.; Zhuang, J.; Nie, L.; Zhang, J.; Zhang, Y.; Gu, N.; Wang, T.; Feng, J.; Yang, D.; Perrett, S.; Yan, X[. Intrinsic Peroxidase-like](https://dx.doi.org/10.1038/nnano.2007.260)

#### <span id="page-4-0"></span>Journal of the American Chemical Society [pubs.acs.org/JACS](pubs.acs.org/JACS?ref=pdf) Communication

[Activity of Ferromagnetic Nanoparticles.](https://dx.doi.org/10.1038/nnano.2007.260) Nat. Nanotechnol. 2007, 2, 577−583.

(10) Jiang, B.; Duan, D.; Gao, L.; Zhou, M.; Fan, K.; Tang, Y.; Xi, J.; Bi, Y.; Tong, Z.; Gao, G.; Xie, N.; Tang, A.; Nie, G.; Liang, M.; Yan, X[. Standardized Assays for Determining the Catalytic Activity and](https://dx.doi.org/10.1038/s41596-018-0001-1) [Kinetics of Peroxidase-like Nanozymes.](https://dx.doi.org/10.1038/s41596-018-0001-1) Nat. Protoc. 2018, 13, 1506− 1520.

(11) Jin, S.; Wu, C.; Ye, Z.; Ying, Y. [Designed Inorganic](https://dx.doi.org/10.1016/j.snb.2018.10.040) [Nanomaterials for Intrinsic Peroxidase Mimics: A Review.](https://dx.doi.org/10.1016/j.snb.2018.10.040) Sens. Actuators, B 2019, 283, 18−34.

(12) Wang, Z.; Zhang, R.; Yan, X.; Fan, K. [Structure and Activity of](https://dx.doi.org/10.1016/j.mattod.2020.08.020) [Nanozymes: Inspirations for](https://dx.doi.org/10.1016/j.mattod.2020.08.020) de novo Design of Nanozymes. Mater. Today 2020, 41, 81−119.

(13) Xia, X.; Zhang, J.; Lu, N.; Kim, M. J.; Ghale, K.; Xu, Y.; McKenzie, E.; Liu, J.; Ye, H[. Pd-Ir Core-Shell Nanocubes: A Type of](https://dx.doi.org/10.1021/acsnano.5b03525) [Highly Efficient and Versatile Peroxidase Mimic.](https://dx.doi.org/10.1021/acsnano.5b03525) ACS Nano 2015, 9, 9994−10004.

(14) Loynachan, C. N.; Thomas, M. R.; Gray, E. R.; Richards, D. A.; Kim, J.; Miller, B. S.; Brookes, J. C.; Agarwal, S.; Chudasama, V.; McKendry, R. A.; Stevens, M. M[. Platinum Nanocatalyst Amplifica](https://dx.doi.org/10.1021/acsnano.7b06229)[tion: Redefining the Gold Standard for Lateral Flow Immunoassays](https://dx.doi.org/10.1021/acsnano.7b06229) [with Ultrabroad Dynamic Range.](https://dx.doi.org/10.1021/acsnano.7b06229) ACS Nano 2018, 12, 279−288.

(15) Wu, R.; Chong, Y.; Fang, G.; Jiang, X.; Pan, Y.; Chen, C.; Yin, J.; Ge, C[. Synthesis of Pt Hollow Nanodendrites with Enhanced](https://dx.doi.org/10.1002/adfm.201801484) [Peroxidase-like Activity against Bacterial Infections: Implication for](https://dx.doi.org/10.1002/adfm.201801484) [Wound Healing.](https://dx.doi.org/10.1002/adfm.201801484) Adv. Funct. Mater. 2018, 28, 1801484.

(16) Benchimol, S.; Fuks, A.; Jothy, S.; Beauchemin, N.; Shirota, K.; Stanners, C. P[. Carcinoembryonic Antigen, a Human-Tumor Marker,](https://dx.doi.org/10.1016/0092-8674(89)90970-7) [Functions as an Intercellular-Adhesion Molecule.](https://dx.doi.org/10.1016/0092-8674(89)90970-7) Cell 1989, 57, 327− 334.

(17) Berglund, G. I.; Carlsson, G. H.; Smith, A. T.; Szoke, H.; Henriksen, A.; Hajdu, J[. The Catalytic Pathway of Horseradish](https://dx.doi.org/10.1038/417463a) [Peroxidase at High Resolution.](https://dx.doi.org/10.1038/417463a) Nature 2002, 417, 463−468.

(18) Gajhede, M.; Schuller, D. J.; Henriksen, A.; Smith, A. T.; Poulos, T. L. [Crystal Structure of Horseradish Peroxidase C at 2.15](https://dx.doi.org/10.1038/nsb1297-1032) [Angstrom Resolution.](https://dx.doi.org/10.1038/nsb1297-1032) Nat. Struct. Biol. 1997, 4, 1032−1038.

(19) Cui, C.; Gan, L.; Heggen, M.; Rudi, S.; Strasser, P. [Compositional Segregation in Shaped Pt Alloy Nanoparticles and](https://dx.doi.org/10.1038/nmat3668) [Their Structural Behaviour during Electrocatalysis.](https://dx.doi.org/10.1038/nmat3668) Nat. Mater. 2013, 12, 765−771.

(20) Wang, L.; Gao, W.; Liu, Z.; Zeng, Z.; Liu, Y.; Giroux, M.; Chi, M.; Wang, G.; Greeley, J.; Pan, X.; Wang, C[. Core-Shell Nano](https://dx.doi.org/10.1021/acscatal.7b02501)[structured Cobalt-Platinum Electrocatalysts with Enhanced Durabil](https://dx.doi.org/10.1021/acscatal.7b02501)[ity.](https://dx.doi.org/10.1021/acscatal.7b02501) ACS Catal. 2018, 8, 35−42.

(21) Zhang, S.; Hao, Y.; Su, D.; Doan-Nguyen, V. V.; Wu, Y.; Li, J.; Sun, S.; Murray, C. B[. Monodisperse Core/Shell Ni/FePt Nano](https://dx.doi.org/10.1021/ja5099066)[particles and Their Conversion to Ni/Pt to Catalyze Oxygen](https://dx.doi.org/10.1021/ja5099066) [Reduction.](https://dx.doi.org/10.1021/ja5099066) J. Am. Chem. Soc. 2014, 136, 15921−15924.

(22) Arico, A. S.; Shukla, A. K.; Kim, H.; Park, S.; Min, M.; Antonucci, V[. An XPS Study on Oxidation States of Pt and Its Alloys](https://dx.doi.org/10.1016/S0169-4332(00)00831-X) [with Co and Cr and Its Relevance to Electroreduction of Oxygen.](https://dx.doi.org/10.1016/S0169-4332(00)00831-X) Appl. Surf. Sci. 2001, 172, 33−40.

(23) Biesinger, M. C.; Payne, B. P.; Grosvenor, A. P.; Lau, L. W. M.; Gerson, A. R.; Smart, R. S[. Resolving Surface Chemical States in XPS](https://dx.doi.org/10.1016/j.apsusc.2010.10.051) [Analysis of First Row Transition Metals, Oxides and Hydroxides: Cr,](https://dx.doi.org/10.1016/j.apsusc.2010.10.051) [Mn, Fe, Co and Ni.](https://dx.doi.org/10.1016/j.apsusc.2010.10.051) Appl. Surf. Sci. 2011, 257, 2717−2730.

(24) Josephy, P. D.; Eling, T. E.; Mason, R. P[. The Horseradish](https://dx.doi.org/10.1016/S0021-9258(18)34832-4) [Peroxidase-Catalyzed Oxidation of 3,5,3](https://dx.doi.org/10.1016/S0021-9258(18)34832-4)′,5′-Tetramethylbenzidine. [Free Radical and Charge-Transfer Complex Intermediates.](https://dx.doi.org/10.1016/S0021-9258(18)34832-4) J. Biol. Chem. 1982, 257, 3669−3675.

(25) Lineweaver, H.; Burk, D. [The Determination of Enzyme](https://dx.doi.org/10.1021/ja01318a036) [Dissociation Constants.](https://dx.doi.org/10.1021/ja01318a036) J. Am. Chem. Soc. 1934, 56, 658−666.

(26) Xi, Z.; Cheng, X.; Gao, Z.; Wang, M.; Cai, T.; Muzzio, M.; Davidson, E.; Chen, O.; Jung, Y.; Sun, S.; Xu, Y.; Xia, X[. Strain Effect](https://dx.doi.org/10.1021/acs.nanolett.9b03782) [in Palladium Nanostructures as Nanozymes.](https://dx.doi.org/10.1021/acs.nanolett.9b03782) Nano Lett. 2020, 20, 272−277.

(27) Fang, G.; Li, W.; Shen, X.; Perez-Aguilar, J. M.; Chong, Y.; Gao, X.; Chai, Z.; Chen, C.; Ge, C.; Zhou, R. [Differential Pd-Nanocrystal](https://dx.doi.org/10.1038/s41467-017-02502-3) [Facets Demonstrate Distinct Antibacterial Activity Against Gram-](https://dx.doi.org/10.1038/s41467-017-02502-3)[Positive and Gram-Negative Bacteria.](https://dx.doi.org/10.1038/s41467-017-02502-3) Nat. Commun. 2018, 9, 129.

(28) Xi, Z.; Gao, W.; Xia, X[. Size Effect in Pd-Ir Core-Shell](https://dx.doi.org/10.1002/cbic.202000147) [Nanoparticles as Nanozymes.](https://dx.doi.org/10.1002/cbic.202000147) ChemBioChem 2020, 21, 2440−2444.

(29) Li, J.; Liu, W.; Wu, X.; Gao, X. [Mechanism of pH-switchable](https://dx.doi.org/10.1016/j.biomaterials.2015.01.012) [Peroxidase and Catalase-like Activities of Gold, Silver, Platinum and](https://dx.doi.org/10.1016/j.biomaterials.2015.01.012) [Palladium.](https://dx.doi.org/10.1016/j.biomaterials.2015.01.012) Biomaterials 2015, 48, 37−44.

(30) Ge, C.; Fang, G.; Shen, X.; Chong, Y.; Wamer, W. G.; Gao, X.; Chai, Z.; Chen, C.; Yin, J. J[. Facet Energy versus Enzyme-like](https://dx.doi.org/10.1021/acsnano.6b06297) [Activities: The Unexpected Protection of Palladium Nanocrystals](https://dx.doi.org/10.1021/acsnano.6b06297) [against Oxidative Damage.](https://dx.doi.org/10.1021/acsnano.6b06297) ACS Nano 2016, 10, 10436−10445.

(31) Wang, X.; Gao, X.; Qin, L.; Wang, C.; Song, L.; Zhou, Y.; Zhu, G.; Cao, W.; Lin, S.; Zhou, L.; Wang, K.; Zhang, H.; Jin, Z.; Wang, P.; Gao, X.; Wei, H. eg [Occupancy as an Effective Descriptor for the](https://dx.doi.org/10.1038/s41467-019-08657-5) [Catalytic Activity of Perovskite Oxide-based Peroxidase Mimics.](https://dx.doi.org/10.1038/s41467-019-08657-5) Nat. Commun. 2019, 10, 704.

(32) Huang, L.; Chen, J.; Gan, L.; Wang, J.; Dong, S[. Single-Atom](https://dx.doi.org/10.1126/sciadv.aav5490) [Nanozymes.](https://dx.doi.org/10.1126/sciadv.aav5490) Sci. Adv. 2019, 5, eaav5490.

(33) Seo, O.; Lee, J. Y.; Kim, J. M.; Kim, J. W.; Kang, H. C.; Chung, J.; Noh, D. Y. [Chemical Ordering in PtNi Nanocrystals.](https://dx.doi.org/10.1016/j.jallcom.2016.01.069) J. Alloys Compd. 2016, 666, 232−236.

(34) Paudyal, D.; Saha-Dasgupta, T.; Mookerjee, A. [Study of Phase](https://dx.doi.org/10.1088/0953-8984/15/7/302) [Stability in NiPt Systems.](https://dx.doi.org/10.1088/0953-8984/15/7/302) J. Phys.: Condens. Matter 2003, 15, 1029− 1046.

(35) Su, H.; Bao, X.; Li, W. [Modulating the Reactivity of Ni-](https://dx.doi.org/10.1063/1.2920174)[Containing Pt(111)-Skin Catalysts by Density Functional Theory](https://dx.doi.org/10.1063/1.2920174) [Calculations.](https://dx.doi.org/10.1063/1.2920174) J. Chem. Phys. 2008, 128, 194707.

(36) Lequin, R. M. [Enzyme Immunoassay (EIA)/Enzyme-Linked](https://dx.doi.org/10.1373/clinchem.2005.051532) [Immunosorbent Assay (ELISA).](https://dx.doi.org/10.1373/clinchem.2005.051532) Clin. Chem. 2005, 51, 2415−2418.

(37) Armbruster, D. A.; Tillman, M. D.; Hubbs, L. M[. Limit of](https://dx.doi.org/10.1093/clinchem/40.7.1233) [Detection (LQD)/Limit of Quantitation (LOQ): Comparison of the](https://dx.doi.org/10.1093/clinchem/40.7.1233) [Empirical and the Statistical Methods Exemplified with GC-MS](https://dx.doi.org/10.1093/clinchem/40.7.1233) [Assays of Abused Drugs.](https://dx.doi.org/10.1093/clinchem/40.7.1233) Clin. Chem. 1994, 40, 1233−1238.