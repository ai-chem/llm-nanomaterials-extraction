**Open Access**

# Bactericidal efects and accelerated wound healing using Tb4O7 nanoparticles with intrinsic oxidase-like activity

Chen Li1†, Yurong Sun1†, Xiaoping Li1†, Sanhong Fan1*, Yimin Liu2 , Xiumei Jiang3 , Mary D. Boudreau4 , Yue Pan2* [,](http://orcid.org/0000-0001-7709-0508) Xin Tian5* and Jun‑Jie Yin3

# **Abstract**

**Background:** Nanomaterials that exhibit intrinsic enzyme-like characteristics have shown great promise as potential antibacterial agents. However, many of them exhibit inefcient antibacterial activity and biosafety problems that limit their usefulness. The development of new nanomaterials with good biocompatibility and rapid bactericidal efects is therefore highly desirable. Here, we show a new type of terbium oxide nanoparticles (Tb4O7 NPs) with intrinsic oxidase-like activity for in vitro and in vivo antibacterial application.

**Results:** We fnd that Tb4O7 NPs can quickly oxidize a series of organic substrates in the absence of hydrogen per‑ oxide. The oxidase-like capacity of Tb4O7 NPs allows these NPs to consume antioxidant biomolecules and generate reactive oxygen species to disable bacteria in vitro. Moreover, the in vivo experiments showed that Tb4O7 NPs are efcacious in wound-healing and are protective of normal tissues.

**Conclusions:** Our results reveal that Tb4O7 NPs have intrinsic oxidase-like activity and show efective antibacterial ability both in vitro and in vivo. These fndings demonstrate that Tb4O7 NPs are efective antibacterial agents and may have a potential application in wound healing.

**Keywords:** Tb4O7 nanoparticles, Oxidase, Reactive oxygen species, Antibacterial, Wound healing

# **Background**

Wound infection is an important cause of poor wound healing and its treatment often requires the use of antibiotics [[1,](#page-8-0) [2\]](#page-8-1). However, excessive use of antibiotics may lead to the development of antibiotic-resistant bacteria, and may also cause side efects on human health, such as gastrointestinal disturbances. In recent years, developments

*Correspondence: fsh729@sxu.edu.cn; panyue@mail.sysu.edu.cn; xtian@suda.edu.cn

2 Guangdong Provincial Key Laboratory of Malignant Tumor Epigenetics and Gene Regulation, Department of Radiation Oncology, Medical Research Center, Sun Yat‑Sen Memorial Hospital, Sun Yat-Sen University, Guangzhou 510120, China

5 State Key Laboratory of Radiation Medicine and Protection, School for Radiological and Interdisciplinary Sciences (RAD‑X), Collaborative Innovation Center of Radiation Medicine of Jiangsu Higher Education Institutions, Soochow University, Suzhou 215123, China Full list of author information is available at the end of the article

in nanomaterial technology have provided an opportunity to develop novel antimicrobial agents. Due to the diversity in mechanisms of action against bacteria, bacterial cells are less likely to develop antibacterial resistance compared to existing antibiotics [\[3](#page-8-2)[–5](#page-8-3)]. However, most of these nanomaterials have application limitations, such as cytotoxicity, not biocompatible for human use, and environmental concerns.

Nanozymes are nanomaterials that catalyze the same reactions originally catalyzed by natural enzymes in biological systems [\[6](#page-8-4)[–8](#page-8-5)]. Over the past several years, a wide variety of nanomaterials, such as noble metals [\[9](#page-8-6)[–11](#page-8-7)], metal oxides [[12](#page-8-8)–[14\]](#page-9-0), and carbon nanomaterials [[15–](#page-9-1)[18\]](#page-9-2), have been explored as potential nanozymes. Based on their intrinsic enzyme-like activity, several nanozymes have been used in antibacterial applications [\[19](#page-9-3)[–23](#page-9-4)]. For instance, platinum nanomaterials have shown efective antibacterial activity in the presence of hydrogen

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

© The Author(s) 2019. This article is distributed under the terms of the Creative Commons Attribution 4.0 International License (<http://creativecommons.org/licenses/by/4.0/>), which permits unrestricted use, distribution, and reproduction in any medium, provided you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The Creative Commons Public Domain Dedication waiver [(http://creativecommons.org/](http://creativecommons.org/publicdomain/zero/1.0/) [publicdomain/zero/1.0/](http://creativecommons.org/publicdomain/zero/1.0/)) applies to the data made available in this article, unless otherwise stated.

<sup>†</sup> Chen Li, Yurong Sun and Xiaoping Li contributed equally to this work 1 School for Life Science, Shanxi University, Taiyuan 030006, China

peroxide (H2O2) [\[24](#page-9-5)]. Te antibacterial activity of these nanozymes are attributed primarily to their oxidase- and peroxidase-like activities that catalyze the production of hydroxyl radicals (·OH) in the presence of exogenous H2O2 and enhance the cellular levels of reactive oxygen species (ROS) within bacteria cells. Fang et al. also showed that palladium nanomaterials with oxidase- and peroxidase-like activities displayed efective antibacterial activity in the presence of H2O2 [\[25](#page-9-6)]. Although many reported enzyme-like nanomaterials have been proposed as novel antibacterial agents, the high price and persistence in living tissues are still important issues. Moreover, the application of H2O2 in human wound disinfection is harmful to healthy tissue and may delay wound healing [\[26](#page-9-7)].

Terbium oxide nanoparticles (Tb4O7 NPs) have been extensively used as precursors for the synthesis of lanthanide nanophosphors and superconductor materials [\[27](#page-9-8), [28](#page-9-9)]. For example, Tb4O7 complexed with reduced graphene oxide composite exhibit typical green emission of terbium ions as well as the blue self-luminescence of graphene [\[28](#page-9-9)]. In addition, it has been found that Tb4O7 NPs can be used as analytical reagents for food analysis [[29\]](#page-9-10). Compared with noble metal nanomaterials, Tb4O7 NPs are easier to synthesize and are less expensive. However, a review of scientifc literature was unable to fnd any studies that described the enzyme-like activity of Tb4O7 NPs and their applications as antibacterial agents. In this paper, we show that Tb4O7 NPs have an intrinsic oxidaselike activity at acidic pH values, as they quickly oxidize a series of organic substrates in the absence of H2O2. We then demonstrate the relationship between the oxidase-like property of Tb4O7 NPs and their antibacterial activity with in vitro studies. Finally, the efects of Tb4O7 NPs on wound disinfection and healing are evaluated in in vivo studies using a wound infection mouse model.

# **Materials and methods**

#### **Chemicals and materials**

Tb4O7 NPs were purchased from US Research Nanomaterials, Inc. (TX, USA). 3,3,5,5-tetramethylbenzidinedihydrochloride (TMB), diammonium 2,2′-azino-bis(3-ethylbenzothiazoline-6-sulfonate) (ABTS), *o*-phenylenediamine (OPD), and Lipid Peroxidation MDA Assay Kit were all purchased from Sigma-Aldrich (St. Louis, MO). Te Live/Dead BacLight bacterial viability kit and 2′,7′-dichlorodihydrofuorescein diacetate (DCFH-DA) were obtained from Termo Fisher Scientifc, Inc. (MA, USA). 5-tert-butoxycarbonyl-5-methyl-1-pyrroline-*N*-oxide (BMPO) and Cell Counting Kit-8 (CCK-8) were obtained from Dojindo Laboratories (Kumamoto, Japan). *Escherichia coli* (*E. coli*) and *Staphylococcus aureus* subsp. *aureus* (*S. aureus*) were obtained from the China General Microbiological Culture Collection Center (CGMCC, Beijing, China). Human umbilical vein endothelial cells (HUVECs) were purchased from the American Type Culture Collection (ATCC, MD, USA).

# **Characterization of Tb4O7 NPs**

Te hydrodynamic size and zeta potential of the Tb4O7 NPs were measured using a Zetasizer Nano-ZS (Malvern, UK). Te morphology and size of the Tb4O7 NPs were characterized using a transmission electron microscopy (TEM, Tecnai G-20, FEI). Te UV–vis absorption spectrum was recorded on a spectrophotometer (UV-3600, Shimadzu).

#### **Electron spin resonance spectroscopic measurements**

Te electron spin resonance (ESR) measurements were carried out using a Bruker EMX ESR spectrometer according to our previous study [\[3](#page-8-2), [9\]](#page-8-6). Te fnal concentration of each component is described in each fgure caption. All the ESR measurements were carried out at ambient temperature.

#### **Measurement of intracellular ROS**

After Tb4O7 NPs (100 μg/mL) treatment, bacteria (1×109 CFU/mL) were collected by centrifugation and incubated with DCFH-DA (10 µM) for 30 min at dark, and stained bacteria were visualized with a confocal laser microscopy.

#### **Cytotoxicity experiments**

HUVECs were employed for investigating the cytotoxicity of Tb4O7 NPs. HUVECs were seeded at a density of 1×105 cells/well in 96-well plates and incubated overnight. Te HUVECs were then incubated with Tb4O7 NPs (0–100 μg/mL) for 24 h, and cell viability was measured by MTT assay.

#### **Mice injury model**

BALB/c mice (8 weeks) were purchased from Pengsheng. On the day 0, the mice were anesthetized using 10% chloral hydrate. Ten, the dorsal hair of mouse was shaved, full-thickness skin wounds with the diameter of 10 mm were created on the back of each mouse. After 24 h (day 1), the mice were treated with 50 μL PBS or Tb4O7 NPs (100 μg/mL). Te Tb4O7 NPs were dripping on the surface of the wound.

#### **Hemolysis test**

Fresh blood was collected under sterile conditions from healthy BALB/c mice (n=5) into an anticoagulation tube. Te red blood cells were precipitated by centrifugation at 2000 rpm for 10 min and washed three times with PBS bufer solution to obtain red blood cells. Te appropriate amount of red blood cells was diluted fve times with PBS bufer solution to prepare a red blood cell solution. 20 μL of the diluted red blood cell suspension was mixed with a series of diferent concentrations of Tb4O7 NPs (0–200 μg/mL); ultrapure water was used as control. All the above samples were incubated at 37 °C for 2 h, centrifuged at 2000 rpm for 10 min, imaged, and the supernatant after centrifugation was taken in a 96-well plate to measure the absorbance at 540 nm using a microplate reader. Te hemolysis rate was calculated as follows:

Hemolysis rate (%)

= sample absorption − negative control absorption /

positive control absorption − negative control absorption

× 100%, and hemolysis rate exceeding 5%

is considered hemolysis.

# **Results and discussion**

# **Characterization of Tb4O7 NPs**

Te Tb4O7 NPs used in the present study were purchased from US Research Nanomaterials, Inc. Te physical characterization of Tb4O7 NPs is shown in Additional fle [1](#page-8-9): Figure S1 and included images of particle core size and shape captured by TEM, the mean and homogeneity of particle hydrodynamic size by dynamic light scattering (DLS), and particle absorption spectrum by UV–vis. According to TEM and DLS data, the dispersity of Tb4O7 NPs is poor. Te mean core particle size of Tb4O7 NPs is approximately 200 nm (Additional fle [1:](#page-8-9) Figure S1a, b); while the DLS result of Tb4O7 NPs is around 400 nm (Additional fle [1](#page-8-9): Figure S1c). Tis is mainly due to the size measured by DLS was a hydrodynamic size, and therefore the nanoparticles showed a larger hydrodynamic volume due to solvent efect in the hydrated state. Te zeta potential value of Tb4O7 NPs is 31.6 mV in water. Te UV–vis spectrum of Tb4O7 NPs is shown in Additional fle [1](#page-8-9): Figure S1d.

# **Catalytic activity of Tb4O7 NPs as oxidase mimetics**

Te oxidase-like activity of Tb4O7 NPs was evaluated using the substrate TMB. Te UV–vis spectroscopy measurements show time-dependent increases in TMB oxidation catalyzed by Tb4O7 NPs, yielding a bluecolored product (Fig. [1a](#page-2-0), b). In addition, Tb4O7 NPs can also catalyze the oxidation of ABTS and OPD (Fig. [1](#page-2-0)a).

We used the oxidation of TMB as a model reaction and found that the catalytic efciency of the Tb4O7 NPs is dependent on TMB concentrations, pH and temperature (Fig. [1](#page-2-0)c and Additional fle [1](#page-8-9): Figure S2). As shown

<DESCRIPTION_FROM_IMAGE>This image is a composite of six panels (a-f) showing various experimental results related to the oxidase-like activity of Tb4O7 nanoparticles (NPs).

Panel a: Two rows of test tubes are shown. The top row contains three tubes labeled TMB, ABTS, and OPD, which appear to contain clear solutions. The bottom row shows the same substrates mixed with Tb4O7 NPs, resulting in colored solutions: blue for TMB, blue-green for ABTS, and orange for OPD. This demonstrates the oxidase-like activity of Tb4O7 NPs on these substrates.

Panel b: UV-Vis absorption spectra of a reaction over time (2-12 minutes). The graph shows absorbance (a.u.) vs wavelength (nm) from 400 to 1000 nm. Two main absorption peaks are visible around 650 nm and 950 nm, with their intensity increasing over time, indicating the progress of the oxidation reaction.

Panel c: A graph showing the absorbance at 652 nm (a.u.) vs time (s) for different particle concentrations of Tb4O7 NPs (75, 100, 125, 150, and 200 μg/mL). The absorbance increases linearly with time for all concentrations, with higher concentrations showing steeper slopes.

Panel d: A linear plot of enzyme units vs Tb4O7 NPs mass (mg). The specific activity (SA) is calculated as 0.016 U/mg.

Panel e: A Michaelis-Menten kinetics plot showing the initial velocity (V) in 10^-8 M s^-1 vs TMB concentration (mM). The curve shows typical enzyme kinetics behavior, approaching saturation at higher substrate concentrations.

Panel f: A Lineweaver-Burk plot (double reciprocal plot) of 1/V (10^8 sM^-1) vs 1/TMB concentration (mM^-1). This linear transformation of the Michaelis-Menten equation allows for the determination of kinetic parameters.

These results collectively demonstrate and characterize the oxidase-like activity of Tb4O7 NPs, showing their ability to catalyze the oxidation of various substrates and providing kinetic data for the reaction with TMB.</DESCRIPTION_FROM_IMAGE>

<span id="page-2-0"></span>**Fig. 1** Oxidase-like activity of Tb4O7 NPs. **a** A photograph showing the capability of the Tb4O7 NPs in catalyzing the oxidations of TMB, ABTS, and OPD that produce colored products. **b** Time-dependent absorption spectra of TMB catalyzed by Tb4O7 NPs. **c** Absorbance at 652 nm measured from samples containing TMB and diferent concentrations of Tb4O7 NPs. **d** The specifc activities of Tb4O7 NPs. Steady-state kinetic assays of Tb4O7 NPs (**e**, **f**). **e** TMB concentration dependence of initial reaction velocity. **f** Double-reciprocal plot generated from (**d**)

in Additional fle [1:](#page-8-9) Figure S2a, Tb4O7 NPs exhibit excellent catalytic activity over a broad temperature range (25–60 °C). Moreover, an acidic condition (pH=3.6) is conducive to the oxidase-like activity of Tb4O7 NPs (Additional fle [1:](#page-8-9) Figure S2b). We adopted pH 3.6 and 25 °C (room temperature) as the standard conditions for subsequent studies.

Next, we determined the apparent steady-state kinetic parameters for the reaction of Tb4O7 NPs with TMB. Typical Michaelis–Menten curves were established (Fig. [1d](#page-2-0)). Te curves were then ftted to the double-reciprocal Lineweaver–Burk plots (Fig. [1e](#page-2-0)), from which the kinetic parameters shown in Table [1](#page-3-0) were determined.

# **Efects of Tb4O7 NPs on the anti‑oxidant defense system**

Te above results show that Tb4O7 NPs have oxidase-like activity oxidizing TMB, ABTS, and OPD in the absence of H2O2. We predict that Tb4O7 NPs would deplete intracellular antioxidants and, eventually, disrupt the antioxidant defense systems of bacteria. To test this hypothesis, we examined the efects of Tb4O7 NPs on ascorbic acid (AA) oxidation in vitro. AA is an important endogenous bacterial antioxidant that prevents cellular damage from ROS. AA can be oxidized to form an intermediate ascorbyl radical (·AA), which is detectable by ESR spectroscopy

<span id="page-3-0"></span>**Table 1 The kinetic constants of Tb4O7 NPs**

|              | [E] (M)    | Km (M)    | Vmax (M/s) | (s−1<br>Kcat<br>) | Kcat/Km<br>(M−1<br>S−1<br>) |
|--------------|------------|-----------|------------|-------------------|-----------------------------|
| Tb4O7<br>NPs | 7.04×10−10 | 1.24×10−4 | 4.31×10−8  | 1.61×10−4         | 1.30                        |

[E] is the concentration of Tb4O7 NPs. The particle number of Tb4O7 NPs is calculated using the density and diameter of Tb4O7 NPs. Dividing the particle number by the Avogadro constant is the molar concentration of Tb4O7 NPs

[[9\]](#page-8-6). As shown in Fig. [2](#page-3-1)a, the oxidation of AA was negligible within 10 min, while in the presence of Tb4O7 NPs the system showed a time-dependent increase in the ESR signal intensity in the frst 8 min and then decreased over time. Tese results indicate that Tb4O7 NPs can accelerate AA oxidation.

In the substrate oxidation mechanism of most oxidases in nature, oxygen acts as the electron acceptor and is reduced to H2O2. To gain a better understanding of the oxidation of AA by Tb4O7 NPs, we examined whether the catalytic oxidation product of Tb4O7 NPs and AA produced H2O2. As shown in Additional fle [1](#page-8-9): Figure S3, a marked increase of H2O2 was detected in the presence of Tb4O7 compared to control (AA alone). Moreover, the production of H2O2 was Tb4O7 concentration-dependent.

Previous studies have demonstrated that several kinds of nanoparticles are capable of catalyzing the production of hydroxyl radicals by H2O2 [\[30](#page-9-11), [31](#page-9-12)]. Terefore, we determined whether Tb4O7 NPs would catalyze the production of hydroxyl radicals by H2O2 using ESR spectroscopy. We selected BMPO as the capture agent, since BMPO can capture hydroxyl radicals to form BMPO/·OH adducts indicated by the presence of four characteristic lines on the ESR spectrum. As shown in Fig. [2](#page-3-1)b, the characteristic ESR signals of BMPO/·OH were negligible in the absence of Tb4O7 NPs. However, the addition of Tb4O7 NPs resulted in a strong ESR spectrum that displayed the four characteristic lines (1:2:2:1) of BMPO/·OH. Tese results clearly show that Tb4O7 NPs can be used as a catalyst in the decomposition of H2O2 to produce hydroxyl radicals.

Taken together, our results confrm that Tb4O7 NPs are capable of catalyzing the oxidation of biologically

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled as Fig. 2a and Fig. 2b, presenting data related to the oxidation of AA by Tb4O7 NPs and ESR spectra of BMPO/·OH.

Fig. 2a:
This graph shows the oxidation of AA by Tb4O7 NPs over time. The x-axis represents Time (min) from 0 to 10 minutes, while the y-axis shows ESR signal intensity (a.u.) ranging from 0 to 800. Three datasets are plotted:

1. Control: Represented by black squares, showing a relatively constant low signal intensity around 50 a.u. throughout the time range.
2. Tb4O7 NPs (50 μg/mL): Represented by blue circles, showing an increasing signal intensity from about 250 a.u. to a maximum of about 450 a.u. at around 7 minutes, then slightly decreasing.
3. Tb4O7 NPs (100 μg/mL): Represented by red triangles, showing the highest signal intensity, increasing from about 350 a.u. to a maximum of about 750 a.u. at around 7-8 minutes, then slightly decreasing.

Fig. 2b:
This graph presents ESR spectra of BMPO/·OH generated from a sample solution containing 25 mM BMPO, 1 mM H2O2 in the absence (control) and presence of different concentrations of Tb4O7 NPs. The x-axis represents the Magnetic field [G] ranging from 3320 to 3420, while the y-axis shows ESR signal intensity (a.u.) without specific numerical values.

Three spectra are shown:

1. Control: A relatively flat line near the bottom of the graph, showing minimal signal intensity.
2. 100 μg/mL Tb4O7 NPs: The middle spectrum, showing four distinct peaks with higher intensity than the control.
3. 50 μg/mL Tb4O7 NPs: The top spectrum, showing four distinct peaks with the highest intensity among the three spectra.

The peaks in both 50 μg/mL and 100 μg/mL spectra are centered around 3340, 3360, 3380, and 3400 G, with the 3380 G peak showing the highest intensity in both cases.

This figure demonstrates the concentration-dependent effect of Tb4O7 NPs on the generation of hydroxyl radicals (·OH) as detected by ESR spectroscopy using BMPO as a spin trap.</DESCRIPTION_FROM_IMAGE>

relevant antioxidant agents, resulting in the production of H2O2. Moreover, Tb4O7 NPs can further catalyze the production of hydroxyl radicals via the decomposition of H2O2.

# **Antibacterial activity of Tb4O7 NPs**

Both H2O2 and hydroxyl radicals have strong oxidizing ability and can oxidize biological macromolecules, such as proteins and phospholipids [[32\]](#page-9-13). Our study found that Tb4O7 NPs with oxidase-like activity can catalyze the production of H2O2 and further produce hydroxyl radicals. Terefore, the oxidase-like activity of the Tb4O7 NPs makes them potentially useful as antibacterial agents. We evaluated the antibacterial activity of Tb4O7 NPs against *E. coli* and *S. aureus*. A colony-forming units plate counting method was used to determine the antibacterial ability (Fig. [3](#page-5-0)a, b). As compared to the PBS control group, Tb4O7 NPs exhibited potent antimicrobial activity against both *S. aureus* and *E. coli* in a concentrationdependent manner. At a concentration of 25 μg/mL, Tb4O7 NPs exhibited only modest antibacterial efects against *S. aureus*; more than 80% of the bacterial cells survived. However, when the concentration of Tb4O7 NPs was increased to 100 μg/mL, nearly 90% of the *S. aureus* were killed. A similar trend of antibacterial efects were observed towards the *E. coli*.

To further investigate the interaction between Tb4O7 NPs and bacteria, a fuorescent-based cell live/dead assay was conducted. As shown in Fig. [3](#page-5-0)c, d, Tb4O7 NPs exhibited signifcant antibacterial activity against both *S. aureus* and *E. coli*, which was consistent with the aforementioned results. Te exposure of *S. aureus* cells to Tb4O7 NPs at a concentration of 100 μg/mL resulted in nearly 100% lethality, as evidenced by the dominant red fuorescent signal. At a concentration of 50 μg/mL, Tb4O7 NPs completely inhibited the bacterial growth of *E. coli*.

Te morphology and membrane integrity of bacteria were then determined by SEM (Fig. [3c](#page-5-0), d). Untreated *S. aureus* displayed a typical rod-shaped structure with a continuous, smooth surface. When exposure to the 50 μg/mL of Tb4O7 NPs, the *S. aureus* bacterial cell walls became partially wrinkled and discontinuance. Notably, after treatment with 100 μg/mL of Tb4O7 NPs, the *S. aureus* bacterial cell walls showed much more pronounced damage, indicating stronger antibacterial efects at higher concentrations of Tb4O7 NPs. A similar tendency was found for *E. coli*. Te loss of membrane integrity of *E. coli* was observed at concentrations lower than 100 μg/mL of Tb4O7 NPs treatment. Moreover, Tb4O7 NPs were observed by SEM and SEM-energy dispersive X-ray spectroscopy (EDS) to aggregate on the surfaces of *S. aureus* and *E. coli* (Additional fle [1](#page-8-9): Figure S4).

It is known that the proton motive force decreases the local pH (as low as pH 3.0) in the cytoplasm and membrane of bacteria cells [\[33](#page-9-14), [34\]](#page-9-15). Since we found that Tb4O7 NPs exhibit oxidase-like activity under acidic conditions, we speculate that the antibacterial mechanism of Tb4O7 NPs may arise from their oxidase activity to accelerate the process of bacterial cell oxidation and consumption of antioxidant biomolecules, leading to a reduction of oxygen products including H2O2 along with other antibacterial activity from the accumulation of ROS. To confrm this hypothesis, the intracellular levels of ROS were determined using the forescent probe, DCFH-DA (Fig. [4)](#page-6-0). For both *S. aureus* and *E. coli*, the untreated cells showed extremely weak fuorescence, indicating low levels in the formation of intracellular ROS. In contrast, bacterial cells exposed to Tb4O7 NPs showed high levels of ROS formed within the cellular cytoplasm, as evidenced by the strong fuorescence signal. We also found that the generation of ROS is Tb4O7 NPs dose-dependent (Additional fle [1](#page-8-9): Figure S5).

# **In vivo wound disinfection efect of Tb4O7 NPs**

Te above fndings suggest that Tb4O7 NPs may have role as an antibacterial agent for bacterial infections in vivo. To assess the antibacterial capacity of Tb4O7 NPs in vivo, a wound infection model was constructed using BALB/c mice. A wound was introduced on the back of the mouse and an infection was established by implanting *S. aureus* into the wounded area. After infection was established, PBS or Tb4O7 NPs were applied to the infected wound. Figure [5a](#page-6-1), b shows the progress of the wounds. Compared with the control (PBS treatment) group after 3 days, the wound area was reduced under Tb4O7 NPs treatment. After treating of 7 days with Tb4O7 NPs treatment, the wounds were nearly healed completely. In contrast, obvious scab was observed from the control group, indicating incomplete recovery.

# **Biosafety of Tb4O7 NPs**

Biosafety is an important factor for antimicrobial agents designers. To assess the biosafety of Tb4O7 NPs, we frst determined the efects of Tb4O7 NPs on red blood cells and HUVECs in vitro. Te efect of Tb4O7 NPs on cell membrane disrupt was frst determined by a red blood cell hemolysis assay. As shown in Fig. [6](#page-7-0)a, pure water can cause severe red blood cells hemolysis within 2 h. In contrast, the introduction of Tb4O7 NPs did not cause signs of hemolysis. In this experimental result, the hemolysis rate was still less than 1% at a concentration of 100 µg/ mL, which fully demonstrated that Tb4O7 NPs have good blood compatibility. Meanwhile, the cytotoxicity tests on

<DESCRIPTION_FROM_IMAGE>This image presents a comprehensive study on the effect of Tb4O7 nanoparticles (NPs) on the survival rates of two bacterial species: Staphylococcus aureus (S. aureus) and Escherichia coli (E. coli). The figure is divided into four parts (a, b, c, and d).

a) Bar graph showing the survival rate of S. aureus at different concentrations of Tb4O7 NPs:
- Control: ~100% survival
- 25 μg/mL: ~80% survival
- 50 μg/mL: ~55% survival
- 100 μg/mL: ~15% survival
Statistical significance (***) is indicated for the 25, 50, and 100 μg/mL concentrations.

b) Bar graph showing the survival rate of E. coli at different concentrations of Tb4O7 NPs:
- Control: ~100% survival
- 10 μg/mL: ~80% survival (** statistical significance)
- 25 μg/mL: ~50% survival (*** statistical significance)
- 50 μg/mL: ~5% survival (*** statistical significance)

c) Representative fluorescence and SEM images of S. aureus after Tb4O7 NP treatments:
1. Control (PBS)
2. 25 μg/mL Tb4O7 NPs
3. 50 μg/mL Tb4O7 NPs
4. 100 μg/mL Tb4O7 NPs
Fluorescence images (top row) show increasing cell death (red/yellow fluorescence) with increasing NP concentration. SEM images (bottom row) display morphological changes and cell damage at higher concentrations.

d) Representative fluorescence and SEM images of E. coli after Tb4O7 NP treatments:
1. Control (PBS)
2. 10 μg/mL Tb4O7 NPs
3. 25 μg/mL Tb4O7 NPs
4. 50 μg/mL Tb4O7 NPs
Fluorescence images (top row) demonstrate increasing cell death with higher NP concentrations. SEM images (bottom row) show progressive morphological changes and cell damage.

The fluorescence images have a scale bar of 40 μM, while the SEM images have a scale bar of 2 μM.

This figure demonstrates the dose-dependent antibacterial effect of Tb4O7 NPs on both S. aureus and E. coli, with E. coli showing higher sensitivity to the nanoparticles.</DESCRIPTION_FROM_IMAGE>

mammalian cells HUVECs further confrm the biosafety of Tb4O7 NPs (Fig. [6](#page-7-0)b).

<span id="page-5-0"></span>Tb4O7 NPs. ***p*<0.01 and ****p*<0.001 vs control

Ten, the biosafety of Tb4O7 NPs in vivo were determined. As shown in Fig. [7a](#page-7-1), the indicators in blood were within the normal range. Te major mouse organs (heart, liver, spleen, lung, and kidney) were formalin-fxed and processed for the evaluation of H&E sections by

<DESCRIPTION_FROM_IMAGE>The image presents two panels, labeled 'a' and 'b', depicting experimental results related to the effect of Tb4O7 nanoparticles (NPs) on bacterial cells.

Panel a: Fluorescence images of bacterial cells
This panel shows four fluorescence microscopy images arranged in a 2x2 grid. The rows are labeled with bacterial species names: S. aureus (top row) and E. coli (bottom row). The columns are labeled as Control (left column) and Tb4O7 NPs (right column). 

The control images for both bacterial species show minimal fluorescence, indicating low levels of reactive oxygen species (ROS). In contrast, the Tb4O7 NPs-treated samples display significantly increased fluorescence intensity, suggesting higher ROS levels. The fluorescence appears more intense and widespread in the Tb4O7 NPs-treated samples compared to their respective controls.

A scale bar of 20 μm is provided in the bottom right image.

Panel b: Analysis of ROS levels by microplate reader
This panel presents a bar graph showing the relative signal intensity of ROS levels in different bacterial samples. The x-axis lists three conditions: Control, S. aureus, and E. coli. The y-axis represents the relative signal intensity, ranging from 0 to 3.

The results show:
1. Control: Relative signal intensity of 1 (baseline)
2. S. aureus: Relative signal intensity of approximately 2.7
3. E. coli: Relative signal intensity of approximately 2.4

Both S. aureus and E. coli samples show significantly higher ROS levels compared to the control, as indicated by the asterisks (***) above the bars, which denote p < 0.001 vs control.

Error bars are present on the S. aureus and E. coli bars, indicating the variability of the measurements.

The figure caption (Fig. 4) provides additional context:
a. Fluorescence images of bacterial cells.
b. Analysis of the ROS levels by microplate reader. ***p < 0.001 vs control

In summary, this figure demonstrates that Tb4O7 nanoparticles induce significant increases in ROS levels in both S. aureus and E. coli bacterial cells, as evidenced by increased fluorescence in microscopy images and quantitative analysis using a microplate reader.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image presents a comprehensive study on wound healing and antibacterial effects of Tb4O7 nanoparticles (NPs) compared to a control group. The figure is divided into three parts: a, b, and c.

a. This section shows a series of photographs depicting wound healing progression on the backs of mice over 7 days. Two rows of images are presented:
   - Control group (PBS treatment)
   - Tb4O7 NPs treatment group
   Images are shown for days 1, 3, 5, and 7. The Tb4O7 NPs treatment group shows visibly faster wound closure and healing compared to the control group.

b. A bar graph illustrating the percentage of original wound size over time (days 1, 3, 5, and 7) for both control and Tb4O7 NPs groups. Key observations:
   - Day 1: Both groups start at around 100% wound size
   - Day 3: Slight decrease in both groups, with Tb4O7 NPs showing marginally better healing
   - Day 5: Significant difference emerges; control group at ~80%, Tb4O7 NPs group at ~30%
   - Day 7: Control group at ~65%, Tb4O7 NPs group at ~18%
   The graph includes error bars and indicates statistical significance (*** denoting p<0.001) for days 5 and 7.

c. A bar graph showing bacterial numbers in infected wounds on day 7, measured in CFU/mL (Colony Forming Units per milliliter). Results:
   - Control group: ~140 x 10^6 CFU/mL
   - Tb4O7 NPs group: ~5 x 10^6 CFU/mL
   The difference is statistically significant (*** indicating p<0.001).

The figure caption provides additional information:
- Fig. 5a: Specifies that n=5 for each group and provides a scale bar of 5 mm.
- Fig. 5b: Describes the graph as showing related wound size in each treatment group.
- Fig. 5c: Indicates bacterial number of infected wounds on the 7th day.

Overall, the data strongly suggests that Tb4O7 NPs treatment significantly enhances wound healing and reduces bacterial infection compared to the control treatment.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled as "a" and "b", both related to the effects of Tb4O7 nanoparticles (NPs) on biological systems.

Graph a:
Title: The hemolysis ratio of red blood cells
X-axis: Concentration (μg/mL), ranging from 0 to 200 μg/mL, with an additional point for H2O
Y-axis: Hemolysis ratio (%), ranging from 0 to 100%

The graph shows very low hemolysis ratios (close to 0%) for concentrations of 0, 25, 50, 100, and 200 μg/mL of Tb4O7 NPs. There is a sharp increase in hemolysis ratio to about 90% for the H2O sample.

An inset image shows 6 tubes containing red blood cell solutions:
Tube 1: PBS buffer
Tubes 2-5: 25, 50, 100, and 200 μg/mL Tb4O7 NPs
Tube 6: Ultrapure water

The tubes visually confirm the graph data, showing minimal hemolysis in tubes 1-5 and complete hemolysis in tube 6.

Graph b:
Title: MTT assays determined cell viability of HUVECs after Tb4O7 NPs treatment
X-axis: Concentration (μg/mL), ranging from 0 to 100 μg/mL
Y-axis: Cell viability (%), ranging from 0 to 100%

The graph shows a slight decrease in cell viability as the concentration of Tb4O7 NPs increases:
0 μg/mL: ~100% viability
25 μg/mL: ~97% viability
50 μg/mL: ~93% viability
75 μg/mL: ~87% viability
100 μg/mL: ~83% viability

Error bars are included for each data point.

Caption: Fig. 6 a The hemolysis ratio of red blood cells. The insert images of tubes containing red blood cells solution show the direct observation of hemolysis. Tube 1: PBS buffer; Tube 2–5: 25, 50, 100, and 200 μg/mL Tb4O7 NPs; Tube 6: ultrapure water. b MTT assays determined cell viability of HUVECs after Tb4O7 NPs treatment

This image demonstrates the biocompatibility of Tb4O7 NPs by showing their minimal effect on red blood cell hemolysis and HUVEC cell viability at various concentrations.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image presents a comprehensive study of the in vivo toxicity of Tb4O7 nanoparticles (NPs) in mice after 7 days of treatment. The figure is divided into two main parts: (a) blood biochemistry data and (b) histological data.

Part a: Blood Biochemistry Data
This section contains 8 bar graphs comparing various blood biochemistry parameters between the control group and the Tb4O7 NPs-treated group. Each graph shows the mean values with error bars, likely representing standard deviation. The parameters measured are:

1. ALT (Alanine Aminotransferase): measured in U/L
   Control: ~38 U/L, Tb4O7 NPs: ~41 U/L

2. ALP (Alkaline Phosphatase): measured in U/L
   Control: ~155 U/L, Tb4O7 NPs: ~160 U/L

3. ALB (Albumin): measured in g/L
   Control: ~29 g/L, Tb4O7 NPs: ~30 g/L

4. AST (Aspartate Aminotransferase): measured in U/L
   Control: ~135 U/L, Tb4O7 NPs: ~160 U/L

5. A/G (Albumin/Globulin ratio): no units
   Control: ~2.7, Tb4O7 NPs: ~2.9

6. TP (Total Protein): measured in g/L
   Control: ~56 g/L, Tb4O7 NPs: ~57 g/L

7. GLOB (Globulin): measured in g/L
   Control: ~26 g/L, Tb4O7 NPs: ~27 g/L

8. UREA: measured in g/L
   Control: ~9 g/L, Tb4O7 NPs: ~8.5 g/L

In general, the differences between the control and Tb4O7 NPs groups are minimal for most parameters, with slightly higher values observed in the Tb4O7 NPs group for ALT, ALP, ALB, AST, A/G, TP, and GLOB. UREA shows a slight decrease in the Tb4O7 NPs group.

Part b: Histological Data
This section presents histological images (H&E staining) of five major organs: Heart, Liver, Spleen, Lung, and Kidney. For each organ, two images are shown: one for the control group and one for the Tb4O7 NPs-treated group. The images depict the tissue structure and cellular organization of each organ.

1. Heart: Both control and Tb4O7 NPs images show aligned cardiac muscle fibers with no apparent differences.

2. Liver: Both images display typical hepatic lobular structure with no noticeable alterations between control and Tb4O7 NPs groups.

3. Spleen: The images show normal splenic architecture with white and red pulp regions in both groups.

4. Lung: Both control and Tb4O7 NPs images depict normal alveolar structure with thin alveolar walls.

5. Kidney: The images show typical renal cortex structure with glomeruli and tubules in both groups.

No significant histological changes or signs of toxicity are apparent in the organs of Tb4O7 NPs-treated mice compared to the control group.

The scale bar provided indicates 100 μm for all histological images.

In conclusion, this figure suggests that Tb4O7 NPs treatment for 7 days does not cause significant alterations in blood biochemistry parameters or organ histology in mice, indicating low in vivo toxicity.</DESCRIPTION_FROM_IMAGE>

histopathology (Fig. [7](#page-7-1)b). No obvious mouse organ damage was observed from Tb4O7 NPs treatment.

# **Conclusions**

In summary, this study demonstrates for the frst time that Tb4O7 NPs exhibit oxidase-like activity. In addition, the results of this study established a relationship between the oxidase-like enzyme activity of Tb4O7 NPs and their antibacterial properties. Te data collected from this work revealed that the oxidase-like activity of Tb4O7 NPs was able to function with a variety of substrates, including biomolecules, and resulted in the generation of ROS, which further enhanced their antibacterial activity. Te application of the antibacterial activities of Tb4O7 NPs were demonstrated in a wound infection mouse model. Our study provides evidence that Tb4O7 NPs can be utilized as an efcient antibacterial agent and the potential applications in wound healing are promising.

# **Additional fle**

<span id="page-8-9"></span>**[Additional fle 1: Figure S1.](https://doi.org/10.1186/s12951-019-0487-x)** Characterization of Tb4O7 NPs. **Figure S2.** The oxidase-like catalytic activity of the Tb4O7 NPs. **Figure S3.** The con‑ centration of H2O2 generated in the catalytic system. **Figure S4.** SEM-EDS elemental images. **Figure S5.** ROS levels of *S. aureus*.

#### **Abbreviations**

Tb4O7: terbium oxide; NPs: nanoparticles; H2O2: hydrogen peroxide; ROS: reactive oxygen species; ABTS: diammonium 2,2′-azino-bis(3-ethylbenzothi‑ azoline-6-sulfonate); OPD: *o*-phenylenediamine; AA: ascorbic acid; DCFH-DA: 2′,7′-dichlorodihydrofuorescein diacetate; BMPO: 5-tert-butoxycarbonyl-5-methyl-1-pyrroline-*N*-oxide; CCK-8: Cell Counting Kit-8; *E. coli*: *Escherichia coli*; *S. aureus*: *Staphylococcus aureus* subsp. *aureus*; HUVEC: human umbilical vein endothelial cells; TEM: transmission electron microscopy; ESR: electron spin resonance; CFUs: colony forming units; PI: propidium iodide; SEM: scanning electron microscope; DLS: dynamic light scattering; EDS: energy dispersive X-ray spectroscopy.

#### **Authors' contributions**

CL, YS, and XL prepared and performed the experiments. YS, XL and YL analyzed the data and interpreted the results. XT, SF and YP conceived and supervised the study. The manuscript was written by XT and XJ, and revised critically by JY and MB. All authors read and approved the fnal manuscript.

#### **Author details**

1 School for Life Science, Shanxi University, Taiyuan 030006, China. 2 Guang‑ dong Provincial Key Laboratory of Malignant Tumor Epigenetics and Gene Regulation, Department of Radiation Oncology, Medical Research Center, Sun Yat‑Sen Memorial Hospital, Sun Yat-Sen University, Guangzhou 510120, China. 3 Division of Analytical Chemistry, Ofce of Regulatory Science, Center for Food Safety and Applied Nutrition, U.S. Food and Drug Administration, College Park, MD 20740, USA. 4 Division of Biochemical Toxicology, National Center for Toxicological Research, U.S. Food and Drug Administration, Jefer‑ son, AR 72079, USA. 5 State Key Laboratory of Radiation Medicine and Protec‑ tion, School for Radiological and Interdisciplinary Sciences (RAD‑X), Collabora‑ tive Innovation Center of Radiation Medicine of Jiangsu Higher Education Institutions, Soochow University, Suzhou 215123, China.

#### **Acknowledgements**

Not applicable.

#### **Competing interests**

The authors declare that they have no competing interests.

#### **Availability of data and materials**

All data generated or analyzed during this study are included in this published article and its additional fle.

#### **Consent for publication**

All authors agree to be published.

# **Ethics approval and consent to participate**

The protocols and the use of animals were approved by and in accordance with the animal welfare committee of Soochow University.

#### **Funding**

This work is partially supported by the National Natural Science Foundation of China (31400862), a project funded by the Priority Academic Program Devel‑ opment of Jiangsu Higher Education Institutions (PAPD), Jiangsu Provincial Key Laboratory of Radiation Medicine and Protection, Guangdong Science and Technology Department (2017B030314026). This article is not an ofcial U.S. FDA guidance or policy statement. No ofcial support or endorsement by the U.S. FDA is intended or should be inferred.

# **Publisher's Note**

Springer Nature remains neutral with regard to jurisdictional claims in pub‑ lished maps and institutional afliations.

# Received: 25 January 2019 Accepted: 8 April 2019

#### **References**

- <span id="page-8-0"></span>1. Fischbach MA, Walsh CT. Antibiotics for emerging pathogens. Science. 2009;325:1089–93.
- <span id="page-8-1"></span>2. Kohanski MA, Dwyer DJ, Collins JJ. How antibiotics kill bacteria: from targets to networks. Nat Rev Microbiol. 2010;8:423–35.
- <span id="page-8-2"></span>3. Tian X, Jiang X, Welch C, Croley TR, Wong TY, Chen C, Fan S, Chong Y, Li R, Ge C, Chen C, Yin JJ. Bactericidal efects of silver nanoparticles on lactobacilli and the underlying mechanism. ACS Appl Mater Interfaces. 2018;10:8443–50.
- 4. Mahmoudi M, Serpooshan V. Silver-coated engineered magnetic nano‑ particles are promising for the success in the fght against antibacterial resistance threat. ACS Nano. 2012;6:2656–64.
- <span id="page-8-3"></span>5. Panacek A, Kvitek L, Smekalova M, Vecerova R, Kolar M, Roderova M, Dycka F, Sebela M, Prucek R, Tomanec O, Zboril R. Bacterial resistance to silver nanoparticles and how to overcome it. Nat Nanotechnol. 2018;13:65–71.
- <span id="page-8-4"></span>6. Jiang B, Duan D, Gao L, Zhou M, Fan K, Tang Y, Xi J, Bi Y, Tong Z, Gao GF, Xie N, Tang A, Nie G, Liang M, Yan X. Standardized assays for determining the catalytic activity and kinetics of peroxidase-like nanozymes. Nat Protoc. 2018;13:1506–20.
- 7. Gao L, Fan K, Yan X. Iron oxide nanozyme: a multifunctional enzyme mimetic for biomedical applications. Theranostics. 2017;7:3207–27.
- <span id="page-8-5"></span>8. Wang X, Hu Y, Wei H. Nanozymes in bionanotechnology: from sensing to therapeutics and beyond. Inorg Chem Front. 2016;3:41–60.
- <span id="page-8-6"></span>9. Chen C, Fan SH, Li C, Chong Y, Tian X, Zheng JW, Fu PP, Jiang XM, Wamer WG, Yin JJ. Platinum nanoparticles inhibit antioxidant efects of vitamin C via ascorbate oxidase-mimetic activity. J Mater Chem B. 2016;4:7895–901.
- 10. Luo W, Zhu C, Su S, Li D, He Y, Huang Q, Fan C. Self-catalyzed self-limiting growth of glucose oxidase-mimicking gold nanoparticles. ACS Nano. 2010;4:7451–8.
- <span id="page-8-7"></span>11. Xia X, Zhang J, Lu N, Kim M, Ghal K, Xu W, McKenzie E, Liu J, Ye H. Pd-Ir core-shell nanocubes: a type of highly efcient and versatile peroxidase mimic. ACS Nano. 2015;9:9994–10004.
- <span id="page-8-8"></span>12. Yao J, Cheng Y, Zhou M, Zhao S, Lin S, Wang X, Wu J, Li S, Wei H. ROS scavenging Mn3O4 nanozymes for in vivo anti-infammation. Chem Sci. 2018;9:2927–33.

- 13. Ghosh S, Roy P, Karmodak N, Jemmis ED, Mugesh G. Nanoisozymes: crystal-facet-dependent enzyme-mimetic activity of V2O5 nanomaterials. Angew Chem Int Ed Engl. 2018;57:4510–5.
- <span id="page-9-0"></span>14. Singh N, Savanur MA, Srivastava S, D'Silva P, Mugesh GA. Redox modula‑ tory Mn3O4 nanozyme with multi-enzyme activity provides efcient cyto‑ protection to human cells in a Parkinson's disease model. Angew Chem Int Ed Engl. 2017;56:14267–71.
- <span id="page-9-1"></span>15. Lin L, Song X, Chen Y, Rong M, Zhao T, Wang Y, Jiang Y, Chen X. Intrinsic peroxidase-like catalytic activity of nitrogen-doped graphene quantum dots and their application in the colorimetric detection of H2O2 and glucose. Anal Chim Acta. 2015;869:89–95.
- 16. Zheng AX, Cong ZX, Wang JR, Li J, Yang HH, Chen GN. Highly-efcient peroxidase-like catalytic activity of graphene dots for biosensing. Biosens Bioelectron. 2013;49:519–24.
- 17. Wang H, Liu C, Liu Z, Ren J, Qu X. Specifc oxygenated groups enriched graphene quantum dots as highly efcient enzyme mimics. Small. 2018;14:e1703710.
- <span id="page-9-2"></span>18. Hassanzadeh J, Khataee A. Ultrasensitive chemiluminescent biosensor for the detection of cholesterol based on synergetic peroxidase-like activity of MoS2 and graphene quantum dots. Talanta. 2018;178:992–1000.
- <span id="page-9-3"></span>19. Wang Z, Dong K, Liu Z, Zhang Y, Chen Z, Sun H, Ren J, Qu X. Activation of biologically relevant levels of reactive oxygen species by Au/g-C3N4 hybrid nanozyme for bacteria killing and wound disinfection. Biomateri‑ als. 2017;113:145–57.
- 20. Cai S, Jia X, Han Q, Yan X, Yang R, Wang C. Porous Pt/Ag nanoparticles with excellent multifunctional enzyme mimic activities and antibacterial efects. Nano Res. 2017;10:2056–69.
- 21. Tao Y, Ju E, Ren J, Qu X. Bifunctionalized mesoporous silica-supported gold nanoparticles: intrinsic oxidase and peroxidase catalytic activities for antibacterial applications. Adv Mater. 2015;27:1097–104.
- 22. Chen Z, Wang Z, Ren J, Qu X. Enzyme mimicry for combating bacteria and bioflms. Acc Chem Res. 2018;51:789–99.
- <span id="page-9-4"></span>23. Chen S, Quan Y, Yu YL, Wang JH. Graphene quantum dot/silver nano‑ particle hybrids with oxidase activities for antibacterial application. ACS Biomater Sci Eng. 2017;3:313–21.

- <span id="page-9-5"></span>24. Ge C, Wu R, Chong Y, Fang G, Jiang X, Pan Y, Chen C, Yin JJ. Synthesis of Pt hollow nanodendrites with enhanced peroxidase-like activity against bacterial infections: implication for wound healing. Adv Funct Mater. 2018;28:1801484.
- <span id="page-9-6"></span>25. Fang G, Li W, Shen X, Perez-Aguilar JM, Chong Y, Gao X, Chai Z, Chen C, Ge C, Zhou R. Diferential Pd-nanocrystal facets demonstrate distinct antibacterial activity against Gram-positive and Gram-negative bacteria. Nat Commun. 2018;9:129.
- <span id="page-9-7"></span>26. Loo AE, Wong YT, Ho R, Wasser M, Du T, Ng WT, Halliwell B. Efects of hydrogen peroxide on wound healing in mice in relation to oxidative damage. PLoS ONE. 2012;7:e49215.
- <span id="page-9-8"></span>27. Nahm CW. Varistor characteristics of ZnO/V2O5/MnO2/Nb2O5 semiconducting ceramics with Tb4O7 addition. J Mater Sci Mater El. 2015;26:4144–51.
- <span id="page-9-9"></span>28. Gao H, Zhou Y, Chen KQ, Li XL. Synthesis of Tb4O7 complexed with reduced graphene oxide for Rhodamine-B absorption. Mater Res Bull. 2016;77:111–4.
- <span id="page-9-10"></span>29. Castillo-Garcia ML, Aguilar-Caballos MP, Gomez-Hens A. Application of Tb(4)O(7) nanoparticles for lasalocid and salicylate determination in food analysis. J Agric Food Chem. 2012;60:11741–7.
- <span id="page-9-11"></span>30. Tian X, Sun Y, Fan S, Boudreau M, Chen C, Ge C, Yin JJ. Photogenerated charge carriers in molybdenum disulfde quantum dots with enhanced antibacterial activity. ACS Appl Mater Interfaces. 2019;11:4858–66.
- <span id="page-9-12"></span>31. Tao W, Zhang H, Chong Y, Wamer WG, Yin JJ, Wu XC. Probing hydroxyl radical generation from H2O2 upon plasmon excitation of gold nanorods using electron spin resonance: molecular oxygen-mediated activation. Nano Res. 2016;9:1663–73.
- <span id="page-9-13"></span>32. Sun HJ, Gao N, Dong K, Ren JS, Qu XG. Graphene quantum dots-bandaids used for wound disinfection. ACS Nano. 2014;8:6202–10.
- <span id="page-9-14"></span>33. Koch AL. The pH in the neighborhood of membranes generating a protonmotive force. J Theor Biol. 1986;120:73–84.
- <span id="page-9-15"></span>34. Xiu ZM, Zhang QB, Puppala HL, Colvin VL, Alvarez PJ. Negligible particle-specifc antibacterial activity of silver nanoparticles. Nano Lett. 2012;12:4271–5.

#### Ready to submit your research ? Choose BMC and benefit from:

- **•** fast, convenient online submission
- **•** thorough peer review by experienced researchers in your field
- rapid publication on acceptance
- support for research data, including large and complex data types
- **•** gold Open Access which fosters wider collaboration and increased citations
- **•** maximum visibility for your research: over 100M website views per year

#### **At BMC, research is always in progress.**

**Learn more** biomedcentral.com/submissions

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo for BMC, which does not convey specific scientific or chemical information relevant to the context of applied chemistry or scientific research. The logo consists of stylized text and a geometric shape, but does not contain any chemical structures, graphs, diagrams, or other scientific content that would require detailed interpretation or analysis.</DESCRIPTION_FROM_IMAGE>
