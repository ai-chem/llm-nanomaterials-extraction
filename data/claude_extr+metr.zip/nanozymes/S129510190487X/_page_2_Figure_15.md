This image is a composite of six panels (a-f) showing various experimental results related to the oxidase-like activity of Tb4O7 nanoparticles (NPs).

Panel a: Two rows of test tubes are shown. The top row contains three tubes labeled TMB, ABTS, and OPD, which appear to contain clear solutions. The bottom row shows the same substrates mixed with Tb4O7 NPs, resulting in colored solutions: blue for TMB, blue-green for ABTS, and orange for OPD. This demonstrates the oxidase-like activity of Tb4O7 NPs on these substrates.

Panel b: UV-Vis absorption spectra of a reaction over time (2-12 minutes). The graph shows absorbance (a.u.) vs wavelength (nm) from 400 to 1000 nm. Two main absorption peaks are visible around 650 nm and 950 nm, with their intensity increasing over time, indicating the progress of the oxidation reaction.

Panel c: A graph showing the absorbance at 652 nm (a.u.) vs time (s) for different particle concentrations of Tb4O7 NPs (75, 100, 125, 150, and 200 μg/mL). The absorbance increases linearly with time for all concentrations, with higher concentrations showing steeper slopes.

Panel d: A linear plot of enzyme units vs Tb4O7 NPs mass (mg). The specific activity (SA) is calculated as 0.016 U/mg.

Panel e: A Michaelis-Menten kinetics plot showing the initial velocity (V) in 10^-8 M s^-1 vs TMB concentration (mM). The curve shows typical enzyme kinetics behavior, approaching saturation at higher substrate concentrations.

Panel f: A Lineweaver-Burk plot (double reciprocal plot) of 1/V (10^8 sM^-1) vs 1/TMB concentration (mM^-1). This linear transformation of the Michaelis-Menten equation allows for the determination of kinetic parameters.

These results collectively demonstrate and characterize the oxidase-like activity of Tb4O7 NPs, showing their ability to catalyze the oxidation of various substrates and providing kinetic data for the reaction with TMB.