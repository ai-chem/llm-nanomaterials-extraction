The image contains two graphs labeled as "a" and "b", both related to the effects of Tb4O7 nanoparticles (NPs) on biological systems.

Graph a:
Title: The hemolysis ratio of red blood cells
X-axis: Concentration (μg/mL), ranging from 0 to 200 μg/mL, with an additional point for H2O
Y-axis: Hemolysis ratio (%), ranging from 0 to 100%

The graph shows very low hemolysis ratios (close to 0%) for concentrations of 0, 25, 50, 100, and 200 μg/mL of Tb4O7 NPs. There is a sharp increase in hemolysis ratio to about 90% for the H2O sample.

An inset image shows 6 tubes containing red blood cell solutions:
Tube 1: PBS buffer
Tubes 2-5: 25, 50, 100, and 200 μg/mL Tb4O7 NPs
Tube 6: Ultrapure water

The tubes visually confirm the graph data, showing minimal hemolysis in tubes 1-5 and complete hemolysis in tube 6.

Graph b:
Title: MTT assays determined cell viability of HUVECs after Tb4O7 NPs treatment
X-axis: Concentration (μg/mL), ranging from 0 to 100 μg/mL
Y-axis: Cell viability (%), ranging from 0 to 100%

The graph shows a slight decrease in cell viability as the concentration of Tb4O7 NPs increases:
0 μg/mL: ~100% viability
25 μg/mL: ~97% viability
50 μg/mL: ~93% viability
75 μg/mL: ~87% viability
100 μg/mL: ~83% viability

Error bars are included for each data point.

Caption: Fig. 6 a The hemolysis ratio of red blood cells. The insert images of tubes containing red blood cells solution show the direct observation of hemolysis. Tube 1: PBS buffer; Tube 2–5: 25, 50, 100, and 200 μg/mL Tb4O7 NPs; Tube 6: ultrapure water. b MTT assays determined cell viability of HUVECs after Tb4O7 NPs treatment

This image demonstrates the biocompatibility of Tb4O7 NPs by showing their minimal effect on red blood cell hemolysis and HUVEC cell viability at various concentrations.