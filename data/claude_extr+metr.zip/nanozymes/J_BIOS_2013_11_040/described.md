<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or decorative illustration rather than a scientific diagram or chemical structure. It depicts a stylized tree with a man standing beneath it, which is a common motif used in academic or publishing logos. The word "ELSEVIER" is prominently displayed below the illustration, indicating this is likely the logo for Elsevier, a well-known academic publishing company. As this image does not contain scientific data, chemical structures, or other content relevant to applied chemistry or scientific analysis, it falls under the category of an abstract or decorative image in this context.</DESCRIPTION_FROM_IMAGE>

Contents lists available at [ScienceDirect](www.sciencedirect.com/science/journal/09565663)

# Biosensors and Bioelectronics

journal homepage: <www.elsevier.com/locate/bios>

<DESCRIPTION_FROM_IMAGE>This image appears to be the cover or title page of a scientific journal called "Biosensors & Bioelectronics". The journal's title is prominently displayed in green text against a white background. 

Below the title, there is a stylized graphical element that resembles a simplified molecular or electronic structure. This symbol consists of two triangular shapes pointing towards each other, connected by a horizontal line in the middle. This abstract design likely represents the interdisciplinary nature of the journal, combining concepts from biology (biosensors) and electronics.

The image also includes the publisher's logo "ELSEVIER" in the top left corner, indicating that this journal is published by Elsevier, a well-known academic publishing company.

This cover design succinctly conveys the journal's focus on the intersection of biological sensing mechanisms and electronic technologies, which is a key area in modern analytical chemistry and biomedical engineering.

While this image doesn't contain specific chemical structures, graphs, or scientific data to analyze in detail, it provides important context about the source and subject matter of the scientific content that would be found within this journal.</DESCRIPTION_FROM_IMAGE>

# Novel tungsten carbide nanorods: An intrinsic peroxidase mimetic with high activity and stability in aqueous and organic solvents

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo for CrossMark, which is not directly related to applied chemistry or scientific content. The logo consists of a stylized letter "i" inside a circle, with the text "CrossMark" to the right. As this is a logo rather than scientific content, I've labeled it as ABSTRACT_IMAGE per the instructions.</DESCRIPTION_FROM_IMAGE>

#### Nan Li a , Ya Yan a , Bao-Yu Xia a , Jing-Yuan Wang b , Xin Wang a,n

a School of Chemical and Biomedical Engineering, Nanyang Technological University, 62 Nanyang Drive, Singapore 637459, Singapore b Residues and Resource Reclamation Centre, Nanyang Technological University, 50 Nanyang Avenue, Singapore 639798, Singapore

# article info

Article history: Received 14 September 2013 Received in revised form 31 October 2013 Accepted 11 November 2013 Available online 26 November 2013

Keywords: Colorimetric sensor Nanomaterials-based artificial enzyme H2O2 detection Peroxidase-like activity Tungsten carbide nanorods

# abstract

Tungsten carbide nanorods (WC NRs) are demonstrated for the first time to possess intrinsic peroxidaselike activity towards typical peroxidase substrates, such as 3, 3', 5, 5'-tetramethylbenzidine (TMB) and ο-phenylenediamine (OPD) in the presence of hydrogen peroxide (H2O2). The reactions catalyzed by these nanorods follow the Michaelis–Menten kinetics. The excellent catalytic performance of WC NRs could be attributed to their intrinsic catalytic activity to efficiently accelerate the electron-transfer process and facilitate the decomposition of H2O2 to generate more numbers of reactive oxygen species (ROS). Based upon the strong peroxidase-like activity of these WC NRs, a colorimetric sensor for H2O2 is designed, which provides good response towards H2O2 concentration over a range of 2 107 – 8 105 M with a detection limit of 60 nM. Moreover, the peroxidase-like activities of WC NRs with TMB as the substrate are investigated in both protic and aprotic organic media, showing different colorimetric reactions from that performed in aqueous solutions. In comparison with the natural horse radish peroxidase, WC NR exhibits excellent robustness of catalytic activity and considerable reusability, thus making it a promising mimic of peroxidase catalysts.

& 2013 Elsevier B.V. All rights reserved.

#### 1. Introduction

Peroxidase activity is essential to many biochemical assays for their application in biomedicine or environmental monitoring. Currently, most of these assays use natural enzyme peroxidases, among which horse radish peroxidase (HRP) is popularly adopted. In spite of their high activity, the wide applications of enzyme peroxidases have been restricted by their limited natural sources, high production costs and low stability [(Wagner et al., 1995](#page-6-0)). Artificial enzyme mimic therefore attracts great attention in the past decades because of its applicability in a wide range of pH, temperature and chemical environment. The organometallic complexes including hemin, hematin and porphyrin have been utilized as peroxidase mimetic [(Johnstone et al., 1997](#page-6-0); [Wang et al., 2007](#page-6-0)) in the earlier research. Recently, nanomaterials that possess peroxidase activity have received a widespread interest due to their reliable reactivity, easier fabrication and storage than organic enzyme mimics. Numerous nanomaterials such as magnetic nanoparticles and nanocomposites ([Dai et al., 2009](#page-6-0); [Gao et al., 2007](#page-6-0); [Gao et al., 2013](#page-6-0); [Lee et al., 2013](#page-6-0); [Park et al., 2011](#page-6-0)), metals and alloys [(Bernsmann et al., 2011](#page-6-0); [Jv et al., 2010](#page-6-0); [Sun et al., 2013](#page-6-0); [Zhang et al., 2013;](#page-6-0) [Zhou et al., 2013)](#page-6-0), metal oxides and sulfides [(Asati et al., 2009;](#page-6-0) [Chen et al., 2012;](#page-6-0) [He et al., 2012;](#page-6-0) [Hong et al., 2013)](#page-6-0), carbon materials [(Li et al., 2013;](#page-6-0) [Shi et al., 2011;](#page-6-0) [Song et al., 2010;](#page-6-0) [Zheng et al., 2013)](#page-6-0) and others [(Lin et al., 2013;](#page-6-0) [Wang et al., 2013)](#page-6-0) are reported for their intrinsic peroxidase-like activities in bioassays. However, some concerns regarding to their robustness, large-scale feasibility and expensive cost still remain. Moreover, nanomaterialbased peroxidase mimics are expected to be more convenient and versatile than natural enzymes in non-aqueous applications. For example, when HRP is used to catalyze the polymerization of phenols or aniline, it requires a complicated and time-consuming process, such as chemical modification or supported immobilization of HRP [(Takahashi et al., 2001)](#page-6-0), in order to retain its enzyme activity in organic media. However, studies on the catalytic properties of peroxidase nanomimics in non-aqueous media are still scarce [(Andre et al., 2011)](#page-6-0). Thus, there is a big motivation to explore novel nanomaterials-based enzyme mimics to be used under unusual or challenging conditions.

Tungsten carbide (WC) as catalyst for electron-transfer reactions has been extensively investigated in various applications, such as, hydrogenolysis and isomerization reactions, fuel cells, hydrogen evolution and oxygen reduction [(Palanker et al., 1976;](#page-6-0) [Rosenbaum](#page-6-0) [et al., 2006)](#page-6-0), because it exhibits catalytic properties similar to those of noble metals [(Levy and Boudart, 1973)](#page-6-0). Based on the distinctive advantages, for example low cost, excellent corrosion resistance, high melting point and good electrical conductivity, WC materials have the potential for a large range of applications in biology [(Rosenbaum](#page-6-0)

n Corresponding author. Tel: þ65 6316 8866; fax: þ65 67947553. E-mail address: [WangXin@ntu.edu.sg (X. Wang).](mailto:WangXin@ntu.edu.sg)

<sup>0956-5663/\$ -</sup> see front matter & 2013 Elsevier B.V. All rights reserved. <http://dx.doi.org/10.1016/j.bios.2013.11.040>

[et al., 2006)](#page-6-0). To our knowledge, the investigation of WC materials as artificial enzyme mimics for bioassay has not been reported. Herein, we demonstrate for the first time that the intrinsic catalytic activity of WC nanorods (WC NRs) towards typical peroxidase substrate, such as 3, 3', 5, 5'-tetramethylbenzidine (TMB) and ο-phenylenediamine (OPD) in the presence of hydrogen peroxide (H2O2). A colorimetric method is developed for simple, fast and sensitive detection of H2O2 using WC NRs. The kinetic parameters of TMB oxidation catalyzed by WC NRs are obtained and compared with that of natural HRP. The possible mechanism for the intrinsic peroxidase-like properties of these WC NRs is proposed. Moreover, the catalytic behavior of WC NRs in various organic media is also studied. Possessing excellent catalytic activity, durable stability and good reusability, WC NRs would be a promising peroxidase mimic.

### 2. Material and methods

### 2.1. Materials

Sodium tungstate dihydrate (Na2WO4 2H2O), Ammonium sulfate (NH4SO4), glucose, TMB, OPD, Rhodaming B (RhB), Orange II, natural HRP (type ІІ, 150–250 units/mg), H2O2, Tungsten (IV) carbide and Sodium acetate anhydrous (NaAC) were purchased from Sigma-Aldrich (Singapore). Hydrochloric acid (HCl), acetic acid (HAC) and organic solvents (methanol, isopropanol and acetonitrile) were purchased from Merck (Singapore). Unless otherwise stated, all of the chemicals were used without further purification. Millipore Milli-Q water (18 MΩ cm1 ) was used in all experiments.

#### 2.2. Synthesis of WC NRs

The unique nanorod-structured WC materials are prepared as described elsewhere [(Yan et al., 2012)](#page-6-0). Briefly, Na2WO4 2H2O (0.6579 g) and (NH4)2SO4 (0.5286 g) were dissolved in 15 mL deionized water, then HCl aqueous solution (3 M) was added under stirring until pH value to 2.0. The solution was maintained in Teflon-lined stainless steel autoclave at 180 1С for 8 h. Then the precipitate was filtered, washed several times with water and ethanol and dried at 60 1С to obtain WO3 nanorods. The asprepared WO3 nanorods and glucose (molar ratio W/C¼0.078) were dissolved in 15 mL deionized water and stirred for 20 min before hydrothermal treatment at 180 1С for 8 h. Finally, the asprepared precursors of carbon-coated WO3 nanorods were calcined at 900 1С under a flow of H2/Ar (VH2/VAr¼1:3, 300 mL min1 ) for 3 h to form nanorod-structured WC materials. The as-prepared WC NRs were analyzed by field emission scanning electron microscopy (FESEM) and high-resolution transmission electron microscopy (HRTEM).

#### 2.3. Peroxidase-like activities of WC NRs

The measurements were conducted using a Shimadzu UV-2450 spectrophotometer by recording the adsorption spectra at 654 nm for 0.6 mM TMB or at 450 nm for 0.4 mM OPD in acetate buffer (500 μL, 50 mM, pH 4.0) containing WC NRs 0.02 mg mL1 and H2O2 (400 mM, 30% (v/v)). Color reactions were observed immediately after the substrates were added. The photographs and UV absorbance were recorded after the reaction for 20 min to reach the stable state. The control experiments were performed in the absence of substrates or WC NRs, or carried out by using commercially available WC particles. The catalytic oxidation of TMB by WC NRs in the presence of H2O2 was also determined under the conditions described before, except that instead of buffer, different organic solvents (acetonitrile, isopropanol and methanol) were selected to prepare all the solutions.

## 2.4. Colorimetric detection of H2O2 using WC NRs

The assay was started by the addition of different concentrations of H2O2 into 500 μL NaAC buffer solutions (50 mM, pH 4.0) in the presence of 0.02 mg mL1 WC NRs and 0.6 mM TMB. After the colorimetric reactions were completed, the WC NRs were removed from the reaction solution by centrifugation and the supernatant solution was used for the analysis at 654 nm. The final concentrations of H2O2 in the system varied from 0.1 μM to 1 mM.

#### 2.5. Kinetics measurements

Kinetics measurements were carried out at room temperature using 0.02 mg mL1 WC NRs in NaAC buffer solutions (500 mL, 50 mM, pH 4.0) by varying the concentration of TMB (0–0.8 mM) at a fixed concentration of H2O2 or vice versa by varying the concentration of H2O2 (0–600 mM). All the reactions were monitored in time-scan mode at 654 nm and the apparent kinetics parameters were determined by nonlinear fitting of the absorbance data to the Michaelie–Menten equation, ν¼Vmax[S]/ (Kmþ[S]), where ν is the initial reaction rate, Vmax is the maximal reaction rate, [S] is the substrate concentration and Km is the Michaelis–Menten constant [(Marquez and Dunford, 1997](#page-6-0)).

### 2.6. Robustness of peroxidase-like activity of WC NRs

WC NRs were incubated in buffers at various pH ranging from 2 to 10 for 4 h and at various temperatures ranging from 20 to 100 1С for 2 h, respectively. Then their catalytic activities were measured under standard experimental condition. For the durability test, WC NRs were incubated in acetate buffer (500 μL, 50 mM, pH 4.0) at room temperature for 24 h, and then their activities were measured under standard condition and compared with that of the freshly-prepared sample. The control experiments of pH value, temperature and time effects on the activity of HRP were performed under the same assay conditions as that for WC NRs, but using 10 ng mL1 HRP, 0.3 mM TMB and 1 mM H2O2.

### 2.7. WC NRs for peroxide-sensitive electrochemical assay

The peroxide-sensitive electrochemical assay using WC NRs was carried out using an Autolab Potentiostat (Eco Chemie, Netherland) in a three-electrode system in NaAC–HAC buffer (pH 4.0). An Ag/AgCl-saturated KCl electrode and a platinum wire served as the reference electrode and counter electrode, respectively. The working electrode was WC NRs modified glass carbon electrode, which was prepared as below. Briefly, a mixture containing the catalyst (2.0 mg), ethanol (2.5 mL), and Nafion solution (0.5 mL, 0.05 w%) was ultrasonicated for 15 min to obtain a well-dispersed ink. Then, a certain amount of such dispersion was transferred onto the surface of the electrode and a catalyst thin film containing WN NRs was obtained after the solvent slowly evaporated. The amperometric currents were recorded at the potential of 0.4 V by successive additions of 33 μM H2O2 in time intervals of 150 s.

#### 3. Results and discussion

#### 3.1. Characterization of WC NRs

WC NRs are synthesized by a template-free pseudomorphic transformation of chemically synthesized WO3 nanorod through a high-temperature method. As shown in [Fig. 1A](#page-2-0), the as-prepared WC nanoscrystals are generally rod-like in shape with an average diameter of 30–50 nm and length of 150–200 nm. The individual

<DESCRIPTION_FROM_IMAGE>The image consists of three panels labeled A, B, and C, each showing microscopic structures at different scales.

Panel A:
This panel shows a scanning electron microscope (SEM) image of nanostructures. The structures appear as elongated, rod-like formations with varying lengths and diameters. They are randomly oriented and intersecting. The scale bar indicates 100 nm, suggesting these are nanoscale structures, likely nanofibers or nanorods.

Panel B:
This panel presents a transmission electron microscope (TEM) image of a larger nanostructure. The structure has an irregular, branched shape resembling a flake or platelet. The main scale bar indicates 20 nm. An inset in the upper right corner shows a high-resolution TEM image of the crystal lattice, with a scale bar of 2 nm and a measurement of 0.28 nm, which likely corresponds to the lattice spacing.

Panel C:
This panel displays another SEM image, showing a collection of particles or agglomerates. The structures appear roughly spherical or polyhedral, with sizes varying but generally larger than those in panels A and B. The particles seem to be clustered together, forming a porous network. The scale bar indicates 500 nm, suggesting these are sub-micron particles.

These images collectively suggest a study of nanomaterials with different morphologies, possibly examining the synthesis or properties of nanofibers, nanoplatelets, and nanoparticles. The varying scales (100 nm, 20 nm, and 500 nm) provide a comprehensive view of the material's structure at different magnifications.</DESCRIPTION_FROM_IMAGE>

Fig. 1. (A) FESEM images and (B) TEM image of as-prepared WC NRs. Inset of image (B) HRTEM image of an individual nanorod with the lattice fringes of WC (001) plane. (C) SEM image of commercial WC materials.

<DESCRIPTION_FROM_IMAGE>This image is composed of four panels labeled A, B, C, and D, each depicting different aspects of an experiment involving WC NRs (likely tungsten carbide nanorods).

Panel A: 
This panel shows a before-and-after comparison of a reaction. The left image shows a clear solution, while the right image shows two vials labeled TMB and OPD. The TMB vial contains a blue solution, and the OPD vial contains a yellow solution. The reaction conditions are specified as WC NRs, H2O2, and pH 4.0.

Panel B:
This is a schematic diagram illustrating the reaction mechanism. It shows WC NRs in the center, with H2O2 and H2O on one side, and a substrate and oxidized substrate (labeled as Substrate_ox) on the other side. This suggests that the WC NRs are catalyzing the oxidation of the substrate using H2O2.

Panel C:
This panel shows UV-Vis absorption spectra for four different samples (a, b, c, d). The x-axis represents wavelength from 300 to 800 nm, and the y-axis represents absorbance in arbitrary units (a.u.) from 0 to 1.2. 

- Sample 'a' (red line) shows two prominent peaks: one around 370 nm and another around 650 nm.
- Sample 'b' (black line) shows a smaller peak around 370 nm and a very small peak around 650 nm.
- Samples 'c' and 'd' (purple and blue lines) show minimal absorption across the spectrum.

An inset image shows four vials corresponding to these samples, with 'a' being blue, 'b' being light blue, and 'c' and 'd' being clear.

Panel D:
This graph shows the change in absorbance at 654 nm over time for the same four samples (a, b, c, d). The x-axis represents time from 0 to 600 seconds, and the y-axis represents absorbance from 0 to 0.5.

- Sample 'a' (red squares) shows the highest increase in absorbance over time.
- Sample 'b' (black circles) shows a moderate increase.
- Samples 'c' and 'd' (blue triangles and purple triangles) show minimal change in absorbance over time.

This panel suggests a kinetic study of the reaction, likely monitoring the formation of the blue product observed in Panel A.</DESCRIPTION_FROM_IMAGE>

Fig. 2. The intrinsic peroxidase-like activity of WC NRs: (A) Photographs of oxidation reaction of TMB and OPD; (B) schematic illustration; (C) UV–vis absorption spectra and (D) time-dependent absorbance change at 654 nm in the different reaction systems: (a) WC NRsþTMBþH2O2; (b) commercial WCþTMBþH2O2; (c) TMBþH2O2; (d) WC NRsþTMB. (For interpretation of the references to color in this figure legend, the reader is referred to the web version of this article.)

nanorod is highly crystalline with lattice fringes of 0.28 nm (Fig. 1B), corresponding to (001) lattice plane of hexagonal WC. In contrast, the commercial WC is composed of crystals with fewmicron size, showing an agglomerated morphology (Fig. 1C).

#### 3.2. Peroxidase-like activity of WC NRs

In the presence of H2O2, WC NRs can quickly catalyze the oxidation of typical peroxidase substrates, TMB and OPD, producing a blue color for TMB and a yellow color for OPD, respectively (Fig. 2A). Even though the slow self-decomposition of H2O2 could cause the imperceptible oxidation of organic substrates, the addition of the as-prepared WC NRs effectively speeds up the reactions, dramatically increasing the sensitivity of the colorimetric reaction [(Fig. S1](#page-6-0) in the Supporting information). It is speculated that WC NRs as heterogeneous catalysts accelerate the electron-transfer process and facilitate the decomposition of H2O2 to generate more numbers of reactive oxygen species (ROS), such as hydroxyl radical (dOH). The schematic illustration of the colorimetric reaction is described in Fig. 2B and the possible mechanism will be discussed in detail later. With regard to the TMB oxidation catalyzed by WC NRs, the maximal absorbance is present at 654 nm (Fig. 2C), indicating the formation of TMB cation radicals by one-electron oxidation [(Josephy et al., 1982](#page-6-0)). Neither H2O2 nor WC NRs alone can efficiently oxidize TMB (Fig. 2C), suggesting that the interaction between WC NRs and H2O2/TMB is important for the catalytic reaction. For comparison purpose, the catalytic activity of commercial WC was also tested (as shown in Fig. 2C and D). The results suggest that the catalytic activities of WC NRs are much higher than that of commercial WC materials (inset of Fig. 2C). The time-dependent absorbance changes further indicate that the initial oxidation rate of TMB catalyzed by WC NRs is 4 times higher than that catalyzed by commercial WC (Fig. 2D). Similar results are observed for the case of OPD as the substrate (Fig. S2 in the Supporting information). These results highlight the importance of the nanostructure to the catalytic properties. Thus, the superior catalytic activity of WC NRs would be attributed to the smaller size and well-defined nanorod structure.

#### 3.3. Optimization of experimental conditions

The catalytic activity of WC NRs is dependent on pH, temperature, substrate concentration and catalyst concentration. Like HRP, the catalytic activity of WC NRs in acidic solution is much higher than that in neutral or basic solutions [(Fig. 3A](#page-3-0)), resulting from the acid-promoted colorimetric reaction of TMB [(Josephy et al., 1982)](#page-6-0). Unlike HRP, WC NRs still retain excellent peroxidase activity at high temperature [(Fig. 3B](#page-3-0)). In addition, WC NRs exhibit their peroxidase activity even in the presence of high H2O2 concentration [(Fig. 3C](#page-3-0)). It is well known that the activity of HRP is restricted

<DESCRIPTION_FROM_IMAGE>This image contains multiple graphs and diagrams comparing the relative activity of WC NRs (likely tungsten carbide nanorods) and HRP (likely horseradish peroxidase) under various conditions. I'll describe each subplot in detail:

A) pH dependence of relative activity:
- X-axis: pH from 2 to 10
- Y-axis: Relative activity (%)
- WC NRs show peak activity around pH 6, reaching nearly 100%
- HRP shows peak activity around pH 5-6, also reaching nearly 100%
- Both enzymes show sharp decreases in activity below pH 4 and above pH 8

B) Temperature dependence of relative activity:
- X-axis: Temperature (°C) from 20 to 100
- Y-axis: Relative activity (%)
- WC NRs maintain high activity (80-100%) across the entire temperature range
- HRP shows peak activity around 40°C, then decreases sharply above 60°C, reaching near 0% at 100°C

C) H2O2 concentration dependence of relative activity:
- X-axis: [H2O2] (M) from 0 to 2.4
- Y-axis: Relative activity (%)
- WC NRs show increasing activity up to 0.6 M H2O2, then maintain high activity (80-100%)
- HRP shows a sharp peak in activity at very low H2O2 concentrations, then rapidly decreases

D) WC concentration dependence of relative activity:
- X-axis: [WC] (μg mL⁻¹) from 0 to 50
- Y-axis: Relative activity (%)
- Activity increases sharply up to 20 μg mL⁻¹, then plateaus at nearly 100%

E) pH stability of relative activity:
- X-axis: pH from 2 to 10
- Y-axis: Relative activity (%)
- WC NRs maintain high activity (80-100%) across the entire pH range
- HRP shows lower stability, with peak activity around pH 6-7

F) Temperature stability of relative activity:
- X-axis: Temperature (°C) from 0 to 100
- Y-axis: Relative activity (%)
- WC NRs maintain nearly 100% activity across the entire temperature range
- HRP maintains activity up to 40°C, then sharply decreases above 60°C

G) Bar graph and images comparing relative activity:
- Four conditions labeled a, b, c, d for both WC NRs and HRP
- WC NRs show high activity (near 100%) for all conditions
- HRP shows high activity for condition c, lower for others
- Inset images show blue color intensity corresponding to activity levels

H) Bar graph showing relative activity for 5 unnamed conditions:
- Y-axis: Relative activity (%)
- Five conditions numbered 1-5
- Activity decreases slightly from condition 1 to 5
- Error bars are included for each measurement

This comprehensive analysis demonstrates the superior stability and activity of WC NRs compared to HRP across various pH levels, temperatures, and H2O2 concentrations.</DESCRIPTION_FROM_IMAGE>

Fig. 3. (A) pH, (B) temperature, (C) H2O2 concentration and (D) WC NRs concentration effect on the peroxidase-like activity of WC NRs. Experiments were carried out using 20 μg mL1 WC NRs or 10 ng mL1 HRP in 0.5 mL in pH 4.0 buffer with 0.6 mM TMB as substrate, except the parameter investigated. The H2O2 concentration was 400 mM for WC NRs and 1 mM for HRP. (E) pH-dependent stability of WC NRs and HRP after incubation at pH 2–10 buffers for 4 h at room temperature; (F) Thermal-dependent stability of WC NRs and HRP after incubation at 4–100 1С for 2 h in pH 4.0 buffers; (G) Time-dependent stability of WC NRs and HRP before and after incubation for 24 h in pH 4.0 buffer at room temperature, (Inset of G) photographs of color evaluation: (a, b) WC NRs, (c, d) HRP. (H) Reutilization of WC NRs for TMB oxidation catalyzed by WC NRs. The maximum point in each curve is set as 100%. (For interpretation of the references to color in this figure legend, the reader is referred to the web version of this article.).

to a narrow range of pH, temperature and chemical environment. In contrast, the as-prepared WC NRs present a stable activity in these conditions that would probably make natural HRP denatured. The experiments were further conducted to obtain the optimal conditions for the maximum catalytic activity of the WC NRs: 20 μg mL1 WC NRs in pH 4.0 buffers containing 400 mM H2O2 and 600 μM TMB at 30 1С (Fig. 3D).

#### 3.4. Robustness and reusability of WC NRs

WC NRs possess superior catalytic activity and stability than HRP after the incubation in a wide range of pH (2–10) and temperature (4–100 1С) (Fig. 3E and F). After such incubation, the activity of HRP decreases dramatically due to the possible denature caused by external environment changes. Benefiting

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled A, B, C, and D, each representing different aspects of a chemical reaction involving TMB (3,3',5,5'-tetramethylbenzidine) and hydrogen peroxide (H2O2). Here's a detailed description of each graph:

A. Reaction rate (v) vs TMB concentration:
- X-axis: [TMB] (mM), ranging from 0 to 0.8 mM
- Y-axis: v (10^-8 M s^-1), ranging from 0 to 6
- The graph shows a typical enzyme kinetics curve, with the reaction rate increasing rapidly at low TMB concentrations and then leveling off at higher concentrations, indicating saturation.

B. Reaction rate (v) vs H2O2 concentration:
- X-axis: [H2O2] (mM), ranging from 0 to 800 mM
- Y-axis: v (10^-8 M s^-1), ranging from 0 to 8
- Similar to graph A, this shows enzyme kinetics behavior with respect to H2O2 concentration, with saturation occurring at higher concentrations.

C. Double reciprocal plot (Lineweaver-Burk plot) for TMB:
- X-axis: 1/[TMB] (mM^-1), ranging from 0 to 14
- Y-axis: 1/v (s), ranging from 0.1 to 0.6
- Three linear plots are shown for different H2O2 concentrations:
  1. 35 mM H2O2
  2. 70 mM H2O2
  3. 152 mM H2O2
- The lines intersect at a point to the left of the y-axis, suggesting mixed inhibition.

D. Double reciprocal plot (Lineweaver-Burk plot) for H2O2:
- X-axis: 1/[H2O2] (M^-1), ranging from 0 to 20
- Y-axis: 1/v (s), ranging from 0.1 to 0.5
- Three linear plots are shown for different TMB concentrations:
  1. 200 μM TMB
  2. 320 μM TMB
  3. 480 μM TMB
- The lines intersect at a point to the left of the y-axis, also suggesting mixed inhibition.

These graphs collectively provide information about the enzyme kinetics of the reaction, including the effects of substrate concentration on reaction rate and the type of inhibition occurring in the system.</DESCRIPTION_FROM_IMAGE>

Fig. 4. Steady-state kinetic assay and catalytic mechanism of WC NRs: (A) The concentration of H2O2 is 0.4 M and the TMB concentration is varied; (B) The concentration of TMB is 0.6 M and the H2O2 is varied; (C, D) Double reciprocal plots of activity of WC NRs with the concentration of one substrate (TMB or H2O2) fixed and the other varied. The error bars represent the standard error derived from three measurements.The relative standard deviations (RSD) for (A) and (B) are 0.979 and 0.983, respectively. And RSD for fitting curves (from top to bottom) in (C) and (D) are 0.989, 0.978, 0.967; and 0.979, 0.991, 0.987, respectively.

from their good corrosive resistance [(Nikolova et al., 1984](#page-6-0)), WC NRs is more stable than other peroxidase nanomimics, such as metal oxide/sulfide, which tend to suffer from "metal ion-leaching" at low pH solution. Moreover, more than 90% of catalytic activity of the WC NRs can be retained after the incubation in acid buffers at 100 1С for 2 h, suggesting a reliable thermal-tolerance compared with HRP and other reported peroxidase nano-mimics [(Table S1](#page-6-0) in the Supporting information). Also, a negligible change on colorimetric results is observed for WC NPs before and after the incubation in pH 4.0 buffer up to 24 h, whereas the activity of HRP almost disappears [(Fig. 3G](#page-3-0)). In terms of the reutilization of WC NRs, the results show that the catalytic activity of WC NRs undergoes a slight decrease after each cycle, yet it still retains 75% after 5 catalytic cycles ([Fig. 3H](#page-3-0)). These results provide strong evidence that WC NRs possess excellent robustness, stable activity and good reusability.

## 3.5. Kinetics parameters and H2O2 detection

To verify the peroxidase-like activity of WC NRs, the steadystate kinetic assays are carried out. The time-dependent UV absorption spectra indicate that the catalytic oxidation of TMB by WC NRs follow the Michaelis–Menten behavior [(Fig. S3](#page-6-0) in the Supporting information). In order to get a better insight into the substrate dependency, various UV absorption spectra are obtained by varying one substrate concentration and fixed the other. The slope of the plot is calculated as the initial reaction rate. By plotting the initial reaction rate against concentration, the typical Michaelis–Menten curves for TMB and H2O2 are obtained in Fig. 4A and B. The kinetic parameters are obtained from Lineweaver and Burk plots [(1934)](#page-6-0) and compared with that of natural HRP (Table 1). The value of Km indicates the affinity strength between the enzyme and the substrates [(Marquez and Dunford, 1997](#page-6-0)). WC

| Table 1                                                                     |  |  |
|-----------------------------------------------------------------------------|--|--|
| Michaelis constant (Km) and maximal reaction rate (Vmax) of WC NRs and HRP. |  |  |

| Catalyst               | Substrate | Km (mM) | Vmax (108 M s1<br>) |
|------------------------|-----------|---------|---------------------|
| WC NRs                 | TMB       | 0.274   | 6.81                |
| WC NRs                 | H2O2      | 119.6   | 7.16                |
| HRP (Gao et al., 2007) | TMB       | 0.434   | 10.00               |
| HRP (Gao et al., 2007) | H2O2      | 3.7     | 8.71                |

NRs has smaller Km value for TMB than that of HRP, indicating a higher affinity of TMB to WC NRs than to HRP. With H2O2 as the substrate, the Km value of WC NRs is significantly larger than that of HRP. It is consistent with the obtained results that a higher concentration of H2O2 is required for the maximal catalytic activity of WC NRs. The double reciprocal plots (Fig. 4C and D) are further obtained from the measurements of the WC NRs activity over a range of TMB and H2O2 concentrations, which indicates a characteristic Ping–Pong mechanism, as observed for HRP [(Rodriguez-Lopez](#page-6-0) [et al., 2001)](#page-6-0).

Based on the intrinsic peroxidase-like activity of WC NRs, a colorimetric method for H2O2 detection is successfully developed. The change of the maximal absorbance of TMB oxidation can be used for H2O2 detection. Under the optimum experimental conditions, the absorbance at 654 nm shows a linear increase with the H2O2 concentration from 2 107 to 8 105 M with a limit of detection (LOD) 60 nM, as shown in [Fig. 5A](#page-5-0). This provides a simple, low-cost and convenient colorimetric assay for H2O2 with high sensitivity ([Table S2](#page-6-0) in the Supporting information). In addition, the amperometric responses of a peroxide sensor are measured at a glassy carbon surface modified by WC NRs. A fast, sensitive and well-defined amperometric signal can be obtained by using the WC NRs-based peroxide sensor [(Fig. 5](#page-5-0)B).

#### <span id="page-5-0"></span>3.6. Peroxidase-like activity of WC NRs in organic solvents

Non-aqueous enzymology has provided an exciting tool for synthetic reaction [(Dordick, 1991)](#page-6-0). Thus, it is also attractive to study the peroxidase-like activities of WC NRs mimics in organic solvents (acetonitrile, isopropanol and methanol). None of the organic solvents leads to specific reaction between TMB and H2O2 in the absence of WC NRs, which further confirms that the catalytic activity is from WC NRs. More interesting observation is that in all the organic solvents investigated, the catalytic oxidation of TMB by WC NRs directly yield light yellow products with the maximal absorbance at 450 nm (Fig. 6A), which is different from the reaction performed in buffer solution. Moreover, the initial oxidation rate of TMB catalyzed by WC NRs shows 2-fold increase in acetonitrile than in protic organic solvent such as methanol and isopropanol (Fig. 6B). Similar results are also obtained for the catalytic oxidation of OPD in the same organic solvents [(Fig. S4](#page-6-0) in the Supporting information). This may be explained by the facilitated decomposition of H2O2 and the promoted stability of transition-metal complexes with reactive oxygen species in aprotic media [(Todres, 1985)](#page-6-0). As shown in Fig. 6C, it is speculated that, unlike in aqueous solution, it is difficult to retain the equilibrium between the free cation radical from one-electron oxidation of TMB and the charge transfer complex in the aprotic environment. Then, organic solvents may play an important role as an initiator to accelerate the direct two- electron catalytic oxidation of TMB, forming yellow diimine products [(Josephy et al., 1982)](#page-6-0).

# 3.7. Preliminary investigation for mechanism of WC NRs as peroxidase mimic

It has been reported that the generation of short-lived dOH radicals could be enhanced by WC particles in phosphoric buffer

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled A and B.

Graph A:
This is a calibration curve showing the relationship between absorbance (y-axis) and hydrogen peroxide concentration (x-axis). The x-axis is labeled "[H2O2] (μM)" ranging from 0 to 80 μM. The y-axis is labeled "Absorbance (a.u.)" ranging from 0 to 0.2. The graph shows a linear relationship with data points and error bars. The linear equation is given as Y = 0.024X + 0.0142, with a correlation coefficient R = 0.997, indicating a strong linear relationship.

Graph B:
This graph shows the change in current over time. The x-axis is labeled "Time (s)" ranging from 0 to 1600 seconds. The y-axis is labeled "Current (μA)" ranging from 0 to -10 μA. The graph shows a stepwise decrease in current over time, with each step showing some noise or fluctuation. There are two lines labeled 'a' and 'b'. Line 'a' remains constant at 0 μA throughout the time range, while line 'b' shows the stepwise decrease in current.

These graphs likely represent experimental data related to the detection or measurement of hydrogen peroxide, possibly using an electrochemical method. Graph A provides a calibration for H2O2 concentration based on absorbance, while Graph B might represent the amperometric response of a sensor to successive additions of H2O2 over time.</DESCRIPTION_FROM_IMAGE>

Fig. 5. (A) Linear calibration plot between the absorbance at 654 nm and the H2O2 concentration. The error bars represent the standard deviation of three measurements. (B) Amperometric response of (a) bare GCE and (b) WC NRs modified glass carbon electrode in NaAC–HAC buffer (pH 4.0) at applied potential of 0.4 V by successive additions of 33 μM H2O2 in the time intervals of 150 s.

<DESCRIPTION_FROM_IMAGE>The image contains three main sections labeled A, B, and C, describing various aspects of a chemical reaction involving tetramethylbenzidine (TMB).

A. UV-Vis absorption spectra and sample vials:
- Graph shows absorbance (a.u.) vs wavelength (nm) for three samples (a, b, c)
- Wavelength range: 300-600 nm
- Peak absorbance around 450 nm for all samples
- Inset image shows three vials (a, b, c) containing pale yellow solutions

B. Reaction scheme for TMB oxidation:
- Starting material: TMB (C18H24N2)
SMILES: Cc1cc(C)c(-c2cc(C)c(N)c(C)c2)cc1N
- λ = 285 nm
- Aqueous oxidation (-e-) produces cation radical
- Non-aqueous oxidation (-2e-) produces diimine
SMILES: Cc1cc(C)c(-c2cc(C)c(=[NH2+])c(C)c2)cc1=[NH2+]
- Diimine λmax = 450 nm
- Charge transfer complex formation (1:1 ratio of TMB and cation radical)
SMILES: Cc1cc(C)c(-c2cc(C)c(N)c(C)c2)cc1N.Cc1cc(C)c(-c2cc(C)c([NH3+])c(C)c2)cc1[NH3+]
- Charge transfer complex λmax = 370, 654 nm
- Two vials shown: blue solution (charge transfer complex) and yellow solution (diimine)

C. Kinetics graph:
- Plot of absorbance (450 nm) vs time (s)
- Three datasets (a, b, c) corresponding to samples in part A
- Time range: 0-300 seconds
- Absorbance range: 0-0.7
- All curves show increasing absorbance over time, with dataset 'a' having the steepest slope and highest final absorbance, followed by 'b', then 'c'

This image illustrates the oxidation of TMB, its spectroscopic properties, and reaction kinetics under different conditions.</DESCRIPTION_FROM_IMAGE>

Fig. 6. TMB oxidation catalyzed by WC NRs in organic solvents: (A) UV–vis adsorption spectra and (inset of A) the color evaluation; (B) Time-dependent absorbance change at 450 nm in different solvents: (a) acetonitrile, (b) isopropanol and (c) methanol. (C) Scheme of TMB oxidation mechanism in aqueous and organic solvents. (For interpretation of the references to color in this figure legend, the reader is referred to the web version of this article.).

<span id="page-6-0"></span>through the electron spin resonance (ESR) studies (Stefaniak et al., 2010). To assess this results, the cost-effective, simple spectrophotometric and fluorescence methods are used to evidence the dOH production. Since RhB and Orange II can be oxidized by dOH to yield photoinactive product (Yu et al., 2008), in the presence of H2O2, the fluorescence quenching of Rhodamine B (RhB) and a decreased absorbance of Orange II under the catalysis of WC NRs are clearly observed (Fig. S5 and S6 in the Supporting Information), which are consistent with the dOH production.

Unlike the redox-based mechanism of Fenton-type reaction for the previously reported peroxidase mimics composed of metal ion (Prousek, 2007), the promoted generation of radical by WC NRs could be explained by the surface catalysis mechanism, which depends upon both particle surface area and surface chemistry (Watanabe et al., 2009). It has demonstrated that the radical generation takes place on some sites of the WC surface activated by atmospheric oxygen (Stefaniak et al., 2010). Due to the large electronegativity of WC (Nwosu, 2012), the generated dOH could be stabilized on the WC NRs surface via partial electron exchange interaction (Harriman et al., 1988). Meanwhile, the protonated TMB molecules are easily absorbed on the WC NRs surface and donate partial long-pair electron transferring from its amino groups to the WC NRs, leading to an increase in electron density and mobility in WC NRs (Zhang et al., 2003). Thus, WC NRs could catalytically decompose H2O2 to generate dOH, which causes a quick oxidation of organic substrates by a nucleophilic attack and leads to an intense color reaction.

#### 4. Conclusion

In summary, it is found that WC NRs possess an intrinsic peroxidase-like activity in both aqueous and organic media. High affinity towards peroxidase substrates and a typical Michaelis– Menten kinetics are observed. Based on the peroxidase-like properties of these WC NRs, a novel method for H2O2 detection is proposed and it provides a simple, low-cost and convenient colorimetric assay for H2O2 with high sensitivity. Compared to natural enzyme HRP, WC NRs exhibit superior catalytic activity and good reutilization. With these advantages, WC NRs are promising as a peroxidase mimic for wide applications in biocatalysis, biosensors, and environmental monitoring.

#### Acknowledgments

We acknowledge financial support from the academic research fund AcRF tier 1 (M4011020 RG8/12) Ministry of Education, Singapore and competitive research program (2009 NRF-CRP 001-032), National Research Foundation, Singapore. The support by the Singapore National Research Foundation under its Campus for Research Excellence And Technological Enterprise (CREATE) programme is also acknowledged.

#### Appendix A. Supporting information

Supplementary data associated with this article can be found in the online version at <http://dx.doi.org/10.1016/j.bios.2013.11.040>.

#### References

- [Andre, R., Natalio, F., Humanes, M., Leppin, J., Heinze, K., Wever, R., Schroder, H.C.,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref1) [Muller, W.E.G., Tremel, W., 2011. Adv. Funct. Mater. 21, 501](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref1)–509.
- [Asati, A., Santra, S., Kaittanis, C., Nath, S., Perez, J.M., 2009. Angew. Chem.-Int. Ed.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref2) [48, 2308](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref2)–2312.
- [Bernsmann, F., Ball, V., Addiego, F., Ponche, A., Michel, M., Gracio, J.J.D., Toniazzo, V.,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref3) [Ruch, D., 2011. Langmuir 27, 2819](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref3)–2825.
- [Chen, Z.W., Yin, J.J., Zhou, Y.T., Zhang, Y., Song, L., Song, M.J., Hu, S.L., Gu, N., 2012.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref4) [Acs Nano 6, 4001](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref4)–4012.
- [Dai, Z.H., Liu, S.H., Bao, J.C., Jui, H.X., 2009. Chem.-a Eur. J. 15, 4321](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref5)–4326.
- [Dordick, J.S., 1991. Curr. Opin. Biotechnol. 2, 401](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref6)–407.
- [Gao, L.Z., Zhuang, J., Nie, L., Zhang, J.B., Zhang, Y., Gu, N., Wang, T.H., Feng, J., Yang, D.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref7) [L., Perrett, S., Yan, X., 2007. Nat. Nanotechnol. 2, 577](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref7)–583.
- [Gao, Z.Q., Xu, M.D., Hou, L., Chen, G.N., Tang, D.P., 2013. Anal. Chem. 85, 6945](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref8)–6952. [Harriman, A., Millward, G.R., Neta, P., Richoux, M.C., Thomas, J.M., 1988. J. Phys.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref9) [Chem. 92, 1286](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref9)–1290.
- [He, W.W., Jia, H.M., Li, X.X., Lei, Y., Li, J., Zhao, H.X., Mi, L.W., Zhang, L.Z., Zheng, Z.,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref10) [2012. Nanoscale 4, 3501](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref10)–3506.
- [Hong, L., Liu, A.L., Li, G.W., Chen, W., Lin, X.H., 2013. Biosens. Bioelectron. 43, 1](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref11)–5.
- [Johnstone, R.A.W., Simpson, A.J., Stocks, P.A., 1997. Chem. Commun., 22772278.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref12)
- [Josephy, P.D., Eling, T., Mason, R.P., 1982. J. Biol. Chem. 257, 3669](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref13)–3675.
- [Jv, Y., Li, B.X., Cao, R., 2010. Chem. Commun. 46, 8017](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref14)–8019.
- [Lee, Y.C., Kim, M.I., Woo, M.A., Park, H.G., Han, J.I., 2013. Biosens. Bioelectron. 42,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref15) 373–[378.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref15)
- [Levy, R.B., Boudart, M., 1973. Science 181, 547](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref16)–549.
- [Li, R.M., Zhen, M.M., Guan, M.R., Chen, D.Q., Zhang, G.Q., Ge, J.C., Gong, P., Wang,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref17) [C.R., Shu, C.Y., 2013. Biosens. Bioelectron. 47, 502](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref17)–507.
- [Lin, Y.H., Zhao, A.D., Tao, Y., Ren, J.S., Qu, X.G., 2013. J. Am. Chem. Soc. 135,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref18) 4207–[4210.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref18)
- [Lineweaver, H., Burk, D., 1934. J. Am. Chem. Soc. 56, 658](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref19)–666.
- [Marquez, L.A., Dunford, H.B., 1997. Biochemistry 36, 9349](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref20)–9355.
- [Nikolova, V., Nikolov, I., Vitanov, T., Yotova, L., 1984. J. Power Sources 12, 1](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref21)–8.
- [Nwosu, C., 2012. J. Technical Sci. Technol. 1, 25](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref22)–28.
- [Palanker, V.S., Sokolsky, D.V., Mazulevsky, E.A., Baybatyrov, E.N., 1976. J. Power](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref23) [Sources 1, 169](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref23)–176.
- [Park, K.S., Kim, M.I., Cho, D.Y., Park, H.G., 2011. Small 7, 1521](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref24)–1525.
- [Prousek, J., 2007. Pure Appl. Chem. 79, 2325](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref25)–2338.
- [Rodriguez-Lopez, J.N., Lowe, D.J., Hernandez-Ruiz, J., Hiner, A.N.P., Garcia-Canovas,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref26) [F., Thorneley, R.N.F., 2001. J. Am. Chem. Soc. 123, 11838](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref26)–11847.
- [Rosenbaum, M., Zhao, F., Schroder, U., Scholz, F., 2006. Angew. Chem.-Int. Ed. 45,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref27) 6658–[6661.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref27)
- [Shi, W.B., Wang, Q.L., Long, Y.J., Cheng, Z.L., Chen, S.H., Zheng, H.Z., Huang, Y.M.,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref28) [2011. Chem. Commun. 47, 6695](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref28)–6697.
- [Song, Y., Qu, K., Zhao, C., Ren, J., Qu, X., 2010. Adv. Mater. 22, 2206](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref29)–2210.
- [Stefaniak, A.B., Harvey, C.J., Bukowski, V.C., Leonard, S.S., 2010. J. Occup. Environ.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref30) [Hyg. 7, 23](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref30)–34.
- [Sun, X.L., Guo, S.J., Chung, C.S., Zhu, W.L., Sun, S.H., 2013. Adv. Mater. 25, 132](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref31)–136. [Takahashi, H., Li, B., Sasaki, T., Miyazaki, C., Kajino, T., Inagaki, S., 2001. Microporous](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref32)
- [Mesoporous Mater. 44, 755](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref32)–762.
- [Todres, Z.V., 1985. Tetrahedron 41, 2771](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref33)–2823.
- [Wagner, J., Lerner, R.A., Barbas, C.F., 1995. Science 270, 1797](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref34)–1800.
- [Wang, H.W., Jiang, W.W., Wang, Y.W., Liu, X.L., Yao, J.L., Yuan, L., Wu, Z.Q., Li, D.,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref35) [Song, B., Chen, H., 2013. Langmuir 29, 3](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref35)–7.
- [Wang, Q.G., Yang, Z.M., Zhang, X.Q., Xiao, X.D., Chang, C.K., Xu, B., 2007. Angew.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref36) [Chem.-Int. Ed. 46, 4285](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref36)–4289.
- [Watanabe, A., Kajita, M., Kim, J., Kanayama, A., Takahashi, K., Mashino, T., Miyamoto,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref37) [Y., 2009. Nanotechnology, 20.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref37)
- [Yan, Y., Zhang, L., Qi, X.Y., Song, H., Wang, J.Y., Zhang, H., Wang, X., 2012. Small 8,](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref38) 3350–[3356.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref38)
- [Yu, F., Xu, D., Lei, R., Li, N., Li, K., 2008. J. Agric. Food Chem. 56, 730](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref39)–735.
- [Zhang, Y.F., Xu, C.L., Li, B.X., Li, Y.B., 2013. Biosens. Bioelectron. 43, 205](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref40)–210.
- [Zhang, Z.Y., Berg, A., Levanon, H., Fessenden, R.W., Meisel, D., 2003. J. Am. Chem.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref41) [Soc. 125, 7959](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref41)–7963.
- [Zheng, A.X., Cong, Z.X., Wang, J.R., Li, J., Yang, H.H., Chen, G.N., 2013. Biosens.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref42) [Bioelectron. 49, 519](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref42)–524.
- [Zhou, Y.T., He, W.W., Wamer, W.G., Hu, X.N., Wu, X.C., Lo, Y.M., Yin, J.J., 2013.](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref43) [Nanoscale 5, 1583](http://refhub.elsevier.com/S0956-5663(13)00826-9/sbref43)–1591.