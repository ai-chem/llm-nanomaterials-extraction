## Nanoparticles DOI: 10.1002/anie.200805279

## Oxidase-Like Activity of Polymer-Coated Cerium Oxide Nanoparticles**

Atul Asati, Santimukul Santra, Charalambos Kaittanis, Sudip Nath, and J. Manuel Perez*

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a chemical sensing system. At the center is a circular object, likely representing a sensor or detection unit. Surrounding this central unit are six circular nodes, each containing a chemical structure.

The chemical structures in the nodes are as follows:

1. 4,4'-diamino-3,3',5,5'-tetramethylbiphenyl
SMILES: CC1=C(C)C(N)=C(C2=CC(C)=C(N)C(C)=C2)C=C1

2. 4,4'-diamino-3,3',5,5'-tetramethylbiphenyl (identical to the first structure)
SMILES: CC1=C(C)C(N)=C(C2=CC(C)=C(N)C(C)=C2)C=C1

3. Bis(2-thioxo-1,3-dithiole-4,5-dithiolato)nickel(III) complex
SMILES: [S-]C1=C2SC(=S)SC2=C([S-])S1.[S-]C1=C2SC(=S)SC2=C([S-])S1.[Ni+3]

4. Bis(2-thioxo-1,3-dithiole-4,5-dithiolato)nickel(II) complex
SMILES: [S-]C1=C2SC(=S)SC2=C([S-])S1.[S-]C1=C2SC(=S)SC2=C([S-])S1.[Ni+2]

5. Dopamine
SMILES: C1=CC(=C(C=C1CCN)O)O

6. 5,6-indolinedione
SMILES: O=C1C2=CC=CC=C2NC1=O

Below the central unit is a representation of a detection surface, shown as a grid with multiple colored dots, suggesting a multi-analyte detection array.

The arrangement of the chemical structures around the central unit, connected by arrows, implies that these compounds are involved in the sensing mechanism, possibly as analytes or sensing elements.

At the bottom of the image is the logo for "Angewandte Chemie," indicating that this figure is likely from a publication in that journal.

This schematic represents a chemical sensing system, possibly based on differential responses to various analytes, using a combination of organic compounds and metal complexes as sensing elements.</DESCRIPTION_FROM_IMAGE>

2308 -

2009 Wiley-VCH Verlag GmbH & Co. KGaA, Weinheim Angew. Chem. Int. Ed. 2009, 48, 2308 –2312

Unique catalytic activities have been reported for nanoscale materials in recent years.[1] These size-dependent properties, which are often absent in the bulk materials, are the basis for the design of novel catalysts with multiple applications in energy storage, chemical synthesis, and biomedical applications.[2, 3] Cerium oxide has been extensively used in catalytic converters for automobile exhaust systems, as an ultraviolet absorber, and as an electrolyte for fuel cells.[4–7] Most recently, it has been found that cerium oxide nanoparticles (nanoceria) possess antioxidant activity at physiological pH values, and the potential use of these materials in biomedical applications, such as protection against radiation damage, oxidative stress, and inflammation, has been reported.[8–12] The ability of these nanoparticles to act as an antioxidant resides on their ability to reversibly switch from Ce3+ to Ce4+. [11] Furthermore, the synthesis of biocompatible dextran-coated nanoceria (DNC) and its enhanced stability in aqueous solution has been recently reported.[12]

Herein, we report that nanoceria has an intrinsic oxidaselike activity at acidic pH values, as it can quickly oxidize a series of organic substrates without any oxidizing agent (e.g. hydrogen peroxide). The observed activity is not only pHdependent but is also dependent on the size of the cerium oxide nanoparticles as well as the thickness of the polymer coating. On the basis of these findings, we have designed an immunoassay in which folate-conjugated cerium oxide nanoparticles provide dual functionality by binding to folateexpressing cancer cells and facilitating detection by catalytic oxidation of sensitive colorimetric substrates (dyes). The unique pH-dependent oxidase-like activity of cerium oxide nanoparticles in aqueous media makes them a powerful tool for a wide range of potential applications in biotechnology and environmental chemistry.

For our first set of experiments, we investigated if a DNC preparation[12] could facilitate the oxidation of a series of organic dyes at low pH values. In these experiments, we selected 3,3',5,5'-tetramethylbenzidine (TMB) and 2,2-azinobis(3-ethylbenzothizoline-6-sulfonic acid) (AzBTS), which upon oxidation develop either a blue (TMB) or green (AzBTS) color in aqueous solution.[13, 14] These dyes are typically used as horseradish peroxidase (HRP) substrates in various bioassays, and most recently they have been used to demonstrate the peroxidase-like activity of iron oxide nanoparticles.[15] However, in these peroxidase-catalyzed reactions, hydrogen peroxide (H2O2) is required as the electron acceptor or oxidizing agent. In contrast, we have found that DNC catalyzes the fast oxidation (within minutes) of both

[*] A. Asati, Dr. S. Santra, C. Kaittanis, Dr. S. Nath, Prof. J. M. Perez Nanoscience Technology Center, Department of Chemistry and Burnett College of Biomedical Sciences University of Central Florida 12424 Research Parkway, Suite 400, Orlando, FL 32826 (USA) Fax: (+1) 407-882-2843 E-mail: jmperez@mail.ucf.edu Homepage: http://www.nanoscience.ucf.edu/faculty/perez.php [**] The authors acknowledge funding by the National Institutes of

Health (CA101781) and an UCF-NSTC Start Up Fund, all to J.M.P.

Supporting information for this article is available on the WWW under [http://dx.doi.org/10.1002/anie.200805279.](http://dx.doi.org/10.1002/anie.200805279)

Angew. Chem. Int. Ed. 2009, 48, 2308 –2312 -

TMB and AzBTS in the absence of hydrogen peroxide, as judged by the appearance of the characteristic color upon addition of the dyes to citrate-buffered solutions (pH 4.0) of the nanoparticles and by the corresponding UV/Vis spectrum (Figure 1 a and Figure S1 in the Supporting Information).

<DESCRIPTION_FROM_IMAGE>This image consists of two parts, labeled a) and b).

a) This part shows four vials containing different solutions:
1. The leftmost vial contains a clear solution labeled "Cerium oxide NP" and "Citrate buffer pH 4.0".
2. The second vial from the left is labeled "TMB" and contains a blue-colored solution.
3. The third vial is labeled "AzBTS" and contains a green-colored solution.
4. The rightmost vial is labeled "DOPA" and contains a brown-colored solution.

All vials appear to contain the same cerium oxide nanoparticles (NP) in citrate buffer at pH 4.0, with different compounds added to each (TMB, AzBTS, and DOPA) resulting in different colorations.

b) This part shows a graph plotting Absorbance at 652 nm (y-axis) against Time in minutes (x-axis) for four different pH conditions:

1. pH 4.0: Shows the highest absorbance, rapidly increasing to about 0.5 within the first 2 minutes, then plateauing.
2. pH 5.0: Shows a lower maximum absorbance of about 0.3, reaching this level within 2 minutes and then plateauing.
3. pH 6.0: Similar to pH 5.0 but with a slightly lower maximum absorbance.
4. pH 7.0: Shows the lowest maximum absorbance of about 0.13, reaching this level quickly and then plateauing.

All curves show a rapid initial increase in absorbance followed by a plateau, with the maximum absorbance decreasing as pH increases from 4.0 to 7.0. This graph likely represents the kinetics of a reaction involving the cerium oxide nanoparticles and one of the compounds (possibly TMB) at different pH values, as measured by absorbance at 652 nm.</DESCRIPTION_FROM_IMAGE>

Figure 1. Formation of colored product owing to substrate oxidation is pH-dependent. a) Photographs show production of colored product upon addition of nanoceria to TMB, AzBTS, and DOPA at pH 4.0. b) Oxidation of TMB is pH-dependent, with the optimum activity at pH 4.0.

Meanwhile, at pH 7.0, no significant oxidation of TMB or AzBTS was observed, even in the presence of hydrogen peroxide or upon overnight incubation, as judged by the absence of color development upon addition of nanoceria at this pH value (Figure S2 in the Supporting Information). Furthermore, pH-dependent studies of the DNC-catalyzed oxidation of TMB show that as the pH value of the buffered solution increases from pH 4.0 to 7.0, the ability of DNC to oxidize the dye decreases (Figure 1 b). These results suggest that DNC behaves as an oxidation catalyst in a pH-dependent manner and performs optimally at acidic pH values.

To further verify the ability of nanoceria to behave as an oxidation nanocatalyst, we chose dopamine (DOPA), a catecholamine difficult to oxidize at low pH values.[16] Results showed that DNC facilitated the oxidation of DOPA in citrate buffer (pH 4.0) within minutes, producing the characteristic orange color corresponding to aminochrome, one of the major oxidation products of DOPA (Figure 1 a). The formation of aminochrome by DNC was confirmed by UV/Vis studies, which show the appearance of the characteristic band at 475 nm (Figure S3 in the Supporting Information). However, in the absence of DNC, no apparent oxidation of DOPA occurs at pH 4.0, even after days of incubation. This result is in contrast to that for DOPA solutions in water or citrate buffer pH 7.0, in which DOPA slowly autoxidizes, developing the characteristic reddish-brown color after overnight incu-

## Communications

bation. Taken together, our results demonstrate that DNC is able to catalyze the oxidation of various organic molecules at acidic pH values.

It has been well established that the catalytic properties of nanomaterials often depend upon the size of the nanocrystal.[17] However, studies on the effect of the thickness of a polymer coating surrounding the nanoparticles are less common. This motivated us to study whether the nanoceriacatalyzed oxidation of these dyes is also dependent on nanoparticle size and on the thickness of the polymer coating. Our previously reported dextran-coated nanoceria (DNC) preparation was synthesized by an in situ procedure,[12] in which the dextran (10 kDa) is present in solution at the time of the initial formation of the cerium oxide nanocrystals. Under these conditions, the polymer influences both the nucleation and the growth of the initial nanocrystal, resulting in nanoparticles with a small nanocrystal core surrounded by a thin polymeric coating. In the case of DNC, we have obtained nanoparticles with a cerium oxide core of 4 nm surrounded by a thin coating of dextran for a total nanoparticle size (hydrodynamic diameter) of 14 nm. Meanwhile, a stepwise procedure in which the polymer is added at a specific time after initial formation of the nanocrystals can be adopted for the synthesis of nanoceria. This method has been reported for the synthesis of polymer-coated iron oxide nanoparticles and yielded nanoparticles with a thicker polymer coating than those from the in situ process.[18] Furthermore, slightly larger nanocrystal cores are also obtained using this method. Therefore, to study the effect of the polymeric coating thickness on the catalytic activity of nanoceria, we synthesized DNC nanoparticles using a stepwise method. In this method, the dextran polymer was added 60 seconds after initial formation of the nanocrystals, to yield a stepwise DNC (swDNC) nanoparticle preparation with an average hydrodynamic diameter of 100 nm, approximately ten times bigger than the DNC nanoparticles obtained with the in situ method (isDNC). Moreover, another set of polymer-coated ceria nanoparticles was synthesized using poly(acrylic acid) (1.8 kDa). The use of a polymer with a smaller molecular weight in the synthesis of polymer-coated nanoceria is advantageous, because it allows the formation of nanoparticles with an even thinner coating than those obtained with dextran (10 kDa) using either the in situ or the stepwise method. Dynamic light scattering experiments show that for the in situ nanoceria preparations coated with poly(acrylic acid) (isPNC), the average hydrodynamic diameter of the nanoparticles was 5 nm; whereas for the stepwise preparation (swPNC), a value of 12 nm was obtained (Figure S4 in the Supporting Information). As expected, smaller nanoparticles with a thinner polymer coating were obtained using the 1.8 kDa poly(acrylic acid) polymer. The average zeta potential value (x) for the DNC preparation was (-0.78 0.4) mV, while for PNC x = (-27.8 2.4) mV.

Next, we used these preparations of nanoceria to perform various kinetic studies and to assess the effect of the coating thickness and nanoparticle size on the catalytic activity of nanoceria. Results show that nanocerias ability to oxidize TMB varies with nanoparticle size in the order isPNC (5 nm) > swPNC (12 nm) > isDNC (14 nm) > swDNC (100 nm). Interestingly, the nanoparticles with a thin poly- (acrylic acid) coating (isPNC) have a higher catalytic activity than those with a thicker dextran coating (swDNC; Figure 2).

<DESCRIPTION_FROM_IMAGE>The image presents a graph showing the relationship between absorbance at 652 nm and time in minutes for different nanoparticle samples. The x-axis represents time, ranging from 0 to 10 minutes, while the y-axis shows absorbance at 652 nm, ranging from 0 to 0.8.

Four different nanoparticle samples are plotted:

1. 5 nm (fsPNC): This sample shows the highest absorbance, reaching approximately 0.7 at 10 minutes. The curve rises steeply initially and then begins to plateau.

2. 12 nm (swPNC): This sample has the second-highest absorbance, reaching about 0.6 at 10 minutes. The curve shape is similar to the 5 nm sample but with slightly lower values.

3. 14 nm (fsDNC): This sample shows a lower absorbance than the previous two, reaching about 0.5 at 10 minutes. The curve follows a similar pattern of rapid initial increase followed by a plateau.

4. 100 nm (swDNC): This sample exhibits the lowest absorbance, reaching only about 0.25 at 10 minutes. The curve rises quickly in the first 2 minutes and then remains relatively constant.

All curves start at or near zero absorbance at 0 minutes and show a rapid increase in the first 2-4 minutes, followed by a more gradual increase or plateau. The graph demonstrates that smaller nanoparticles (5 nm and 12 nm) generally show higher absorbance values compared to larger nanoparticles (14 nm and 100 nm) over the 10-minute period.

This graph likely represents a kinetic study of nanoparticle formation or aggregation, with absorbance at 652 nm serving as an indicator of the process progression. The different sizes and types of nanoparticles (PNC and DNC) exhibit varying rates and extents of this process.</DESCRIPTION_FROM_IMAGE>

Figure 2. Nanoceria-promoted oxidation of TMB is size-dependent. At pH 4.0, smaller ceria nanoparticles show higher oxidase-like activity than larger nanoparticles.

This result might be attributed to the fact that nanoceria with a thin and permeable poly(acrylic acid) coating can facilitate the transfer of molecules to and from the nanoceria core surface faster than a thicker coating. Similar experiments were performed with AzBTS, which shows similar behavior to TMB (Figure S5 in the Supporting Information).

Next, we determined the steady-state kinetic parameters for the nanoceria-catalyzed oxidation of TMB. Typical Michaelis–Menten curves were obtained for both PNC and DNC (Figures S6 and S7 in the Supporting Information). Results show that as the hydrodynamic diameter of the nanoparticles increases, lower values for the Michaelis constant Km and reaction rate Vmax are obtained (Table 1). Similar

Table 1: Comparison of nanoceria's size-dependent kinetic parameters.[a]

| Nanoceria | Size [nm] | Km [mm] | Vmax [mms<br>1<br>] |
|-----------|-----------|---------|---------------------|
| isPNC     | 5         | 3.8     | 0.7                 |
| swPNC     | 12        | 1.9     | 0.6                 |
| isDNC     | 14        | 1.8     | 0.5                 |
| swDNC     | 100       | 0.8     | 0.3                 |

[a] Data obtained at pH 4.0

results were observed with AzBTS. The fact that the nanoceria preparation with the smallest hydrodynamic diameter and thinnest coating (isPNC) displays the fastest kinetics (contrary to swDNC) suggests that the thickness of the polymer coating plays a key role in the rate of oxidation of the substrate. Furthermore, kinetic studies of nanoceria (isPNC) at various pH values indicate faster kinetics at acidic pH values (Km = 3.8, Vmax = 0.7) and much slower kinetics at neutral pH values (Km = 1.3, Vmax = 0.1; Table 2), as expected. These results contrast those obtained using the enzyme HRP or iron oxide nanoparticles, for which slower kinetics are reported even in the presence of hydrogen peroxide.[15]

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or masthead for a publication or organization called "Angewandte Chemie". It does not contain any scientific chemical structures, graphs, diagrams or other technical content relevant to applied chemistry, so I have classified it as an ABSTRACT_IMAGE as per the instructions.</DESCRIPTION_FROM_IMAGE>

Table 2: Nanoceria's oxidase-like kinetics are pH-dependent.[a]

| pH  | Km [mm] | Vmax [mms<br>1<br>] |  |
|-----|---------|---------------------|--|
| 4.0 | 3.8     | 0.70                |  |
| 5.0 | 6.9     | 0.36                |  |
| 6.0 | 2.4     | 0.10                |  |
| 7.0 | 1.3     | 0.10                |  |

[a] Data obtained with isPNC.

The oxidase-like activity of ceria nanoparticles in slightly acidic aqueous solution makes them potentially useful as aqueous redox catalysts for the oxidation of water pollutants.[19] An immediate and equally important application of this technology is in the design of more robust and reliable TMB-based immunoassays using surface-modified nanoceria. In traditional ELISA, an HRP-labeled secondary antibody is utilized to assess the binding of a specific primary antibody to a particular target or surface receptor (Figure 3 a). This binding event is assessed by the ability of HRP to oxidize a chromogenic substrate such as TMB in the presence of hydrogen peroxide. In traditional ELISA, the high rate of negative results is mainly attributed to 1) the instability of the antibodies that, when denatured, do not bind effectively to their target, 2) the instability of HRP that, when denatured, loses its peroxidase activity, and 3) the instability of hydrogen peroxide which, upon prolonged storage, decomposes and losses its ability to oxidize the substrate TMB in the presence of HRP. We hypothesized that a nanoceria-based detection approach would be more robust than current HRP-based assays, as no enzyme or hydrogen peroxide would be needed for detection (Figure 3 b). The oxidase-like activity of the nanoceria, by itself, should facilitate the oxidation and corresponding color development. Using this assay, we can perform an immunoassay and identify the presence and

<DESCRIPTION_FROM_IMAGE>The image presents a comparison between two types of Sandwich ELISA (Enzyme-Linked Immunosorbent Assay) techniques: Traditional Sandwich ELISA (a) and Nanoceria Based-Sandwich ELISA (b).

a) Traditional Sandwich ELISA:
- Shows a solid surface with three antigen molecules attached.
- Primary antibodies are bound to the antigens.
- HRP (Horseradish Peroxidase) antibodies are attached to the primary antibodies.
- H2O2 (hydrogen peroxide) is shown interacting with the HRP.
- TMB (3,3',5,5'-Tetramethylbenzidine) molecules are depicted above, indicating the colorimetric substrate.

b) Nanoceria Based-Sandwich ELISA:
- Similar setup with antigens on a solid surface and primary antibodies.
- Instead of HRP antibodies, it shows nanoceria particles attached to the primary antibodies.
- The nanoceria particles are depicted as spherical structures.
- TMB molecules are shown above, similar to the traditional method.

The key difference is in the detection system:
- Traditional method uses HRP enzyme for catalysis.
- Nanoceria method uses cerium oxide nanoparticles.

At the bottom of the image, there's a legend showing:
- HRP Antibody structure
- Nanoceria particle structure, which is depicted as a larger sphere with smaller attached molecules.

The nanoceria particle is further detailed, showing:
- A central cerium (Ce) atom
- Surrounding folate molecules attached via triazole rings, represented by the SMILES notation: C1=NN=NN1

This image illustrates the evolution of ELISA techniques, moving from enzyme-based detection to nanoparticle-based detection, potentially offering improved sensitivity or other advantages in immunoassays.</DESCRIPTION_FROM_IMAGE>

Figure 3. Comparison of traditional ELISA (a) and nanoceria-based ELISA (b). In traditional ELISA, an HRP antibody is utilized as secondary antibody that, upon hydrogen peroxide treatment, facilitates the oxidation of TMB, resulting in color development. In nanoceriabased ELISA, the oxidase-like activity of nanoceria facilitates the direct oxidation of TMB without the need of HRP or hydrogen peroxide.

concentration of a target faster and cheaper than using traditional ELISA.

For this purpose, nanoceria coated with poly(acrylic acid) (isPNC) was conjugated to folic acid using click chemistry (Scheme S1 and Figure S8 in the Supporting Information).[20–22] Folic acid is the ligand for the folate receptor, which is overexpressed in many tumors and cancer cell lines.[23, 24] We hypothesized that a nanoceria conjugate with folic acid instead of an antifolate receptor antibody will make a more robust nanoprobe for our immunoassay. Experiments were performed using the lung cancer cell line (A-549), which overexpresses the folate receptor.[23, 24] In control experiments, cardiac myocytes (H9c2) that do not overexpress the folate receptor were used.[25] In our first set of experiments, either A-549 or H9c2 cells (6000 cells) were incubated with an increasing amount of folate–cerium oxide nanoparticles in a 96-well plate for three hours and subsequently incubated with TMB (0.04 mm) for 30 minutes; product formation was monitored at 652 nm using a microtiter plate reader. As expected, folate–nanoceria-dependent binding was observed for the lung carcinoma cell line (A-549) compared to cardiac myocytes (H9c2), as judged by an increase in absorbance at 652 nm with increasing amount of folate–nanoceria (Figure 4). In another set of experiments, an increasing number of folate-positive lung carcinoma cells (1500 to 6000 cells) were treated with a constant amount of folate–ceria (5.0 mm). Results show an increase in the formation of TMB oxidation product (652 nm absorbance) with increasing number of A549 cells (Figure 5). This result was expected, as an increasing number of A549 cells translates into an increasing number of surface folate receptors available for binding to the folate–ceria nanoparticles. These results demonstrate the utility of cerium oxide nanoparticles as a detection tool, which arises from their dual functionality.

> Nanoceria-based assays outperform traditional sandwich ELISA, which requires hydrogen peroxide and an additional step to introduce an antibody carrying horseradish peroxidase (HRP antibody) to allow detection.

> In conclusion, we report that ceria nanoparticles possess unique oxidase-like activity, as they can facilitate the fast oxidation of organic dyes and small molecules in slightly acidic conditions without the need of hydrogen peroxide. When compared to other systems that require peroxides or proteins (such as oxidases and peroxidases), our polymer-coated nanoceria is a more robust and water-soluble redox nanocatalyst, as it is not susceptible to denaturation or decomposition. Furthermore, conjugation with targeting ligands makes nanoceria an effective nanocatalyst and detection tool in immunoassays. Taken together, these results demonstrate that this unique aqueous oxidase-like activity of nanoceria can be used in a wide range of new potential applications in biotech-

Angew. Chem. Int. Ed. 2009, 48, 2308 –2312 -

## Communications

<DESCRIPTION_FROM_IMAGE>This image presents a bar graph comparing the absorbance of two different cell types - Lung carcinoma (A-549) and Cardiac myocytes (H9c2) - at varying concentrations of Folate-Cerium oxide.

The x-axis represents the concentration of Folate-Cerium oxide in μM, with five data points: 0.5, 1.0, 1.5, 2.5, and 5.0 μM.

The y-axis shows the absorbance, ranging from 0 to 0.25.

Two types of bars are used to represent the two cell types:
1. Grid-patterned bars for Lung carcinoma (A-549)
2. Diagonal-lined bars for Cardiac myocytes (H9c2)

The graph demonstrates the following trends:

1. Lung carcinoma (A-549):
   - Shows a clear dose-dependent increase in absorbance
   - Absorbance values (approximate):
     0.5 μM: 0.02
     1.0 μM: 0.02
     1.5 μM: 0.04
     2.5 μM: 0.12
     5.0 μM: 0.24

2. Cardiac myocytes (H9c2):
   - Shows minimal change in absorbance across all concentrations
   - Absorbance values (approximate):
     0.5 μM: 0.00
     1.0 μM: 0.01
     1.5 μM: 0.02
     2.5 μM: 0.02
     5.0 μM: 0.02

The graph includes error bars for each data point, indicating the variability or uncertainty in the measurements.

Key observations:
1. Lung carcinoma cells show a much higher sensitivity to increasing Folate-Cerium oxide concentrations compared to cardiac myocytes.
2. The difference in absorbance between the two cell types becomes more pronounced at higher concentrations of Folate-Cerium oxide.
3. Cardiac myocytes maintain a relatively constant, low absorbance across all concentrations tested.

This graph suggests a selective effect of Folate-Cerium oxide on lung carcinoma cells compared to cardiac myocytes, which could have implications for targeted cancer treatments or diagnostic applications.</DESCRIPTION_FROM_IMAGE>

Figure 4. Nanoceria-mediated ELISA detection of folate receptor expressing cells. Folate–nanoceria associating with A-549 cells, which overexpress the folate receptor, effectively oxidizes TMB.

<DESCRIPTION_FROM_IMAGE>The image presents a bar graph showing the relationship between the number of A549 cells and the absorbance of [Folate-Cerium oxide]/5.0 μM. The x-axis represents the number of A549 cells, ranging from 1.5×10³ to 6×10³ cells. The y-axis shows the absorbance values, ranging from 0 to 0.25.

The graph contains four bars, each corresponding to a different number of cells:

1. 1.5×10³ cells: Absorbance approximately 0.11
2. 3×10³ cells: Absorbance approximately 0.14
3. 4.5×10³ cells: Absorbance approximately 0.19
4. 6×10³ cells: Absorbance approximately 0.24

Each bar includes error bars, likely representing standard deviation or standard error.

The graph demonstrates a clear positive correlation between the number of A549 cells and the absorbance of [Folate-Cerium oxide]/5.0 μM. As the number of cells increases, the absorbance also increases in a roughly linear fashion.

This data suggests that the [Folate-Cerium oxide]/5.0 μM complex interacts with or is taken up by A549 cells in a concentration-dependent manner. The relationship could be useful for quantifying cell numbers or studying the interaction between the folate-cerium oxide complex and A549 cells.</DESCRIPTION_FROM_IMAGE>

Figure 5. Nanoceria-based immunoassay is sensitive to the number of folate-positive cells (folate-receptor-expressing cells A-549).

nology, environmental chemistry, and medicine.

Received: October 28, 2008 Published online: January 7, 2009

.Keywords: cerium · immunoassays · nanotechnology · oxidases · oxidation

- [1] D. Astruc, F. Lu, J. R. Aranzaes, [Angew. Chem.](http://dx.doi.org/10.1002/ange.200500766) 2005, 117, 8062; [Angew. Chem. Int. Ed.](http://dx.doi.org/10.1002/anie.200500766) 2005, 44, 7852.
- [2] F. Raimondi, G. G. Scherer, R. Kotz, A. Wokaun, [Angew. Chem.](http://dx.doi.org/10.1002/ange.200460466) 2005, 117[, 2228](http://dx.doi.org/10.1002/ange.200460466); [Angew. Chem. Int. Ed.](http://dx.doi.org/10.1002/anie.200460466) 2005, 44, 2190.
- [3] J. H. Choi, F. T. Nguyen, P. W. Barone, D. A. Heller, A. E. Moll, D. Patel, S. A. Boppart, M. S. Strano, [Nano Lett.](http://dx.doi.org/10.1021/nl062306v) 2007, 7, 861.
- [4] M. Chen, P. Z. Zhang, X. M. Zheng, [Catal. Today](http://dx.doi.org/10.1016/j.cattod.2004.06.032) 2004, 93–95, [671](http://dx.doi.org/10.1016/j.cattod.2004.06.032).
- [5] T. Masui, M. Yamamoto, T. Sakata, H. Mori, G. Adachi, [J. Mater.](http://dx.doi.org/10.1039/a906583k) [Chem.](http://dx.doi.org/10.1039/a906583k) 2000, 10, 353.
- [6] C. Laberty-Robert, J. W. Long, E. M. Lucas, K. A. Pettigrew, R. M. Stroud, M. S. Doescher, D. R. Rolison, [Chem. Mater.](http://dx.doi.org/10.1021/cm051385t) 2006, 18[, 50](http://dx.doi.org/10.1021/cm051385t).
- [7] C. Laberty-Robert, J. W. Long, K. A. Pettigrew, R. M. Stroud, D. R. Rolison, [Adv. Mater.](http://dx.doi.org/10.1002/adma.200601840) 2007, 19, 1734.
- [8] R. W. Tarnuzzer, J. Colon, S. Patil, S. Seal, [Nano Lett.](http://dx.doi.org/10.1021/nl052024f) 2005, 5, [2573](http://dx.doi.org/10.1021/nl052024f).
- [9] J. P. Chen, S. Patil, S. Seal, J. F. McGinnis, [Nat. Nanotechnol.](http://dx.doi.org/10.1038/nnano.2006.91) 2006, 1[, 142](http://dx.doi.org/10.1038/nnano.2006.91).
- [10] J. Niu, A. Azfer, L. M. Rogers, X. Wang, P. E. Kolattukudy, [Cardiovasc. Res.](http://dx.doi.org/10.1016/j.cardiores.2006.11.031) 2007, 73, 549.
- [11] M. Das, S. Patil, N. Bhargava, J. F. Kang, L. M. Riedel, S. Seal, J. J. Hickman, [Biomaterials](http://dx.doi.org/10.1016/j.biomaterials.2006.11.036) 2007, 28, 1918.
- [12] J. M. Perez, A. Asati, S. Nath, C. Kaittanis, [Small](http://dx.doi.org/10.1002/smll.200700824) 2008, 4, 552.
- [13] P. D. Josephy, R. P. Mason, T. Eling, Cancer Res. 1982, 42, 2567.
- [14] C. Henriquez, C. Aliaga, E. Lissi, [Int. J. Chem. Kinet.](http://dx.doi.org/10.1002/kin.10094) 2002, 34, [659](http://dx.doi.org/10.1002/kin.10094).
- [15] L. Z. Gao, J. Zhuang, L. Nie, J. B. Zhang, Y. Zhang, N. Gu, T. H. Wang, J. Feng, D. L. Yang, S. Perrett, X. Yan, [Nat. Nanotechnol.](http://dx.doi.org/10.1038/nnano.2007.260) 2007, 2[, 577](http://dx.doi.org/10.1038/nnano.2007.260).
- [16] M. Bisaglia, S. Mammi, L. Bubacco, [J. Biol. Chem.](http://dx.doi.org/10.1074/jbc.M610893200) 2007, 282, [15597](http://dx.doi.org/10.1074/jbc.M610893200).
- [17] M. Shokouhimehr, Y. Piao, J. Kim, Y. Jang, T. Hyeon, [Angew.](http://dx.doi.org/10.1002/ange.200702386) [Chem.](http://dx.doi.org/10.1002/ange.200702386) 2007, 119, 7169; [Angew. Chem. Int. Ed.](http://dx.doi.org/10.1002/anie.200702386) 2007, 46, 7039.
- [18] H. Lee, E. Lee, D. K. Kim, N. K. Jang, Y. Y. Jeong, S. Jon, [J. Am.](http://dx.doi.org/10.1021/ja061529k) [Chem. Soc.](http://dx.doi.org/10.1021/ja061529k) 2006, 128, 7383.
- [19] B. Meunier, [Science](http://dx.doi.org/10.1126/science.1070976) 2002, 296, 270.
- [20] M. G. Finn, H. C. Kolb, V. V. Fokin, K. B. Sharpless, Prog. Chem. 2008, 20, 1.
- [21] H. C. Kolb, M. G. Finn, K. B. Sharpless, [Angew. Chem.](http://dx.doi.org/10.1002/1521-3757(20010601)113:11%3C2056::AID-ANGE2056%3E3.0.CO;2-W) 2001, 113, [2056](http://dx.doi.org/10.1002/1521-3757(20010601)113:11%3C2056::AID-ANGE2056%3E3.0.CO;2-W); [Angew. Chem. Int. Ed.](http://dx.doi.org/10.1002/1521-3773(20010601)40:11%3C2004::AID-ANIE2004%3E3.0.CO;2-5) 2001, 40, 2004.
- [22] M. A. White, J. A. Johnson, J. T. Koberstein, N. J. Turro, [J. Am.](http://dx.doi.org/10.1021/ja064041s) [Chem. Soc.](http://dx.doi.org/10.1021/ja064041s) 2006, 128, 11356.
- [23] H. Yuan, J. Miao, Y. Z. Du, J. You, F. Q. Hu, S. Zeng, [Int. J.](http://dx.doi.org/10.1016/j.ijpharm.2007.07.012) [Pharm.](http://dx.doi.org/10.1016/j.ijpharm.2007.07.012) 2008, 348, 137.
- [24] M. E. Nelson, N. A. Loktionova, A. E. Pegg, R. C. Moschel, [J.](http://dx.doi.org/10.1021/jm049758+) [Med. Chem.](http://dx.doi.org/10.1021/jm049758+) 2004, 47, 3887.
- [25] N. Parker, M. J. Turk, E. Westrick, J. D. Lewis, P. S. Low, C. P. Leamon, [Anal. Biochem.](http://dx.doi.org/10.1016/j.ab.2004.12.026) 2005, 338, 284.