<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Research Paper

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

2017; 7(8): 2277-2286. doi: 10.7150/thno.19257

# Boosting the Peroxidase-Like Activity of Nanostructured Nickel by Inducing Its 3+ Oxidation State in LaNiO3 Perovskite and Its Application for Biomedical Assays

Xiaoyu Wang1, Wen Cao1, Li Qin1, Tingsheng Lin2,Wei Chen2, Shichao Lin1,Jia Yao1,Xiaozhi Zhao2, Min Zhou1, Cheng Hang3, and Hui Wei1, 4

- 1. Department of Biomedical Engineering, College of Engineering and Applied Sciences, Collaborative Innovation Center of Chemistry for Life Sciences, Nanjing National Laboratory of Microstructures, Nanjing University, Nanjing, Jiangsu, 210093, China;
- 2. Department of Urology, Nanjing Drum Tower Hospital, the Affiliated Hospital of Nanjing University Medical School, Nanjing, Jiangsu, 210008, China;
- 3. State Key Laboratory of Coordination Chemistry, School of Chemistry and Chemical Engineering, Nanjing University, Nanjing 210093, China;

4. State Key Laboratory of Analytical Chemistry for Life Science, School of Chemistry and Chemical Engineering, Nanjing University, Nanjing 210093, China.

Corresponding author: weihui@nju.edu.cn; Fax: +86-25-83594648; Tel: +86-25-83593272; Web: http://weilab.nju.edu.cn.

© Ivyspring International Publisher. This is an open access article distributed under the terms of the Creative Commons Attribution (CC BY-NC) license (https://creativecommons.org/licenses/by-nc/4.0/). See http://ivyspring.com/terms for full terms and conditions.

Received: 2017.01.19; Accepted: 2017.03.22; Published: 2017.06.01

## **Abstract**

Catalytic nanomaterials with intrinsic enzyme-like activities, called nanozymes, have recently attracted significant research interest due to their unique advantages relative to natural enzymes and conventional artificial enzymes. Among the nanozymes developed, particular interests have been devoted to nanozymes with peroxidase mimicking activities because of their promising applications in biosensing, bioimaging, biomedicine, etc. Till now, lots of functional nanomaterials have been used to mimic peroxidase. However, few studies have focused on the Ni-based nanomaterials for peroxidase mimics. In this work, we obtained the porous LaNiO3 nanocubes with high peroxidase-like activity by inducing its 3+ oxidation state in LaNiO3 perovskite and optimizing the morphology of LaNiO3 perovskite. The peroxidase mimicking activity of the porous LaNiO3 nanocubes with Ni3+ was about 58~fold and 22~fold higher than that of NiO with Ni2+ and Ni nanoparticles with Ni0 . More, the porous LaNiO3 nanocubes exhibited about 2-fold higher activity when compared with LaNiO3 nanoparticles. Based on the superior peroxidase-like activity of porous LaNiO3 nanocubes, facile colorimetric assays for H2O2, glucose, and sarcosine detection were developed. Our present work not only demonstrates a useful strategy for modulating nanozymes' activities but also provides promising bioassays for clinical diagnostics.

Key words: nanozymes, peroxidase-like activity, LaNiO3 perovskite oxide, oxidation state, biomedical assays.

# **Introduction**

Natural enzymes, with remarkable catalytic efficiency and extraordinary substrate specificity, have attracted researchers' enormous interest due to their important roles not only in living systems but also in biomedical diagnostics and therapeutics.[1] However, the intrinsic shortcomings of natural enzymes such as high cost, low stability, and difficulty of recycling have impeded their practical applications. To address these drawbacks, great efforts have been devoted to searching for natural enzymes' alternatives called as "artificial enzymes".[2-5] Recently, nanomaterials with enzyme-like characteristics, called as "nanozymes", have been developed to act as promising artificial enzymes along with the remarkable achievements in the field of nanotechnology.[6-9] As a new type of artificial enzymes, nanozymes are advantageous over natural enzymes in several aspects such as low cost, long-term storage, and high stability. More, nanozymes are even superior to conventional artificial enzymes in their large surface area for bioconjugation, self-assembly capabilities, tunable catalytic activities, etc.[10-12] Therefore, intensive efforts have been devoted to developing functional nanomaterials for enzyme mimics in recent years.[13-27]

Among the nanozymes developed, particular interests have been focused on nanozymes with peroxidase mimicking activities due to their great promise in biomedical diagnosis, bioimaging, antibacterial agents, antibiofouling medical devices, etc.[28-38] Till now, lots of functional nanomaterials (e.g., carbon based, metal oxide based and metal based nanomaterials) have been explored to mimic peroxidase.[15, 17, 39-41] Among them, transition metal oxide nanomaterials had been extensively studied due to their excellent catalytic activities, high stability, low cost and ease of preparation.[6, 10, 11] For instance, Fe3O4 nanoparticles have been fabricated to mimic peroxidase for Ebola diagnosis and tumor immunostaining.[30, 42] Despite of these progresses, very little attention has been paid to developing Ni-based nanomaterials as peroxidase mimics. A recent study reported that NiO nanoparticles modified with H2TCPP had an intrinsic peroxidase mimicking activity. However, the catalytic activity may be mainly from the H2TCPP ligand rather than the NiO nanoparticle itself.[43] More, several seminal studies have demonstrated that the activities of nanozymes were strongly dependent on the size, composition, shape, surface ligand, and exposed facet of nanomaterials.[12, 44-49] Previous studies have also showed that the oxidation state was very important for cerium oxides' and iron oxides' enzyme mimicking activities.[50-53] However, very little information was available about the influence of nanostructured nickels' oxidation state on their enzyme mimicking activities. Such information, if available, would help to rationally design nanozymes with high enzyme mimicking activities (including peroxidase mimicking activities).

Here, we showed that high peroxidase mimicking activity of LaNiO3 perovskite could be achieved by inducing the 3+ oxidation state of nickel into the perovskite lattice. To find out the effect of nickel atom's oxidation state on the Ni-based nanomaterials' peroxidase mimicking activity, other Ni-based nanomaterials such as NiO and Ni nanoparticles with Ni2+ and Ni0 were also studied respectively. The peroxidase mimicking activity study revealed that the oxidation state of nickel in Ni-based nanomaterials was very important for the peroxidase mimicking activity and Ni3+ was superior to Ni0 and Ni2+ for the nanozymes' catalytic activities. Specifically, the peroxidase mimicking activity of the porous LaNiO3 was about 58~fold and 22~fold higher than that of NiO and Ni nanoparticles. More, the influence of LaNiO3 morphology on its peroxidase-like activity was also investigated. The result showed that the peroxidase-like activities of porous LaNiO3 nanocubes were about 2~fold higher than that of LaNiO3 nanoparticles. The latter were synthesized by a conventional sol-gel method. Finally, the porous LaNiO3 nanocubes with the highest peroxidase mimicking activity were employed to develop reliable diagnostic platforms for important biomolecular targets.

It has been established that bioactive small biomolecules, such as glucose and sarcosine, play critical roles in disease diagnosis.[54-58] For example, glucose is not only a well-known indicator for diabetes but also closely associated with ischemia stroke and even cancers.[59-65] Previous study also suggested that sarcosine may act as a metabolic biomarker for prostate cancer.[66] The oxidation of glucose and sarcosine with the corresponding oxidase produces H2O2. The produced H2O2 can catalytically oxidize peroxidase substrates with LaNiO3 nanocubes-based peroxidase mimics to produce colored products for signaling. Therefore, we further developed facile bioassays for glucose and sarcosine detection by combining glucose oxidase (GOx) and sarcosine oxidase (SOx) with the porous LaNiO3 nanocubes-based peroxidase mimics.

# **Materials and Methods**

# **Chemicals and Materials**

Nickel nitrate hexahydrate, citric acid, sucrose, and glucose were obtained from Nanjing Chemical Reagent Co., Ltd. Ethylene glycol, lactose, sodium hydroxide, hydrogen peroxide, and ammonium hydroxide were purchased from Sinopharm Chemical Reagent Co., Ltd. TMB (3,3',5,5'-tetramethylbenzidine), OPD (o-phenylenediamine), ABTS (2,2′-azino-bis(3-ethylbenzothiazoline-6-sulphonic acid)), fructose, glycine, lanthanum nitrate hexahydrate, lanthanum oxide, Ni nanoparticles, and glucose oxidase (GOx from Aspergillus niger, >180 units/mg) were purchased from Aladdin Chemical Reagent Co., Ltd. Polyvinyl pyrrolidone (PVP, molecular weight=58000) and sarcosine oxidase (SOx) were obtained from Sigma-Aldrich. All chemical reagents were used as received without further purification. Deionized water produced by Millipore system was used in all experiments.

# **Instrumentation**

Powder X-ray diffraction (XRD) data were collected at room temperature on a Rigaku Ultima diffractometer by using Cu Kα radiation. The diffractometer was operated at 40 kV and 40 mA with a scan rate of 2°/minute. Transmission electron microscopy (TEM) imaging was performed on a JEOL JEM-2100 transmission electron microscope at an acceleration voltage of 200 kV. Scanning electron microscopy (SEM) imaging was performed on a Hitachi S-4800 scanning electron microscope operating at 5 kV. UV-visible absorption spectra were collected on a UV-visible spectrophotometer (TU-9100, Beijing Purkinje General Instrument Co. Ltd., China). Nitrogen adsorption-desorption isotherms were performed on Micromeritics ASAP 2020 surface area and porosity analyzer, from which the nanozymes' surface areas were calculated with the Brunauer-Emmett-Teller (BET) method.

# **Synthesis of Porous LaNiO3 Nanocubes via a Hydrothermal Method**

LaNiO3 nanocubes were synthesized as follows.[67] Briefly, the lanthanum nitrate hexahydrate (1.0 mmol), nickel nitrate hexahydrate (1.0 mmol), and glycine (4 mmol) were dissolved in 25 mL of deionized water, followed by the adding 0.3 g of PVP. After stirring for 30 min, the pH of the solution was adjusted to about 7.0 via slowly adding ammonium hydroxide. The resulting solution was transferred into a 40 mL Teflon-lined autoclave and heated at 180 °C for 24 hours. The resulting product was centrifuged and washed with deionized water and ethanol for several times, which was then dried at 60 °C for overnight. The precursor powder was finally annealed at 650 °C for 2 hours with a ramp rate of 5 °C/minute to obtain the final porous LaNiO3 nanocubes.

# **Synthesis of LaNiO3-H2 Nanocubes**

The LaNiO3-H2 was obtained by controlled reduction of as-prepared LaNiO3 porous nanocubes with H2 to partially form Ni2+ in the LaNiO3-H2 lattice. Specifically, the as-prepared LaNiO3 was heated to 350 °C at a ramp rate of 5 °C/minute and maintained at 350 °C for 2 hours under a forming gas of 5% H2 in Argon.

# **Synthesis of LaNiO3-H2-Air Nanocubes**

To obtain the LaNiO3-H2-Air nanocubes, the as-prepared LaNiO3-H2 nanocubes were recalcined at 650 °C in the air for 2 hours with a ramp rate of 5 °C/minute.

# **Synthesis of LaNiO3 Nanoparticles via a Sol-Gel Method**

The LaNiO3 nanoparticles were synthesized via a conventional sol-gel strategy.[68] Briefly, lanthanum nitrate hexahydrate (1.5 mmol), nickel nitrate hexahydrate (1.5 mmol), and citric acid (12 mmol) were dissolved in 100 mL of deionized water, followed by adding 1.5 mL of ethylene glycol. Subsequently, the resulting transparent solutions were condensed at 90 °C into a gel under stirring, which were then decomposed at 180 °C for 5 hours to form solid precursors. The solid precursors were then decomposed at 400 °C for 2 hours to obtain foam-like precursors via removing the organic components. The precursors were further annealed at 700 °C for 5 hours with a ramp rate of 5 °C/minute to obtain the final LaNiO3 nanoparticles. The obtained LaNiO3 nanoparticles was denoted as LaNiO3-SG.

# **Synthesis of NiO**

NiO nanoparticles were synthesized as follows.[69] 0.5 g of NaOH and 1.66 g of PVP were dissolved in 25 mL of deionized water and 1.45 g of nickel nitrate hexahydrate was dissolved in 10 mL of deionized water, respectively. The nickel nitrate aqueous solution was then added to the NaOH/PVP solution dropwise under stirring. The resulting solution was stirred for 3 hours to obtain the NiO precursor, followed by washing with H2O and ethanol for several times and drying at 60 °C overnight. Then, the precursor was annealed at 650 °C for 2 hours in air with a ramp rate of 5 °C/minute to form the final NiO nanoparticles.

# **Colorimetric Detection of H2O2, Glucose, and Sarcosine with the Porous LaNiO3 Nanocubes**

H2O2 detection was carried out as follows: (1) 20 μL of porous LaNiO3 nanocubes (1 mg/mL), 80 μL of TMB (10 mM), and 800 μL of NaOAc buffer (0.2 M, pH 4.5) was added into a 1.5 mL tube. (2) 100 μL of H2O2 with various concentrations was added into the above reaction solution. (3) The mixed solution was incubated for 20 min at 37 °C and then the absorption spectra were measured when keeping the solution in an ice water bath.

Glucose detection was performed as follows: (1) 100 μL of GOx (1 mg/mL) and 100 μL of glucose with different concentrations in 0.2 M phosphate buffer (pH 7.0) were incubated for 30 min at 37 °C. (2) 20 μL of porous LaNiO3 nanocubes (1 mg/mL), 100 μL of TMB (10 mM), and 680 μL of NaOAc buffer (0.2 M, pH 4.5) were added into the above 200 μL of glucose and GOx reaction solution. (3) The mixed solution was incubated for 20 min at 37 °C and then the absorption spectra were measured when keeping the solution in an ice water bath.

Sarcosine detection was performed as follows: (1) 100 μL of SOx (2 mg/mL) and 100 μL of sarcosine with various concentrations in 0.2 M phosphate buffer (pH 7.0) were incubated for 90 min at 37 °C. (2) 60 μL of porous LaNiO3 nanocubes (1 mg/mL), 100 μL of TMB (10 mM), and 640 μL of NaOAc buffer (0.2 M, pH 4.5) was added into the above 200 μL sarcosine and SOx reaction solution. (3) The mixed solution was incubated for 20 min at 45 °C and then the absorption spectra were measured when keeping the solution in an ice water bath.

#### **Cell Assays**

Hela cells were incubated in High Glucose DMEM medium with 10% fetal bovine serum (FBS) at 37 °C with the atmosphere containing 5% CO2. Fresh cells were subcultured into 96 wells, and 10 μg/mL lipopolysaccharides (LPS) was used to incubate with cells overnight. Then, 40 μg/mL LaNiO3 and 0.5 mM TMB were added into the cells. The cells solution was incubated for 10 min and the absorbance values at 652 nm were measured.

# **Results and Discussion**

#### **Synthesis and Characterization of Porous LaNiO3 Nanocubes**

The porous LaNiO3 nanocubes were obtained by annealing the nanocube-like precursors at 650 °C for 2 hours with a ramp rate of 5 °C/minute. The SEM images of nanocube-like precursors shown in Figure 1A and Figure S1A revealed that the precursors had smooth surfaces with the size of about 800 nm. After annealing in air at 650 °C for 2 hours, the annealed products maintained the precursors' nanocube-like morphology. The annealed products had rough surfaces with the size about 600 nm as shown in Figure 1B and Figure S1B. As shown in the SEM and TEM images of Figure 1B and Figure 1C, lots of pores randomly distributed in the annealed products after annealing the precursors in air at 650 °C for 2 hours. The high-resolution TEM images of the porous LaNiO3 nanocubes showed in Figure S1D suggested that the annealed products were polycrystalline. As shown in Figure 1D, the distance of the adjacent fringes was 0.271 nm, which was corresponded to the lattice spacing of the (110) plane of LaNiO3 perovskite. X-ray diffraction patterns confirmed that the annealed products had a perovskite structure with high phase purity, as seen in Figure 1E. This result suggested that nanocube-like precursors were completely transformed into porous LaNiO3 perovskite oxide after annealing in air at 650 °C for 2 hours.

<DESCRIPTION_FROM_IMAGE>The image contains six panels labeled (A) through (F), each depicting different aspects of a material analysis:

(A) Scanning Electron Microscope (SEM) image showing cubic structures with smooth surfaces. The scale bar indicates 1.00μm.

(B) SEM image of cubic structures with rougher surfaces. The scale bar indicates 500nm.

(C) Transmission Electron Microscope (TEM) image of cubic structures with internal textures. The scale bar indicates 200 nm.

(D) High-resolution TEM image showing lattice fringes. A measurement line indicates a d-spacing of 0.371 nm.

(E) X-ray diffraction (XRD) patterns. The upper pattern (red) shows multiple sharp peaks, indicating a crystalline structure. The lower pattern (black) shows broader, less intense peaks, suggesting a less crystalline or amorphous structure. The 2θ range is from 20 to 80 degrees.

(F) Crystal structure model of a cubic unit cell. The structure contains:
- Large spheres at the corners and face centers, likely representing metal atoms
- Smaller spheres at the edges and within the cell, possibly representing sulfur or another chalcogen
- A central, larger sphere (blue) surrounded by a tetrahedral arrangement of smaller spheres, suggesting a complex anion

This panel represents a face-centered cubic (FCC) structure with additional atoms, possibly a metal chalcogenide or similar compound.

The progression from (A) to (D) suggests a multi-scale analysis of the material's morphology and structure, from micron-scale to nanometer-scale. The XRD pattern in (E) correlates with the crystalline structure shown in (F), providing complementary bulk and atomic-scale structural information.</DESCRIPTION_FROM_IMAGE>

**Figure 1.** Representative SEM images of (A) the obtained nanocube-like precursors and (B) the porous LaNiO3 nanocubes after annealing the precursors. (C) Representative TEM images of the porous LaNiO3 nanocubes. (D) High-resolution TEM images of the porous LaNiO3 nanocubes. (E) Powder X-ray diffraction patterns of the nanocube-like precursors (black line) and the porous LaNiO3 nanocubes (red line). (F) Schematic of LaNiO3 perovskite oxide structure (La in grey, Ni in blue, and O in yellow).

## **Evaluation of Peroxidase Mimicking Activity of Porous LaNiO3 Nanocubes**

After establishing the successful fabrication of the porous LaNiO3 nanocubes, the peroxidase-like activity of the nanocubes was investigated. To evaluate the peroxidase mimicking activity of the porous LaNiO3 nanocubes, TMB was selected as the catalytic substrate because it was a typical chromogenic substrate for peroxidase. The oxidation of TMB generated the oxidized product (i.e., TMBox) with characteristic absorption peaks at 370 nm and 652 nm. As seen in Figure 2, the porous LaNiO3 nanocubes along with H2O2 and TMB incubated at room temperature for 10 min showed a deep blue color with strong absorbance at 370 nm and 652 nm. However, the other control experiments suggested that the solution contained TMB alone or H2O2 and TMB showed negligible color change. Note, the LaNiO3 and TMB system also showed a slight color change, which was probably due to the oxidase mimicking activity of LaNiO3 nanocubes. To further confirm the peroxidase-like activity of porous LaNiO3 nanocubes, the colorimetric experiments were also performed with the other two typical peroxidase substrates (i.e., OPD and ABTS). As confirmed in Figure S2, all three peroxidase substrates showed deep color changes with strong absorbance, which were attributed to the catalytic oxidation of the substrates with the porous LaNiO3 nanocubes in the presence of H2O2. These results confirmed that the porous LaNiO3 nanocubes possessed peroxidase-like activity.

<DESCRIPTION_FROM_IMAGE>The image shows a UV-Visible absorption spectrum graph with wavelength (nm) on the x-axis ranging from 300 to 800 nm and absorbance (a.u.) on the y-axis ranging from 0 to 1.0. The graph displays four different spectra:

1. TMB (black line): Shows minimal absorption across the spectrum.
2. TMB+LaNiO3 (red line): Similar to TMB, shows minimal absorption.
3. TMB+H2O2 (blue line): Slight increase in absorption around 370 nm and 650 nm.
4. TMB+H2O2+LaNiO3 (pink line): Shows two prominent peaks - a sharp, intense peak at about 370 nm with absorbance around 0.85, and a broader peak centered around 650 nm with absorbance around 0.55.

The graph includes an inset image showing four vials labeled a, b, c, and d, corresponding to the four spectra. The contents of the vials appear to change in color intensity, with vial d showing the most intense color.

Key observations:
1. The combination of TMB+H2O2+LaNiO3 produces the most significant spectral changes.
2. The peaks at 370 nm and 650 nm in the TMB+H2O2+LaNiO3 spectrum suggest the formation of a colored product, likely oxidized TMB.
3. LaNiO3 appears to catalyze the reaction between TMB and H2O2, as evidenced by the dramatic increase in absorbance when all three components are present.

This graph demonstrates the colorimetric response of TMB (3,3',5,5'-tetramethylbenzidine) in the presence of hydrogen peroxide and LaNiO3, suggesting a potential application in catalytic or sensing systems.</DESCRIPTION_FROM_IMAGE>

**Figure 2.** The absorption spectra of different reaction systems: (a) TMB only, (b) TMB + H2O2, (c) TMB + LaNiO3 nanocubes, and (d) TMB + H2O2 + LaNiO3 nanocubes.

The activity of nature enzymes is dependent on substrate concentrations and reaction conditions. Similar with the nature enzymes, the influence of H2O2 concentrations, catalyst concentrations, temperature, and pH on the peroxidase-like activity of the porous LaNiO3 nanocubes was investigated. As seen in Figure 3A, the reaction rate increased with the increase of H2O2 concentrations, indicating that the peroxidase-like activity of porous LaNiO3 nanocubes was dependent on the H2O2 concentrations. The effect of catalyst concentrations was also evaluated by monitoring the time-dependent absorption spectra under various catalyst concentrations. The reaction rate dramatically increased with the increase of catalyst concentrations, demonstrating that the peroxidase-like activity of porous LaNiO3 nanocubes was dependent on the catalyst concentrations. More, the pH and temperature-dependent peroxidase-like activity were also investigated. As shown in Figure 3C, the peroxidase-like activity of porous LaNiO3 nanocubes was gradually increased in the pH range from 1 to 4.5, while the peroxidase-like activity was gradually decreased in the pH range from 4.5 to 10. The effect of temperature on the peroxidase-like activity of LaNiO3 nanocubes was evaluated in the range from 20 °C to 60 °C. The peroxidase-like activity was confirmed to be the optimal at 55 °C. In a word, the peroxidase-like activity of porous LaNiO3 nanocubes was dependent on the pH and temperature and the optimized pH and temperature were 4.5 and 55 °C, respectively.

To investigate the catalytic mechanism and quantify the peroxidase-like activity of porous LaNiO3 nanocubes, the apparent steady-state kinetic parameters for the oxidation of TMB and H2O2 were determined. The kinetic data were obtained by varying the concentration of one substrate of H2O2 or TMB while keeping the other's concentration constant. In the suitable concentration range of H2O2 and TMB, typical Michaelis-Menten curves were obtained (Figure 4). The important enzyme kinetic parameters of maximum initial velocity (*V*max) and Michaelis-Menten constant (*K*m) were obtained using the Lineweaver-Burk plot. *K*m value showed the affinity of an enzymatic catalyst to its substrate, where the lower *K*m value represented the higher affinity. *V*max and *K*m values of porous LaNiO3 nanocubes, HRP, Pd-Ir cubes, graphene oxide (GO-COOH) and Fe3O4 were listed in Table S1. As seen in Table S1, the *K*m value of porous LaNiO3 nanocubes with H2O2 as the substrate was higher when compared to HRP, suggesting that the porous LaNiO3 nanocubes had a lower affinity with H2O2 than HRP. Low affinity between nanozymes and H2O2 is common for the nanozymes with peroxidase-like activities (such as the metal-, metal oxide-, and carbon-based nanozymes in Table S1). Interestingly, the *K*m value of porous LaNiO3 nanocubes with TMB as the substrate was lower when compared to HRP, which indicated the higher affinity between the porous LaNiO3 nanocubes and TMB than HRP. It is noteworthy that the porous LaNiO3 nanocubes showed higher *V*max values for both H2O2 and TMB when compared to other peroxidase-like nanozymes previously reported (Table S1). This demonstrated the excellent peroxidase mimicking activities of the currently developed LaNiO3 nanocubes.

<DESCRIPTION_FROM_IMAGE>The image contains four separate graphs labeled (A), (B), (C), and (D), each depicting different aspects of a chemical or biochemical experiment.

(A) Graph of Absorbance vs. Time:
- X-axis: Time (s), ranging from 0 to 200 seconds
- Y-axis: Absorbance (a.u.), ranging from 0 to 1.2
- Multiple curves shown, representing different concentrations
- Legend indicates concentration range from 0 mM to 100 mM
- Curves show increasing absorbance over time, with higher concentrations resulting in steeper slopes and higher final absorbance values

(B) Graph of Absorbance vs. Time:
- X-axis: Time (s), ranging from 0 to 200 seconds
- Y-axis: Absorbance (a.u.), ranging from 0 to 0.8
- Multiple curves shown, representing different concentrations
- Legend indicates concentration range from 0 μg/mL to 50 μg/mL
- Curves show increasing absorbance over time, with higher concentrations resulting in steeper slopes and higher final absorbance values

(C) Graph of Relative Activity vs. pH:
- X-axis: pH, ranging from 0 to 10
- Y-axis: Relative activity (%), ranging from 0 to 100%
- Single curve with error bars
- Peak activity observed at pH 5, reaching nearly 100% relative activity
- Sharp decline in activity on either side of the peak, with activity dropping to near 0% at pH 0 and pH 8-10

(D) Graph of Relative Activity vs. Temperature:
- X-axis: Temperature (°C), ranging from 20 to 70°C
- Y-axis: Relative activity (%), ranging from 20 to 100%
- Single curve with error bars
- Activity increases with temperature up to about 55°C, reaching a maximum of approximately 100% relative activity
- Slight decrease in activity observed above 55°C
- Error bars increase in size at higher temperatures, indicating greater variability in measurements

These graphs collectively suggest an analysis of enzyme or catalyst activity under varying conditions of concentration (A and B), pH (C), and temperature (D). The data indicate optimal conditions for the studied reaction or process, with peak activity occurring at specific pH and temperature values.</DESCRIPTION_FROM_IMAGE>

**Figure 3.** (A) Kinetic curves of A652 for monitoring the catalytic oxidation of 1 mM TMB with various concentrations of H2O2 in the presence of 10 μg/mL porous LaNiO3 nanocubes. (B) Kinetic curves of A652 for monitoring the catalytic oxidation of 1 mM TMB with various concentrations of porous LaNiO3 nanocubes in the presence of 10 mM H2O2. (C, D) pH and temperature-dependent peroxidase-like activities of the porous LaNiO3 nanocubes.

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled (A), (B), (C), and (D), each showing different relationships between velocity and concentration of chemical compounds. I will describe each graph in detail:

(A) This graph shows the relationship between velocity (10^-8 M s^-1) and TMB (3,3',5,5'-tetramethylbenzidine) concentration (μM). The x-axis ranges from 0 to 600 μM, while the y-axis ranges from 0 to 35 x 10^-8 M s^-1. The data points follow a saturation curve, with velocity increasing rapidly at lower TMB concentrations and then leveling off at higher concentrations. The curve appears to approach a maximum velocity of around 30-32 x 10^-8 M s^-1.

(B) This graph depicts the relationship between velocity (10^-8 M s^-1) and H2O2 (hydrogen peroxide) concentration (mM). The x-axis ranges from 0 to 600 mM, while the y-axis ranges from 0 to 250 x 10^-8 M s^-1. Similar to graph A, this shows a saturation curve with velocity increasing rapidly at lower H2O2 concentrations and then leveling off. The maximum velocity appears to be around 220-230 x 10^-8 M s^-1.

(C) This graph presents a double reciprocal (Lineweaver-Burk) plot of 1/Velocity (10^8 M^-1 s) versus 1/TMB concentration (mM^-1). The x-axis ranges from 0 to 50 mM^-1, while the y-axis ranges from 0 to 0.20 x 10^8 M^-1 s. The data points form a linear relationship, with the line extending from about 0.03 x 10^8 M^-1 s at x=0 to about 0.18 x 10^8 M^-1 s at x=50 mM^-1.

(D) This graph shows another double reciprocal plot, this time of 1/Velocity (10^8 M^-1 s) versus 1/H2O2 concentration (mM^-1). The x-axis ranges from 0 to 0.6 mM^-1, while the y-axis ranges from 0 to 0.20 x 10^8 M^-1 s. The data points again form a linear relationship, with the line extending from close to the origin to about 0.15 x 10^8 M^-1 s at x=0.5 mM^-1.

These graphs collectively provide information about the kinetics of an enzyme-catalyzed reaction involving TMB and H2O2, likely a peroxidase reaction. Graphs A and B show the saturation kinetics typical of enzyme-catalyzed reactions, while graphs C and D are Lineweaver-Burk plots used to determine kinetic parameters such as Km and Vmax.</DESCRIPTION_FROM_IMAGE>

**Figure 4.** The steady-state kinetic assays of the porous LaNiO3 nanocubes. Plots of the velocity of the reaction versus different concentrations of TMB (A, 10 mM H2O2) or H2O2 (B, 0.8 mM TMB). Double reciprocal plots of the velocity versus varying concentration of (C) TMB and (D) H2O2.

# **Comparison of the Peroxidase-Like Activity of Porous LaNiO3 Nanocubes and Other Ni-based Nanomaterials**

We investigated the influence of oxidation state of nickel atom in the Ni-based nanomaterials on their peroxidase-like activities. The peroxidase-like activities of Ni nanoparticles, LaNiO3-H2 nanocubes, and NiO with different oxidation state of nickel atom were studied and compared with that of the porous LaNiO3 nanocubes. LaNiO3-H2 nanocubes were obtained by annealing the porous LaNiO3 nanocubes at 350 °C for 2 hours under a forming gas with 5% H2 in argon, which partially reduced the Ni3+ to Ni2+. The successful synthesis of these Ni-based nanomaterials was confirmed by SEM and XRD (Figures S3-S6). The nickel atom in Ni nanoparticles was in the oxidation state of Ni0, while the nickel atom in LaNiO3 was Ni3+ and the nickel atom in NiO was Ni2+. As shown in Figure 5A and Figure 5C, the porous LaNiO3 nanocubes with Ni3+ exhibited the highest peroxidase-like activity while the Ni nanoparticles with Ni0 and NiO with Ni2+ showed negligible peroxidase-like activities. Interestingly, the LaNiO3-H2 nanocubes exhibited about 71% peroxidase-like activity of LaNiO3 nanocubes. The peroxidase-like activity of LaNiO3-H2 nanocubes decreased when compared to LaNiO3 nanocubes because the Ni3+ was partially reduced to Ni2+ in LaNiO3-H2 nanocubes. These results demonstrated that the oxidation state of nickel atom was very important for the peroxidase-like activity of Ni-based nanomaterials. More, the Ni3+ can be an optimal oxidation state for Ni-based nanomaterials with peroxidase mimicking activity. It is noteworthy that the peroxidase-like activity of LaNiO3-H2 nanocubes can be recovered when the LaNiO3-H2 nanocubes were reoxidized at 650 °C for 2 hours under the air to form LaNiO3-H2-Air. The peroxidase-like activity of LaNiO3-H2-Air was almost the same as that of the LaNiO3 nanocubes. The recovered catalytic activity of LaNiO3-H2-Air was attributed to the reoxidized Ni3+, further confirming the importance of Ni3+ to the Ni-based nanomaterials' peroxidase mimicking activities.

To study the effect of La atom on the catalytic activity of LaNiO3 nanocubes, the peroxidase mimicking activity of La2O3 nanoparticles with the same La3+ as LaNiO3 was investigated. As shown in Figure S7, La2O3 nanoparticles exhibited nearly negligible activity when compared with LaNiO3 nanocubes, suggesting that the Ni3+ instead of La3+ played the dominant role in the peroxidase mimicking activity of LaNiO3.

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled (A), (B), (C), and (D), presenting data related to LaNiO3 and its derivatives.

(A) Graph of Absorbance (a.u.) vs Time (s) for four materials:
- LaNiO3 Cubes: Highest absorbance, increasing from ~0.1 to 0.9 over 200 seconds
- LaNiO3-H2: Second highest, increasing from ~0.1 to 0.65 over 200 seconds
- Ni: Low absorbance, slight increase from ~0.05 to 0.1 over 200 seconds
- NiO: Lowest absorbance, nearly constant at ~0.02 over 200 seconds

(B) Graph of Absorbance (a.u.) vs Time (s) for two materials:
- LaNiO3 Cubes: Higher absorbance, increasing from ~0.1 to 0.9 over 200 seconds
- LaNiO3-SG: Lower absorbance, increasing from ~0.05 to 0.5 over 200 seconds

(C) Bar graph of Relative Activity for four materials:
- Ni: Very low activity (~0.05)
- LaNiO3: Highest activity (~1.0)
- LaNiO3-H2: Second highest activity (~0.7)
- NiO: Lowest activity (nearly 0)

(D) Bar graph of Relative Activity for two materials:
- LaNiO3-SG: Lower activity (~0.55)
- LaNiO3 nanocubes: Higher activity (~1.0)

The graphs demonstrate the superior performance of LaNiO3 cubes or nanocubes in terms of absorbance and relative activity compared to other forms (SG, H2-treated) and related materials (Ni, NiO). The time-dependent absorbance measurements in (A) and (B) suggest kinetic studies, possibly related to catalytic activity. The relative activity comparisons in (C) and (D) highlight the effectiveness of the nanocube structure in enhancing the material's performance.</DESCRIPTION_FROM_IMAGE>

**Figure 5.** (A, B) Kinetic curves of A652 for monitoring the catalytic oxidation of 1 mM TMB with 40 mM H2O2 in the presence of 10 μg/mL of (A) LaNiO3, LaNiO3-H2, Ni, and NiO; and (B) LaNiO3 and LaNiO3-SG. (C, D) Comparison of the peroxidase mimicking activities of (C) Ni, LaNiO3, LaNiO3-H2, and NiO; and (D) LaNiO3-SG and LaNiO3 nanocubes.

The peroxidase-like activity of LaNiO3-SG was also investigated and compared with that of the porous LaNiO3 nanocubes. The LaNiO3-SG was synthesized via a conventional sol-gel method to form LaNiO3 nanoparticles. Since the LaNiO3-SG and porous LaNiO3 nanocubes had the same 3+ oxidation state but different morphologies, it enabled us to study the morphology effect on the peroxidase-like activities of LaNiO3. Quantitative analysis showed that the porous LaNiO3 nanocubes exhibited about 2-fold higher activity when compared with LaNiO3-SG. The higher activity of porous LaNiO3 nanocubes than LaNiO3-SG may be attributed to the rough surfaces and rich porosity of nanocubes' morphology.

To exclude the effect of surface area on the catalytic activity, we investigated the surface area normalized peroxidase-like activities of Ni-based nanomaterials. As shown in Figure S8A, the surface area normalized results also showed that the oxidation state of nickel atom was very important for the peroxidase-like activity of Ni-based nanomaterials. The Ni3+ could be an optimal oxidation state for Ni-based nanomaterials with peroxidase-like activities. As shown in Figure S8B, the LaNiO3 nanocubes showed a higher surface area normalized activity than LaNiO3-SG, suggesting that the effect of morphology on the peroxidase-like activity of nanomaterials. In conclusion, the results obtained from the surface area normalized activity was well agreed with those obtained from mass normalized activity.

Therefore, the porous LaNiO3 nanocubes with the highest peroxidase mimicking activity were obtained by inducing its 3+ oxidation state of nickel atom in LaNiO3 perovskite and optimizing the morphology of nanomaterials.

#### **Detection of H2O2, Glucose, and Sarcosine**

On the basis of the highest intrinsic

peroxidase-like activity of the porous LaNiO3 nanocubes, we developed colorimetric assays for H2O2, glucose, and sarcosine detection. As demonstrated above, the peroxidase-like activity of porous LaNiO3 nanocubes was dependent on the H2O2 concentrations, which can be used to detect H2O2 by monitoring the absorbance of TMB at 652 nm. As seen in Figure S10A and Figure S10B, the intensity of absorption peak at 652 nm increased with the increase of H2O2 concentration from 0 μM to 1000 μM. Figure S10C and Figure S10D exhibited good linearity relationships between the absorbance intensity at 652 nm and the H2O2 concentrations from 0 μM to 30 μM and 40 μM to 500 μM.

The glucose detection was then carried out by coupling cascade reactions of the glucose oxidation catalyzed by GOx and the TMB oxidation catalyzed by LaNiO3 nanocubes (Figure S11). First, GOx catalyzed the glucose oxidation with O2 to produce H2O2; then, the LaNiO3 nanocubes catalyzed the TMB oxidation with the *in situ* generated H2O2. Therefore, glucose could be determined by monitoring the absorbance of TMB at 652 nm. Figure 6A showed that the absorbance intensity exhibited a good response to glucose concentration from 2 μM to 1000 μM. A linear range from 10 μM to 50 μM and a detection limit of 8.16 μM were obtained for glucose detection. Control experiments were performed to evaluate the selectivity of the developed colorimetric assay for glucose by using other sugars such as fructose, lactose, and sucrose. As showed in Figure 6B, the other glucose analogues with a high concentration of 5 mM exhibited a negligible absorbance when compared with that of 1 mM glucose. This result demonstrated that the developed colorimetric assay had a good selectivity for glucose detection because of the high specificity of GOx for catalytic glucose oxidation.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (A) and (B), both related to absorbance measurements.

Graph (A):
This graph shows the relationship between glucose concentration (x-axis) and absorbance at 652 nm (y-axis). The main plot covers a glucose concentration range from 0 to 1000 μM, with absorbance values ranging from 0 to approximately 0.4. The curve shows a non-linear relationship, with a steep initial increase in absorbance at lower glucose concentrations, followed by a more gradual increase at higher concentrations, suggesting a saturation effect.

An inset graph in the upper right corner of (A) focuses on the lower glucose concentration range (0-50 μM) and shows a linear relationship between glucose concentration and absorbance. The absorbance values in this inset range from about 0.10 to 0.18.

Error bars are visible on some data points, particularly noticeable for the highest concentration point on the main plot and for several points in the inset.

Graph (B):
This is a bar graph comparing the absorbance (in arbitrary units, a.u.) for different sugar solutions. The x-axis shows five categories: Blank, Fructose, Lactose, Sucrose, and Glucose. The y-axis represents absorbance, ranging from 0 to 0.4 a.u.

The results show:
1. Blank: absorbance around 0.1 a.u.
2. Fructose: slightly higher than blank, about 0.1 a.u.
3. Lactose: similar to fructose, about 0.1 a.u.
4. Sucrose: noticeably higher, around 0.12 a.u.
5. Glucose: significantly higher than all others, approximately 0.32 a.u.

Error bars are visible on all bars, with glucose showing the largest error range.

This graph demonstrates the selectivity of the measurement method for glucose compared to other sugars, with glucose producing a much higher absorbance signal.

Together, these graphs illustrate both the quantitative relationship between glucose concentration and absorbance (A) and the selectivity of the method for glucose over other common sugars (B).</DESCRIPTION_FROM_IMAGE>

**Figure 6.** (A) Dependence of A652 for monitoring the catalytic oxidation of TMB on the concentration of glucose from 2 μM to 1 mM. The inset shows the linear calibration plot between the concentration of glucose and the absorbance at 652 nm. (B) Selectivity of glucose detection with the porous LaNiO3 nanocubes. Absorbance of TMB at 652 nm in the absence and presence of 5 mM fructose, 5mM lactose, 5 mM sucrose, and 1 mM glucose.

To demonstrate the practical applications of the developed colorimetric assay in real samples, four serum samples from patients were used for glucose detection. As shown in Table S3, the results obtained by our colorimetric assay agreed with the results obtained by a glucose meter, validating the developed colorimetric assay for glucose detection in complicated biomedical samples.

To show the general applications of the porous LaNiO3 nanocubes based colorimetric assays, the sarcosine detection was also performed. By using SOx and LaNiO3 nanocubes catalyzed cascade reaction, the sarcosine concentration could be determined by monitoring the absorbance of TMB at 652 nm (Figure S12). As shown in Figure S13, the absorbance intensity also exhibited a good response to sarcosine concentration from 0.5 μM to 500 μM. A linear range from 0.5 μM to 20 μM and a detection limit of 0.5 μM were obtained for sarcosine detection. The selectivity of the developed colorimetric assay for sarcosine detection was evaluated by using other amino acids such as glutamic acid, histidine, aspartic acid, and lysine. As shown in Figure S14, the other amino acids with a high concentration of 5 mM exhibited a negligible absorbance while sarcosine with a concentration of 1 mM showed a high absorbance, suggesting that the developed colorimetric assay had a good selectivity for sarcosine detection.

# **Conclusion**

In conclusion, we obtained the porous LaNiO3 nanocubes as a peroxidase mimic by optimizing the oxidation state of nickel atom in Ni-based nanomaterials and the morphology of LaNiO3 perovskite oxide. For Ni-based nanomaterials, LaNiO3 perovskite oxide containing 3+ oxidation state showed excellent peroxidase-like activity while the Ni nanoparticles with Ni0 and NiO with Ni2+ exhibited negligible activities, confirming the importance of the oxidation state of nickel atom in Ni-based nanomaterials. More, the porous LaNiO3 nanocubes were more active than the LaNiO3 nanoparticles synthesized by a conventional sol-gel method. The porous LaNiO3 nanocubes followed the typical Michaeli-Menten kinetics and showed the dependence on the temperature, pH, catalyst concentration and H2O2 concentration. Based on the peroxidase-like activity of the porous LaNiO3 nanocubes, sensitive and selective colorimetric assays for H2O2, glucose, and sarcosine detection have been developed. The porous LaNiO3 nanocubes with high peroxidase-like activity exhibited promising applications in clinical diagnostics.

# **Supplementary Material**

Supplementary figures and tables. http://www.thno.org/v07p2277s1.pdf

# **Acknowledgements**

This work was supported by National Natural Science Foundation of China (21405081), Natural Science Foundation of Jiangsu Province (BK20130561), 973 Program (2015CB659400), PAPD program, Shuangchuang Program of Jiangsu Province, Open Funds of the State Key Laboratory of Analytical Chemistry for Life Science (SKLACLS1704), Open Funds of the State Key Laboratory of Electroanalytical Chemistry (SKLEAC201501), and Thousand Talents Program for Young Researchers.

# **Competing Interests**

The authors have declared that no competing interest exists.

# **References**

- 1. Nelson DL, Cox MM. Lehninger Principles of Biochemistry. 5th edition. New York: W. H. Freeman and Company; 2008: 183-229.
- 2. Breslow R. Artificial Enzymes. Science. 1982; 218: 532-7.
- 3. Murakami Y, Kikuchi J, Hisaeda Y, Hayashida O. Artificial enzymes. Chem Rev. 1996; 96: 721-58.
- 4. Breslow R. Artificial enzymes. Wiley-VCH Verlag GmbH & Co KGaA, Weinheim. 2005.
- 5. Cheng H, Wang X, Wei H. Artificial Enzymes: The Next Wave. In: Wang Z, ed. Encyclopedia of Physical Organic Chemistry, First Edition. John Wiley & Sons, Inc. 2017: 3885-3948.
- 6. Wei H, Wang EK. Nanomaterials with enzyme-like characteristics (nanozymes): next-generation artificial enzymes. Chem Soc Rev. 2013; 42: 6060-93.
- 7. Ragg R, Tahir MN, Tremel W. Solids Go Bio: Inorganic Nanoparticles as Enzyme Mimics. Eur J Inorg Chem. 2016;: 1906-15.
- 8. Gao L, Yan X. Nanozymes: an emerging field bridging nanotechnology and biology. Sci China Life Sci. 2016; 59: 400-2.
- 9. Melemenidis S, Jefferson A, Ruparelia N, Akhtar AM, Xie J, Allen D, et al. Molecular Magnetic Resonance Imaging of Angiogenesis In Vivo using Polyvalent Cyclic RGD-Iron Oxide Microparticle Conjugates. Theranostics. 2015; 5: 515-29.
- 10. Wang X, Hu Y, Wei H. Nanozymes in bionanotechnology: from sensing to therapeutics and beyond. Inorg Chem Front. 2016; 3: 41-60.
- 11. Wang X, Guo W, Hu Y, Wu J, Wei H. Nanozymes: Next Wave of Artificial Enzymes. Springer; 2016.
- 12. Liu B, Liu J. Surface modification of nanozymes. Nano Research. 2017; 10:1125-48.
- 13. Manea F, Houillon FB, Pasquato L, Scrimin P. Nanozymes: Gold-nanoparticle-based transphosphorylation catalysts. Angew Chem Int Ed. 2004; 43: 6165-9.
- 14. Gao L, Zhuang J, Nie L, Zhang J, Zhang Y, Gu N, et al. Intrinsic peroxidase-like activity of ferromagnetic nanoparticles. Nat Nanotechnol. 2007; 2: 577-83.
- 15. Song Y, Qu K, Zhao C, Ren J, Qu X. Graphene Oxide: Intrinsic Peroxidase Catalytic Activity and Its Application to Glucose Detection. Adv Mater. 2010; 22: 2206-10.
- 16. Natalio F, Andre R, Hartog AF, Stoll B, Jochum KP, Wever R, et al. Vanadium pentoxide nanoparticles mimic vanadium haloperoxidases and thwart biofilm formation. Nat Nanotechnol. 2012; 7: 530-5.
- 17. Xia X, Zhang J, Lu N, Kim MJ, Ghale K, Xu Y, et al. Pd-Ir Core-Shell Nanocubes: A Type of Highly Efficient and Versatile Peroxidase Mimic. ACS Nano. 2015; 9: 9994-10004.
- 18. Cai R, Yang D, Peng S, Chen X, Huang Y, Liu Y, et al. Single Nanoparticle to 3D Supercage: Framing for an Artificial Enzyme System. J Am Chem Soc. 2015; 137: 13957-63.
- 19. Zhang W, Hu S, Yin J, He W, Lu W, Ma M, et al. Prussian Blue Nanoparticles as Multienzyme Mimetics and Reactive Oxygen Species Scavengers. J Am Chem Soc. 2016; 138: 5860-5.
- 20. Luo W, Zhu C, Su S, Li D, He Y, Huang Q, et al. Self-Catalyzed, Self-Limiting Growth of Glucose Oxidase-Mimicking Gold Nanoparticles. ACS Nano. 2010; 4: 7451-8.

- 21. Zheng X, Liu Q, Jing C, Li Y, Li D, Luo W, et al. Catalytic Gold Nanoparticles for Nanoplasmonic Detection of DNA Hybridization. Angew Chem Int Ed. 2011; 50: 11994-8.
- 22. Vernekar AA, Sinha D, Srivastava S, Paramasivam PU, D'Silva P, Mugesh G. An antioxidant nanozyme that uncovers the cytoprotective potential of vanadia nanowires. Nat Commun. 2014; 5: 5301.
- 23. Shen X, Liu W, Gao X, Lu Z, Wu X, Gao X. Mechanisms of Oxidase and Superoxide Dismutation-like Activities of Gold, Silver, Platinum, and Palladium, and Their Alloys: A General Way to the Activation of Molecular Oxygen. J Am Chem Soc. 2015; 137: 15882-91.
- 24. Tonga GY, Jeong Y, Duncan B, Mizuhara T, Mout R, Das R, et al. Supramolecular regulation of bioorthogonal catalysis in cells using nanoparticle-embedded transition metal catalysts. Nat Chem. 2015; 7: 597-603.
- 25. Zhao Y, Huang Y, Zhu H, Zhu Q, Xia Y. Three-in-One: Sensing, Self-Assembly, and Cascade Catalysis of Cyclodextrin Modified Gold Nanoparticles. J Am Chem Soc. 2016; 138: 16645-54.
- 26. Lin Y, Li Z, Chen Z, Ren J, Qu X. Mesoporous silica-encapsulated gold nanoparticles as artificial enzymes for self-activated cascade catalysis. Biomaterials. 2013; 34: 2600-10.
- 27. Lin Y, Ren J, Qu X. Nano-Gold as Artificial Enzymes: Hidden Talents. Adv Mater. 2014; 26: 4200-17.
- 28. Wei H, Wang E. Fe3O4 magnetic nanoparticles as peroxidase mimetics and their applications in H2O2 and glucose detection. Anal Chem. 2008; 80: 2250-4.
- 29. Liu B, Han X, Liu J. Iron oxide nanozyme catalyzed synthesis of fluorescent polydopamine for light-up Zn2+ detection. Nanoscale. 2016; 8: 13620-6.
- 30. Fan K, Cao C, Pan Y, Lu D, Yang D, Feng J, et al. Magnetoferritin nanoparticles for targeting and visualizing tumour tissues. Nat Nanotechnol. 2012; 7: 459-64.
- 31. Tao Y, Ju E, Ren J, Qu X. Bifunctionalized Mesoporous Silica-Supported Gold Nanoparticles: Intrinsic Oxidase and Peroxidase Catalytic Activities for Antibacterial Applications. Adv Mater. 2015; 27: 1097-104.
- 32. Xue T, Peng B, Xue M, Zhong X, Chiu C-Y, Yang S, et al. Integration of molecular and enzymatic catalysts on graphene for biomimetic generation of antithrombotic species. Nat Commun. 2014; 5: 3200.
- 33. Gao L, Giglio KM, Nelson JL, Sondermann H, Travis AJ. Ferromagnetic nanoparticles with peroxidase-like activity enhance the cleavage of biological macromolecules for biofilm elimination. Nanoscale. 2014; 6: 2588-93.
- 34. Kim CK, Kim T, Choi I-Y, Soh M, Kim D, Kim Y-J, et al. Ceria Nanoparticles that can Protect against Ischemic Stroke. Angew Chem Int Ed. 2012; 51: 11039-43.
- 35. Kwon HJ, Cha M-Y, Kim D, Kim DK, Soh M, Shin K, et al. Mitochondria-Targeting Ceria Nanoparticles as Antioxidants for Alzheimer's Disease. ACS Nano. 2016; 10: 2860-70.
- 36. Zhang Y, Wang Z, Li X, Wang L, Yin M, Wang L, et al. Dietary Iron Oxide Nanoparticles Delay Aging and Ameliorate Neurodegeneration in Drosophila. Adv Mater. 2016; 28: 1387-93.
- 37. Chen ZW, Yin JJ, Zhou YT, Zhang Y, Song L, Song MJ, et al. Dual Enzyme-like Activities of Iron Oxide Nanoparticles and Their Implication for Diminishing Cytotoxicity. ACS Nano. 2012; 6: 4001-12.
- 38. Xiong F, Wang H, Feng Y, Li Y, Hua X, Pang X, et al. Cardioprotective activity of iron oxide nanoparticles. Sci Rep. 2015; 5.
- 39. Dong J, Song L, Yin J-J, He W, Wu Y, Gu N, et al. Co3O4 Nanoparticles with Multi-Enzyme Activities and Their Application in Immunohistochemical Assay. ACS Appl Mat Interfaces. 2014; 6: 1959-70.
- 40. Wu G, He S, Peng H, Deng H, Liu A, Lin X, et al. Citrate-Capped Platinum Nanoparticle as a Smart Probe for Ultrasensitive Mercury Sensing. Anal Chem. 2014; 86: 10955-60.
- 41. Shi W, Wang Q, Long Y, Cheng Z, Chen S, Zheng H, et al. Carbon nanodots as peroxidase mimetics and their applications to glucose detection. Chem Commun. 2011; 47: 6695-7.
- 42. Duan D, Fan K, Zhang D, Tan S, Liang M, Liu Y, et al. Nanozyme-strip for rapid local diagnosis of Ebola. Biosens Bioelectron. 2015; 74: 134-41.
- 43. Liu Q, Yang Y, Li H, Zhu R, Shao Q, Yang S, et al. NiO nanoparticles modified with 5,10,15,20-tetrakis(4-carboxyl pheyl)-porphyrin: Promising peroxidase mimetics for H2O2 and glucose detection. Biosens Bioelectron. 2015; 64: 147-53.
- 44. He W, Wu X, Liu J, Hu X, Zhang K, Hou S, et al. Design of AgM Bimetallic Alloy Nanostructures (M = Au, Pd, Pt) with Tunable Morphology and Peroxidase-Like Activity. Chem Mater. 2010; 22: 2988-94.
- 45. Liu S, Lu F, Xing R, Zhu J. Structural Effects of Fe3O4 Nanocrystals on Peroxidase-Like Activity. Chem Euro J. 2011; 17: 620-5.
- 46. Ge C, Fang G, Shen X, Chong Y, Wamer WG, Gao X, et al. Facet Energy versus Enzyme-like Activities: The Unexpected Protection of Palladium Nanocrystals against Oxidative Damage. ACS Nano. 2016; 10: 10436-45.
- 47. Wang S, Chen W, Liu A, Hong L, Deng H, Lin X. Comparison of the Peroxidase-Like Activity of Unmodified, Amino-Modified, and Citrate-Capped Gold Nanoparticles. ChemPhysChem. 2012; 13: 1199-204.
- 48. Fan K, Wang H, Xi J, Liu Q, Meng X, Duan D, et al. Optimization of Fe3O4 nanozyme activity via single amino acid modification mimicking an enzyme active site. Chem Commun. 2016; 53: 424-7.
- 49. Cheng H, Lin S, Muhammad F, Lin Y-W, Wei H. Rationally Modulate the Oxidase-like Activity of Nanoceria for Self Regulated Bioassays. ACS Sensors. 2016; 1: 1336-43.
- 50. Heckert EG, Karakoti AS, Seal S, Self WT. The role of cerium redox state in the SOD mimetic activity of nanoceria. Biomaterials. 2008; 29: 2705-9.

- 51. Pirmohamed T, Dowding JM, Singh S, Wasserman B, Heckert E, Karakoti AS, et al. Nanoceria exhibit redox state-dependent catalase mimetic activity. Chem Commun. 2010; 46: 2736-8.
- 52. Liu B, Huang Z, Liu J. Boosting the oxidase mimicking activity of nanoceria by fluoride capping: rivaling protein enzymes and ultrasensitive F- detection. Nanoscale. 2016; 8: 13562-7.
- 53. Zhang X-Q, Gong S-W, Zhang Y, Yang T, Wang C-Y, Gu N. Prussian blue modified iron oxide magnetic nanoparticles and their high peroxidase-like activity. J Mater Chem. 2010; 20: 5110-6.
- 54. Xiong R, Soenen SJ, Braeckmans K, Skirtach AG. Towards Theranostic Multicompartment Microcapsules: in-situ Diagnostics and Laser-induced Treatment. Theranostics. 2013; 3: 141-51.
- 55. Cheng H, Wang X, Wei H. Ratiometric Electrochemical Sensor for Effective and Reliable Detection of Ascorbic Acid in Living Brains. Anal Chem. 2015; 87: 8889-95.
- 56. Sun X, Guo S, Chung C-S, Zhu W, Sun S. A Sensitive H2O2 Assay Based on Dumbbell-like PtPd-Fe3O4 Nanoparticles. Adv Mater. 2013; 25: 132-6.
- 57. Qian C, Chen Y, Zhu S, Yu J, Zhang L, Feng P, et al. ATP-Responsive and Near-Infrared-Emissive Nanocarriers for Anticancer Drug Delivery and Real-Time Imaging. Theranostics. 2016; 6: 1053-64.
- 58. Zhang P, Chen Y, Zeng Y, Shen C, Li R, Guo Z, et al. Virus-mimetic nanovesicles as a versatile antigen-delivery system. Proc Natl Acad Sci USA. 2015; 112: E6129-E38.
- 59. Cheng H, Zhang L, He J, Guo W, Zhou Z, Zhang X, et al. Integrated Nanozymes with Nanoscale Proximity for in Vivo Neurochemical Monitoring in Living Brains. Anal Chem. 2016; 88: 5489-97.
- 60. Liu B, Sun Z, Huang P-JJ, Liu J. Hydrogen Peroxide Displacing DNA from Nanoceria: Mechanism and Detection of Glucose in Serum. J Am Chem Soc. 2015; 137: 1290-5.
- 61. Gu Z, Dang TT, Ma M, Tang BC, Cheng H, Jiang S, et al. Glucose-Responsive Microgels Integrated with Enzyme Nanocapsules for Closed-Loop Insulin Delivery. ACS Nano. 2013; 7: 6758-66.
- 62. Yu J, Zhang Y, Ye Y, DiSanto R, Sun W, Ranson D, et al. Microneedle-array patches loaded with hypoxia-sensitive vesicles provide fast glucose-responsive insulin delivery. Proc Natl Acad Sci USA. 2015; 112: 8260-5.
- 63. He H, Xu X, Wu H, Jin Y. Enzymatic Plasmonic Engineering of Ag/Au Bimetallic Nanoshells and Their Use for Sensitive Optical Glucose Sensing. Adv Mater. 2012; 24: 1736-40.
- 64. Chen L, Li H, He H, Wu H, Jin Y. Smart Plasmonic Glucose Nanosensors as Generic Theranostic Agents for Targeting-Free Cancer Cell Screening and Killing. Anal Chem. 2015; 87: 6868-74.
- 65. Fan W, Lu N, Huang P, Liu Y, Yang Z, Wang S, et al. Glucose-Responsive Sequential Generation of Hydrogen Peroxide and Nitric Oxide for Synergistic Cancer Starving-Like/Gas Therapy. Angew Chem Int Ed. 2017; 56: 1229-33.
- 66. Sreekumar A, Poisson LM, Rajendiran TM, Khan AP, Cao Q, Yu J, et al. Metabolomic profiles delineate potential role for sarcosine in prostate cancer progression. Nature. 2009; 457: 910-4.
- 67. Zhang J, Zhao Y, Zhao X, Liu Z, Chen W. Porous Perovskite LaNiO3 Nanocubes as Cathode Catalysts for Li-O2 Batteries with Low Charge Potential. Sci Rep. 2014; 4: 6005.
- 68. Liu H, More R, Grundmann H, Cui C, Erni R, Patzke GR. Promoting Photochemical Water Oxidation with Metallic Band Structures. J Am Chem Soc. 2016; 138: 1527-35.
- 69. Mahaleh YBM, Sadrnezhaad SK, Hosseini D. NiO Nanoparticles Synthesis by Chemical Precipitation and Effect of Applied Surfactant on Distribution of Particle Size. J Nanomater. 2008; 2008: 470595.