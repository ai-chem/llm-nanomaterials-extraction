## **OPEN**

received: 08 July 2016 accepted: 28 September 2016 Published: 17 October 2016

# **Redox enzyme-mimicking activities of CeO2 nanostructures: Intrinsic influence of exposed facets**

**YushiYang1, Zhou Mao1, Wenjie Huang1, Lihua Liu1, Junli Li2, Jialiang Li3 & QingzhiWu1**

**CeO2 nanoparticles (NPs) have been well demonstrated as an antioxidant in protecting against oxidative stress-induced cellular damages and a potential therapeutic agent for various diseases thanks to their redox enzyme-mimicking activities. The Ce3+/Ce4+ ratio and oxygen vacancies on the surface have been considered as the major originations responsible for the redox enzyme-mimicking activities of CeO2 NPs. Herein, CeO2 nanostructures (nanocubes and nanorods) exposed different facets were synthesized via a facile hydrothermal method. The characterizations by X-ray photoelectron spectroscopy, Raman spectroscopy, and UV-Vis spectroscopy show that the Ce3+/Ce4+ ratio and oxygen vacancy content on the surfaces of as-synthesized CeO2 nanostructures are nearly at the same levels. Meanwhile, the enzymatic activity measurements indicate that the redox enzyme-mimicking activities of as-synthesized CeO2 nanostructures are greatly dependent on their exposed facets. CeO2 nanocubes with exposed {100} facets exhibit a higher peroxidase but lower superoxide dismutase activity than those of the CeO2 nanorods with exposed {110} facets. Our results provide new insights into the redox enzyme-mimicking activities of CeO2 nanostructures, as well as the design and synthesis of inorganic nanomaterials-based artificial enzymes.**

Enzyme-mimicking activities of various nanomaterials have attracted considerable interest in industrial catalysis and biomedical fields. CeO2 nanoparticles (NPs) have been well demonstrated as an antioxidant highly effective in protecting against oxidative stress-induced cellular damages and a potential therapeutic agent for various diseases, such as cancer, diabetes, chronic inflammation, brain autoimmune degenerative disease, and retinal pathologies[1–4.](#page-5-0) Numerous studies have shown that CeO2 NPs display high activities mimicking a series of redox enzymes, including superoxide dismutase (SOD)[5–7](#page-5-1), catalase[8–10](#page-5-2), peroxidase[11–15](#page-5-3), phosphotriesterase[16,](#page-5-4) phosphatas[e17](#page-5-5)[,18](#page-5-6), and oxidas[e19,](#page-5-7) which can scavenge reactive oxygen and nitrogen species. In CeO2, the intrinsic defects derived from the existence of Ce3+ result in the formation of oxygen vacancies compensating for the positive charge deficiency. The enzyme-mimicking activities of CeO2 NPs have been attributed to the auto-regenerative cycle of Ce3+/Ce4+ and oxygen vacancies on the surface of CeO2. Hence, the redox state of Ce ions on the surface plays a crucial role in the redox enzyme-mimicking activities of CeO2 NPs. Studies by Self *et al.*[5–10](#page-5-1) indicated that the high Ce3+/Ce4+ ratio on the surface of CeO2 NPs corresponded to high SOD mimetic activity, which was inhibited and transferred to catalase/peroxidase mimetic activities when the Ce3+/Ce4+ ratio decreased. On the other hand, some results suggested that increasing the Ce3+ concentration on the surface of CeO2 NPs was beneficial to peroxidase mimetic activity[11](#page-5-3),[12.](#page-5-8)

The exposed facets have been demonstrated to considerably contribute to the catalytic performances of various metals, alloys, and metal oxides[20–23](#page-5-9). Recent studies by Shen *et al.* based on theoretical calculations and experimental data confirmed that redox enzyme-mimicking activities of noble metals (Au, Ag, Pd, and Pt) were critically dependent on exposed facet[s24](#page-6-0). Previous studies also showed that the catalytic activities of CeO2 NPs in the oxidation of CO, NO, and propane were substantially related to the exposed facets[25–31](#page-6-1). So far, the relationship between the exposed facets of CeO2 NPs and their redox enzyme-mimicking activities has not yet been explored.

Herein, CeO2 nanocubes with exposed {100} facets and nanorods with exposed {110} facets were synthesized through a facile hydrothermal method. Phase structures and morphologies were characterized by X-ray

1 State Key Laboratory of Advanced Technology for Materials Synthesis and Processing, and Biomedical Material and Engineering Center, Wuhan University of Technology, Wuhan 430070, China. 2 School of Chemical Engineering and Life Science, Wuhan University of Technology, Wuhan 430070, China. 3 School of Chemical Engineering, Shangdong University of Technology, Zibo 255000, China. Correspondence and requests for materials should be addressed to Q.Z.W. (email: [wuqzh@whut.edu.cn)](mailto:wuqzh@whut.edu.cn)

<DESCRIPTION_FROM_IMAGE>This image is a composite of eight panels labeled (a) through (h), showing various microscopy and crystallographic data for nanostructures:

(a) Transmission electron microscopy (TEM) image showing a collection of nanoparticles with cubic morphology. Scale bar: 50 nm.

(b) High-resolution TEM image of a single nanoparticle, revealing lattice fringes. The (002) plane is labeled with a d-spacing of 0.27 nm. The [001] direction is indicated, forming a 90° angle with the (002) plane. Scale bar: 10 nm.

(c) Selected area electron diffraction (SAED) pattern with zone axis [100]. Diffraction spots are indexed, showing (020), (022), and (002) planes.

(d) Schematic representation of a cubic nanoparticle with {100} facets labeled.

(e) TEM image showing rod-like nanostructures. Scale bar: 200 nm.

(f) High-resolution TEM image of a single nanorod. The [001] growth direction is indicated, forming a 54.7° angle with the (111) plane. The d-spacing of the (111) plane is measured as 0.31 nm. Scale bar: 10 nm.

(g) SAED pattern with zone axis [110]. Diffraction spots are indexed, showing (111) and (002) planes.

(h) Schematic representation of a rod-like nanoparticle with {111} and {110} facets labeled. The growth direction [001] is indicated along the long axis of the rod.

This composite image provides comprehensive structural characterization of two types of nanostructures: cubic nanoparticles and rod-like nanoparticles, including their morphology, crystal structure, and growth directions.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image presents a compilation of Transmission Electron Microscopy (TEM) and High-Resolution Transmission Electron Microscopy (HRTEM) images of as-synthesized CeO2 (cerium dioxide) nanostructures. The figure is divided into multiple panels labeled (a) through (h), showcasing two types of nanostructures: nanocubes and nanorods.

Panels (a-f) focus on CeO2 nanocubes:
- (a) and (b) likely show lower magnification TEM images of the nanocubes, providing an overview of their size distribution and morphology.
- (c) and (d) are probably higher magnification HRTEM images, revealing the crystalline structure of individual nanocubes.
- (e) and (f) appear to be additional HRTEM images, possibly showing different orientations or facets of the nanocubes.

Panels (g) and (h) present information on CeO2 nanorods:
- These panels likely show TEM and HRTEM images of the nanorod structures, illustrating their elongated morphology and crystalline nature.

Panels (c) and (g) display Fast Fourier Transform (FFT) patterns corresponding to the areas marked with white lines in panels (b) and (f), respectively. These FFT patterns provide information about the crystallographic structure and orientation of the nanostructures.

Panels (e) and (h) showcase proposed models of the CeO2 nanocubes and nanorods, respectively. These models were created using software called VESTA (version 32), which is commonly used for visualizing crystal structures and electron densities.

The figure caption emphasizes that these are as-synthesized CeO2 nanostructures, indicating that the images represent the particles immediately after their synthesis, without any post-processing or modifications.

This comprehensive figure provides a detailed characterization of the morphology, size, and crystalline structure of CeO2 nanocubes and nanorods using advanced electron microscopy techniques.</DESCRIPTION_FROM_IMAGE>

diffraction (XRD), transmission electron microscopy (TEM), and high resolution transmission electron microscopy (HRTEM). The surface information of the cerium element located on the surface of the CeO2 nanostructures was analyzed by X-ray photoelectron spectroscopy (XPS), Raman spectroscopy, and UV-Vis spectroscopy. The specific surface areas of the CeO2 nanostructures were measured by nitrogen adsorption in accordance with the Brunauer-Emmett-Teller (BET) method. Furthermore, the peroxidase and SOD mimetic activities of the CeO2 nanostructures were evaluated.

#### **Results and Discussion**

[Figure 1](#page-1-0) shows the TEM and HRTEM images of the as-synthesized CeO2 nanostructures. Homogeneous CeO2 nanocubes were obtained at an average size of approximately 13± 3 nm [(Fig. 1a](#page-1-0)). The HRTEM image displays the well-aligned crystal planes, indicating the single-crystalline nature of CeO2 nanocubes [(Fig. 1b](#page-1-0)). The interplanar spacing of approximately 0.27 nm could be indexed to the (200) plane of the face-centered cubic CeO2. The spots that appeared on the fast Fourier transformation (FFT) pattern of the area marked with white lines in [Fig. 1b](#page-1-0) were indexed, and the zone axis was found to be [100] ([Fig. 1c](#page-1-0)). Accordingly, a three-dimensional model describing the nanocubes is shown in [Fig. 1d](#page-1-0), representing a cubic structure enclosed with {100} facets. CeO2 nanorods with an average diameter of approximately 10± 3 nm were obtained by adjusting the synthesis parameters ([Fig. 1e](#page-1-0)). The well-aligned crystal planes observed from the HRTEM image in [Fig. 1f](#page-1-0) also indicate the single-crystalline structure of CeO2 nanorods.

The interplanar spacing of approximately 0.31 nm could be indexed to the (111) plane. The spots that appeared on the FFT pattern of the area marked with white lines in [Fig. 1f](#page-1-0) were indexed, and the zone axis was found to be [110] [(Fig. 1g)](#page-1-0). Accordingly, a three-dimensional model describing the nanorods is shown in [Fig. 1h,](#page-1-0) suggesting a rod-like structure enclosed with {110} and {111} facets and truncated by (100) and (00Ī) facets at the z-axis.

The phase structure of the as-synthesized CeO2 nanostructures was identified by XRD characterization. All of the diffraction peaks in the XRD patterns could be indexed to the cubic fluorite structure of CeO2 (JCPDS Card 34–0394) ([Fig. 2a)](#page-2-0). Pawley method[34](#page-6-2) was adopted to obtain the full width at half maximum (FWHM) of the individual peak in the XRD patterns. The result is illustrated as Williamson-Hall plots ([Fig. 2b)](#page-2-0)[35.](#page-6-3) The coefficient of the fitted lines reflects the magnitude of the microstrain (a higher coefficient denotes a higher microstrain), and the intercept of the fitted lines indicates the crystallite size. No microstrain existed in the CeO2 nanocubes, but a large microstrain was observed in the CeO2 nanorods (0% vs. 0.98%). Meanwhile, the crystallite size calculated from the intercept of the fitted lines was approximately 13.5nm for the CeO2 nanocubes and 10.7nm for the CeO2 nanorods, consistent with the average size obtained from the TEM images. In addition, the BET specific surface area measured by N2 adsorption-desorption isotherms was approximately 70.9m2 /g for the CeO2 nanocubes and 95.4m2 /g for the CeO2 nanorods, indicating the larger specific surface area of the CeO2 nanorods compared with that of the CeO2 nanocubes.

The surface chemical information of the CeO2 nanostructures was analyzed by XPS, Raman spectroscopy, and UV-Vis spectroscopy. The peaks in the XPS spectra were fitted using the Gaussian function ([Fig. 3a,](#page-2-1)b). The areas of the fitting peaks ascribed to Ce3+ and Ce4+ were used to calculate the contents of Ce3+ and Ce4+ on the surface of the CeO2 nanostructures[15,](#page-5-10)[36.](#page-6-4) The calculations yielded approximately 31.8% of Ce3+ for the CeO2

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (a) and (b), presenting data related to nanocubes and nanorods.

Graph (a) shows X-ray diffraction (XRD) patterns:
- X-axis: 2θ (degrees), ranging from 20° to 100°
- Y-axis: Intensity (arbitrary units)
- Three patterns are shown:
  1. Nanocubes (top line)
  2. Nanorods (middle line)
  3. PDF#34-0394 reference pattern (bottom vertical lines)
- Major peaks are labeled with Miller indices: (111), (200), (220), (311), (222), (400), (331), (420), (422), (333)
- The nanocubes pattern shows sharper and more intense peaks compared to nanorods
- Both patterns match the reference PDF#34-0394, indicating the same crystal structure

Graph (b) presents a Williamson-Hall plot:
- X-axis: sin(θ), ranging from 0 to 0.8
- Y-axis: FWHM × cos(θ), ranging from 0 to 6
- Data and fitted lines for both nanocubes and nanorods are shown:
  1. Nanorods: diamond markers with a fitted line showing a positive slope
  2. Nanocubes: square markers with a fitted line showing almost no slope (horizontal)
- The nanorods data shows more scatter and a steeper slope compared to nanocubes
- Error bars are visible on some data points

This image compares the structural characteristics of nanocubes and nanorods, likely of the same material. The XRD patterns indicate crystallinity and phase purity, while the Williamson-Hall plot provides information about crystallite size and strain in the nanostructures. The differences in peak broadening and slope in the Williamson-Hall plot suggest that nanorods have more strain or defects compared to nanocubes.</DESCRIPTION_FROM_IMAGE>

<span id="page-2-0"></span>**Figure 2.** (**a**) XRD patterns of the as-synthesized CeO2 nanostructures. (**b**) Williamson-Hall plots of the CeO2 nanostructures derived from the XRD patterns. The coefficient of the fitted lines indicates the microstrain (a higher coefficient denotes a higher microstrain), and the intercept of the fitted lines indicates the crystallite size (a higher intercept means a smaller size). The linear and nonlinear fittings were performed using software Fity[k33](#page-6-9).

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled (a), (b), (c), and (d), each providing different spectroscopic data for nanocubes and nanorods of cerium oxide.

(a) X-ray photoelectron spectroscopy (XPS) spectrum for nanocubes with {100} facets:
- X-axis: Binding Energy (eV) ranging from 880 to 920 eV
- Y-axis: Intensity (arbitrary units)
- Shows fitted peaks for Ce3+ and Ce4+ oxidation states
- Data points, fitted curve, and residual are plotted

(b) XPS spectrum for nanorods with {110} facets:
- X-axis: Binding Energy (eV) ranging from 880 to 920 eV
- Y-axis: Intensity (arbitrary units)
- Shows fitted peaks for Ce3+ and Ce4+ oxidation states
- Data points, fitted curve, and residual are plotted

(c) Raman spectroscopy data:
- X-axis: Raman Shift (cm^-1) ranging from 200 to 1000 cm^-1
- Y-axis: Intensity (a.u.)
- Compares nanocubes {100} and nanorods {110}
- Notable features:
  1. F2g peak around 460 cm^-1
  2. Oxygen Vacancy peak around 600 cm^-1
- Excitation wavelength (λex) = 325 nm

(d) UV-Visible absorption spectroscopy:
- X-axis: Wavelength (nm) ranging from 200 to 400 nm
- Y-axis: Absorbance (a.u.)
- Compares nanocubes {100} and nanorods {110}
- Notable features:
  1. Ce3+ absorption band around 250 nm
  2. Ce4+ absorption band around 300 nm

The graphs collectively provide information on the electronic structure, oxidation states, and optical properties of cerium oxide nanocubes and nanorods with different exposed crystal facets.</DESCRIPTION_FROM_IMAGE>

<span id="page-2-1"></span>**Figure 3.** (**a,b**) XPS spectra of the as-synthesized CeO2 nanostructures. The peaks in XPS spectra were fitted using Gaussian function and ascribed to Ce3+ and Ce4+, respectively. (**c**) Raman spectra of the as-synthesized CeO2 nanostructures at the excitation wavelength of 325nm. (**d**) UV-Vis spectra of the as-synthesized CeO2 nanostructures.

nanocubes and 31.2% of Ce3+ for the CeO2 nanorods, suggesting the similar Ce3+ contents on the surfaces of the as-synthesized CeO2 nanostructures. [Figure 3c](#page-2-1) shows the Raman spectra of CeO2 nanostructures at the excitation wavelength of 325nm. The strong peak at 462 cm−1 could be ascribed to the F2g mode[37,](#page-6-6)[38.](#page-6-7) The asymmetrical and broader peak in the Raman spectrum of the CeO2 nanorods could be attributed to the smaller crystallite size and larger microstrain compared with those of the CeO2 nanocubes[39](#page-6-8). Notably, the two CeO2 nanostructures exhibited similar Raman absorption at 595 cm−1 , which corresponds to the characteristic peak of oxygen vacancy[37](#page-6-6),[38.](#page-6-7)

This result implies that oxygen vacancies on the surfaces of both CeO2 nanostructures were at the same level. The absorption peak at 250nm in UV-Vis spectra of CeO2 has been ascribed to Ce3+, and the absorption peak at

<DESCRIPTION_FROM_IMAGE>The image presents a graph comparing the absorbance at 652 nm over time for three different samples: nanocubes {100}, nanorods {110}, and a blank control. The x-axis represents time in minutes, ranging from 0 to 30 minutes. The y-axis shows absorbance at 652 nm, with values ranging from 0 to 2.

For nanocubes {100}, represented by square markers:
- The absorbance increases rapidly from 0 to about 10 minutes, reaching a maximum of approximately 1.1.
- From 10 to 30 minutes, the absorbance remains relatively stable with a slight decrease, ending at about 0.9.
- There are large error bars throughout the curve, indicating significant variability in measurements.

For nanorods {110}, represented by diamond markers:
- The absorbance shows a gradual increase over time.
- The values start near 0 and reach about 0.2 by the end of the 30-minute period.
- The error bars are smaller compared to the nanocubes, suggesting less variability.

For the blank control, represented by circle markers:
- The absorbance remains close to 0 throughout the entire time range.
- There is minimal variation, with values consistently below 0.1.

The graph demonstrates a clear difference in absorbance behavior between the nanocubes and nanorods, with nanocubes showing a much higher and faster increase in absorbance compared to nanorods. The blank control confirms that the observed changes are due to the nanostructures and not background interference.

This data suggests that the {100} facets of nanocubes have a significantly higher activity or reactivity compared to the {110} facets of nanorods in the context of the experiment being conducted, which likely involves some form of surface-mediated reaction or adsorption process monitored at 652 nm.</DESCRIPTION_FROM_IMAGE>

<span id="page-3-0"></span>**Figure 4. Peroxidase mimetic activity of the CeO2 nanostructures.** The change in absorbance at 652nm represents the conversion of TMB to oxidized TMB (TMBox).

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled (a), (b), (c), and (d), each showing the relationship between substrate concentration and initial reaction velocity (V_init) for different nanostructures and substrates.

(a) Nanocubes {100} with TMB as substrate:
- X-axis: TMB Concentration (mM), range 0-3 mM
- Y-axis: V_init (10^-4 • Ms^-1), range 0-6
- Shows a rapid increase in V_init up to ~1 mM TMB, then plateaus
- Experimental data points with error bars closely follow the fitting line

(b) Nanocubes {100} with H2O2 as substrate:
- X-axis: H2O2 Concentration (mM), range 0-2000 mM
- Y-axis: V_init (10^-4 • Ms^-1), range 0-8
- Rapid increase in V_init up to ~500 mM H2O2, then gradual increase to plateau
- Experimental data points with larger error bars, generally following the fitting line

(c) Nanorods {110} with TMB as substrate:
- X-axis: TMB Concentration (mM), range 0-3 mM
- Y-axis: V_init (10^-5 • Ms^-1), range 0-2
- Rapid increase in V_init up to ~0.5 mM TMB, then plateaus
- Experimental data points with error bars, closely following the fitting line

(d) Nanorods {110} with H2O2 as substrate:
- X-axis: H2O2 Concentration (mM), range 0-2000 mM
- Y-axis: V_init (10^-5 • Ms^-1), range 0-3
- Nearly linear increase in V_init across the entire H2O2 concentration range
- Experimental data points with error bars, generally following the fitting line

All graphs show Michaelis-Menten-like kinetics, except (d) which appears more linear. The nanocubes {100} show higher V_init values compared to nanorods {110} for both substrates. The graphs illustrate the dependence of catalytic activity on nanostructure morphology and substrate type.</DESCRIPTION_FROM_IMAGE>

<span id="page-3-1"></span>**Figure 5. Steady-state kinetic assay of peroxidase mimetic activity.** 

295nm has been ascribed to Ce4+[6](#page-5-11)[,10.](#page-5-12) No obvious absorption peak belonging to Ce3+ was observed for both of the CeO2 nanostructures [(Fig. 3d](#page-2-1)), implying the low Ce3+ content in the crystal structure of the CeO2 nanostructures. Therefore, these results strongly demonstrated that both the Ce3+/Ce4+ ratio and oxygen vacancies on the surface

of the as-synthesized CeO2 nanostructures were nearly at the same levels. The peroxidase-mimicking activity of the CeO2 nanostructures was evaluated by monitoring the catalytic reaction between H2O2 and tetramethylbenzidine (TMB) in acetic buffer solution (equation 1).

$$\text{TMB} + \text{H}_2\text{O}_2 \rightarrow \text{TMB}_{\text{ox}} + 2\text{H}_2\text{O} + \text{O}_2 \tag{1}$$

The change in absorbance at 652 nm indicates the formation of TMBox. Almost no change in absorbance was observed within 30 min ([Fig. 4)](#page-3-0), implying that H2O2 failed to oxidize TMB in the absence of catalysts. Subsequently, in the presence of CeO2 nanorods with exposed {110} facets, a slight increase in absorbance was observed with reaction time extension, suggesting that the TMB was slowly oxidized by H2O2. The absorbance was dramatically increased with the reaction prolongation in the presence of CeO2 nanocubes, demonstrating that the oxidation of TMB by H2O2 was greatly accelerated by the CeO2 nanocubes with exposed {100} facets.

[Figure 5](#page-3-1) shows the results of a steady-state kinetic assay conducted by varying the concentrations of TMB and H2O2. Kinetic parameters were calculated by fitting experimental data to the Michaelis-Menten equation. *V*max is the maximal reaction velocity, and *Km* is the Michaelis constant. A higher *V*max value represents a higher conversion rate from substrate to product, and a higher *Km* denotes a smaller catalyst affinity to the substrate. Under varied TMB concentrations ([Fig. 5a,](#page-3-1)c), the *Km* value was approximately 0.217 mM for the CeO2 nanocubes and approximately 0.240mM for the CeO2 nanorods, consistent with the values reported previously[14,](#page-5-13)[40](#page-6-10). These results suggest the similar affinities of TMB to both of the CeO2 nanostructures. However, *V*max value was approximately 8.2×10−8 M/s for the CeO2 nanocubes and 0.4×10−8 M/s for the CeO2 nanorods, indicating that the rate of the reaction catalyzed by the CeO2 nanocubes with exposed {100} facets was 23 times higher than that catalyzed by the CeO2 nanorods with exposed {110} facets. Meanwhile, under varying H2O2 concentrations, the *Km* and *V*max for the CeO2 nanocubes were approximately 153.6 mM and 12.2×10−8 M/s, respectively. In such cases, the *Km* obtained is far greater than that obtained from the varied TMB levels, suggesting that the affinity of H2O2 on the surface of the CeO2 nanocubes was far smaller than that of TMB. While the larger *V*max in the case of varying H2O2 concentrations than that in the case of varying TMB concentrations suggests that the catalytic reaction was more sensitive to the H2O2 concentration. Notably, the Michaelis-Menten equation failed to describe the relation between the concentration of H2O2 and the initial velocity of the reaction in the presence of the CeO2 nanorods [(Fig. 5d](#page-3-1)). Instead, a linear relation was observed, implying a simple first-order reaction dependent on the concentration of the H2O2 catalyzed by the CeO2 nanorods.

The peroxidase-mimicking activity of the CeO2 nanorods was also measured after a heating treatment at 650 °C for 48 h because the fitting of the XRD patterns reveals the existence of microstrain in the CeO2 nanorods. However, no significant increase in enzyme activity was observed in despite of the disappearance of the microstrain in the CeO2 nanorods after annealing (see Supplementary Figs S1 and S2). Hence, the peroxidase mimetic activities of the CeO2 nanostructures were influenced by the exposed facets instead of the microstrain.

The SOD mimetic activity of the CeO2 nanostructures was also evaluated with colorimetric assay kits. The results indicate that the SOD mimetic activity of the CeO2 nanorods with exposed {110} facets was four times higher than that of the CeO2 nanocubes with exposed {100} facets (see Supplementary Fig. S3). After annealing to remove the microstrain, the CeO2 nanorods still exhibited a higher SOD mimetic activity than that of the CeO2 nanocubes. Thus, the SOD mimetic activity of the CeO2 nanostructures may have also depended on the exposed facets instead of the microstrain.

Theoretical calculations and experimental data have indicated that redox enzymes-mimicking activities of CeO2 could be ascribed to the transformation between Ce4+ and Ce3+ ions and the generation of oxygen vacancies compensating for the positive charge deficiency on the surfaces[41–43.](#page-6-11) However, in the present study, both the Ce3+/Ce4+ ratio and oxygen vacancies were of the same level on the surfaces of the two CeO2 nanostructures, which displayed different redox enzyme-mimicking activities. Therefore, the different exposed facets should be responsible for such different catalytic performances. It is generally known that CeO2 possesses three low-index facets: {111}, {110}, and {100} facet. Among which, CeO2 {110} surface is a type I ionic crystal surface with neutral atomic planes due to a stoichiometric balance between anions and cations, while CeO2 {111} surface is a type II ionic crystal surface with charged planes but without net dipole moment perpendicular to the surface. Both CeO2 {110} and {111} surfaces have relatively low surface energies and display modest relaxations on the surfaces compared to the bulk. By comparison, CeO2 {100} surface has a nearly infinite free energy and therefore require a major reconstruction compared to the bulk because such a surface consists of alternatively charged planes and thus produces a dipole moment perpendicular to the surface. Accordingly, the stability of three facets decreased in an order of {111} >{110} >{100}, which means the higher catalytic activity of {100} facets than that of {110} and {111} facets[41–43](#page-6-11). According to an energy-based model describing the facet-dependent redox enzyme-mimicking activities of noble metal NPs, the dissociative adsorption of O2 on the metal surfaces was proposed to be the key step that provided the surfaces with oxidase-like activitie[s24](#page-6-0). Meanwhile, the protonation of O2 ·− and adsorption and rearrangement of HO2 · on metal surfaces were mainly responsible for SOD-like activity of these metals[24.](#page-6-0) Therefore, it is reasonable to speculate that the facet-dependent adsorption, activation, and rearrangement processes between the reacting species and the exposed facets may play crucial roles on the redox enzyme-mimicking activities of CeO2 nanostructures in addition to the transformation between Ce4+ and Ce3+ions ratio and the generation of oxygen vacancies on the surfaces. Unfortunately, although numerous theoretical and experimental investigations have been performed in order to interpret the relationship between the catalytic activity and the surface compositions and crystal structures, the accurate atomic structures of CeO2 nanostructures, particularly for the CeO2 with exposed {110} and {100} facets, still remain indistinc[t41–44](#page-6-11). Therefore, more theoretical and experimental investigations are necessary to elucidate the precise mechanisms on the influences of redox enzyme-mimicking activities of CeO2 nanostructures by their exposed facets.

### **Conclusion**

In summary, we have shown that the redox enzyme mimetic activities of the CeO2 nanostructures were determined by the exposed facets. At the same levels of Ce3+/Ce4+ ions and oxygen vacancies on the surfaces, CeO2 nanocubes with exposed {100} facets displayed a higher peroxidase but lower SOD mimetic activity than those of the CeO2 nanorods with exposed {110} facets. Therefore, integrated factors, including exposed facets, Ce3+/Ce4+ ratio, and oxygen vacancy surface content, should be carefully considered when CeO2 nanostructures are employed as antioxidant and therapeutic agent for various diseases on the basis of their redox enzyme-mimicking activities. Our results provide new insight into the redox enzyme-mimicking activities of CeO2 nanostructures, as well as the design and synthesis of other inorganic nanomaterials-based artificial enzymes.

#### **Methods**

**Materials.** Sodium hydroxide (NaOH, 96%), hydrogen peroxide (H2O2, 30%), acetic acid (99.5%) and cerium nitrate hexahydrate (Ce(NO3)3·6H2O, 99%) were of analytical grade and purchased from Sinopharm Chemical Reagent Co. (Shanghai, China). 3,3′,5,5′-tetramethyl-benzidine (TMB, 98%) was obtained from Aladdin (Shanghai, China). Silicon (SRM™ 640e) was obtained from National Institute of Standards and Technology (NIST). All reagents were used as received without further purification.

**Synthesis of CeO2 nanostructures.** In a typical synthesis, 20mL of Ce(NO3) 3·6H2O solution (0.1mol/L) was added dropwise into NaOH solution (0.1mol/L for nanocubes and 12mol/L for nanorods). The mixed solution was then transferred and sealed in a 50mL Teflon-lined stainless steel autoclave, with subsequent heating for 24h. The heating temperature was kept at 140 °C for nanocubes and 100 °C for nanorods. After the reaction, the precipitate was collected by centrifugation (9000 rpm, 5min) and washed alternately with ethanol and deionized water several times, and then dried at 60 °C in the air.

**Characterization of CeO2 nanostructures.** The phase structure of the samples was identified by powder X-ray diffraction (XRD) on a D8 Advance diffractometer using Cu Kα radiation (λ = 1.5418Å). NIST SRM™ 640e was used to obtain the instrumental broadening profile. X-ray photoelectron spectroscopy (XPS) measurements were performed on a spectrometer (Axis Ultra DLD-600W, Kratos Analytical Ltd.) using Al Kα radiation as the excitation source. The morphologies of the samples were observed using high resolution transmission electron microscopy (HRTEM, JEM-2100F STEM/EDS, JEOL Corp, Japan). The Raman spectra of the samples were recorded by a Raman spectrometer with a 325nm laser excitation (VERTEX 70, Bruker, Germany). The UV-Vis spectra of the samples were recorded with an ultraviolet–visible spectrometer (Shimadzu Corp., UV-2550 PC).

**Enzyme mimetic activity of CeO2 nanostructures.** The peroxidase mimetic activity of CeO2 was evaluated by monitoring the redox reaction between TMB and H2O2 in the presence of the CeO2 nanostructures. Typically, 1mL acetate buffer solution (50mM, pH=4.0) containing 25μg CeO2, 0.5μmol TMB, and 1mol H2O2 was added in a cuvette. The reaction was monitored using an ultraviolet–visible spectroscopy (Shimadzu Corp., UV-2550 PC) at wavelength of 652 nm. The measurement was recorded at an interval of one minute and the temperature was kept at 25 °C. In order to obtain the apparent kinetic parameters, experiments varying concentrations of the substrates were carried out. The measurement was recorded at an interval of 10 seconds in order to obtain a higher accuracy. All the rest reaction conditions were unchanged. More details on the calculation of apparent kinetic parameters can be found in the Supplementary Information. The SOD mimetic activity of CeO2 nanostructures was determined with colorimetric assay kits (Nanjing Jiancheng Bioengineering Institute, China).

**Data process.** All the non-linear curve fittings (XRD, XPS and Michaelis-Menten Kinetic) were processed using software Fityk (version 1.3.0[)33.](#page-6-9) All the experiments were repeated at least triplicated to obtain the standard deviation.

#### **References**

- <span id="page-5-0"></span>1. Celardo, I., Pedersen, J. Z., Traversa, E. & Ghibelli, L. Pharmacological potential of cerium oxide nanoparticles. *Nanoscale* **3,** 1411–1420 (2011).
- 2. Wason, M. S. & Zhao, J. Cerium oxide nanoparticles: Potential applications for cancer and other diseases. *Am. J. Transl. Res.* **5,** 126–131 (2013).
- 3. Xu, C. & Qu, X. Cerium oxide nanoparticle: a remarkably versatile rare earth nanomaterial for biological applications. *NPG Asia Mater*. **6,** e90 (2014).
- 4. Heckman, K. L. *et al.* Custom Cerium Oxide Nanoparticles Protect against a Free Radical Mediated Autoimmune Degenerative Disease in the Brain. *ACS Nano* **7,** 10582–10596 (2013).
- <span id="page-5-1"></span>5. Korsvik, C., Patil, S., Seal, S. & Self, W. T. Superoxide dismutase mimetic properties exhibited by vacancy engineered ceria nanoparticles. *Chem. Commun.* 1056–1058 (2007).
- <span id="page-5-11"></span>6. Heckert, E. G., Karakoti, A. S., Seal, S. & Self, W. T. The role of cerium redox state in the SOD mimetic activity of nanoceria. *Biomaterials* **29,** 2705–2709 (2008).
- 7. Liu, X. *et al.* Apoferritin–CeO2 nanotruffle that has excellent artificial redox enzyme activity. *Chem. Commun.* **48,** 3155–3157 (2012).
- <span id="page-5-2"></span>8. Pirmohamed, T. *et al.* Nanoceria exhibit redox state-dependent catalase mimetic activity. *Chem. Commun.* **46,** 2736–2738 (2010).
- 9. Singh, S. *et al.* A phosphate-dependent shift in redox state of cerium oxide nanoparticles and its effects on catalytic properties. *Biomaterials* **32,** 6745–6753 (2011).
- <span id="page-5-12"></span>10. Singh, R. & Singh, S. Role of Phosphate on Stability and Catalase Mimetic Activity of Cerium Oxide Nanoparticles. *Colloids Surfaces B Biointerfaces* **132,** 78–84 (2015).
- <span id="page-5-3"></span>11. Xiao, X., Luan, Q., Yao, X. & Zhou, K. Single-crystal CeO2 nanocubes used for the direct electron transfer and electrocatalysis of horseradish peroxidase. *Biosens. Bioelectron*. **24,** 2447–2451 (2009).
- <span id="page-5-8"></span>12. Li, X., Zhang, Z., Tao, L., Li, Y. & Li, Y. Y. A chemiluminescence microarray based on catalysis by CeO2 nanoparticles and its application to determine the rate of removal of hydrogen peroxide by human erythrocytes. *Appl. Biochem. Biotechnol.* **171,** 63–71 (2013).
- 13. Wang, N., Sun, J., Chen, L., Fan, H. & Ai, S. A Cu2(OH)3Cl-CeO2 nanocomposite with peroxidase-like activity, and its application to the determination of hydrogen peroxide, glucose and cholesterol. *Microchim. Acta* **182,** 1733–1738 (2015).
- <span id="page-5-13"></span>14. Tian, Z. *et al.* Highly sensitive and robust peroxidase-like activity of porous nanorods of ceria and their application for breast cancer detection. *Biomaterials* **59,** 116–124 (2015).
- <span id="page-5-10"></span>15. Zhao, H., Dong, Y., Jiang, P., Wang, G. & Zhang, J. Highly Dispersed CeO2 on TiO2 Nanotube: A Synergistic Nanocomposite with Superior Peroxidase-Like Activity. *ACS Appl. Mater. Interfaces* **7,** 6451–6461 (2015).
- <span id="page-5-4"></span>16. Vernekar, A. A., Das, T. & Mugesh, G. Vacancy-Engineered Nanoceria: Enzyme Mimetic Hotspots for the Degradation of Nerve Agents. *Angew. Chemie Int. Ed.* **54,** 1–6 (2015).
- <span id="page-5-5"></span>17. Kuchma, M. H. *et al.* Phosphate ester hydrolysis of biologically relevant molecules by cerium oxide nanoparticles. *Nanomedicine Nanotechnology, Biol. Med*. **6,** 738–744 (2010).
- <span id="page-5-7"></span><span id="page-5-6"></span>18. Tan, F. *et al.* An efficient method for dephosphorylation of phosphopeptides by cerium oxide. *J. Mass Spectrom.* **43,** 628–632 (2008). 19. Asati, M. A., Santra, D. S., Kaittanis, M. C., Nath, D. S. & Perez, P. J. M. Oxidase Activity of Polymer-Coated Cerium Oxide Nanoparticles. *Angew. Chem. Int. Ed.* **48,** 2308–2312 (2010).
- <span id="page-5-9"></span>20. Tian, N., Zhou, Z.-Y., Sun, S.-G., Ding, Y. & Wang, Z. L. Synthesis of Tetrahexahedral Platinum Nanocrystals with High-Index Facets and High Electro-Oxidation Activity. *Science* **316,** 732–735 (2007).
- 21. Mu, J., Zhang, L., Zhao, G. & Wang, Y. The crystal plane effect on the peroxidase-like catalytic properties of Co3O4 nanomaterials. *Phys. Chem. Chem. Phys.* **16,** 15709 (2014).

- 22. Yu, J., Low, J., Xiao, W., Zhou, P. & Jaroniec, M. Enhanced photocatalytic CO2-Reduction activity of anatase TiO2 by Coexposed {001} and {101} facets. *J. Am. Chem. Soc.* **136,** 8839–8842 (2014).
- 23. Lin, Y., Ren, J. & Qu, X. Catalytically active nanomaterials: a promising candidate for artificial enzymes. *Acc. Chem. Res.* **47,** 1097–1105 (2014).
- <span id="page-6-0"></span>24. Shen, X. *et al.* Mechanisms of Oxidase and Superoxide Dismutation-like Activities of Gold, Silver, Platinum, and Palladium, and Their Alloys: A General Way to the Activation of Molecular Oxygen. *J. Am. Chem. Soc.* **137,** 15882–15891 (2015).
- <span id="page-6-1"></span>25. Aneggi, E., Llorca, J., Boaro, M. & Trovarelli, A. Surface-structure sensitivity of CO oxidation over polycrystalline ceria powders. *J. Catal.* **234,** 88–95 (2005).
- 26. Agarwal, S., Zhu, X., Hensen, E. J. M., Mojet, B. L. & Lefferts, L. Surface-Dependence of Defect Chemistry of Nanostructured Ceria. *J. Phys. Chem. C* **119,** 12423–12433 (2015).
- 27. Hu, Z. *et al.* Effect of Ceria Crystal Plane on the Physicochemical and Catalytic Properties of Pd/Ceria for CO and Propane Oxidation. *ACS Catal*. **6,** 2265–2279 (2016).
- 28. Tang, K. *et al.* The Effect of Exposed Facets of Ceria to the Nickel Species in Nickel-Ceria Catalysts and Their Performance in a NO+ CO Reaction. *ACS Appl. Mater. Interfaces* **7,** 26839–26849 (2015).
- 29. Sun, C., Li, H. & Chen, L. Nanostructured ceria-based materials: synthesis, properties, and applications. *Energy Environ. Sci.* **5,** 8475–8505 (2012).
- 30. Zhang, D., Du, X., Shi, L. & Gao, R. Shape-controlled synthesis and catalytic application of ceria nanomaterials. *Dalton Trans*. **41,** 14455–14475 (2012).
- 31. Younis, A., Chu, D., Kaneti, Y. V. & Li, S. Tuning the surface oxygen concentration of {111} surrounded ceria nanocrystals for enhanced photocatalytic activities. *Nanoscale* **8,** 378–387 (2016).
- <span id="page-6-5"></span>32. Momma, K. & Izumi, F. VESTA 3 for three-dimensional visualization of crystal, volumetric and morphology data. *J. Appl. Crystallogr*. **44,** 1272–1276 (2011).
- <span id="page-6-9"></span>33. Wojdyr, M. *Fityk.* A general-purpose peak fitting program. *J. Appl. Crystallogr*. **43,** 1126–1128 (2010).
- <span id="page-6-2"></span>34. Pawley, G. S. Unit-cell refinement from powder diffraction scans. *J. Appl. Crystallogr*. **14,** 357–361 (1981).
- <span id="page-6-3"></span>35. Scardi, P., Leoni, M. & Delhez, R. Line broadening analysis using integral breadth methods: A critical review. *J. Appl. Crystallogr.* **37,** 381–390 (2004).
- <span id="page-6-4"></span>36. Natile, M. M. & Glisenti, A. CoOx/CeO2 Nanocomposite Powders: Synthesis, Characterization, and Reactivity. *Chem. Mater.* **17,** 3403–3414 (2005).
- <span id="page-6-6"></span>37. Reddy, B. M. *et al.* Surface Characterization of CeO2/SiO2 and V2O5/CeO2/SiO2 Catalysts by Raman, XPS, and Other Techniques. *J. Phys. Chem. B* **106,** 10964–10972 (2002).
- <span id="page-6-7"></span>38. Wu, Z., Li, M., Howe, J., Meyer, H. M. & Overbury, S. H. Probing defect sites on CeO2 nanocrystals with well-defined surface planes by raman spectroscopy and O2 adsorption. *Langmuir* **26,** 16595–16606 (2010).
- <span id="page-6-8"></span>39. Spanier, J. E., Robinson, R. D., Zhang, F., Chan, S.-W. & Herman, I. P. Size-dependent properties of CeO2-y nanoparticles as studied by Raman scattering. *Phys. Rev. B* **64,** 245407 (2001).
- <span id="page-6-10"></span>40. Gao, L. *et al.* Intrinsic peroxidase-like activity of ferromagnetic nanoparticles. *Nat. Nanotechnol*. **2,** 577–583 (2007).
- <span id="page-6-11"></span>41. Huang, W. Oxide Nanocrystal Model Catalysts. *Acc. Chem. Res.* **49,** 520–527 (2016).
- 42. Mullins, D. R. The surface chemistry of cerium oxide. *Surf. Sci. Rep.* **70,** 42–85 (2015).
- 43. Paier, J., Penschke, C. & Sauer, J. Oxygen defects and surface chemistry of ceria: Quantum chemical studies compared to experiment. *Chem. Rev.* **113,** 3949–3985 (2013).
- 44. Conesa, J. Computer modeling of surfaces and defects on cerium dioxide. *Surf. Sci*. **339,** 337–352 (1995).

#### **Acknowledgements**

This work was financially supported by the Natural Science Foundation of China (Nos 30800256 and 31301735), and the basic research project of Wuhan Science and Technology Bureau (No. 2014060101010041).

### **Author Contributions**

Y.Y., Z.M., W.H. and L.L. synthesized the CeO2 nanostructures and evaluated the enzyme mimicking activities. Y.Y. analyzed the data. Y.Y., J.L. and Q.W. designed the whole work and drafted the manuscript. All the authors revised the manuscript.

#### **Additional Information**

**Supplementary information** accompanies this paper at<http://www.nature.com/srep>

**Competing financial interests:** The authors declare no competing financial interests.

**How to cite this article**: Yang, Y. *et al.* Redox enzyme-mimicking activities of CeO2 nanostructures: Intrinsic influence of exposed facets. *Sci. Rep.* **6**, 35344; doi: 10.1038/srep35344 (2016).

This work is licensed under a Creative Commons Attribution 4.0 International License. The images or other third party material in this article are included in the article's Creative Commons license, unless indicated otherwise in the credit line; if the material is not included under the Creative Commons license, users will need to obtain permission from the license holder to reproduce the material. To view a copy of this license, visit<http://creativecommons.org/licenses/by/4.0/>

© The Author(s) 2016