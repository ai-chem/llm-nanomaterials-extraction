<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Contents lists available at [ScienceDirect](http://www.sciencedirect.com/science/journal/00219797)

# Journal of Colloid and Interface Science

<DESCRIPTION_FROM_IMAGE>This image appears to be the cover of a scientific journal titled "Colloid and Interface Science Communications". The cover features a composite illustration related to colloid and interface science concepts:

The main visual elements include:

1. A circular arrangement of spherical particles, likely representing a colloidal system or nanoparticle assembly. These particles appear to be in a liquid medium, suggesting a colloidal suspension or emulsion.

2. An overlaid molecular structure diagram, showing a hexagonal lattice pattern typical of certain nanomaterials or 2D materials like graphene. This structure extends across part of the spherical particle arrangement.

3. In the background, there are larger spherical objects that could represent macroscale particles or droplets in a multiphase system.

The combination of these elements visually represents the multi-scale nature of colloid and interface science, spanning from molecular and nanoscale structures to macroscopic particles and interfaces.

The journal's title is prominently displayed at the top of the cover. At the bottom, there is an Elsevier logo, indicating this is an Elsevier publication.

This cover image effectively conveys the interdisciplinary nature of colloid and interface science, showcasing various structural scales and phenomena studied in this field.</DESCRIPTION_FROM_IMAGE>

journal homepage: [www.elsevier.com/locate/jcis](http://www.elsevier.com/locate/jcis)

Regular Article

## MoO3x nanodots with dual enzyme mimic activities as multifunctional modulators for amyloid assembly and neurotoxicity

<DESCRIPTION_FROM_IMAGE>This image does not contain scientific content related to chemistry or other scientific fields. Instead, it appears to be a graphical user interface element or icon. The image shows a circular design with a stylized bookmark or flag shape inside. Below the circular icon is text that reads "Check for updates". This type of image is likely used in software applications to indicate a function for checking and installing software updates. As it does not contain relevant scientific or chemical information, the appropriate response is:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Qiusen Han a,b,1 , Xinhuan Wang a,1 , Xueliang Liu a , Yufei Zhang a , Shuangfei Cai a , Cui Qi a , Chen Wang a,b,⇑ , Rong Yang a,b,⇑

a CAS Key Lab for Biomedical Effects of Nanomaterials and Nanosafety, Center of Materials Science and Optoelectronics Engineering, CAS Center for Excellence in Nanoscience, National Center for Nanoscience and Technology, University of Chinese Academy of Sciences, Beijing 100190, PR China b Sino-Danish College, Sino-Danish Center for Education and Research, University of Chinese Academy of Sciences, Beijing 100190, PR China

### graphical abstract

The fabrication process of MoO3x nanodots by PLA method. MoO3x nanodots exhibited dual enzyme mimic activities and were adopted as multifunctional agents to modulate Ab assembly.

<DESCRIPTION_FROM_IMAGE>This image depicts a schematic representation of a process involving the dissociation and inhibition of amyloid beta (Aβ) fibrillation using molybdenum-based nanomaterials. The diagram is divided into several parts, each illustrating different stages and components of the process:

1. ROS clearance: On the left side, there's a chemical equation showing the conversion of hydrogen peroxide (H2O2) to water and oxygen, catalyzed by catalase. Below this, another equation shows superoxide dismutase (SOD) converting superoxide radicals to hydrogen peroxide and oxygen.

2. Central mechanism: In the middle, there's an oval shape representing a reaction chamber or environment. Inside this, a vertical green line represents a laser, and red crossed lines represent fibers. At the bottom of the oval, there are representations of MoS2 nanosheets and MoO3-x dots with SH-PEG polymer.

3. Aβ fibrillation: On the right side, the diagram shows the progression from monomers to oligomers to fibrils, representing the stages of Aβ aggregation.

4. Dissociation and Inhibition: Arrows indicate that the MoO3-x dots interact with the oligomers and fibrils, leading to their dissociation. The final stage shows inhibition, with the formation of a "random coil" structure.

Key chemical structures mentioned:
1. H2O2 (Hydrogen peroxide) - SMILES: OO
2. O2 (Oxygen) - SMILES: O=O
3. H2O (Water) - SMILES: O

The diagram illustrates a complex process involving reactive oxygen species (ROS) clearance, the use of molybdenum-based nanomaterials (MoS2 nanosheets and MoO3-x dots), and their interaction with Aβ aggregates, ultimately leading to the dissociation of fibrils and inhibition of further aggregation.</DESCRIPTION_FROM_IMAGE>

# article info

Article history: Received 5 November 2018 Revised 24 December 2018 Accepted 26 December 2018 Available online 27 December 2018

Keywords: MoO3x nanodots Enzyme-mimic activity Amyloid Pulsed laser ablation Neurotoxicity

# abstract

Development of effective inhibitors toward Ab aggregation and reactive oxygen species (ROS) scavengers are of crucial therapeutic implications for Alzheimer's disease (AD). Herein, a novel agent with dual enzyme mimic activities has been fabricated as a multifunctional Ab fibrillation modulator. MoO3x nanodots were synthesized by pulsed laser ablation (PLA) method in MoS2 nanosheets solutions, which may act directly as numerous fine targets. MoO3x nanodots showed a uniform and monodispersed morphology, and the tiny dots were around 3–5 nm with a narrow size distribution. Due to the efficient charge transition between Mo5+/Mo6+ on the dots surface, MoO3x nanodots exhibited excellent catalase and SOD mimic activities, which were adopted to alleviate Ab-mediated oxidative stress. Moreover, MoO3x nanodots can efficiently inhibit Ab aggregation and destabilize the preformed fibrils, and eventually protect neuronal cells from apoptosis induced by Ab. Taken together, MoO3x nanodots with multifunctional roles can act as a potential therapeutic strategy for treatment of amyloid induced neurotoxicity.

2019 Elsevier Inc. All rights reserved.

⇑ Corresponding authors at: CAS Key Lab for Biomedical Effects of Nanomaterials and Nanosafety, Center of Materials Science and Optoelectronics Engineering, CAS Center for Excellence in Nanoscience, National Center for Nanoscience and Technology, University of Chinese Academy of Sciences, Beijing 100190, PR China; Sino-Danish College, Sino-Danish Center for Education and Research, University of Chinese Academy of Sciences, Beijing 100190, PR China.

- E-mail addresses: [wangch@nanoctr.cn](mailto:wangch@nanoctr.cn) (C. Wang), [yangr@nanoctr.cn](mailto:yangr@nanoctr.cn) (R. Yang).
- 1 The authors contributed equally to this article.

#### 1. Introduction

The fibrillation of amyloid peptides into cytotoxic oligomers or fibril aggregates has been believed to be one of the major pathologic mechanisms of neurodegenerative diseases, including Alzheimer's disease (AD), Parkinson's disease (PD), Huntington's disease (HD) and prion diseases [\[1\]](#page-8-0). Given the central role of amyloid-b (Ab) fibrillation in AD pathology, interfering with or blocking of the assembly of Ab is a promising strategy for the development of potential agents to treat AD [\[2,3\]](#page-8-0).

Simultaneously, for human beings, the brain is particularly sensitive to oxidative damage due to the very high dioxygen consumption (20% of the total body consumption). As we know, during the redox reaction, dioxygen is the final electron acceptor and may form reactive oxygen species (ROS), such as superoxide anion (O2 ), hydrogen peroxide (H2O2) and hydroxyl radical (HO) [\[4,5\].](#page-8-0) Generally, ROS are kept at a low level controlled by several enzymes and the accumulation may occur either by an overproduction or an insufficient elimination [\[6\].](#page-8-0) In AD, ROS can oxidize neuronal membrane biomolecules, such as lipids, proteins and nucleic acids and lead to a disruption of membrane integrity. More importantly, the effect may be enhanced by Ab coordinating with redox active metal [\[7\].](#page-8-0) Hence, oxidative stress and oxidative damage induced by Ab have been also considered pivotal in the pathogenesis of AD and may represent another target for therapy [\[5\].](#page-8-0)

Therefore, many efforts are aim to better understand the pathologic mechanisms, and the novel therapeutic strategy has focused on developing multifunctional agents to modulate Ab assembly. For example, nanoparticles (NPs) have been widely studied due to the relative strong interaction between NPs and peptides [\[8–](#page-8-0) [14\].](#page-8-0) The influences of nanoparticles on protein fibrillation are varied due to the differences of proteins and nanomaterials [\[15–17\].](#page-9-0) However, their therapeutic efficiency is far from satisfactory due to the poor ROS scavenge ability. Some NPs even induce ROS generation, which limits their applications in AD therapy field [\[18\].](#page-9-0)

In general, elimination of ROS is performed by an antioxidant compound. In this context, antioxidant enzymes, like superoxide dismutases (SOD), catalase, glutathione peroxidase (GPx) and so on, can destroy the superoxide anion and H2O2 and sustain the redox equilibrium [\[19\].](#page-9-0) For instance, SOD is a family of enzymes that catalyze the dismutation of superoxide anions to oxygen and hydrogen peroxide. However, natural enzymes are susceptible to environmental factors and are easily denatured. Thus, the practical application is often hampered [\[20\].](#page-9-0)

Recently, some catalytically active nanomaterials have received increasing attention as candidates for natural enzymes, and are usually named as nanozymes. Compared to natural enzymes, nanozymes display excellent tunability in catalytic activities, controlled synthesis, as well as high stability against harsh conditions [\[21\].](#page-9-0)

Up to now, most reports mainly focus on peroxidase-like nanozymes, like iron oxide NPs [\[22,23\],](#page-9-0) Pt-based NPs [\[24–27\]](#page-9-0) and so on. Except Co3O4 NPs [\[28\],](#page-9-0) nanoceria [\[29\]](#page-9-0) and V2O5 nanowires [\[30\],](#page-9-0) few works report that NPs own the catalase or SOD mimic activities. Thus, the applications of NPs as antioxidants are limited.

The advantage of nanomaterials also includes the promising ability to penetrate the blood-brain barrier (BBB), which can directly target the diseased brain. The traditional mechanisms of molecule crossing the BBB include passive diffusion and receptor-mediated endocytosis [\[31\].](#page-9-0) Recently, several nanomaterials were reported to cross the BBB with various mechanisms. Reduced graphene oxide (rGO) with diameter of 342 ± 23.5 nm was found mainly located in the thalamus and hippocampus of rats after systemically-injection. The entry of rGO involved a transitory decrease in the BBB paracellular tightness, and was confirmed at anatomical, subcellular and molecular levels [\[32\].](#page-9-0) In addition, poly (ethylene glycol) (PEG) coating may improve the BBB penetration. Nance et al have proved that PEG coating improved the penetration of large polymeric NPs in brain tissue as it conferred an increase of half-life circulation of NPs in blood [\[33\].](#page-9-0)

Here, we developed a multi-functional therapeutic platform with dual enzyme mimic activities by using a single material of MoO3x nanodots. MoO3x nanodots were fabricated by pulsed laser ablation (PLA) method in MoS2 nanosheets solutions. PLA method can be utilized to synthesize nanostructures with various compositions and morphologies [\[11,34,35\]](#page-9-0). In addition, the laser ablation of suspended nanomaterials can be adopted to further modify their size, shape, and composition [\[36\]](#page-9-0). The as-prepared MoO3x nanodots exhibit excellent catalase and SOD mimic activities and reduce Ab mediated ROS level efficiently. Meanwhile, MoO3x nanodots can also inhibit Ab aggregation and promote Ab clearance, and eventually alleviate Ab induced neurotoxicity. Accordingly, MoO3x nanodots could act as a multi-functional agent in the treatment of amyloid protein related disease.

#### 2. Experimental section

#### 2.1. Materials and chemicals

Chemicals including MoS2 powder, n-butyllithium, 1,1,1,3,3, 3-hexafluoroisopropanol (HFIP), Thioflavin T (ThT), l-anilinonaph thalene-8-sulphonate (ANS) and 2,7-Dichlorodi–hydrofluorescein diacetate (DCFH-DA) were bought from Sigma-Aldrich. SH-PEG was purchased from Shanghai Ponsurebio Technology Co., Ltd. NaH2PO4, NaOH, H2O2 and Dimethyl sulfoxide (DMSO) were obtained from Sinopharm Chemical Reagent Beijing Co., Ltd. Water soluble tetrazolium-1 (WST-1) was from DOJINDO, Japan. Ab42 (purity 95%) was synthesized by Shanghai Science Peptide Biological Technology Co. Ltd, China.

### 2.2. Synthesis of MoO3x nanodots

Layered MoS2 nanosheets were synthesized according to Morrison method [\[37\]](#page-9-0) with sone modification. In brief, 0.5 g MoS2 powder was mixed with 5 mL 1.6 M n-butyllithium solution in hexane for 48 h under N2 condition. Then the sample was immediately washed several times to discard organic materials and dispersed in water. Next, ultrasonication was applied to obtain exfoliated nanosheets and unexfoliated MoS2 was removed by centrifugation. Finally, the sample was dialyzed for 2 days to obtain MoS2 nanosheets dispersed in water.

MoO3x nanodots were fabricated by using PLA method. Briefly, 7 mL MoS2 nanosheets (50 lg/mL) were first mixed with SH-PEG (1.25 mg) in a quartz cell. A Nd:YAG pulsed laser (532 nm, 10 Hz, pulse duration between 7 ns and pulse energy of 150 mJ) was used to ablate the prepared solution for 20 min. During the course of the ablation, the colloidal solution was continuously stirred by a magnetic stirrer.

### 2.3. Characterization of MoO3x nanodots

The morphology and zeta potential of MoO3x nanodots were characterized by transmission electron microscopy (TEM, Tecnai G220 ST) and Zeta potential analyzer (Malvern Zetasizer Nano ZS). MoO3x nanodots were deposited on a glass slide and then dried by heating, the crystal phase composition was determined by X-ray diffraction (XRD, Bruker D8). The Mo3d binding energy of the sample was determined using X-ray photoelectron spectroscopy (XPS, Perkin Elmer PHI 5600). The concentration of MoO3x nanodots used for next studies was measured with optical emission spectroscope of inductively coupled plasma ICP-OES (Perkin-Elmer optima 6300DV).

#### 2.4. Catalase mimic activity determination

The catalytic activities of MoO3x nanodots as catalase mimics were evaluated in NaH2PO4–NaOH buffer (350 lL, 0.1 M, pH 9) containing 20 lg/mL MoO3x nanodots and 20 mM H2O2. The amount of H2O2 was monitored by UV–Vis-NIR spectrophotometer (Perkin Elmer) at 240 nm with a time-drive mode. The effects of pH and temperature on the catalytic activities of MoO3x nanodots were also determined with the same condition. The reaction time was 15 min.

The apparent steady-state reaction rate of MoO3x nanodots were deduced according to the initial linear range of the kinetic curves and the concentration of H2O2. The reaction rates were fitted to the Michaelis–Menten equation to calculate the kinetic constants: m = Vmax [S]/(Km + [S]), where v is the initial velocity, Vmax is the maximal reaction velocity, [S] is the concentration of H2O2, and Km refers the Michaelis constant.

#### 2.5. Superoxide dismutase (SOD) mimic activity determination

The SOD activity of MoO3x nanodots was determined by measuring the inhibition effect of WST-1 formazan formation, according to the SOD test kit (Dojindo). The assay contained positive control, negative control, sample group (MoO3x nanodots of various concentrations) and sample control, respectively. After reaction for 20 min, the absorbance was measured at 450 nm using a micro plate reader (Envision).

#### 2.6. Ab42 peptide preparation.

Ab42 was dissolved in HFIP to a final concentration of 1 mg/mL and shaken overnight at room temperature. Before use, the HFIP was evaporated under a gentle stream of nitrogen and vacuum, and then DMSO was used to resolve the peptide.

#### 2.7. ThT assay for determination Ab42 fibrillation process.

The effect of MoO3x nanodots on Ab42 fibrillation process was detected by ThT assay. MoO3x nanodots with various concentrations (2.5, 5, 10, 20 lg/mL, respectively) were incubated with Ab42 for continuous shaking at 37 C. The final concentration of Ab42 was 20 lM. ThT probe was used to study the process of fibrillation. 20 lL aliquots from each sample were mixed with 180 lL ThT (10 lM) at different time points and added to a black 96-well plate for detection. The ThT fluorescence was measured at 485 nm with excitation at 450 nm using a microplate reader (Envision).

#### 2.8. Characterization of peptide secondary structure

Circular dichroism (CD) spectra were used to characterize the secondary structure of Ab42 on a Jasco-J1500 spectropolarimeter (Jasco) at room temperature under a constant flow of nitrogen gas. Ab42 was prepared in 1:1 (v/v) mixture of trifluoroethanol and Milli-Q water with or without MoO3x nanodots. Typically, spectra were collected between 260 nm and 190 nm with a step size of 0.2 nm and a speed of 100 nm/s. The bandwidth for the CD measurements was 1 nm.

#### 2.9. Tyrosine fluorescence spectra

Fluorescence spectra were collected using a Hitachi FP-4500 fluorescence spectrophotometer. An excitation wavelength of 280 nm (slit width = 5 nm) was used and data were collected over 290–400 nm (slit width = 5 nm). Samples were placed in a foursided quartz fluorescence cell and data were recorded at room temperature.

#### 2.10. TEM study of the peptide aggregation

Morphology of the peptide aggregation was characterized by TEM. 10 lL of sample solution was placed on 200 mesh carboncoated copper grids. After that the sample was negatively stained with 2% fresh phosphotungstic acid for 2 min. Tecnai G220ST electron microscope was operated at 200 kV.

#### 2.11. Cell culture

SH-SY5Y human neuroblastoma cells (ATCC, USA) were cultured in RPMI 1640 (Hyclone) with 15% (v/v) fetal bovine serum (Hyclone), containing 100 IU/mL penicillin and 100 lg/mL streptomycin (Gibco). The cells were routinely sub-cultured once every 3 days at a dilution of 1:3 and incubated at 37 C in a humidified incubator with 5% CO2.

#### 2.12. Cell viability assay

SH-SY5Y cells (15 000 cells/well, 100 lL) were first seeded in 96-well plate and incubated overnight. Then the cells were treated with Ab42 with various concentrations (2, 5, 10, 20, 30, 40 lM) in the presence or absence of MoO3x (10 lg/mL) for 48 h, respectively. The cell viability was evaluated by using CCK8 assay. Cell viability was expressed as the percentage of viable cell relative to untreated cells using the absorbance at 450 nm (Envision).

#### 2.13. Reactive oxygen species measurement

The ROS level was evaluated by using DCFH-DA probe (Sigma). SY5Y cells (2 105 cells/mL) were first cultured in 24 well plate for 14 h. Then, the cells were incubated with DCFH-DA (100 lM) for 2 h, and washed three times with PBS. After that, the cells were incubated with various concentrations of MoO3x nanodots for 1 h. Then Ab42 (40 lM) was introduced. The DCF fluorescence intensity inside the cells was determined after 4 h later by using a micro plate reader (Envision) with excitation/emission at 485/530 nm. All the procedures were performed without exposure to light.

#### 2.14. Statistical analyses

All experiments are means of triplicates. All of the data are expressed as mean standard deviation (SD). Statistical analysis were carried out with SPSS with a paired t-test. The difference was considered statistically significant when P < 0.05.

#### 3. Results and discussion

In this work, MoO3x nanodots were fabricated via pulsed laser ablation (PLA) in MoS2 nanosheets/SH-PEG solution. PLA is a relative versatile and simple method to synthesize various NPs, mainly focus the laser beam on ablated targets in various solvents. Here, we focused the laser beam in the MoS2 nanosheets solution, and the nanosheets may act directly as numerous fine targets. The

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a catalytic system for reactive oxygen species (ROS) clearance using MoS2 nanosheets and MoOx dots.

The left side of the image shows an oval-shaped area representing a reaction environment. Within this area, a laser beam is shown penetrating from the top, focusing on MoS2 nanosheets at the bottom. The laser beam is represented as a cone shape, wider at the top and narrowing towards the bottom. Scattered throughout the reaction environment are representations of MoOx dots and SH-PEG polymer.

On the right side of the image, two chemical reactions are depicted:

1. The first reaction shows the decomposition of hydrogen peroxide:
   2H2O2 → 2 H2O + O2
   This reaction is catalyzed by Catalase, as indicated.

2. The second reaction shows the dismutation of superoxide:
   2O2- + 2H+ → H2O2 + O2
   This reaction is catalyzed by SOD (Superoxide Dismutase), as indicated.

Between these two reactions, a box labeled "ROS clearance" is shown, indicating that these reactions contribute to the removal of reactive oxygen species.

The image also includes a legend at the bottom, identifying the components:
- MoS2 nanosheets
- MoOx dots
- SH-PEG polymer

This schematic illustrates a system where MoS2 nanosheets, activated by laser irradiation, work in conjunction with MoOx dots and SH-PEG polymer to facilitate ROS clearance through catalase-like and SOD-like activities.</DESCRIPTION_FROM_IMAGE>

Scheme 1. The fabrication process of MoO3x nanodots by PLA method and the dual enzyme mimic activities.

as-prepared MoO3x nanodots exhibited catalase and SOD mimic activities, as illustrated in scheme 1.

As shown in [Fig. 1a](#page-4-0), the TEM image clearly exhibited that the as-prepared sample was composed of numerous tiny dots with homogeneous dispersion, and the dots were around 3–5 nm with a narrow size distribution [(Fig. 1b](#page-4-0)). The photo image of MoS2 nanosheets and as-prepared MoO3x nanodots (Fig. S1) showed the color change from black to light yellow at the same concentration (50 lg/mL), also suggesting that layered-structure in the suspension transformed into ultrafine dots. According to the fabrication mechanism [\[36\],](#page-9-0) during the laser ablation, MoS2 nanosheets underwent a process of fragmentation under high temperature and high pressure. Hence, the oxidation reaction may be inevitable.

To understand the crystal structure of the as-prepared nanodots, high resolution transmission electron microscopy (HRTEM) and x-ray diffraction (XRD) analysis were adopted. The HRTEM image shown in [Fig. 1c](#page-4-0) presented the typical dots and paralleled lattice fringes, indicating a definite crystalline nature. The crystalline lattice constant was determined to be 0.22 nm. Then, the crystalline nature was further explored by XRD analysis. As shown in [Fig. 1](#page-4-0)d, the diffraction peaks at 2h values of 33.67, 47.30, and 53.11 can be assigned to the (1 1 0), (2 0 0) and (0 0 4) crystal planes of a MoO3 monoclinic structure, respectively. (ICDD-JCPDS card no. 47-1320).

The chemical valence state was then checked by X-ray photoelectron spectroscopy (XPS). According to the detailed Mo 3d spectrum, the curve could be divided into two groups of spin–orbit doublets: the first doublets located at 234.5 and 231.4 eV could be assigned to Mo6+ ions, while the second doublets with lower binding energies at 233.55 and 230.75 eV represented Mo5+ 3d3/2 and Mo5+ 3d5/2, respectively [(Fig. 1f](#page-4-0)). The existence of mixed valence state of Mo in the as-prepared nanodots confirmed that the obtained nanodots were substoichiometric molybdenum oxide, which named as MoO3x. Meanwhile, the ratio of Mo6+ and Mo5+ contained in MoO3x nanodots were obtained by calculating the area ratio from the XPS spectra. We can conclude that 58.5.0% Mo6+ and 41.5% Mo5+ exist in MoO3x nanodots, respectively, which also indicated that oxygen-deficient molybdenum oxides were formed. In addition, in the full range of the XPS spectra, the peaks corresponding to the elements C, Mo, S and O were discerned [(Fig. 1e](#page-4-0)). Taken together, MoS2 nanosheets have transformed to MoO3x nanodots during the laser ablation process.

To optimize the morphology and property of nanodots, a series of control experiments were carried out. Various surfactants, such as NH2-PEG5000, PVP5000, NH2-PEG5000-NH2 were selected to studied their effects. First, we studied the sample synthesized without the addition of surfactants. The nanodots showed a nonhomogeneous morphology and could aggregate easily, as shown in Fig. S2. We also found that NH2-PEG5000 and NH2-PEG5000-NH2 could induce the aggregation of nanodots. The PVP could help to increase the dispersion of nanodots, while the uniformity of the dots is not very well (Fig. S3). The SH-PEG5000 had the best effect on preparation of MoO3x nanodots. We also studied the influnece of the concentration of SH-PEG5000 on the nanodot preparation. With a low concentration of SH-PEG (15 lM), the capping effect was not good and the nanodots stacked together. However, when the concentration was up to 72 lM, the activity of nanodots may be reduced due to a large amount of PEG around each dots (Fig. S4). Thus, SH-PEG with concentration of 36 lM was chosen as a typical surfactant for further studies.

We also studied the stability of MoO3x nanodots under physiological conditions. The zeta potential was measured in PBS and cell medium with 10% fetal bovine serum (FBS). The result showed that MoO3x nanodots had a negative potential around 13.4 ± 1.6 mV and 15.3 mV in PBS and cell medium, respectively. No aggregation can be seen for several months owning to the SH-PEG protection, indicating that MoO3x nanodots were stable under physiological condition (Fig. S5).

To investigate the catalase mimic activity of MoO3x nanodots, the decomposition of H2O2 were measured by monitoring the absorbance (A) change of H2O2 at 240 nm. Similar to catalase [(Fig. 2](#page-5-0)a), the intensity of A240 was decreased dramatically and vigorous gas bubbles can be seen when MoO3x nanodots incubated with H2O2 over reaction time [(Fig. 2b](#page-5-0)). The results indicated that H2O2 was decomposed by MoO3x nanodots and oxygen generated. The catalytic decomposition process of H2O2 by MoO3x nanodots was also evaluated. The plot of log [H2O2]t vs time was linear, which illustrated that the reaction catalyzed by MoO3x nanodots followed the first-order kinetics [(Fig. 2](#page-5-0)c). These findings indicated that MoO3x nanodots possessed catalase activity.

Next, the effect of various external conditions such as temperature, pH and nanodot concentration on the catalytic activities of the MoO3x nanodots was investigated. [(Fig. 2d](#page-5-0)–f). The activity of catalase was also evaluated over the same range of parameters. Compared to catalase, MoO3x nanodots exhibited higher catalytic activity at a wide range of temperature (25–90 C) and various pH values (3.0–9.0) (Figs. S6 and S7). Thus, MoO3x nanodots have a great potential for application under harsh conditions. Simultaneously, with a constant concentration of H2O2 (20 mM), the catalytic ability showed a linear dependence on the concentration of MoO3x nanodots, implying that H2O2 decomposition followed the first-order kinetics with respect to MoO3x nanodots.

The catalytic properties of MoO3x nanodots were further investigated using steady-state kinetics experiments. The kinetic parameters of MoO3x nanodots were measured by monitoring the absorbance change of H2O2 at various H2O2 concentrations [(Fig. 3)](#page-5-0). The catalytic performance was fitted well to the typical Michaelis–Menten model, and Michaelis-Menten constant (Km) and maximum initial rate (mmax) can be obtained using the Lineweaver–Burk double reciprocal plots, which showed the good linear relationship between m1 and [S]1 . Km value represents the affinity of the enzyme toward the substrate, and a lower value indicates a greater affinity. The Km value of MoO3x nanodots was 6.72 mM, which was much lower than that of catalase (Km = 54.3 mM), suggesting that MoO3x nanodots have higher affinity to H2O2 than catalase. Meanwhile, the mmax (1.96 105 MS1 ) was similar to catalase (1.62 105 MS1 ).

<DESCRIPTION_FROM_IMAGE>The image contains six panels labeled a through f, each presenting different analytical data for a nanomaterial, likely molybdenum oxide (MoO3-x) nanoparticles.

a) Transmission Electron Microscopy (TEM) image showing a uniform distribution of dark, circular nanoparticles against a lighter background. The scale bar indicates 50 nm.

b) Size distribution histogram of the nanoparticles. The x-axis shows size in nm from 1.5 to 5.0, and the y-axis shows the number of particles. The distribution follows a normal curve with a peak at 3.0-3.5 nm. The average particle size is stated as 3.1 ± 0.7 nm.

c) High-resolution TEM image of a single nanoparticle showing lattice fringes. The lattice spacing is measured and labeled as 0.22 nm.

d) X-ray diffraction (XRD) pattern. The x-axis shows 2 Theta values from 10 to 60 degrees. The y-axis shows intensity in arbitrary units (a.u.). Peaks are labeled with Miller indices (110), (200), and (004).

e) X-ray photoelectron spectroscopy (XPS) survey spectrum. The x-axis shows binding energy from 0 to 1200 eV. The y-axis shows counts per second. Peaks are labeled for O1s, C1s, Mo3d, and S2p.

f) High-resolution XPS spectrum of the Mo3d region. The x-axis shows binding energy from 228 to 240 eV. The y-axis shows intensity in arbitrary units (a.u.). The spectrum is labeled as MoO3-x and shows a complex peak structure with multiple fitted components, indicating different oxidation states of molybdenum.

This comprehensive analysis suggests the successful synthesis of molybdenum oxide nanoparticles with a well-defined size distribution and crystalline structure, as well as the presence of multiple oxidation states of molybdenum in the sample.</DESCRIPTION_FROM_IMAGE>

Fig. 1. (a) TEM image, (b) particle size distribution, (c) HRTEM image, (d) XRD, (e) The survey spectra of MoO3x nanodots and (f) Mo 3d XPS of MoO3x nanodots.

Then, the SOD activity of MoO3x nanodots was quantified using SOD test kit (WST-1). The assay was based on the capacity of MoO3x nanodots to inhibit the reduction of WST-1 by superoxide anion radical in the presence of xanthine oxidase. As shown in [Fig. 4](#page-6-0), MoO3x nanodots displayed SOD activity in a dose dependent manner. When the concentration was reached to 50 lg/mL, MoO3x nanodots totally inhibited WST-1 reduction, indicating the excellent SOD activity, which can be ascribed to the different valence states of Mo species.

It is known that the aggregation of Ab42 is associated with the neurotoxicity in AD, it is crucial to inhibit the aggregation as well as keep the balance of Ab42 between its formation and degradation. For investigating the effect of MoO3x nanodots on aggregation kinetics, ThT binding assay was performed. For Ab42 alone, ThT fluorescence exhibited a typical sigmoidal shape as a function of incubation time. After co-incubation of Ab42 monomers and MoO3x nanodots over a period of time, the intensity of the growth curve was dramatically decreased with a dose dependent manner, indicating the lack of fibril production [(Fig. 5](#page-6-0)a). At the same time, the influence of nanodots on ThT fluorescence was evaluated. As shown in Fig. S8, due to the relative low concentration used in the assay, fluorescence quenching can be negligible.

<DESCRIPTION_FROM_IMAGE>The image contains multiple panels labeled a through f, each depicting different aspects of a chemical reaction and its analysis:

a) A chemical equation is shown: 2H2O2 -> 2 H2O + O2
   This represents the decomposition of hydrogen peroxide into water and oxygen, catalyzed by nanoparticles (NPs) depicted as small red dots.

b) A photograph of a test tube or cuvette containing a liquid with visible gas bubbles, likely showing the reaction in progress.

c) A graph plotting Log[H2O2]t against Time (S). The x-axis ranges from 0 to 120 seconds, while the y-axis ranges from 0.2 to -0.3. The data points show a linear decrease, fitted with a red line, indicating a first-order reaction kinetics for H2O2 decomposition.

d) A graph of Relative activity vs NPs concentration (μg/mL). The x-axis ranges from 5 to 30 μg/mL, and the y-axis from 0.2 to 1.2. The plot shows a linear increase in relative activity with increasing NP concentration up to about 25 μg/mL, after which it appears to plateau.

e) A graph of Relative activity vs Temperature (°C). The x-axis ranges from 20 to 90°C, and the y-axis from 0 to 1.0. The plot shows a sigmoidal curve, with activity increasing slowly up to about 60°C, then rapidly increasing to plateau around 80°C.

f) A graph of Relative activity vs pH. The x-axis ranges from 3 to 10 pH units, and the y-axis from 0 to 1.0. The plot shows a bell-shaped curve with optimal activity around pH 9, and decreasing activity at both lower and higher pH values.

All graphs include error bars on the data points. Graphs c and d show linear fits, while e and f show curved fits to the data.

This set of graphs comprehensively characterizes the catalytic activity of the nanoparticles in the decomposition of hydrogen peroxide, showing its dependence on reaction time, catalyst concentration, temperature, and pH.</DESCRIPTION_FROM_IMAGE>

Fig. 2. Catalase mimics activity of MoO3x nanodots. (a) The scheme of the reaction catalyzed by MoO3x nanodots. (b) The photo of oxygen bubble induced by MoO3x nanodots incubated with H2O2. (c) Decomposition of H2O2 by MoO3x nanodots over reaction time. The effects of nanodots concentration (d), temperature (e) and pH (f) on the catalytic activity. The maximum point is set as 100%.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled 'a' and 'b', both related to the kinetics of a reaction involving hydrogen peroxide (H2O2).

Graph a:
This graph shows the relationship between the velocity of the reaction (y-axis) and the concentration of H2O2 (x-axis). The y-axis is labeled "Velocity (10^-6 Ms^-1)" and ranges from 0.4 to 1.8. The x-axis is labeled "[H2O2](mM)" and ranges from 0 to 30 mM. The data points follow a typical Michaelis-Menten kinetics curve, starting with a steep increase in velocity at low H2O2 concentrations and then leveling off as the concentration increases, approaching a maximum velocity. Error bars are visible on each data point. The curve appears to be approaching saturation around 1.6 x 10^-6 Ms^-1.

Graph b:
This graph presents a Lineweaver-Burk plot, which is a linear transformation of the Michaelis-Menten equation. The y-axis is labeled "1/Velocity (10^5 SM^-1)" and ranges from 0.4 to 2.0. The x-axis is labeled "1/[H2O2](mM^-1)" and ranges from 0.0 to 0.4 mM^-1. The data points form a straight line, consistent with the Lineweaver-Burk equation. Error bars are visible on each data point.

The linear equation of the line is given as y = 3.426x + 0.5097, with an R^2 value of 0.999, indicating an excellent fit to the data.

From this Lineweaver-Burk plot, we can derive important kinetic parameters:
1. The y-intercept (0.5097) is equal to 1/Vmax, so Vmax ≈ 1.96 x 10^-6 Ms^-1
2. The x-intercept (-0.5097/3.426 ≈ -0.149) is equal to -1/Km, so Km ≈ 6.71 mM

These graphs together provide a comprehensive view of the enzyme kinetics for this reaction, allowing for the determination of key parameters like Vmax and Km.</DESCRIPTION_FROM_IMAGE>

Fig. 3. (a) The Michaelis-Menten model and Lineweaver-Burk model (b) of MoO3x nanodots as catalase mimics. The concentration of MoO3x nanodots was 10 lg/mL and H2O2 concentration was varied in 0.1 M NaH2PO4-NaOH buffer (pH 9.0).

<DESCRIPTION_FROM_IMAGE>The image consists of two graphs labeled 'a' and 'b'.

Graph a:
This is an absorbance spectrum graph. The x-axis represents wavelength in nanometers (nm), ranging from 360 to 570 nm. The y-axis shows absorbance, ranging from 0 to 1.0. The graph contains five curves representing different concentrations:
1. CONT (control): highest peak, maximum absorbance around 0.95 at ~450 nm
2. 5 μg/mL: second highest peak, maximum absorbance around 0.75 at ~450 nm
3. 10 μg/mL: third highest peak, maximum absorbance around 0.55 at ~450 nm
4. 20 μg/mL: fourth highest peak, maximum absorbance around 0.28 at ~450 nm
5. 50 μg/mL: lowest peak, maximum absorbance around 0.05 at ~450 nm

All curves show a similar shape with a single peak centered around 450 nm, decreasing in intensity as the concentration increases from 5 to 50 μg/mL.

Graph b:
This is a bar graph showing inhibitor rate as a percentage. The x-axis represents concentration in μg/mL, with four bars corresponding to 5, 10, 20, and 50 μg/mL. The y-axis shows the inhibitor rate percentage, ranging from 0 to 100%.

The inhibitor rate increases with concentration:
1. 5 μg/mL: approximately 17% inhibition
2. 10 μg/mL: approximately 39% inhibition
3. 20 μg/mL: approximately 71% inhibition
4. 50 μg/mL: approximately 97% inhibition

Error bars are visible on each bar, indicating some variation in the measurements.

The graphs together suggest a dose-dependent relationship between the concentration of an inhibitor and its effect on absorbance and inhibition rate. As the concentration increases, the absorbance decreases (graph a) while the inhibition rate increases (graph b).</DESCRIPTION_FROM_IMAGE>

Fig. 4. SOD activity assay. Inhibition of WST-1 reduction by incubation with MoO3x nanodots. The WST-1 reduction was induced by superoxide anion radicals generated in the presence of xanthine oxidase in vitro.

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled a, b, c, and d, each presenting different aspects of an experiment involving Aβ42 (likely referring to amyloid-beta 42) and MoO3-x (molybdenum oxide) nanoparticles.

Graph a: This graph shows the intensity (in arbitrary units, a.u.) over time (in hours) for Aβ42 alone and in the presence of different concentrations of MoO3-x (2.5, 5, 10, and 20 μg/mL). The Aβ42 curve shows a rapid increase in intensity, reaching a plateau around 4000 a.u. after about 20 hours. The MoO3-x curves show a concentration-dependent reduction in intensity, with higher concentrations of MoO3-x resulting in lower intensity values.

Graph b: This bar graph displays the Tyr FL Intensity (Tyrosine Fluorescence Intensity, in a.u.) for Aβ42 alone and with different concentrations of MoO3-x Dots (2.5, 5, 10, and 20 μg/mL). There is a clear dose-dependent decrease in fluorescence intensity as the concentration of MoO3-x Dots increases. Statistical significance (p < 0.01) is indicated by asterisks (**) between all groups.

Graph c: This graph shows the fluorescence emission spectra (intensity in a.u. vs wavelength in nm) for Aβ42 alone and in the presence of different concentrations of MoO3-x Dots (2.5, 5, 10, and 20 μg/mL). The spectra range from 400 to 700 nm, with peak intensity around 480 nm. The Aβ42 alone shows the highest peak, while increasing concentrations of MoO3-x Dots progressively reduce the peak intensity.

Graph d: This graph presents circular dichroism (CD) spectra, showing intensity vs wavelength (nm) from 190 to 260 nm. It compares Aβ42 alone with Aβ42 in the presence of different concentrations of MoO3-x (5, 10, and 20 μg/mL). The Aβ42 alone curve shows a characteristic negative peak around 218 nm, indicative of β-sheet structure. The presence of MoO3-x appears to alter the CD spectrum, suggesting changes in the secondary structure of Aβ42.

Overall, these graphs demonstrate that MoO3-x nanoparticles interact with Aβ42, affecting its aggregation kinetics, fluorescence properties, and secondary structure in a concentration-dependent manner.</DESCRIPTION_FROM_IMAGE>

Fig. 5. Inhibition effects of MoO3x nanodots on Ab42 assembly. (a) Aggregation kinetics of Ab42 monitored by ThT probe in the absence and presence of MoO3x nanodots with various concentrations. (b) Tyrosine fluorescence intensity, (c) ANS fluorescence signal, (d) CD spectra of Ab42 in absence or presence of MoO3x nanodots with concentrations of 2.5, 5 ,10 and 20 lg/mL.

To further understand the mechanism of inhibition effect of the nanodots on Ab42, a series of spectra assays were adopted, including tyrosine fluorescence, ANS fluorescence and circular dichroism (CD) spectroscopy. Tyrosine fluorescence is an intrinsic probe of Ab42. It is known that tyrosine fluorescence of Ab42 can be quenched by nanomaterials due to the adsorption and burying effects. Our experimental results clearly showed that MoO3x nanodots decreased the fluorescence intensity, indicating that MoO3x nanodots could bind to the Ab42 peptides (Fig. 5b).

ANS is a fluorescent dye molecule that recognizes hydrophobic sites in peptides. The emission spectra of ANS can be enhanced when it interacts with the hydrophobic domain of peptides. Thus, ANS spectra were utilized to study the interaction between MoO3x nanodots and Ab42. As shown in Fig. 5c, after introducing of MoO3x nanodots, the intensity of ANS fluorescence reduced significantly, indicating less hydrophobic region of Ab42 can be targeted. In other words, the hydrophobic region of Ab42 may be occupied by MoO3x nanodots.

As we know, the assembly of Ab42 to form fibril is due to the b-sheet structure. Hence, we wonder whether the interaction between MoO3x nanodots and Ab42 affect the secondary structure. CD spectra were utilized to monitor the structure change. Ab42 alone exhibited a strong negative valley at 216 nm and a positive peak at 195 nm, indicating the typical b-sheet structure formed. Upon introducing of MoO3x nanodots, the peak at 216 nm disappeared, and the weakened valley shift to 208 nm, demonstrating some a-helix structures appeared [(Fig. 5](#page-6-0)d). The spectral deconvolution was carried out using the spectra analysis software and the Reed's reference was employed. For Ab42 alone, b-sheet and a-helix structure were 80% and 20%, respectively. After incubation with 20 lg/mL nanodots, b-sheet structure decreased to 24%. While, a-helix and random coil structure increased to 39% and 37%, respectively. The CD spectrum of the nanodots alone was also studied, as shown in Fig. S9. No CD signal was observed, indicating that the spectral contribution from the nanodots can be negligible. Accordingly, MoO3x nanodots can adsorb to the hydrophobic region of Ab42 and induce the secondary structure transition and finally inhibited the Ab42 aggregation.

Moreover, the inhibition effect was confirmed by TEM image. After incubation for 7 days, Ab42 alone can form a relative long and non-branched fibril with diameter of about 15 nm and several hundred nanometers in length. Upon introduction of MoO3x nanodots with 2.5 lg/mL and 5 lg/mL, the fiber length became to less than 100 nm and the width was about l0 nm, the fiber number was also decreased. When the concentration was up to 10 lg/ mL, most fiber lengths were down to 50 nm. If further increasing the nanodots concentration, e.g. 20 lg/mL, very few fibers can be seen, and the fiber length was less than 50 nm. Meanwhile, many amorphous spheres were obtained. The morphology changes illustrating that Ab42 aggregation kinetics can be hindered by MoO3x nanodots (Fig. 6a–e).

Simultaneously, since the pathogenicity of senile plaques in AD patients, the degradation of preformed Ab fibril is more desirable. So, here we studied the effects of MoO3x nanodots on the deploymerization of Ab42 fibrils. First, the mature fibrils were obtained by 7 days incubation, and then MoO3x nanodots with various concentrations were introduced. After mixing for 2 h and 4 h, TEM was used to investigate the dissociation effect. From Fig. 7a–e, one can see that Ab fibril with several hundred nanometers in length can be degraded to short fiber by MoO3x nanodots. When nanodots concentration was reached to 20 lg/mL, lager species were hard to find. Then, ThT probe was also used to determine the dissociation effect. As shown in Fig. 7f, ThT fluorescence intensity decreased dramatically with a time and dose dependent

<DESCRIPTION_FROM_IMAGE>The image presents a series of five microscopic views labeled from 'a' to 'e', showing the progression of a material's morphology or structure at what appears to be the nanoscale. Each image has a scale bar of 200 nm.

Image a: Shows a dense network of elongated, fibrous structures. These structures appear to be interconnected and cover most of the visible area.

Image b: Depicts a transition state where the fibrous structures are less prominent. There are more particulate or globular structures visible, interspersed with some remaining fibrous elements.

Image c: Exhibits a further reduction in the fibrous structures. The particulate or globular structures are more dominant and appear to be more evenly distributed across the field of view.

Image d: Shows a significant decrease in the fibrous structures. The particulate or globular structures are now the primary feature, appearing larger and more distinct than in the previous images.

Image e: Presents the final stage where the fibrous structures are almost completely absent. The particulate or globular structures are now the dominant feature, appearing larger and more sparsely distributed compared to the previous images.

This series of images likely represents a time-dependent process or a gradient of conditions affecting the material's structure, possibly demonstrating a transformation from a fibrous network to discrete particulate structures at the nanoscale. The progression could be related to a chemical reaction, a physical process like aggregation or dissolution, or the effect of varying experimental conditions on the material's morphology.</DESCRIPTION_FROM_IMAGE>

Fig. 6. TEM images of Ab42 fibrils alone (a), and in presence of MoO3x nanodots (concentrations are 2.5 (b), 5 (c), 10 (d) and 20 lg/mL (e)). Scale bar is 200 nm.

<DESCRIPTION_FROM_IMAGE>This image is a composite of six panels labeled a through f, showing transmission electron microscopy (TEM) images and a graph related to the study of amyloid beta (Aβ) aggregation.

Panels a-e: TEM images
These panels show TEM micrographs of Aβ42 peptide aggregates at different concentrations and/or time points. Each image has a scale bar of 200 nm.

Panel a: Shows a dense network of thin, elongated fibrils with some darker spots, possibly representing nucleation points or larger aggregates.

Panel b: Displays a less dense network of aggregates with a more branched, interconnected structure.

Panel c: Similar to panel b, but with slightly larger and more distinct aggregate structures.

Panel d: Shows smaller, more dispersed aggregate structures with less interconnectivity.

Panel e: Exhibits the least dense distribution of small aggregate structures.

Panel f: Graph
This panel presents a bar graph showing fluorescence (FL) intensity (in arbitrary units, a.u.) for different concentrations of Aβ42 (2.5, 5, 10, and 20 μg/mL) at three time points (0h, 2h, and 4h).

Key observations from the graph:
1. At 0h (black bars), FL intensity decreases as Aβ42 concentration increases.
2. For 2.5 μg/mL, FL intensity remains relatively constant across all time points.
3. For higher concentrations (5, 10, 20 μg/mL), FL intensity decreases over time.
4. The decrease in FL intensity is more pronounced at higher Aβ42 concentrations.
5. Some bars are marked with asterisks (*), likely indicating statistical significance.

This graph suggests that Aβ42 aggregation is concentration and time-dependent, with higher concentrations leading to more rapid aggregation and a corresponding decrease in fluorescence intensity.

The TEM images (a-e) and the graph (f) together provide a comprehensive view of Aβ42 aggregation behavior, showing both the physical structures formed and quantitative data on the aggregation process over time and at different concentrations.</DESCRIPTION_FROM_IMAGE>

Fig. 7. The dissociation effect of MoO3x nanodots on Ab fibrils monitored by TEM and ThT fluorescence assay. (a–e) TEM images of Ab fibrils alone (a, aggregation for 7 days) and Ab fibrils incubated with MoO3x nanodots of various concentrations for 6 h. The concentrations are 2.5 (b), 5 (c), 10 (d) and 20 lg/mL (e). Scale bar is 200 nm. (f) ThT fluorescence assay.

<DESCRIPTION_FROM_IMAGE>The image contains two bar graphs labeled 'a' and 'b'.

Graph a:
This graph shows cell viability as a function of concentration (μM). The x-axis represents concentration from 0 (labeled as 'Cont') to 40 μM. The y-axis represents cell viability from 0 to 1.0. There are two sets of bars for each concentration: black bars (labeled as Aβ42) and red bars (labeled as Aβ42+NPs). 

Key observations:
1. At lower concentrations (Cont, 2.5, 5 μM), both conditions show similar high cell viability (around 0.9-1.0).
2. As concentration increases, cell viability decreases for both conditions.
3. The Aβ42+NPs condition consistently shows higher cell viability compared to Aβ42 alone, especially at higher concentrations.
4. At 40 μM, there is a significant difference in cell viability between the two conditions, marked with an asterisk (*).

Graph b:
This graph shows intensity (a.u.) for different conditions. The x-axis represents different treatments, and the y-axis represents intensity from 0 to 8000 a.u.

Key observations:
1. The control (Cont) shows the lowest intensity, around 2000 a.u.
2. Aβ42 alone shows the highest intensity, around 7800 a.u.
3. NPs at different concentrations (5, 10, 20 μg/mL) show decreasing intensity as concentration increases.
4. NPs at 5 μg/mL is marked with a single asterisk (*), while 10 and 20 μg/mL are marked with double asterisks (**), indicating statistical significance.

Overall, the graphs suggest that the addition of NPs (likely nanoparticles) reduces the negative effects of Aβ42 (likely amyloid-beta 42, associated with Alzheimer's disease) on cell viability and reduces its intensity, potentially indicating a protective effect.</DESCRIPTION_FROM_IMAGE>

Fig. 8. (a) Protection effect of MoO3x nanodots on Ab42 mediated cytotoxicity. (b) ROS level induced by Ab42 and scavenged by MoO3x nanodots with concentrations of 5, 10 and 20 lg/mL.

manner. Hence, MoO3x nanodots can also dissociate the preformed fibril. The reason may be that the steady-state levels of Ab42 are determined by the balance between its production and degradation, and the binding would lower the stability of the fibril and depolymerize the fibril to monomers or random coil, which further shift the equilibrium away from fibrillation.

Here, we select SY5Y cell as a nerve cell model to explore their cellular metabolism. First, to investigate the biocompatibility of MoO3x nanodots, we performed CCK-8 assay to probe cellular proliferation. As shown in Fig. S10, no toxic effect can be seen with the dose we used. Meanwhile, the effect of nanodots on cell morphology was also investigated. SY5Y cells were incubated with or without nanodots for 48 h and then the photo images were obtained. No obvious morphology change can be seen in the absence and in the presence of nanodots, indicating that nanodots are non-toxic (Fig. S11). However, the cell viability treated with Ab42 was greatly decreased with increasing Ab concentration from 2.5 to 40 lM. While, MoO3x nanodots (10 lg/mL) can efficiently improve the viability of SY5Y cell treated by Ab42, indicating the protection effect was achieved. (Fig. 8a)

ROS scavengers also seem to be promising during the AD treatment. Due to the catalase and SOD mimic activities, the ROS scavenge function of MoO3x nanodots was further studied. It is known that Ab42 fibrils can elevate the ROS level in the brain of AD patients, which may induce the lipids, proteins, DNA and RNA damage. The intracellular ROS level was detected using DCFH-DA as a probe. SY5Y cells exposed to Ab42 alone induced an increase of ROS generation. However, pre-treatment of SY5Y cells with MoO3x nanodots may alleviate the ROS level and a dose dependent manner was shown in Fig. 8b. Combining the inhibition and dissociation effects of the nanodots, few fibrils existed in the system and ROS level was further decreased. Therefore, owning to the effects of inhibition aggregation, dissociation mature Ab fibril, as well as ROS scavenging activities, MoO3x nanodots resulted in reducing Ab-mediated cell-toxicity.

#### 4. Conclusions

In summary, MoO3x nanodots were fabricated by PLA method in MoS2 nanosheets solutions. Here, MoS2 nanosheets with diameter of 200–300 nm acted directly as numerous fine targets. During the laser ablation, MoS2 nanosheets underwent a process of fragmentation under high temperature and high pressure and transfered to MoO3x nanodots, which were confirmed by TEM, HRTEM, XRD, XPS. MoO3x nanodots showed a homogeneous morphology with narrow size distribution, the average diameter is about 3 nm. MoO3x nanodots exhibit excellent catalase and SOD mimic activities, which was reported for the first time according to our knowledge. Then MoO3x nanodots are used to allevate Ab-mediated oxidative stress. In addition, MoO3x nanodots inhibit Ab aggregation and destabilize the preformed fibrils, and eventually protect neuronal cells from apoptosis induced by Ab. The relative inhibition mechanisms are further studied. Compared to other nanomaterials which also showed Ab inhibition effect [\[11\],](#page-9-0) our MoO3x nanodots have much smaller size and may easier to cross the BBB in the future studies. Furthermore, PEG coating may also improve the penetration of nanodots in brain tissue as it conferred an increase of half-life circulation in blood [\[31\].](#page-9-0) Therefore, MoO3x nanodots with multifunctional activities may act as an efficient candidate for treatment of neurotoxicity mediated by amyloid-b peptide.

#### Acknowledgements

This work was supported by National key research and development program from the Ministry of Science and Technology of China (2016YFC0207102), National Natural Science Foundation of China (21503053, 21573050, 21501034).

#### Appendix A. Supplementary material

Supplementary data to this article can be found online at [https://doi.org/10.1016/j.jcis.2018.12.093.](https://doi.org/10.1016/j.jcis.2018.12.093)

#### References

- [1] [C.L. Masters, R. Bateman, K. Blennow, C.C. Rowe, R.A. Sperling, J.L. Cummings,](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0005) [Alzheimer's disease, Nat. Rev. Dis. Prime. 1 (2015) 15056](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0005).
- [2] [M. Boiret, How to illustrate ligand-protein binding in a class experiment: an](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0010) [elementary fluorescent assay, J. Chem. Educ. 63 (1986) 365–366.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0010)
- [3] [A. Ray Chowdhuri, S. Tripathy, S. Chandra, S. Roy, S.K. Sahu, A ZnO decorated](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0015) [chitosan-graphene oxide nanocomposite shows significantly enhanced](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0015) [antimicrobial activity with ROS generation, RSC Adv. 5 (2015) 49420–49428](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0015).
- [4] [D.A. Butterfield, Amyloid beta-peptide (1–42)-induced oxidative stress and](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0020) [neurotoxicity: implications for neurodegeneration in Alzheimer's disease brain](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0020) [a review, Free Rad. Res. 36 (2002) 1307–1313.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0020)
- [5] [C. Cheignon, M. Tomas, D. Bonnefont-Rousselot, P. Faller, C. Hureau, F. Collin,](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0025) [Oxidative stress and the amyloid beta peptide in Alzheimer's disease, Redox](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0025) [Biol. 14 (2018) 450–464](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0025).
- [6] [G. Pizzino, N. Irrera, M. Cucinotta, G. Pallio, F. Mannino, V. Arcoraci, F.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0030) [Squadrito, D. Altavilla, A. Bitto, Oxidative stress: harms and benefits for human](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0030) [health, Oxid. Med. Cell Longev. 2017 (2017) 13](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0030).
- [7] [A. Tramutola, C. Lanzillotta, M. Perluigi, D.A. Butterfield, Oxidative stress,](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0035) [protein modification and Alzheimer disease, Brain Res. Bull. 133 (2017) 88–96](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0035).
- [8] [B. Andrea, B. Eva, K. Martina, K. Peter, V. Francesco, T. Natalia, T. Milan, B.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0040) [Jaroslava, B. Fabio, G. Zuzana, Effect of Fe 3 O 4 magnetic nanoparticles on](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0040) [lysozyme amyloid aggregation, Nanotechnology 21 (2010) 065103.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0040)
- [9] J.E. Kim, M. Lee, Fullerene inhibits b[-amyloid peptide aggregation, Biochem.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0045) [Biophys. Res. Commun. 303 (2003) 576–579.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0045)
- [10] [A.V. Ghule, K.M. Kathir, T.K. Suresh Kumar, S.-H. Tzing, J.-Y. Chang, C. Yu, Y.-C.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0050) [Ling, Carbon nanotubes prevent 2,2,2 trifluoroethanol induced aggregation of](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0050) [protein, Carbon 45 (2007) 1586–1589](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0050).

- <span id="page-9-0"></span>[11] [Q. Han, S. Cai, L. Yang, X. Wang, C. Qi, R. Yang, C. Wang, Molybdenum disulfide](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0055) [nanoparticles as multifunctional inhibitors against Alzheimer's disease, ACS](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0055) [Appl. Mater. Interface 9 (2017) 21116–21123.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0055)
- [12] [M. Li, X. Yang, J. Ren, K. Qu, X. Qu, Using graphene oxide high near-infrared](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0060) [absorbance for photothermal treatment of Alzheimer's disease, Adv. Mater. 24](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0060) [(2012) 1722–1728](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0060).
- [13] [M. Mahmoudi, O. Akhavan, M. Ghavami, F. Rezaee, S.M.A. Ghiasi, Graphene](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0065) [oxide strongly inhibits amyloid beta fibrillation, Nanoscale 4 (2012) 7322–](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0065) [7325.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0065)
- [14] [D. Sun, W. Zhang, Q. Yu, X. Chen, M. Xu, Y. Zhou, J. Liu, Chiral penicillamine](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0070)[modified selenium nanoparticles enantioselectively inhibit metal-induced](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0070) amyloid b [aggregation for treating Alzheimer's disease, J. Colloid Interface Sci.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0070) [505 (2017) 1001–1010](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0070).
- [15] [C. Cabaleiro-Lago, F. Quinlan-Pluck, I. Lynch, S. Lindman, A.M. Minogue, E.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0075) [Thulin, D.M. Walsh, K.A. Dawson, S. Linse, Inhibition of amyloid](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0075) b protein [fibrillation by polymeric nanoparticles, J. Am. Chem. Soc. 130 (2008) 15437–](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0075) [15443.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0075)
- [16] [V.L. Colvin, K.M. Kulinowski, Nanoparticles as catalysts for protein fibrillation,](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0080) [P. Natl. Acad. Sci. 104 (2007) 8679–8680](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0080).
- [17] [S. Linse, C. Cabaleiro-Lago, W.-F. Xue, I. Lynch, S. Lindman, E. Thulin, S.E.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0085) [Radford, K.A. Dawson, Nucleation of protein fibrillation by nanoparticles, P.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0085) [Natl. Acad. Sci 104 (2007) 8691–8696](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0085).
- [18] [E. Ju, K. Dong, Z. Chen, Z. Liu, C. Liu, Y. Huang, Z. Wang, F. Pu, J. Ren, X. Qu,](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0090) [Copper(II)–graphitic carbon nitride triggered synergy: improved ROS](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0090) [generation and reduced glutathione levels for enhanced photodynamic](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0090) [therapy, Angew Chem. Int. Ed. 55 (2016) 11467–11471.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0090)
- [19] [R. Bottino, A.N. Balamurugan, S. Bertera, M. Pietropaolo, M. Trucco, J.D.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0095) [Piganelli, Preservation of human islet cell functional mass by anti-oxidative](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0095) [action of a novel SOD mimic compound, Diabetes 51 (2002) 2561–2567.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0095)
- [20] [Y. Lin, J. Ren, X. Qu, Catalytically active nanomaterials: a promising candidate](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0100) [for artificial enzymes, Acc. Chem. Res. 47 (2014) 1097–1105.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0100)
- [21] [H. Wei, E. Wang, Nanomaterials with enzyme-like characteristics](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0105) [(nanozymes): next-generation artificial enzymes, Chem. Soc. Rev. 42 (2013)](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0105) [6060–6093](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0105).
- [22] [L. Gao, J. Zhuang, L. Nie, J. Zhang, Y. Zhang, G. Ning, T. Wang, J. Feng, D. Yang, S.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0110) [Perrett, X. Yan, Intrinsic peroxidase-like activity of ferromagnetic](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0110) [nanoparticles, Nat. Nanotechnol. 2 (2007) 577–583](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0110).
- [23] [K. Fan, C. Cao, Y. Pan, D. Lu, D. Yang, J. Feng, L. Song, M. Liang, X. Yan,](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0115) [Magnetoferritin nanoparticles for targeting and visualizing tumour tissues,](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0115) [Nat. Nanotechnol. 7 (2012) 459.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0115)
- [24] [S. Cai, Q. Han, C. Qi, Z. Lian, X. Jia, R. Yang, C. Wang, Pt74Ag26 nanoparticle](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0120)[decorated ultrathin MoS2](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0120) [nanosheets as novel peroxidase mimics for highly](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0120)

[selective colorimetric detection of H2O2](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0120) [and glucose, Nanoscale 8 (2016)](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0120) [3685–3693](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0120).

- [25] [X. Wang, Q. Han, S. Cai, T. Wang, C. Qi, R. Yang, C. Wang, Excellent peroxidase](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0125) [mimicking property of CuO/Pt nanocomposites and their application as an](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0125) [ascorbic acid sensor, Analyst 142 (2017) 2500–2506.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0125)
- [26] [S. Cai, X. Jia, Q. Han, X. Yan, R. Yang, C. Wang, Porous Pt/Ag nanoparticles with](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0130) [excellent multifunctional enzyme mimic activities and antibacterial effects,](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0130) [Nano Res. 10 (2017) 2056–2069.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0130)
- [27] [S. Cai, C. Qi, Y. Li, Q. Han, R. Yang, C. Wang, PtCo bimetallic nanoparticles with](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0135) [high oxidase-like catalytic activity and their applications for magnetic](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0135)[enhanced colorimetric biosensing, J. Mater. Chem. B 4 (2016) 1869–1877.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0135)
- [28] [J. Mu, L. Zhang, M. Zhao, Y. Wang, Catalase mimic property of Co3O4](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0140) [nanomaterials with different morphology and its application as a calcium](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0140) [sensor, ACS Appl. Mater. Interface 6 (2014) 7090–7098](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0140).
- [29] [R.W. Tarnuzzer, J. Colon, S. Patil, S. Seal, Vacancy engineered ceria](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0145) [nanostructures for protection from radiation-induced cellular damage, Nano](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0145) [Lett. 5 (2005) 2573–2577](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0145).
- [30] [Y. Huang, Z. Liu, C. Liu, E. Ju, Y. Zhang, J. Ren, X. Qu, Self-assembly of multi](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0150)[nanozymes to mimic an intracellular antioxidant defense system, Angew](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0150) [Chem. Int. Ed. 55 (2016) 6646–6650](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0150).
- [31] [Y. Zhou, Z. Peng, E.S. Seven, R.M. Leblanc, Crossing the blood-brain barrier with](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0155) [nanoparticles, J. Cont. Rel. 270 (2018) 290–303](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0155).
- [32] [M.C.P. Mendonça, E.S. Soares, M.B.D. Jesus, H.J. Ceragioli, M.S. Ferreira, R.R.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0160) [Catharino, M.A. Cruzhöfling, Reduced graphene oxide induces transient blood–](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0160) [brain barrier opening: an in vivo study, J. Nanobiotechnol. 13 (2015) 78–91](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0160).
- [33] [E.A. Nance, G.F. Woodworth, K.A. Sailor, T.Y. Shih, Q. Xu, G. Swaminathan, D.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0165) [Xiang, C. Eberhart, J. Hanes, A dense poly(ethylene glycol) coating improves](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0165) [penetration of large polymeric nanoparticles within brain tissue, Sci. Transl.](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0165) [Med. 4 (2012) 119](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0165).
- [34] [J. Li, Q. Han, X. Wang, N. Yu, L. Yang, R. Yang, C. Wang, Reduced aggregation](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0170) [and cytotoxicity of amyloid peptides by graphene oxide/gold nanocomposites](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0170) [prepared by pulsed laser ablation in water, Small 10 (2014) 4386–4394](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0170).
- [35] [H. Wu, R. Yang, B. Song, Q. Han, J. Li, Y. Zhang, Y. Fang, R. Tenne, C. Wang,](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0175) [Biocompatible inorganic fullerene-like molybdenum disulfide nanoparticles](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0175) [produced by pulsed laser ablation in water, ACS Nano 5 (2011) 1276–1281](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0175).
- [36] [H. Zeng, X.W. Du, S.C. Singh, S.A. Kulinich, S. Yang, J. He, W. Cai, Nanomaterials](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0180) [via laser ablation/irradiation in liquid: a review, Adv. Func. Mater. 22 (2012)](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0180) [1333–1353](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0180).
- [37] [P. Joensen, R.F. Frindt, S.R. Morrison, Single-layer MoS2, Mater. Res. Bull. 21](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0185) [(1986) 457–461](http://refhub.elsevier.com/S0021-9797(18)31534-0/h0185).