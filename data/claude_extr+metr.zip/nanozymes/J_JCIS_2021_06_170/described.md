<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or branding element rather than a scientific diagram or chemical structure. It depicts a stylized tree with intricate branches and leaves, with two human figures standing beneath it. The word "ELSEVIER" is prominently displayed below the illustration in orange text. As this does not contain relevant scientific or chemical information, it is classified as an abstract image in the context of chemistry research.</DESCRIPTION_FROM_IMAGE>

Contents lists available at [ScienceDirect](http://www.sciencedirect.com/science/journal/00219797)

# Journal of Colloid and Interface Science

journal homepage: [www.elsevier.com/locate/jcis](http://www.elsevier.com/locate/jcis)

## Porous Au@Pt nanoparticles with superior peroxidase-like activity for colorimetric detection of spike protein of SARS-CoV-2

<DESCRIPTION_FROM_IMAGE>This image appears to be a simple logo or icon design. It consists of a circular shape with a stylized bookmark or ribbon symbol inside. Given that this does not convey specific scientific or chemical information, I would classify this as:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Zhao Fu a,1 , Weilun Zeng a,b,1 , Shuangfei Cai a,⇑ , Haolin Li a,b , Jianwei Ding a , Chen Wang a , Yunfa Chen c , Ning Han c , Rong Yang a,b,⇑

a CAS Key Lab for Biomedical Effects of Nanomaterials and Nanosafety, Center of Materials Science and Optoelectronics Engineering, CAS center for Excellence in Nanoscience, National Center for Nanoscience and Technology, University of Chinese Academy of Sciences, Beijing, China b Sino-Danish College, Sino-Danish Center for Education and Research, University of Chinese Academy of Sciences, Beijing, China

c State Key Laboratory of Multiphase Complex Systems, Institute of Process Engineering, Chinese Academy of Sciences, Beijing, China

## graphical abstract

Porous Au@Pt nanoparticles (NPs) with electron-rich Pt shells exhibited significantly enhanced peroxidase-like activity by changing the catalytic reaction path, which offered valuable opportunities to construct sensitive colorimetric biosensors, as exemplified by detection of spike 1 protein of severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2).

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a chemical process involving the synthesis and application of gold-platinum nanoparticles (Au@Pt NPs) for the detection of SARS-CoV-2 spike protein. The process is illustrated in several steps:

1. Nanoparticle Synthesis:
   - A series of three flasks shows the reduction process:
     a) First flask: Au3+ ions
     b) Second flask: Reduction of Au3+ to form gold nanoparticles
     c) Third flask: Further reduction with Pt4+ to form Au@Pt core-shell nanoparticles

2. Nanoparticle Characterization:
   - An enlarged view of the Au@Pt nanoparticles shows their spherical structure and core-shell nature

3. Antibody Conjugation:
   - The Au@Pt nanoparticles are conjugated with antibodies, represented by Y-shaped structures

4. Detection Mechanism:
   - The conjugated nanoparticles interact with the SARS-CoV-2 spike protein (represented by a star-like structure)
   - This interaction triggers a catalytic reaction:
     a) H2O2 (hydrogen peroxide) is converted to H2O (water)
     b) TMB (3,3',5,5'-tetramethylbenzidine) is oxidized to oxTMB

5. Assay Format:
   - A multi-well plate is shown, suggesting the reaction occurs in a plate-based assay format

The image illustrates the integration of nanotechnology, immunology, and catalytic chemistry for the development of a potential diagnostic tool for SARS-CoV-2 detection. The use of Au@Pt nanoparticles as catalysts for the TMB oxidation in the presence of H2O2 forms the basis of a colorimetric assay, where the presence of the spike protein can be detected through the color change of TMB to oxTMB.</DESCRIPTION_FROM_IMAGE>

## article info

Article history: Received 17 April 2021 Revised 18 June 2021 Accepted 30 June 2021 Available online 5 July 2021

## abstract

The development of colorimetric assays for rapid and accurate diagnosis of coronavirus disease 2019 (COVID-19), caused by severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2), is of practical importance for point-of-care (POC) testing. Here we report the colorimetric detection of spike (S1) protein of SARS-CoV-2 based on excellent peroxidase-like activity of Au@Pt nanoparticles, with merits of rapidness, easy operation, and high sensitivity. The Au@Pt NPs were fabricated by a facile seed-

<sup>⇑</sup> Corresponding authors at: CAS Key Lab for Biomedical Effects of Nanomaterials and Nanosafety, Center of Materials Science and Optoelectronics Engineering, CAS center for Excellence in Nanoscience, National Center for Nanoscience and Technology, University of Chinese Academy of Sciences, Beijing, China.

E-mail addresses: [caisf@nanoctr.cn](mailto:caisf@nanoctr.cn) (S. Cai), [yangr@nanoctr.cn](mailto:yangr@nanoctr.cn) (R. Yang).

<sup>1</sup> Z. Fu and W. L. Zeng contributed equally to this work.

Keywords: Nanozyme Catalysis Mechanism Colorimetric Detection SARS-CoV-2 spike protein mediated growth approach, in which spherical Au NPs were premade as seeds, followed by the Pt growth on Au seeds, producing uniform, monodispersed and porous Au@Pt core–shell NPs. The as-obtained Au@Pt NPs showed a remarkable enhancement in the peroxidase-mimic catalysis, which well abided by the typical Michaelis-Menten theory. The enhanced catalysis of Au@Pt NPs was ascribed to the porous nanostructure and formed electron-rich Pt shells, which enabled the catalytic pathway to switch from hydroxyl radical generation to electron transfer process. On a basis of these findings, a colorimetric assay of spike (S1) protein of SARS-CoV-2 was established, with a linear detection range of 10–100 ng mL1 of protein concentration and a low limit of detection (LOD) of 11 ng mL1 . The work presents a novel strategy for diagnosis of COVID-19 based on metallic nanozyme-catalysis.

2021 Elsevier Inc. All rights reserved.

## 1. Introduction

In recent years, the rapid development of nanozymes based on enzyme-like activity of inorganic nanomaterials, especially metallic nanoparticles/nanoclusters containing biocompatible elements (e. g., Au and Pt), has gained considerable attention, owing to potential applications in biomedical fields [\[1–5\]](#page-8-0). Under mild reaction conditions (e. g., physiological temperature and aqueous phase media), these metallic nanomaterials could catalyze the oxidations of chromogenic enzyme substrates with environmentally benign oxidants including molecular oxygen (O2) and hydrogen peroxide (H2O2), exhibiting same behavior as oxidases and peroxidases. Besides eco-friendliness of the catalytic system, many of metallic nanozymes demonstrated simplicity of preparation and satisfactory stability, which overcome several intrinsic drawbacks of enzymes [\[6\],](#page-8-0) thus attractive for both biochemical industry and laboratory research. For example, via a simple NaBH4 reduction method, Ahmed et al. obtained the positively-charged cysteamine stabilized Au nanoparticles [\[7\]](#page-8-0), which exhibited good peroxidaselike activity in the oxidation of 3,30 ,5,50 -tetramethylbenzidine (TMB), yielding typical blue products readily observed by naked eyes. After conjugation of Au nanoparticles (NPs) with influenza virus-specific antibodies, a colorimetric assay was successfully applied to the detection of clinically isolated influenza virus (H3N2), which afforded a LOD of 11.62 plaque forming units (PFU) mL1 , two orders of magnitude sensitive than conventional enzyme-linked immunosorbent assay (ELISA) and the commercial kit. Therefore, with advantages of convenience, reliability, and practicality, metallic nanozymes provide a useful platform for colorimetric biosensing.

Despite broad prospect of metallic nanozymes in biomedical areas, there is still much room to boost their activities, which is crucial to efficient utilization of metal atoms. In this goal, to develop multimetallic nanozymes has become an effective strategy. Previous studies presented that, the introduction of other metals into metallic NPs to construct the multimetallic nanostructures (e. g., alloy [\[8,9\]](#page-8-0) and core–shell structures [\[10,11\])](#page-8-0), contributed to an enhancement of enzymatic activity, depending on their composition, morphology and size. However, the comprehensive mechanism still lacks sufficient investigation, which is of importance to fully exert the biocatalytic capacities, in terms of ever-growing demands for practical applications.

Currently, the world is combating coronavirus disease 2019 (COVID-19), a novel human infectious disease arisen from severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) [\[12\].](#page-8-0) For global spread epidemic, the accurate diagnosis with rapidity, simplicity, and low cost, is the primary focus of attention. Several diagnostic methodologies based on plasmonic photothermal effect and localized surface plasmon resonance (LSPR) sensing transduction [\[13\],](#page-8-0) reverse transcription-polymerase chain reaction (RT-PCR) [\[14\],](#page-8-0) electrochemical [\[15\],](#page-8-0) graphene-based field-effect transistor (FET) [\[16\],](#page-8-0) and immunofluorimetric assay [\[17\],](#page-8-0) have been developed. Despite high sensitivity, the first one fails to achieve desired reproducibility in large batches of testing, while others require specific conditions, high testing costs and professional analytical skills, thus unfavorable for point-of-care (POC) test. Intriguingly, Ventura et al. proposed a colorimetric method based on Au NP interaction induced by SARS-CoV-2, which gave rise to the variation of extinction spectrum of corresponding solution in a few minutes, demonstrating potential applications of colorimetric assays in fast and reliable detection of SARS-CoV-2 [\[18\].](#page-8-0) To develop a colorimetric assay based on metallic nanozymes for spike (S1) protein of SARS-Cov-2 is anticipated for the POC diagnosis, but less explored to date.

Herein, we report superior peroxidase-catalysis of Au@Pt NPs conjugated by the polyclonal antibodies, which allowed sensitive colorimetric detection of spike (S1) protein of SARS-CoV-2 [(Fig. 1)](#page-2-0). To access the Au@Pt NPs, the uniform and monodispersed Au NPs as seeds were first prepared, followed by in situ reduction of the Pt4+ ions on the surface of Au NPs, creating a core–shell nanostructure with porous characteristics. Interestingly, the asobtained Au@Pt NPs showed remarkably enhanced peroxidasecatalysis. Importantly, the introduction of Pt atoms into Au NPs leaded to a significant change in the enzyme-catalysis pathway, from reactive oxygen species (ROS) generation to fast electron transfer (ET) process. Benefiting from outstanding peroxidase-like activity of Au@Pt NPs, a colorimetric assay for detection of S1 protein of SARS-Cov-2 was then proposed, on a basis of ELISA described as follows (see details in experimental section). Firstly, the as-obtained Au@Pt NPs were functionalized by the antibodies. Afterwards, the capture antibodies were immobilized onto the 96 wells plate, in which the detected antigen was anchored to the specific sites and the bovine serum albumin (BSA) was used to block the remaining unbound sites. Finally, the antibodyfunctionalized Au@Pt NPs were introduced to attach the antigen, which catalyzed TMB oxidation and realized the detection of the target antigen. The work provides a colorimetric assay based on the metallic nanozyme-catalysis for sensitive detection of S1 protein of SARS-CoV-2.

#### 2. Experimental

#### 2.1. Reagents and materials

HAuCl43H2O (99.9% pure), H2PtCl66H2O (99% pure), L-(+) ascorbic acid (99% pure), 3,30 -diaminobenzidine (99% pure), ophenylenediamine (98% pure) and carbamoyl-2,2,5,5-tetrame thyl-3-pyrrolin-1-yloxy (CTPO, 99% pure) were provided by Alfa Aesar. 5,5-Dimethyl-1-pyrroline N-oxide (DMPO, 98% pure) and 2,2,6,6-tetramethylpiperidine (TEMP, 99% pure) were acquired from Innochem. Rhodamine B and glucose oxidase (GOx) were supplied by Amresco. Reduced cytochrome C was purchased from Abcam (Shanghai, China). 2,20 -Azinobis (3-ethylbenzo-thiazoline-

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a chemical process involving the synthesis and application of gold-platinum nanoparticles (Au@Pt NPs) for the detection of spike proteins, likely in the context of viral diagnostics.

The process is illustrated in several steps:

1. Nanoparticle Synthesis:
   - Three flasks show the reduction process:
     a) Initial solution (likely containing Au3+ ions)
     b) Intermediate step after first reduction (possibly forming gold nanoparticles)
     c) Final step after second reduction with Pt4+ ions, forming Au@Pt NPs

2. Nanoparticle Conjugation:
   - The Au@Pt NPs are shown to be conjugated with antibodies

3. Detection Mechanism:
   - The conjugated nanoparticles interact with spike proteins (likely from a virus)
   - This interaction is shown to occur in a multi-well plate

4. Colorimetric Assay:
   - TMB (3,3',5,5'-Tetramethylbenzidine) is added as a substrate
   - H2O2 (hydrogen peroxide) is also added
   - The Au@Pt NPs catalyze the oxidation of TMB in the presence of H2O2
   - This results in the formation of oxTMB, which produces a colored product

The image suggests that this system can be used for the colorimetric detection of spike proteins, potentially for rapid viral diagnostics. The use of Au@Pt NPs as catalysts for the TMB oxidation reaction allows for signal amplification, likely improving the sensitivity of the assay.

Key components in the image:
- Au@Pt NPs: Gold-platinum core-shell nanoparticles
- Antibody: Y-shaped structures representing antibodies conjugated to the nanoparticles
- Spike 1 protein: Likely representing viral spike proteins
- TMB: 3,3',5,5'-Tetramethylbenzidine (substrate)
- H2O2: Hydrogen peroxide
- oxTMB: Oxidized form of TMB (colored product)

The image does not provide specific SMILES notations for the chemical structures involved.</DESCRIPTION_FROM_IMAGE>

Fig. 1. Illustration of colorimetric detection of spike 1 protein of SARS-CoV-2 based on peroxidase-catalysis of Au@Pt NPs.

6-sulfonic acid) diammonium salt (99% pure) was bought from J&K Scientific Ltd. (Beijing, China). TMB (99% pure) was obtained from Acros. Trisodium citrate dihydrate (99% pure) was provided by Sinopharm Chemical Reagent Co., Ltd. (Beijing, China). PBS buffer (pH 7.2–7.4), a-amylase, lysozyme, and horseradish peroxidase (HRP) were provided by Solarbio Science & Technology Co., Ltd. (Beijing, China). Collagen was supplied by Yuanye Co., Ltd. (Shanghai, China). SARS-CoV-2 S1 recombinant protein (S1 protein), nucleocapsid protein (N protein) and anti-SARS-CoV-2 S1 antibody were acquired from Sangon Biotech Co., Ltd. (Shanghai, China).

#### 2.2. Instruments

The morphology of NPs was characterized by transmission electron microscopy (TEM, FEI Tecnai G2 F20 U-TWIN). The crystal structure of NPs was determined by X-ray powder diffraction (XRD, Bruker D8 focus). The composition of NPs was measured by the inductively coupled plasma optical emission spectroscopy (ICP-OES, Thermo Scientific iCAP 6300). The surface analysis for NPs was completed by X-ray photoelectron spectroscopy (XPS, Thermo Fisher ESCALAB 250Xi). Zeta potential data was collected by a nanoparticle analyzer (Malvern zetasizer Nano ZS). Electron paramagnetic resonance (EPR) measurements were carried out at ambient temperature in a Bruker EMX EPR spectrometer (Billerica, MA).

### 2.3. Synthesis of Au NPs

Typically, 240 lL of HAuCl43H2O (25 mM) was diluted with 10 mL of deionized water, followed by heating to 100 C. Then, 1 mL of trisodium citrate dihydrate (10 mg mL1 ) was quickly added, which allowed for 10 min of reaction. After cooling down to room temperature, the product was separated by centrifugation and redispersed in deionized water to form a dispersion (0.442 mg mL1 ).

## 2.4. Synthesis of Au@Ptx NPs

Briefly, 1.0 mL of above Au NP dispersion was diluted with 8 mL of deionized water, followed by addition of the required volume of H2PtCl66H2O aqueous solution (20 mM) and 0.1 M of ascorbic acid (AA, AA/Pt4+ = 5). The mixture was heated at 80 C for 30 min with stirring. Finally, the product was separated by centrifugation, washed repeatedly, and redispersed in deionized water to obtain a dispersion.

#### 2.5. Enzyme-catalysis test

For the oxidase-mimic-catalysis, the substrate (10 lL, 50 mM) and NP dispersion (30 lL, 0.218 mM) were incubated in acetate buffer (100 mM, same as below) for the required time, followed by measuring absorbance at 652 nm using a multimode plate reader (PerkinElmer EnSpire, same as below). For the peroxidasemimic-catalysis, above procedure was applied except that H2O2 (10 lL, 250 mM) was additionally introduced.

#### 2.6. Investigations of ROS generation

The possible ROS generated during catalysis, including hydroxyl radicals (OH), superoxide anions (O2 ), and singlet oxygen (1 O2), were identified by the oxidations of probe molecules and EPR, using acetate buffer (pH 4) or DMSO as the reaction media.

#### 2.6.1. Oxidations of probe molecules

For oxidation of rhodamine B, H2O2 (10 lL, 50 mM), rhodamine B (30 lL, 0.5 mM) and NP dispersion (30 lL, 0.218 mM) were added to buffer (930 lL), followed by incubation for 30 min in the dark. Then, the UV–Vis spectrum of reaction mixture was collected.

For oxidation of isopropanol, TMB (10 lL, 50 mM), H2O2 (10 lL, 50 mM) and Au@Pt3.15 dispersion (30 lL, 0.218 mM) were added to buffer (940 lL), followed by incubation with isopropanol with different concentrations (10 lL, 25, 50, 100 and 200 mM). Then, the absorbance of reaction mixture was measured at 652 nm.

For oxidation of terephthalic acid, terephthalic acid (0.25 mmol) was first dissolved in NaOH solution (10 mL) to prepare a solution of terephthalic acid (0.025 M). Then, above solution (10 lL, 0.025 M), H2O2 (10 lL, 50 mM) and Au@Pt3.15 dispersion (5 lL, 0.218 mM) were incubated in buffer (975 lL) in the dark for 1 h. Finally, the fluorescence spectrum of reaction mixture was collected.

#### 2.6.2. EPR measurement

All samples were prepared on the spot, followed by EPR measurement. To test possible OH radicals, the DMPO solution (10 lL, 500 mM), H2O2 solution (10 lL, 200 mM) and NP dispersion (10 lL, 5 mM) were added into buffer (470 lL), followed by incubation of 10 min.

To test possible 1 O2, the TEMP solution (10 lL, 2 M) and NP dispersion (10 lL, 5 mM) were added into buffer (480 lL), followed by incubation of 10 min.

To test possible O2 radicals, the NP powder (1 mg) was dissolved in DMSO (490 lL). The resulted solution was incubated in air for 10 min, followed by addition of DMPO solution (10 lL, 500 mM).

Besides, the possible O2 production, from catalytic decomposition of H2O2 by Au@Pt3.15 NPs, was also studied by EPR. Considering interference of dissolved O2, N2 was introduced to exclude residual O2 in all reaction solutions before use. Briefly, the deoxygenated CTPO solution (10 lL, 1 mM), H2O2 solution (10 lL, 200 mM) and Au@Pt3.15 dispersion with different concentrations (10 lL, 0.5 or 5 mM) were co-incubated in buffer (470 lL) for 10 min, followed by EPR measurement.

### 2.7. Electron transfer experiment

The possible electron transfer during catalysis was study by oxidation of reduced cytochrome C. Briefly, under N2 atmosphere, the reduced cytochrome C (10 lL, 4 mM) and Au@Pt3.15 dispersion (20 lL, 0.218 mM) were incubated in acetate buffer (970 lL, pH 4) for 2.5 h. Then, the UV–Vis spectrum of reaction mixture was recorded.

## 2.8. Conjugation of the Au@Ptx NPs

The antibodies were conjugated onto the Au@Ptx NPs by adsorption. Take the conjugation of the Au@Pt3.15 NPs for example, 1.0 mL of Au@Pt3.15 dispersion (0.853 mg mL1 ) was mixed with 19 mL of S1 detection antibody with different concentrations (0.25, 0.5, 1.0, 2.0, 5.0, 7.5 and 10 ng mL1 ), followed by the coincubation at 4 C for 24 h. After washing with PBS buffer (same as below), the antibody-conjugated NPs were used for antigen detection in immunoassay. Above procedure was applied to the incubation of HRP (0.213 mg mL1 ) conjugated with antibody except for washing by PBS.

### 2.9. Detection of S1 protein of SARS-Cov-2

The detection of S1 protein was performed in 96-well polystyrene plates. Firstly, 100 lL of the capture antibody was loaded into each well and incubated at 4 C overnight. After washing 5 times, each well was blocked by 1% BSA in PBS buffer, followed by addition of 100 lL of S1 protein with different concentrations, coincubation at 4 C for the required time, and washing 5 times. Next, 100 lL of the antibody-conjugated Au@Pt3.15 NPs (0.218 mM) was added into each well and incubated at room temperature for 2 h, which was further allowed to wash 5 times. Afterwards, 100 lL of solution containing TMB (2 mM) and H2O2 (10 mM) was added into each well to initiate the catalysis at room temperature for 20 min. Finally, 50 lL of H2SO4 solution (2 M) was added to stop the reaction, and the absorbance was recorded at 450 nm.

### 3. Discussion

#### 3.1. Synthesis and characterization

The Au NPs were prepared by the liquid-phase reduction of HAuCl43H2O by trisodium citrate dihydrate in boiling water. The obtained Au NPs has fine uniformity in size with about 13 nm in diameter (Fig. S1). With Au NPs as seeds, H2PtCl66H2O as the metal precursor was introduced together with ascorbic acid as the reductant, allowing the subsequent reduction of Pt4+ ions on the Au NPs at 80 C. The synthetic methodology demonstrates advantages of rapidness, easy manipulation, as well as without employment of toxic agents/solvents and complex equipment. During the synthesis, by fixing the amount of Au seeds while simply adjusting the feed of Pt precursors, a series of Au@Ptx NPs (x = 1, 5, 7.5, 10, 12.5, 15) were synthesized, where x represents the molar ratio of Pt/Au.

Expectedly, the diameter of NPs had a tendency to increase as the Pt/Au feed ratio increased (Fig. S2). The larger feed ratio also resulted in more Pt content in products, from the composition analysis by ICP-OES (Table S1). [Fig. 2A](#page-4-0) displays a representative TEM image of the as-obtained Au@Pt3.15 NPs using a Pt/Au feed ratio of 5, with porous characteristics and an average diameter of about 25 nm. From the high-resolution TEM (HRTEM) image shown in [Fig. 2](#page-4-0)B, lots of smaller particles (ca. 4 nm in size) were distributed on the surface of a single NP selected randomly, which were assembled into a porous outer layer. The lattice fringes of a typical particle with interplanar spacing of 0.226 nm [(Fig. 2](#page-4-0)C), corresponded well to Pt (111) plane. These results suggest that the surface particles were composed of Pt elements. The core–shell structure of NPs was also confirmed by the XRD analysis. Fig. S3 shows all diffraction peaks of the Au@Pt3.15 NPs were well indexed to (111), (2 00), (22 0), (311) and (222) planes of the facecentered cubic (fcc) Au (JCPDS No. 04–0802) and fcc Pt (JCPDS No. 04–0784), indicating two metallic phases in the products. The Au@Ptx NPs obtained by other feed ratios gave similar diffraction patterns. More structural evidences were acquired from the high-angle, annular dark-field scanning TEM (HAADF-STEM) image [(Fig. 2](#page-4-0)D) and corresponding elemental maps of metals [(Fig. 2E](#page-4-0) and 2F). Besides, the XPS analysis of surface chemical state of metals in the Au@Pt3.15 NPs also provided useful information. As shown in [Fig. 2G](#page-4-0), the sample was observed at binding energies (BEs) of 71.8 eV (Pt 4f7/2) and 75.1 eV (Pt 4f5/2) attributed to metallic Pt, while BEs at 72.4 eV (Pt 4f7/2) and 75.9 eV (Pt 4f5/2) corresponded to Pt2+ species [\[19\],](#page-8-0) respectively. Meanwhile, the Au 4f7/2 and Au 4f5/2 core level BEs appeared at 84.7 eV and 88.4 eV [(Fig. 2H](#page-4-0)), respectively in good agreement with bulk Au metallic values [\[20\].](#page-8-0) Thus, the obtained NPs was made of Au0 cores and Pt shells with coexistence of Pt0 and Pt2+.

#### 3.2. Catalytic properties

To investigate enzymatic activity, TMB oxidation was carried out in open air, with the Au@Pt3.15 NPs as a model catalyst. After addition of NPs, the solution clearly displayed a blue color [(Fig. 3](#page-4-0)A), with maximum absorption at 652 nm characteristic of oxidized TMB [\[21\]](#page-8-0). Additional introduction of H2O2 gave rise to a deeper blue color of the solution. Besides, in the absence or presence of H2O2, other chromogenic substrates like ABTS, OPD, and DAB, could be oxidized by the Au@Pt3.15 NPs, exhibiting characteristic green, yellow and brown color, respectively [(Fig. 3](#page-4-0)B to D). Thus, the Au@Pt3.15 NPs possessed oxidase- and peroxidase-like activities.

#### 3.3. Optimization of reaction parameters

The peroxidase-like activity is of special interest due to numerous applications in biomedical areas. To obtain the best catalytic performance of the Au@Ptx NPs for practical applications, several parameters for TMB oxidation were systematically investigated. As previously revealed, the composition of multimetallic NPs could affect their enzymatic activity [\[22\]](#page-8-0). For the Au@Ptx NPs, as the Pt/ Au ratio increased, the absorbance increased but gradually decreased when above 3.15 [(Fig. 4](#page-5-0)A). Meanwhile, pH and temperature played essential roles in the catalysis, in which the optimal

<DESCRIPTION_FROM_IMAGE>This image is a composite of several microscopy and spectroscopy results, labeled A through H. I'll describe each part in detail:

A: Transmission Electron Microscopy (TEM) image showing aggregated nanoparticles with a scale bar of 20 nm. The particles appear as dark, irregularly shaped clusters.

B: Higher magnification TEM image of a single nanoparticle aggregate with a scale bar of 5 nm. A blue box highlights a specific area for further analysis.

C: High-resolution TEM image of the area highlighted in B. It shows lattice fringes, indicating crystallinity. The lattice spacing is measured as 0.226 nm, as indicated by yellow lines and text.

D: Scanning Electron Microscopy (SEM) image of the nanoparticles, showing their three-dimensional morphology. Scale bar is 20 nm.

E: Energy Dispersive X-ray Spectroscopy (EDS) mapping image, likely showing the distribution of a specific element (possibly gold) in yellow.

F: Another EDS mapping image, showing the distribution of a different element (possibly platinum) in red.

G: X-ray Photoelectron Spectroscopy (XPS) spectrum focusing on the 4f region, likely of platinum. Two main peaks are visible, labeled as 4f5/2 and 4f7/2. The binding energy range is from 68 to 80 eV. The spectrum is deconvoluted into multiple component peaks.

H: Another XPS spectrum, likely of gold, showing the 4f region. Two main peaks are visible, labeled as 4f5/2 and 4f7/2. The binding energy range is from 84 to 90 eV.

This set of images suggests a comprehensive characterization of bimetallic nanoparticles, likely a gold-platinum alloy or core-shell structure. The microscopy images reveal the morphology and size of the particles, while the spectroscopy data provides information about their elemental composition and chemical state.</DESCRIPTION_FROM_IMAGE>

Fig. 2. Characterization of the Au@Pt3.15 NPs: (A) TEM image, (B) HRTEM image, (C) enlarged HRTEM image of the region indicated in Fig. 2B, (D) HAADF-STEM image and corresponding element maps of (E) Au and (F) Pt as well as high-resolution XPS spectra of (G) Pt and (H) Au.

<DESCRIPTION_FROM_IMAGE>This image contains four UV-Vis absorption spectra labeled A, B, C, and D, each showing the absorbance of different chemical systems across various wavelengths.

A) This graph shows absorbance from 400 to 800 nm. It includes an inset image of five vials with a color gradient from clear to blue. The legend indicates five conditions:
- 'a' (lowest absorbance)
- 'b', 'c', 'd' (intermediate, overlapping near zero)
- 'e' (highest absorbance, peak around 650 nm)
The main peak for 'e' is at approximately 650 nm with an absorbance of about 1.4.

B) This graph shows absorbance from 350 to 500 nm. The legend indicates:
- ABTS
- NPs
- H2O2 + ABTS
- NPs + ABTS
- NPs + H2O2 + ABTS (highest absorbance)
The NPs + H2O2 + ABTS condition shows a peak around 415 nm with an absorbance of about 0.8.

C) This graph shows absorbance from 300 to 700 nm. The legend indicates:
- OPD
- NPs
- H2O2 + OPD
- NPs + OPD
- NPs + H2O2 + OPD (highest absorbance)
The NPs + H2O2 + OPD condition shows a peak around 450 nm with an absorbance of about 0.4.

D) This graph shows absorbance from 300 to 700 nm. The legend indicates:
- DAB
- NPs
- H2O2 + DAB
- NPs + DAB
- NPs + H2O2 + DAB (highest absorbance)
The NPs + H2O2 + DAB condition shows a broad peak from 350 to 450 nm with a maximum absorbance of about 0.7.

Each of B, C, and D includes an inset image of two vials with different colored solutions.

These spectra likely represent the peroxidase-like activity of nanoparticles (NPs) with different substrates (ABTS, OPD, DAB) in the presence of hydrogen peroxide (H2O2).</DESCRIPTION_FROM_IMAGE>

Fig. 3. (A) UV–Vis spectra of solutions: (a) TMB, (b) catalyst, (c) TMB + H2O2, (d) TMB + catalyst and (e) TMB + catalyst + H2O2 as well as UV–Vis spectra of reaction solutions for catalytic oxidations of (B) ABTS, (C) OPD and (D) DAB.

absorbance were achieved at pH = 4 [(Fig. 4B](#page-5-0)) and 60 C [(Fig. 4](#page-5-0)C), respectively, similar to other Au-based nanozymes [\[23\].](#page-8-0) Additionally, the concentration of oxidant, substrate, and catalyst, also affected catalysis. The absorbance continuously increased with H2O2 concentration (cH) below 10 mM, but it gradually decreased when cH was above 10 mM [(Fig. 4D](#page-5-0)). For the concentration of TMB (cTMB), a moderate value of cTMB (2 mM) gave the largest absorbance [(Fig. 4](#page-5-0)E). Moreover, the absorbance increased as the concentration of catalyst (ccat) below 1.1 lM; however, by further raising ccat, the absorbance slightly decreased [(Fig. 4F](#page-5-0)). Therefore, the optimized parameters for the Au@Pt3.15 NPs are as follows: pH 4, 60 C of temperature, 10 mM of cH, 2 mM of cTMB, and 1.1 lM of ccat.

### 3.4. Kinetics study

To elucidate the mechanism, the TMB oxidation by the Au@Pt3.15 NPs was conducted by the steady-state kinetic experi-

<DESCRIPTION_FROM_IMAGE>The image contains six separate graphs labeled A through F, each showing the relationship between absorbance and various parameters. Here's a detailed description of each graph:

A. Absorbance vs Pt/Au (mol%):
The graph shows a sharp peak at around 3 mol% Pt/Au, with absorbance reaching approximately 0.62. The absorbance starts at about 0.34 at 0 mol%, rises to the peak, and then decreases to about 0.22 at 8 mol%.

B. Absorbance vs pH:
This graph demonstrates a bell-shaped curve with a maximum at pH 4, where the absorbance is about 0.55. The absorbance is lowest at pH 2 (about 0.08) and pH 8 (about 0.06), with a gradual increase and decrease on either side of the peak.

C. Absorbance vs Temperature (°C):
The absorbance increases with temperature from about 0.3 at 0°C to a maximum of about 0.72 at 60°C. After 60°C, there's a sharp decrease to about 0.2 at 80°C.

D. Absorbance vs cH (mM):
This graph shows a rapid increase in absorbance from 0 to 10 mM cH, reaching a maximum of about 1.4. After 10 mM, there's a gradual decrease to about 1.1 at 50 mM.

E. Absorbance vs cTMB (mM):
The absorbance increases sharply from 0 to 2 mM cTMB, reaching about 1.0. After 2 mM, the absorbance plateaus with a slight decrease to about 0.96 at 5 mM.

F. Absorbance vs ccat (μM):
This graph shows a steady increase in absorbance as ccat increases. The absorbance starts at about 0.4 at 0 μM and rises to about 1.8 at 1.2 μM, with the curve beginning to level off at higher concentrations.

All graphs show error bars on the data points, indicating experimental uncertainty. The x-axis scales and units vary between graphs, while the y-axis consistently represents absorbance. These graphs likely represent optimization studies for a chemical or biochemical assay, investigating the effects of various parameters on the absorbance of a system.</DESCRIPTION_FROM_IMAGE>

Fig. 4. Effect of (A) Pt/Au feed ratio, (B) pH, (C) temperature, concentration of (D) H2O2, (E) TMB and (F) catalyst on the peroxidase-like activities of Au@Ptx NPs. All samples were measured in triplicates.

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled A, B, C, and D, each showing different relationships between variables related to chemical kinetics.

Graph A:
- X-axis: CH (mM), ranging from 0 to 10 mM
- Y-axis: v (μM s^-1), ranging from 0 to 14 μM s^-1
- Shows a non-linear relationship between CH and v
- Data points follow a curve that appears to be approaching saturation
- R^2 value of 0.988 indicates a good fit of the data to the model

Graph B:
- X-axis: CTMB (mM), ranging from 0 to 1 mM
- Y-axis: v (μM s^-1), ranging from 0 to 0.35 μM s^-1
- Displays a hyperbolic curve characteristic of enzyme kinetics or similar saturation processes
- R^2 value of 0.992 suggests an excellent fit of the data to the model

Graph C:
- X-axis: 1/CH (mM^-1), ranging from 0 to 4 mM^-1
- Y-axis: 1/v (μM^-1 s), ranging from 0 to 1.6 μM^-1 s
- Shows a linear relationship between 1/CH and 1/v
- This graph is likely a Lineweaver-Burk plot, used in enzyme kinetics analysis
- R^2 value of 0.991 indicates a very good linear fit

Graph D:
- X-axis: 1/CTMB (mM^-1), ranging from 0 to 20 mM^-1
- Y-axis: 1/v (μM^-1 s), ranging from 2 to 12 μM^-1 s
- Displays a linear relationship between 1/CTMB and 1/v
- This is also likely a Lineweaver-Burk plot for a different substrate or condition
- R^2 value of 0.997 suggests an excellent linear fit

These graphs collectively provide information about the kinetics of a chemical or enzymatic reaction, showing both direct plots (A and B) and reciprocal plots (C and D) that are commonly used in analyzing reaction rates and determining kinetic parameters such as Km and Vmax.</DESCRIPTION_FROM_IMAGE>

Fig. 5. Kinetic analysis for the Au@Pt3.15 NPs-catalyzed TMB oxidations by (A, B) Michaelis-Menten and (C, D) Lineweaver-Burk models, respectively. The catalyst concentration was kept at 0.654 lM (based on total metals) for all reactions, which were completed at 60 C in buffer (pH 4), by changing concentration of either H2O2 (0.25, 0.5, 1, 2.5, 5, 7.5 and 10 mM) or TMB (0.05, 0.1, 0.25, 0.5, 0.75 and 1 mM).

ments, on a basis of similar procedure reported by our grou[p\[24\].](#page-8-0) By respectively changing the cH and cTMB in the reaction system, the kinetic data as a function of time were carefully gathered.

As shown in Fig. 5, the kinetic data of the Au@Pt3.15 NPs could be fitted well with both the Michaelis-Menten equation and Lineweaver-Burk model, suggesting they exhibited typical behavior of HRP. For comparison, the same observation was obtained for the Au NPs (Fig. S4). By virtue of two important parameters in the Michaelis-Menten equation, i. e., Km and vmax which respectively represent the affinity of enzyme towards the substrate and the maximum reaction rate, the enzyme-catalysis capability of the Au@Pt3.15 NPs and Au NPs could be compared. As listed in Table S2, the Km values for Au@Pt3.15 NPs were comparable to those for HRP and other NPs like Fe3O[4\[25\]](#page-8-0) and Pt NP[s\[26\],](#page-8-0) indicating

<DESCRIPTION_FROM_IMAGE>The image contains four separate graphs labeled A, B, C, and D, each presenting different spectroscopic data.

Graph A: UV-Vis absorption spectra
- X-axis: Wavelength (nm) from 400 to 800 nm
- Y-axis: Absorbance from 0 to 0.5
- Four conditions plotted:
  1. Rh B + H2O2 + NPs (highest peak)
  2. Rh B + H2O2 (overlapping with 1)
  3. Rh B + NPs (overlapping with 1 and 2)
  4. H2O2 + NPs (flat line near zero absorbance)
- Main absorption peak at approximately 560 nm
- Slight shoulder visible around 520 nm

Graph B: Bar graph of absorbance vs isopropanol concentration
- X-axis: Cisopropanol (mM) with values: Control, 0.25, 0.5, 1, 2
- Y-axis: Absorbance from 0 to 1.4
- All bars show similar absorbance values around 1.3
- No significant difference observed between control and various isopropanol concentrations

Graph C: Fluorescence emission spectra
- X-axis: Wavelength (nm) from 350 to 600 nm
- Y-axis: FL intensity (a.u.) from 0 to 1200
- Three conditions plotted:
  1. TA + H2O2 (highest intensity)
  2. TA + H2O2 + NPs (medium intensity)
  3. TA + NPs (lowest intensity, near baseline)
- Emission peak centered around 435 nm for conditions 1 and 2

Graph D: UV-Vis absorption spectra
- X-axis: Wavelength (nm) from 300 to 800 nm
- Y-axis: Absorbance from 0 to 1.6
- Two conditions plotted:
  1. red-CytC + N2
  2. red-CytC + N2 + NPs
- Major absorption peak at approximately 415 nm
- Smaller peaks/shoulders visible around 520 and 550 nm
- Inset graph shows magnified view of 500-600 nm region

Key observations:
1. NPs (likely nanoparticles) affect the spectroscopic properties in various systems
2. Rhodamine B (Rh B) shows characteristic absorption around 560 nm
3. Isopropanol concentration doesn't significantly affect absorbance in the tested system
4. TA (possibly terephthalic acid) fluorescence is quenched by NPs
5. Reduced cytochrome C (red-CytC) shows characteristic absorption peaks, with NPs causing slight changes in the spectrum</DESCRIPTION_FROM_IMAGE>

Fig. 6. UV–Vis spectra of solutions for oxidations of (A) Rh B and (B) isopropanol; (C) fluorescence spectra of reaction solutions for oxidation of TA and (D) UV–Vis spectra of solutions for oxidation of red-CytC.

good affinity of the Au@Pt3.15 NPs. Despite similar affinity of the Au NPs towards substrates, however, they delivered far lower vmax values. The formed porous shells by introducing Pt atoms could provide abundant reaction sites and tunnels, which could be beneficial for adsorption and activation of reactants, thus leading to enhanced catalysis of the Au@Pt3.15 NPs.

## 3.5. Catalytic mechanism

The peroxidase-mimic catalysis involving metallic NPs often undergoes two types of pathways: the ROS production [\[27\]](#page-8-0) and the ET process [\[28\]](#page-8-0). For the former, the metals could catalyze decomposition of OAO bonds in H2O2 molecules, generating OH radicals as important active oxygen intermediates. Contrarily, for the latter, the metals could not trigger ROS generation during catalysis, but mediate ET from the enzyme substrate to the catalyst.

To probe possible OH radicals yielded by Au@Pt3.15 NPs, several typical probes (rhodamine B [\[29\],](#page-8-0) isopropanol [\[30\]](#page-8-0) and terephthalic acid [\[31\])](#page-8-0) were employed, since they can react with OH radicals. However, in both of potential oxidations of rhodamine B (Rh B) and isopropanol, the absorbance of solutions remained substantially unchanged after co-incubation of probes, H2O2, and NPs (Fig. 6A and 6B), implying that OH radicals could not be generated in the system. Similar result was obtained from another probe reaction by oxidation of terephthalic acid (TA). From the blue curve shown in Fig. 6C, when the NPs were absent, the fluorescence (FL) spectrum of the solution displayed an obvious peak located at about 440 nm, corresponding to 2-hydroxyterephthalic acid as the oxidized product of TA [\[32\]](#page-8-0). Moreover, the FL intensity of the solution could be increased by prolonging reaction time or raising concentration of H2O2 (Fig. S5). These results indicate TA molecules were partially oxidized by OH radicals, deriving from selfdecomposition of instable H2O2. However, the FL intensity of the solution at the same wavelength significantly decreased after addition of NPs (red curve, Fig. 6C). To investigate whether the decrease in FL intensity was related to catalytic decomposition of H2O2 by the Au@Pt3.15 NPs, the EPR experiments were performed, with CTPO as spin trap for oxygen. As shown in Fig. S6A, compared to the control experiment, the super hyperfine structure in the EPR spectra became weak in the presence of 0.5 mM of Au@Pt3.15 NPs, which further became smooth when the concentration of Au@Pt3.15 NPs was increased to 5 mM, indicating production of more O2 gas. Thus, the Au@Pt3.15 NPs could catalytically decompose H2O2, showing similar behavior as catalases and reducing the concentration of H2O2. In this case, the production of OH radicals by self-decomposition of H2O2 was limited, thereby leading to a decrease of FL intensity of TA oxidation products. Meanwhile, direct evidence of OH generation by the Au@Pt3.15 NPs was not obtained by EPR, in which no signal was observed (Fig. S6B). Above results suggest no additional OH radicals could be generated in the presence of the Au@Pt3.15 NPs.

However, the case for the Au NPs was just on the opposite. In the presence of Au NPs, there was a slight decrease in the absorbance of solution of Rh B (Fig. S7A), while an increase in the fluorescence intensity of solution at 440 nm was observed for TA oxidation (Fig. S7B). The results indicate partial oxidation of Rh B and TA molecules, as a result of generation of OH radicals by the Au NPs. The observation was also proved by EPR, in which the Au NPs gave a four-line signal with a 1:2:2:1 peak-to-peak intensity pattern (Fig. S6B), characteristic of adduct of OH and DMPO [\[1\],](#page-8-0) suggesting capability of generating OH radicals by the Au NPs. Thus, different from the Au@Pt3.15 NPs, the Au NPs followed a pathway of ROS generation during catalysis. Additionally, considering the dissolved O2 in buffer, other possible ROS like 1 O2 and O2 radicals were also studied by EPR. However, neither of them was identified for both Au and Au@Pt3.15 NPs, since no obvious change of EPR signal compared with those of control experiments (Figs. S6C and 6D). Collectively, ROS generation could be excluded during the peroxidase-catalysis of Au@Pt NPs.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled A and B, each showing the relationship between absorbance and concentration (CS1) in ng mL^-1. Both graphs have insets with linear regression analyses.

Graph A:
- Main plot: Absorbance vs CS1 concentration from 0 to 800 ng mL^-1
- Absorbance range: 0.0 to 1.6
- Curve shape: Rapid increase initially, then leveling off (saturation-like curve)
- Inset: Linear portion of the curve
  - X-axis: 0 to 100 ng mL^-1
  - Y-axis: 0.2 to 1.0 absorbance units
  - Linear equation: y = 0.00426x + 0.431
  - R^2 value: 0.980

Graph B:
- Main plot: Absorbance vs CS1 concentration from 0 to 800 ng mL^-1
- Absorbance range: 0.0 to 0.6
- Curve shape: Similar to Graph A, but with lower overall absorbance values
- Inset: Linear portion of the curve
  - X-axis: 0 to 100 ng mL^-1
  - Y-axis: 0.00 to 0.30 absorbance units
  - Linear equation: y = 0.00186x + 0.0767
  - R^2 value: 0.967

Both graphs have a series of small circular images above them, showing gradual color change from light to darker shades, likely representing the visual change in samples as concentration increases.

The graphs demonstrate a concentration-dependent increase in absorbance, with a linear relationship at lower concentrations and saturation at higher concentrations. Graph A shows higher overall absorbance values compared to Graph B, suggesting different sensitivity or experimental conditions between the two measurements.</DESCRIPTION_FROM_IMAGE>

Fig. 7. Colorimetric detection of S1 protein of SARS-CoV-2 based on ELISA: Absorbance of solutions along with the increase of protein concentration using (A) the Au@Pt3.15 NPs and (B) HRP. All samples were measured in triplicates. The top insets display corresponding color of solutions, and the bottom right insets show the linear relationship between absorbance and the concentration of S1 protein.

At the same time, the possible ET process was investigated by oxidation of reduced cytochrome C (red-CytC), an active electron acceptor bears characteristic absorption peaks at 520 and 550 nm [\[33\].](#page-8-0) After co-incubation of red-CytC and NPs, these peaks disappeared while a new peak appeared at 530 nm assigned to the oxidized CytC [(Fig. 6D](#page-6-0)), indicating electron transfer from the substrate to the catalyst. Meanwhile, the electronic structure of the Au@Pt3.15 NPs was studied by XPS. Compared to the Au 4f7/2 core level BE (84.3 eV) in the Au NPs (Fig. S8), the Au@Pt3.15 NPs exhibited a positive Au 4f7/2 core level BE shift (0.4 eV), suggesting the electronic structure of Au atoms was modified by Pt atoms. The increase of BE in the Au@Pt3.15 NPs indicates that electrons transferred from Au atoms to Pt atoms, leading to formation of electron-deficient Au cores but electron-rich Pt shells, and thus favorable for adsorption and activation of TMB molecules. The Au cores provided electrons for the Pt atoms on the shells, which brought a substantial change in the catalytic pathway of the Au NPs, that is, from intrinsic ROS generation to fast ET, ultimately facilitating catalysis of the Au@Pt3.15 NPs.

#### 3.6. Colorimetric detection of S1 protein of SARS-CoV-2

The highly efficient peroxidase-catalysis of the Au@Pt3.15 NPs could be potentially beneficial to construct sensitive biosensors for S1 protein of SARS-CoV-2. Taking advantage of porous Pt shells, the NPs could be conveniently functionalized with the polyclonal antibodies through simple adsorption, which was verified by the measurement of Zeta potential in water (Fig. S9). However, the coating of antibodies might block active sites of the NPs, causing a decrease in the enzyme-like activity. Experimentally, in the range of antibody concentration (cab) from 0.25 to 0.5 ng mL1 , about one half of absorbance relative to the largest value remained; as cab further increased, the absorbance greatly decreased (Fig. S10). To guarantee specificity for detection, the NPs were modified using a value of cab of 0.5 ng mL1 . Meanwhile, the incubation of S1 protein within 2 h was adequate for the detection (Fig. S11).

The colorimetric reaction was completed within 20 min. As the concentration of S1 protein (cS1) increased (from 10 ng mL1 to 800 ng mL1 ), the absorbance of reaction solutions gradually increased, and was linearly proportional to cS1 in the range of 10–100 ng mL1 (Fig. 7A). As the parallel test, the assay based on the HRP was also made (Fig. 7B). To estimate the LOD, the absorbance of a series of blank samples (n = 12) without protein were carefully determined (Fig. S12). The limit of detection was then calculated from the equation: LOD = 3r/S, where r represents the standard deviation of blank samples and S refers to the slope of the calibration curve. As listed in Table S3, present ELISA kit gave

<DESCRIPTION_FROM_IMAGE>The image presents a bar graph showing the absorbance values for different proteins and enzymes, along with a series of vials in the upper right corner. The graph's y-axis represents absorbance, ranging from 0 to 1.6. The x-axis lists seven different biomolecules: Spike 1 protein, Nuclear protein, GOx, Collagen, BSA, α-Amylase, and Lysozyme.

The absorbance values for each biomolecule are as follows:

1. Spike 1 protein: approximately 1.5
2. Nuclear protein: approximately 0.4
3. GOx (Glucose Oxidase): approximately 0.35
4. Collagen: approximately 0.37
5. BSA (Bovine Serum Albumin): approximately 0.35
6. α-Amylase: approximately 0.4
7. Lysozyme: approximately 0.35

Each bar in the graph has an error bar at the top, indicating the standard deviation or error range of the measurements.

The Spike 1 protein shows a significantly higher absorbance compared to the other biomolecules, which all have relatively similar absorbance values ranging between 0.35 and 0.4.

In the upper right corner of the image, there is a series of seven small vials or wells, likely corresponding to the seven biomolecules tested. The leftmost vial appears to have a darker color compared to the others, which could be related to the higher absorbance value of the Spike 1 protein.

This graph likely represents a comparative study of the absorbance properties of these different proteins and enzymes, possibly in the context of a binding assay or protein quantification experiment.</DESCRIPTION_FROM_IMAGE>

Fig. 8. Selectivity for colorimetric detection of S1 protein of SARS-CoV-2 using Au@Pt3.15 NPs. The inset shows corresponding color of solutions. All samples were measured in triplicates.

a LOD with a value of 11 ng mL1 , lower than the HRP conjugated one (19 ng mL1 ), HRP conjugated monoclonal antibodies (37 ng mL1 for F26G18 or 19 ng mL1 for F157) [\[34\],](#page-8-0) and other methods such as electrochemical (14 ng mL1 ) [\[35\].](#page-8-0) Therefore, present assay showed high sensitivity.

The selectivity of our method was further examined. From Fig. 8, the solution containing S1 protein presented the largest absorbance, showing a brown color easily observed by naked eyes. However, in the control experiments involving other proteins (e. g., nuclear protein, glucose oxidase, collagen, BSA, a-amylase, and lysozyme), none of them gave significant absorbance, with light yellow color of solutions. Thus, the established assay demonstrated good selectivity towards S1 protein.

### 4. Conclusion

In summary, the Au@Pt3.15 NPs were successfully utilized to construct a novel colorimetric biosensor for S1 protein of SARS-CoV-2 based on their excellent peroxidase-like activity, with merits of simplicity, high sensitivity and selectivity. Notably, the porous nanostructure and electron-rich Pt shells of the Au@Pt3.15 NPs significantly enhanced their peroxidase-catalysis, during which fast electron transfer was believed to be an important cat<span id="page-8-0"></span>alytic pathway, different from that of the Au NPs-catalyzed ROS generation. Our observations will be helpful to the mechanism understanding of nanozyme catalysis and development of colorimetric biosensors based on metallic NPs for practical diagnosis.

### CRediT authorship contribution statement

Zhao Fu: Investigation, Data curation, Formal analysis, Visualization. Weilun Zeng: Investigation, Data curation, Visualization. Shuangfei Cai: Conceptualization, Methodology, Validation, Writing - original draft. Haolin Li: Resources. Jianwei Ding: Resources. Chen Wang: Supervision. Yunfa Chen: Supervision. Ning Han: Supervision. Rong Yang: Supervision, Funding acquisition, Project administration.

#### Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

#### Acknowledgments

This work was supported by the Strategic Priority Research Program of the Chinese Academy of Sciences (XDB36000000), National key research and development program from the Ministry of Science and Technology of China (2016YFC0207102), and National Natural Science Foundation of China (21503053).

#### Appendix A. Supplementary material

Supplementary data to this article can be found online at <https://doi.org/10.1016/j.jcis.2021.06.170>.

#### References

- [1] [S. Cai, R. Yang, Noble Metal-Based Nanozymes, in: X. Yan (Ed.), In](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0005) [Nanozymology: Connecting Biology and Nanotechnology, Springer,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0005) [Singapore, 2020, pp. 331–365](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0005).
- [2] [Y. Huang, J. Ren, X. Qu, Nanozymes: Classification, Catalytic Mechanisms,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0010) [Activity Regulation, and Applications, Chem. Rev. 119 (6) (2019) 4357–4412](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0010).
- [3] [L. Jin, Z. Meng, Y. Zhang, S. Cai, Z. Zhang, C. Li, L. Shang, Y. Shen, Ultrasmall Pt](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0015) [Nanoclusters as Robust Peroxidase Mimics for Colorimetric Detection of](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0015) [Glucose in Human Serum, ACS Appl. Mater. Interfaces. 9 (11) (2017) 10027–](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0015) [10033.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0015)
- [4] [P. Ni, H. Dai, Y. Wang, Y. Sun, Y. Shi, J. Hu, Z. Li, Visual detection of melamine](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0020) [based on the peroxidase-like activity enhancement of bare gold nanoparticles,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0020) [Biosens. Bioelectron. 60 (2014) 286–291.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0020)
- [5] [H. Wei, E. Wang, Nanomaterials with enzyme-like characteristics](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0025) [(nanozymes): next-generation artificial enzymes, Chem. Soc. Rev. 42 (14)](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0025) [(2013) 6060–6093](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0025).
- [6] [H. Wang, K. Wan, X. Shi, Recent Advances in Nanozyme Research, Adv. Mater.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0030) [31 (45) (2019) e1805368](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0030).
- [7] [S.R. Ahmed, J. Kim, T. Suzuki, J. Lee, E.Y. Park, Detection of influenza virus using](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0035) [peroxidase-mimic of gold nanoparticles, Biotechnol. Bioeng. 113 (10) (2016)](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0035) [2298–2303.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0035)
- [8] [W. He, X. Han, H. Jia, J. Cai, Y. Zhou, Z. Zheng, AuPt Alloy Nanostructures with](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0040) [Tunable Composition and Enzyme-like Activities for Colorimetric Detection of](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0040) [Bisulfide, Sci. Rep. 7 (1) (2017) 40103](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0040).
- [9] [Q. Wang, L. Zhang, C. Shang, Z. Zhang, S. Dong, Triple-enzyme mimetic activity](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0045) [of nickel-palladium hollow nanoparticles and their application in colorimetric](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0045) [biosensing of glucose, Chem. Commun. 52 (31) (2016) 5410–5413](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0045).
- [10] [Z. Gao, M. Xu, M. Lu, G. Chen, D. Tang, Urchin-like (gold core)@(platinum shell)](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0050) [nanohybrids: A highly efficient peroxidase-mimetic system for in situ](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0050) [amplified colorimetric immunoassay, Biosens. Bioelectron. 70 (2015) 194–201.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0050)
- [11] [T. Jiang, Y. Song, D. Du, X. Liu, Y. Lin, Detection of p53 Protein Based on](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0055) [Mesoporous Pt–Pd Nanoparticles with Enhanced Peroxidase-like Catalysis,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0055) [ACS Sens. 1 (6) (2016) 717–724.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0055)
- [12] [R. Lu, X. Zhao, J. Li, P. Niu, B. Yang, H. Wu, W. Wang, H. Song, B. Huang, N. Zhu,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0060) [Y. Bi, X. Ma, F. Zhan, L. Wang, T. Hu, H. Zhou, Z. Hu, W. Zhou, L. Zhao, J. Chen, Y.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0060) [Meng, J. Wang, Y. Lin, J. Yuan, Z. Xie, J. Ma, W.J. Liu, D. Wang, W. Xu, E.C.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0060) [Holmes, G.F. Gao, G. Wu, W. Chen, W. Shi, W. Tan, Genomic characterisation](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0060)

[and epidemiology of 2019 novel coronavirus: implications for virus origins](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0060) [and receptor binding, Lancet 395 (10224) (2020) 565–574](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0060).

- [13] [G. Qiu, Z. Gai, Y. Tao, J. Schmitt, G.A. Kullak-Ublick, J. Wang, Dual-Functional](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0065) [Plasmonic Photothermal Biosensors for Highly Accurate Severe Acute](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0065) [Respiratory Syndrome Coronavirus 2 Detection, ACS Nano 14 (5) (2020)](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0065) [5268–5277.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0065)
- [14] [Z. Huang, D. Tian, Y. Liu, Z. Lin, C.J. Lyon, W. Lai, D. Fusco, A. Drouin, X. Yin, T.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0070) [Hu, B. Ning, Ultra-sensitive and high-throughput CRISPR-p owered COVID-19](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0070) [diagnosis, Biosens. Bioelectron. 164 (2020) 112316](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0070).
- [15] [J.-H. Lee, M. Choi, Y. Jung, S.K. Lee, C.-S. Lee, J. Kim, J. Kim, N.H. Kim, B.-T. Kim,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0075) [H.G. Kim, A novel rapid detection for SARS-CoV-2 spike 1 antigens using](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0075) [human angiotensin converting enzyme 2 (ACE2), Biosens. Bioelectron. 171](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0075) [(2021) 112715.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0075)
- [16] [G. Seo, G. Lee, M.J. Kim, S.-H. Baek, M. Choi, K.B. Ku, C.-S. Lee, S. Jun, D. Park, H.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0080) [G. Kim, S.-J. Kim, J.-O. Lee, B.T. Kim, E.C. Park, S.I. Kim, Rapid Detection of](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0080) [COVID-19 Causative Virus (SARS-CoV-2) in Human Nasopharyngeal Swab](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0080) [Specimens Using Field-Effect Transistor-Based Biosensor, ACS Nano 14 (4)](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0080) [(2020) 5135–5142.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0080)
- [17] [C. Bravin, V. Amendola, Wide range detection of C-Reactive protein with a](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0085) [homogeneous immunofluorimetric assay based on cooperative fluorescence](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0085) [quenching assisted by gold nanoparticles, Biosens. Bioelectron. 169 (2020)](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0085) [112591.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0085)
- [18] [B.D. Ventura, M. Cennamo, A. Minopoli, R. Campanile, S.B. Censi, D.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0090) [Terracciano, G. Portella, R. Velotta, Colorimetric Test for Fast Detection of](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0090) [SARS-CoV-2 in Nasal and Throat Swabs, ACS Sens. 5 (10) (2020) 3043–3048](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0090).
- [19] [D. Lu, Y. Zhang, S. Lin, L. Wang, C. Wang, Synthesis of PtAu bimetallic](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0095) [nanoparticles on graphene–carbon nanotube hybrid nanomaterials for](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0095) [nonenzymatic hydrogen peroxide sensor, Talanta 112 (2013) 111–116.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0095)
- [20] [Y. Jia, R. Hu, Q. Zhou, H. Wang, X. Gao, J. Zhang, Boron-modified activated](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0100) [carbon supporting low-content Au-based catalysts for acetylene](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0100) [hydrochlorination, J. Catal. 348 (2017) 223–232.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0100)
- [21] [S. Cai, C. Qi, Y. Li, Q. Han, R. Yang, C. Wang, PtCo bimetallic nanoparticles with](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0105) [high oxidase-like catalytic activity and their applications for magnetic](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0105)[enhanced colorimetric biosensing, J. Mater. Chem. B 4 (10) (2016) 1869–1877.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0105)
- [22] [Y. Sun, J. Wang, W. Li, J. Zhang, Y. Zhang, Y. Fu, DNA-stabilized bimetallic](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0110) [nanozyme and its application on colorimetric assay of biothiols, Biosens.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0110) [Bioelectron. 74 (2015) 1038–1046.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0110)
- [23] [Y. Tao, Y. Lin, Z. Huang, J. Ren, X. Qu, Incorporating graphene oxide and gold](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0115) [nanoclusters: a synergistic catalyst with surprisingly high peroxidase-like](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0115) [activity over a broad pH range and its application for cancer cell detection,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0115) [Adv. Mater. 25 (18) (2013) 2594–2599](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0115).
- [24] [S. Cai, X. Jia, Q. Han, X. Yan, R. Yang, C. Wang, Porous Pt/Ag nanoparticles with](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0120) [excellent multifunctional enzyme mimic activities and antibacterial effects,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0120) [Nano Res. 10 (6) (2017) 2056–2069.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0120)
- [25] [L. Gao, J. Zhuang, L. Nie, J. Zhang, Y. Zhang, N. Gu, T. Wang, J. Feng, D. Yang, S.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0125) [Perrett, X. Yan, Intrinsic peroxidase-like activity of ferromagnetic](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0125) [nanoparticles, Nature Nanotechnol. 2 (9) (2007) 577–583.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0125)
- [26] [L. Liu, B. Du, C. Shang, J. Wang, E. Wang, Construction of surface charge](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0130)[controlled reduced graphene oxide-loaded Fe3O4 and Pt nanohybrid for](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0130) [peroxidase mimic with enhanced catalytic activity, Anal. Chim. Acta. 1014](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0130) [(2018) 77–84](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0130).
- [27] [M. Ma, Y. Zhang, N. Gu, Peroxidase-like catalytic activity of cubic Pt](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0135) [nanocrystals, Colloids Surf. A 373 (1) (2011) 6–10.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0135)
- [28] [M. Cui, J. Zhou, Y. Zhao, Q. Song, Facile synthesis of iridium nanoparticles with](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0140) [superior peroxidase-like activity for colorimetric determination of H2O2 and](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0140) [xanthine, Sens. Actuators. B 243 (2017) 203–210.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0140)
- [29] [Z. Chen, J.-J. Yin, Y.-T. Zhou, Y. Zhang, L. Song, M. Song, S. Hu, N. Gu, Dual](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0145) [Enzyme-like Activities of Iron Oxide Nanoparticles and Their Implication for](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0145) [Diminishing Cytotoxicity, ACS Nano 6 (5) (2012) 4001–4012](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0145).
- [30] [S. Cai, W. Xiao, H. Duan, X. Liang, C. Wang, R. Yang, Y. Li, Single-layer Rh](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0150) [nanosheets with ultrahigh peroxidase-like activity for colorimetric biosensing,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0150) [Nano Res. 11 (12) (2018) 6304–6315.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0150)
- [31] [G. Fang, W. Li, X. Shen, J.M. Perez-Aguilar, Y. Chong, X. Gao, Z. Chai, C. Chen, C.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0155) [Ge, R. Zhou, Differential Pd-nanocrystal facets demonstrate distinct](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0155) [antibacterial activity against Gram-positive and Gram-negative bacteria,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0155) [Nature Commun. 9 (1) (2018) 129](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0155).
- [32] [Y. Tao, E. Ju, J. Ren, X. Qu, Bifunctionalized mesoporous silica-supported gold](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0160) [nanoparticles: intrinsic oxidase and peroxidase catalytic activities for](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0160) [antibacterial applications, Adv. Mater. 27 (6) (2015) 1097–1104.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0160)
- [33] [S. Cai, Z. Fu, W. Xiao, Y. Xiong, C. Wang, R. Yang, Zero-Dimensional/Two-](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0165)[Dimensional AuxPd100–x](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0165) [Nanocomposites with Enhanced Nanozyme Catalysis](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0165) [for Sensitive Glucose Detection, ACS Appl. Mater. Interfaces. 12 (10) (2020)](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0165) [11616–11624](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0165).
- [34] [H.H. Sunwoo, A. Palaniyappan, A. Ganguly, P.K. Bhatnagar, D. Das, A.O.S. El-](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0170)[Kadi, M.R. Suresh, Quantitative and sensitive detection of the SARS-CoV spike](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0170) [protein using bispecific monoclonal antibody-based enzyme-linked](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0170) [immunoassay, J. Virol. Methods. 187 (1) (2013) 72–78.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0170)
- [35] [L. Fabiani, M. Saroglia, G. Galatà, R. De Santis, S. Fillo, V. Luca, G. Faggioni, N.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0175) [D'Amore, E. Regalbuto, P. Salvatori, G. Terova, D. Moscone, F. Lista, F. Arduini,](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0175) [Magnetic beads combined with carbon black-based screen-printed electrodes](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0175) [for COVID-19: A reliable and miniaturized electrochemical immunosensor for](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0175) [SARS-CoV-2 detection in saliva, Biosens. Bioelectron. 171 (2021) 112686.](http://refhub.elsevier.com/S0021-9797(21)01055-9/h0175)