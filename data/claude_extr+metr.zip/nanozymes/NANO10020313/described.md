<DESCRIPTION_FROM_IMAGE>The image represents the logo for "nanomaterials". It consists of two main elements:

1. A graphical representation of a nanomaterial structure:
   This appears to be a spherical molecular structure, likely representing a fullerene or similar nanoscale carbon structure. The structure is composed of interconnected nodes, forming a cage-like spherical arrangement typical of nanomaterials like buckminsterfullerene (C60).

2. Text element:
   The word "nanomaterials" is written in lowercase letters to the right of the graphical element.

This logo is likely used to represent a scientific journal, conference, or organization focused on nanomaterials research. The combination of the molecular structure graphic and the text effectively communicates the focus on materials at the nanoscale.

While this image is primarily a logo and doesn't contain detailed scientific information, it does convey the concept of nanomaterials through its graphical representation. Therefore, it's not appropriate to classify this as an ABSTRACT_IMAGE in the context of materials science and nanotechnology.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to simply contain the word "Article" written in an italic serif font. It does not contain any chemical structures, graphs, diagrams or other scientific content relevant to chemistry. Therefore, I have responded with ABSTRACT_IMAGE as instructed for images that do not convey information in the context of applied chemistry or science.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image depicts the logo of MDPI (Multidisciplinary Digital Publishing Institute), a prominent open-access academic publisher. The logo consists of the letters "MDPI" in a bold, sans-serif font. Above the letters is a simple line drawing of a house or roof shape, which forms part of the overall logo design. The logo is presented in a single color against a white background. As this is a publisher's logo and does not contain specific scientific or chemical information, I will classify this as an ABSTRACT_IMAGE.</DESCRIPTION_FROM_IMAGE>

# **Test-System for Bacteria Sensing Based on Peroxidase-Like Activity of Inkjet-Printed Magnetite Nanoparticles**

**Maxim Zakharzhevskii, Andrey S. Drozdov *, Denis S. Kolchanov, Liubov Shkodenko and Vladimir V. Vinogradov *** 

Laboratory of Solution Chemistry of Advanced Materials and Technologies, ITMO University, 197101 St. Petersburg, Russia; maxim_z@scamt-itmo.ru (M.Z.); kolchanov@scamt-itmo.ru (D.S.K.); Shkodenko@scamt-itmo.ru (L.S.)

***** Correspondence: drozdov@scamt-itmo.ru (A.S.D.); vinogradov@scamt-itmo.ru (V.V.V.)

Received: 07 January 2020; Accepted: 08 February 2020; Published: 12 February 2020

**Abstract:** Rapid detection of bacterial contamination is an essential task in numerous medical and technical processes and one of the most rapidly developing areas of nano-based analytics. Here, we present a simple-to-use and special-equipment-free test-system for bacteria detection based on magnetite nanoparticle arrays. The system is based on peroxide oxidation of chromogenic substrate catalyzed by magnetite nanoparticles, and the process undergoes computer-aided visual analysis. The nanoparticles used had a pristine surface free of adsorbed molecules and demonstrated high catalytic activities up to 6585 U/mg. The catalytic process showed the Michaelis–Menten kinetic with *Km* valued 1.22 mmol/L and *Vmax* of 4.39 µmol/s. The nanoparticles synthesized were used for the creation of inkjet printing inks and the design of sensor arrays by soft lithography. The printed sensors require no special equipment for data reading and showed a linear response for the detection of model bacteria in the range of 104–108 colony-forming units (CFU) per milliliter with the detection limit of 3.2 × 103 CFU/mL.

**Keywords:** magnetite; nanoparticles; enzyme-like activity; bacteria detection; inkjet

# **1. Introduction**

Pathogenic bacteria cause many globally essential diseases. Even if the number of dangerous pathogens is negligible in a sample, it can lead to severe consequences [1]. Rapid detection of hazardous bacteria in air, water, and food can improve the quality of clinical diagnosis and reduce the rate of disease transmittance. Another important issue is a high cost of bacteria tests, as the majority of bacterial diseases are found in the third world countries [2,3]. Unfortunately, modern methods for bacteria detection feature several disadvantages, such as high cost, long-time procedures, etc. A standard technique for bacteria determination is based on culturing and plating, which is relatively inexpensive, but it requires lengthy incubation for reliable results [4]. In its turn, reducing detection time and increasing overall sensitivity may be developed by the application of molecularly-amplified (eq polymerase chain reaction) and enzyme-amplified (eq enzyme-linked immunosorbent assay) methods. However, these techniques are expensive and require specialized laboratory facilities [5]. Currently, big efforts are focused on the application of nanomaterials and their properties to overcome the drawbacks other methods have [6]. There are two main strategies. The first class of methods is based on the interactions of bacterial metabolites or bacterial cell walls and nanomaterial. Such an interaction changes physicochemical properties of the latter [7,8]. For instance, Ag and Au nanoparticles can be used for surface-enhanced Raman scattering (SERS) [9], carbon nanotubes for potentiometry [10], CdSe [11], and CdS [12] quantum dots in the fluorescence microscopy and other materials and methods have found their application in bacteria sensing as well [13,14].

The second approach focuses on the optimization of standard biomedical methods using nanomaterials as artificial biomolecular analogues. The methods, which use enzyme mimetics combining the high activity of natural enzymes with comparative cheapness and stability of inorganic catalysts, are actively explored [15]. The pioneering work of Gao et al., has shown that the ability of magnetite particles to catalyze the decomposition of hydrogen peroxide is close to the enzymatic activity of horseradish peroxidase (HRP) [16]. Developing of the area has led to the discovery of other inorganic enzyme mimics with catalase-like, oxidase-like, and phosphatase-like activities [17–19]. Such materials and composites find their application in designing biosensors towards various analytes ranging from small molecules to the whole cells with the working principle based on promotion or inhibition of catalytic activities [20–22]. This principle can also be used for bacteria detection, and modern trends are aimed at increasing the effectiveness and sensitivity of detection systems and at simplifying analysis processes, thus moving to the point of care diagnostics [23–25].

In this article, we describe a simple test-system for bacteria detection which can be used without sophisticated analytical equipment (Fig. 1). The system described is based on a stable magnetite hydrosol with a pristine surface and extremely high peroxidase-like activity, which was patterned into sensor arrays by inkjet printing on polyethylene terephthalate (PET) substrates. The bacteria detection used the inhibition of the sensor peroxidase activity and showed linear dependence in the range of 104–108 colony-forming units (CFU) per milliliter with the detection limit of 3.2 × 103 CFU/mL. Physico-chemical characteristics of the nanoparticles and enzyme-like activity were measured and discussed.

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a process for creating a bacterial biosensor using inkjet printing and E. coli bacteria. The process is shown in four steps:

1. Inkjet printer: The first step shows an inkjet printer depositing Fe2O3 nanoparticles onto a substrate in a grid pattern of circular spots.

2. Inkjet printed Fe2O3 nanoparticles: The second step displays the substrate with the printed grid of Fe2O3 nanoparticle spots.

3. ABTS + E. Coli: In the third step, a solution containing ABTS (2,2'-azino-bis(3-ethylbenzothiazoline-6-sulfonic acid)) and E. coli bacteria is added to the substrate with the Fe2O3 nanoparticle spots.

4. Bacteria concentration: The final step shows a larger grid of spots with varying intensities, representing different concentrations of bacteria across the substrate.

The process illustrates the creation of a biosensor array using inkjet printing technology to deposit Fe2O3 nanoparticles, followed by the addition of ABTS and E. coli. The resulting array demonstrates varying bacterial concentrations, which can be used for sensing or analytical purposes.

Key components mentioned:
- Inkjet printer
- Fe2O3 nanoparticles
- ABTS (2,2'-azino-bis(3-ethylbenzothiazoline-6-sulfonic acid))
- E. coli bacteria

The image demonstrates the integration of nanomaterials (Fe2O3 nanoparticles) with biological components (E. coli) to create a functional biosensor array using a common printing technology.</DESCRIPTION_FROM_IMAGE>

**Figure 1.** Principal scheme of the analytical system proposed.

## **2. Materials and Methods**

## *2.1. Chemicals*

Iron(II) chloride tetrahydrate >98.5% iron (III) chloride hexahydrate >99%, and 2,2′-azino-bis(3 ethylbenzothiazoline-6-sulphonic acid) (ABTS, >99%) were obtained from Sigma-Aldrich and used without further purification. Diethylene glycol (DEG), glycine hydrochloride, aqueous ammonia solution >27.5%, and hydrogen peroxide >35% were purchased from Vekton (Saint-Petersburg, Russia).

## *2.2. Synthesis of Magnetite Nanoparticles* (*MNPs*)

The Fe3O4 nanoparticles were synthesized by a coprecipitation method, as previously described [26,27]. An amount of 2.5 g FeCl2·4H2O and 5 g of FeCl3·6H2O were dissolved with 100 mL of deionized water. Then, 11 mL of aqueous ammonia solution was added to the solution under constant stirring (500 rpm) at room temperature and mixed for 1 min. The magnetite nanoparticles were collected using a magnet and washed using deionized water until a neutral pH level. Magnetic separation included repeated stages: Particle deposition by applying a magnetic field, decantation, adding water, and mechanical resuspension of the sediment. The resulting black precipitate was mixed with 100 mL of deionized water and subjected to ultrasonic treatment (30 kHz, 110 W) under constant stirring for 2 h. Finally, the solution of magnetite nanoparticles was cooled down to room temperature. The ensuing solution of magnetite nanoparticles exhibited the magnetic liquid properties, thus, when a magnetic field was applied, the particles did not separate from the water. The mass fraction of magnetite in the resulting colloid solution was 2% wt.

# *2.3. Inkjet Printing of MNPs*

To pattern MNPs by inkjet printing, the inks with proper rheological parameters were prepared in the manner described earlier [28]. For that purpose, MNPs hydrosol was mixed with diethylene glycol in a ratio of 1:1 to increase its viscosity and decrease the surface tension of the ink to form a steady drop. The hydrodynamic radius of magnetite particles in ink did not exceed 25 nm. The solution was thoroughly mixed and cleaned from possible impurities using a filter with a pore size of 0.22 microns before loading into the cartridge. The cartridge was degassed in the desiccator under vacuum to avoid the formation of residual air bubbles during printing. The test system for bacteria sensing was printed on a Dimatix 2831 R&D inkjet printer, using Dimatix Material cartridges 11610 with a drop volume of 10 pL. The frequency of droplet formation was set to 20 kHz, and the nozzle voltage was set to 19 mV, to achieve a drop rate of 5 m/s.

# *2.4. Hydrodynamic Size and Zeta Potential Measurements*

Hydrodynamic radii and zeta potentials were measured by dynamic light scattering and electrophoretic light scattering techniques, respectively, using a Photocor Compact-Z analyzer (Moscow, Russia). All experiments were conducted under the thermostatic conditions at temperature 25 °C, laser beam power 15 mW, and the time of measurements of 40 s. A 90-degree scattering angle was used to determine the particle size, and a 20-degree angle was used to estimate the zeta potential. Before measurements, equal amounts of hydrosol or xerogel MNPs were diluted in Milli-Q water until transparent solutions were obtained.

# *2.5. Evaluation of MNPs Colloidal Stability at Different pH Levels*

To evaluate the colloidal stability of MNPs in various media, the hydrosol of MNPs was diluted with solutions of sodium hydroxide or hydrochloric acids until the desired pH level was achieved. The solutions were analyzed using dynamic and electrophoretic scattering methods to obtain hydrodynamic characteristics. The experiments were conducted in the manner described in Section 2.4.

## *2.6. Enzymatic Activity of MNPs*

The peroxidase-like activity of freshly synthesized magnetite nanoparticles was determined spectrophotometrically by catalytic oxidation of chromogenic substrate ABTS in the presence of H2O2 at room temperature. The as-prepared hydrosol was dissolved in the glycine buffer (pH = 3.5) to a final concentration of 40 µg/mL. To 1.8 mL of MNPs hydrosol, 100 µL of ABTS (25 mg/mL) and 100 µL of H2O2 (40 mM) solutions were added, the optical density of the system was measured at 415 nm in a kinetic mode. Control experiments included the examination of optical densities of the mixtures of ABTS and MNPs, MNPs and H2O2 (2.0 mM), and ABTS (1.2 mM) with H2O2 (2.0 mM) in 20 mM glycine buffer (pH = 3.5), respectively. To compare the activities of different transition states of MNPs as-prepared hydrosol, xerogel, inks, and dried inks were tested in the same conditions.

#### *2.7. Steady*-*State Kinetics Assay*

Steady-state kinetic measurements were measured in a kinetic mode at 415 nm under the standard reaction conditions (20 mM Gly buffer, pH = 3.5, 25 °C, 40 µg/mL Fe3O4 hydrosol) by varying the concentration of ABTS at a fixed concentration of H2O2 or vice versa. The Michaelis–Menten constant and kinetic parameters were calculated using Lineweaver–Burk linearization plots.

#### *2.8. Colorimetric Detection of Bacteria*

Colorimetric detection of bacteria was established based on the inhibition of MNPs peroxidase mimics. For the experiment, the bacteria were preliminarily separated from the medium by centrifuging and replacing the medium with a buffer solution, after which sequential dilution was

performed to obtain samples with different concentrations of bacteria. Typically, 10 µ*L* of MNPs with

a concentration of 40 µg/mL and 10 µL of aliquot with different concentrations of *E. coli* were added into a 2 mL solution of 1.2 mM ABTS and 20 mM glycine buffer (pH = 3.5). The maximum value of optical density (concentration of oxidized ABTS) of the mixture obtained was plotted against the bacteria concentration. The control CFU measurements were done by culturing and plating.

## *2.9. Image-Based Measurements of Printed Sensors*

An amount of 35 µ*L* ABTS-H2O2 mixture in a glycine buffer (pH = 3.5) was dropped using a multichannel pipette onto the printed sensor and was kept at 25 °C for 10 min on a backlighting table. The standard mixture includes 10 mM H2O2 and varied concentrations of ABTS acting as chromogenic substrate. Images were taken with a digital camera in a manual mode and were converted into the grayscale mode in Photoshop. The luminance of the samples was measured with the Color Sampler Tool in the center of drops with the sample size of 31 × 31 pixels.

## *2.10. Image-Based Bacteria Detection*

Following the calibration chart, *E. coli* concentration was varied. All measurements were conducted under standard conditions, including 20 mM glycine buffer, pH = 3.5, 25 °C, and 10 mM of hydrogen peroxide, 1.2 mM of ABTS by varying the concentration of *E. coli* from 104 to 108 CFU/mL. The samples were incubated for 10 min and analyzed.

#### *2.11. Characterization*

Specific surface area, average pore diameter, and total pore volume were determined by the nitrogen adsorption–desorption method using Quantachrome Nova 1200(e). Sample preparation included samples degassing for 2 h at 100 °C. The surface area was calculated using the Brunauer– Emmett–Teller (BET) equation; the average pore diameter was calculated by the method of Barrett– Joyner–Halenda (BJH). For the comparison, the xerogel was obtained by evaporation at 70 °C in an air oven at normal pressure. The crystal phase was characterized by an X-ray diffractometer D8 Advance of Bruker AXS using Cu *Ka* radiation (λ = 1.54 Å). The specimen was characterized by TEM using a high-resolution TEM Tecnai F20 G2 and by SEM using (HR-SEM) Sirion. Spectrophotometric evaluations were made by Agilent Cary 8454 UV–Visible spectrophotometer with a thermostatic cuvette chamber. Digital images were taken with a Nikon D5300 camera, AF-S DX Nikkor 18–55 mm f/3.5–5.6G VRII shot at 31 mm, manual exposure, 1/100 s, f/4.5, ISO 400, compensation: −1/3.

## **3. Results and Discussion**

# *3.1. Physical Properties of MNPs*

The stable hydrosol of magnetite nanoparticles was obtained by the US-assisted coprecipitation procedure using a mixture of ferric and ferrous chlorides and water–ammonia solution as a base [29]. The precipitate was washed with deionized water by magnetic separation to eliminate nonmagnetic by-products and excess of ammonia. The resulting material was dispersed in 15 MOhm deionized water and subjected to ultrasonic treatment for 2 h (see Section 2.2 for details). Ultrasonication of the particles in water led to the disintegration of the aggregates formed during the coprecipitation process, and intense hydroxylation of the particle surface. As a result, a black stable colloidal system with a magnetic fluid-like behavior was formed. Dynamic light scattering showed that the solution consisted of monodisperse nanoparticles with a hydrodynamic radius of 35 ± 3 nm. The kinetic stability of the resulting colloidal solution was confirmed by electrophoretic light scattering, which shows that zeta potential was 36 ± 2 mV.

To further study the composition and physical properties, the colloidal solution was dried in a vacuum for several hours to avoid oxidation. The thermogravimetric study revealed that the mass fraction of magnetite nanoparticles in the solution was >2%. The X-ray diffraction pattern of the material corresponded to the crystal phase of magnetite, peaks referred to JCPDS file No. 19-0629 (Figure 2A). According to the Scherrer equation, the crystallite size was 10.9 nm. The analysis of particles via TEM and SEM proved a narrow particle size distribution with the diameter of crystallites 10 ± 3 nm. (Figure 2B,C). Upon solvent removal, MNPs underwent sol-gel transition and formed a mesoporous xerogel matrix with the total surface area of 120 m2/g and a mean pore diameter of 8 nm (ESI Figures S1 and S2). Such xerogels were stable in water solutions without any signs of resuspension. The magnetization curve of the material showed superparamagnetic behavior with magnetization up to 78 emu/g at 8 kOe (Figure 2D).

<DESCRIPTION_FROM_IMAGE>The image consists of four panels labeled A, B, C, and D, each representing different analytical techniques used in materials characterization.

Panel A: X-ray Diffraction (XRD) Pattern
This panel shows an XRD pattern with intensity (counts) on the y-axis and 2 Theta (degrees) on the x-axis. The pattern displays several sharp peaks, indicating a crystalline material. The most prominent peaks are observed at approximately 30°, 35°, and 63° 2 Theta. The background shows some noise, typical of XRD measurements. The 2 Theta range extends from 0° to 70°.

Panel B: Transmission Electron Microscopy (TEM) Image
This panel presents a TEM image of spherical nanoparticles. The particles appear to be relatively uniform in size and shape, with diameters ranging from approximately 5 to 10 nm. The particles are well-dispersed and do not show significant agglomeration. The scale bar indicates 10 nm.

Panel C: Scanning Electron Microscopy (SEM) Image
This panel shows an SEM image of a nanostructured material. The material appears to have a porous or sponge-like structure composed of interconnected nanoparticles or nanocrystals. The structure shows a high surface area with numerous small features. The scale bar indicates 100 nm.

Panel D: Magnetic Hysteresis Loop
This panel displays a magnetic hysteresis loop, showing the relationship between magnetization (M, emu/g) on the y-axis and applied magnetic field (H, Oe) on the x-axis. The loop is symmetric and S-shaped, characteristic of a ferromagnetic or ferrimagnetic material. Key features include:

1. Saturation magnetization: approximately 80 emu/g
2. Coercivity: the loop crosses the x-axis at around ±500 Oe
3. Remanence: the magnetization at zero field is about ±40 emu/g

The magnetic field range extends from -8000 Oe to +8000 Oe.

This set of images provides a comprehensive characterization of a nanomaterial, including its crystal structure (XRD), morphology (TEM and SEM), and magnetic properties (hysteresis loop).</DESCRIPTION_FROM_IMAGE>

**Figure 2.** XRD pattern of the synthesized magnetite nanoparticles (MNPs) (**A**); TEM image of the particles (**B**); SEM image of the MNPs (**C**); magnetization curve of the material (**D**).

Excellent colloidal stability and absence of surface modification with organic molecules determined the prospects of the synthesized MNPs towards hydrogen peroxide catalytic cleavage. The colorimetric reaction of ABTS oxidation by hydroxyl radicals resulting in the emerald-green coloring of the solution with the maximum absorbance at 415 nm was used to explore the peroxidaselike activity of the material [30,31]. The initial examinations aimed to find optimal concentrations of H2O2 related to reaction rates. The reaction rate showed Michaelis–Menten dependence on hydrogen peroxide (Figure 3A,B) with *Km* measured for the system valued at 152 mmol/L. The dependence of the ABTS oxidation rate on its concentration was performed at the concentration of hydrogen peroxide of 10 mM to overcome the problems connected with over-oxidation of the substrate [32].

<DESCRIPTION_FROM_IMAGE>This image contains four separate graphs labeled A, B, C, and D, each representing different aspects of chemical kinetics studies.

Graph A:
X-axis: C (H2O2) x 10^4, M (Concentration of hydrogen peroxide in 10^-4 molar)
Y-axis: V^0 x 10^6, M/s (Initial reaction rate in 10^-6 molar per second)
Description: This graph shows the relationship between the concentration of hydrogen peroxide and the initial reaction rate. The curve is non-linear, suggesting a complex reaction order. It shows a steep increase in rate at low concentrations, followed by a more gradual increase at higher concentrations.

Graph B:
X-axis: 1/C (H2O2), 1/M (Inverse of hydrogen peroxide concentration in M^-1)
Y-axis: 1/V^0 x 10^5, s/M (Inverse of initial reaction rate in 10^5 seconds per molar)
Description: This is a linear plot of the inverse initial rate versus the inverse concentration of hydrogen peroxide. The linear relationship suggests adherence to Lineweaver-Burk kinetics. The equation of the line is given as y = 2201.6x + 304148, with an R^2 value of 0.9287, indicating a good fit to the linear model.

Graph C:
X-axis: C (ABTS), mM (Concentration of ABTS in millimolar)
Y-axis: V^0 x 10^6, M/s (Initial reaction rate in 10^-6 molar per second)
Description: This graph shows the relationship between the concentration of ABTS (2,2'-azino-bis(3-ethylbenzothiazoline-6-sulfonic acid)) and the initial reaction rate. The curve is non-linear, showing a rapid increase in rate at low concentrations of ABTS, followed by a plateau at higher concentrations. This shape is characteristic of enzyme kinetics following Michaelis-Menten behavior.

Graph D:
X-axis: 1/C (ABTS), 1/mM (Inverse of ABTS concentration in mM^-1)
Y-axis: 1/V^0 x 10^5, s/M (Inverse of initial reaction rate in 10^5 seconds per molar)
Description: This is a linear plot of the inverse initial rate versus the inverse concentration of ABTS. The linear relationship confirms Michaelis-Menten kinetics. The equation of the line is given as y = 230449x + 189809, with an R^2 value of 0.9578, indicating a very good fit to the linear model.

Overall, these graphs represent kinetic analyses of reactions involving hydrogen peroxide and ABTS, likely in the context of enzyme kinetics or catalysis studies. The combination of non-linear rate plots and their linear transformations allows for the determination of important kinetic parameters and the elucidation of the reaction mechanisms.</DESCRIPTION_FROM_IMAGE>

**Figure 3.** Peroxidase-like activity of MNPs. The kinetic curve and the double reciprocal plots of peroxidase activity at the constant concentration of H2O2 (**A**,**B**); the kinetic curve and the double reciprocal plots of peroxidase activity at the constant concentration of 2,2′-azino-bis(3 ethylbenzothiazoline-6-sulphonic acid) (ABTS) (**C**,**D**).

ABTS concentration was varied to investigate kinetic parameters of the process using the Michaelis–Menten model and Lineweaver–Burk linearization graphs [33] (See Section 2 for details). The dependence of the initial inverse velocity on the inverse concentration of a chromogenic substrate showed linear dependence for nanozyme; therefore, kinetics were described using the Michaelis– Menten model with calculated *Km* 1.22 mmol/L, *Vmax* 4.39 µmol/s, and *Kcat* 365.8 s−1) (Figure 3C,D). The calculated activity of the magnetite hydrosol obtained was 6585 U/mg of dry magnetite, which exceeded the activity of the majority of commercially available enzymes [34]. Compared to the data from the literature for this substrate, the tested pristine nanoparticles showed higher reaction rates, which can be attributed to the higher activity of the surface due to the availability of catalytic centers and lower diffusion limitations (See ESI Table S1).

#### *3.2. Bacteria Detection*

The principal for bacteria detection in this study relied on bacteria-induced inhibition of MNPs peroxidase activity. Therefore, adding different concentrations of washed bacteria to the solution modified the procedure of the catalytic experiment. The experiments showed that increasing the bacterial concentration decreases the rate of reaction, which reduces the slope of the kinetic curve. Bacteria inhibit the activity of magnetite nanocatalysts in the oxidation reaction of a chromogenic substrate ABTS-hydrogen peroxide. In this case, one can use the optical density at a wavelength of an analytical signal at a specific time. In this study, we chose a 4-min point that gave the most reproducible results (Figure 4).

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled A and B.

Graph A:
This graph shows the relationship between optical density (OD) and bacterial concentration expressed as log(CFU/ml). The x-axis represents lg(CFU/ml) ranging from 3 to 7, while the y-axis shows OD values from 0.7 to 1.1. The data points are plotted with error bars, and a linear trend line is drawn through the points. The graph demonstrates a negative correlation between OD and bacterial concentration, with OD decreasing as bacterial concentration increases.

Graph B:
This graph illustrates the relationship between zeta potential (mV) and bacteria concentration (x10^5 CFU). The x-axis represents bacteria concentration from 0 to 12 x 10^5 CFU, while the y-axis shows zeta potential values ranging from -20 mV to 40 mV. Data points are plotted with error bars, and a linear trend line is drawn through the points. The graph shows a strong negative correlation between zeta potential and bacteria concentration, with zeta potential decreasing as bacteria concentration increases.

Both graphs appear to be related to bacterial studies, possibly investigating the relationship between bacterial concentration and various measurable properties such as optical density and zeta potential. The linear trends in both graphs suggest a consistent relationship between the variables in each case.</DESCRIPTION_FROM_IMAGE>

**Figure 4.** The effect of bacteria on peroxidase activity and colloidal stability of a solution of magnetite nanoparticles. Relationship of the optical density of the reaction mixture vs. decimal logarithm of the concentration of added E. coli. after 4 min of incubation (A); dependence of MNPs zeta potential against E.coli concentration (B).

The dependence of optical density plotted on the logarithm of the bacteria concentration was almost linear. Some deviations from the relationship were associated with increased turbidity in samples with a high level of bacteria. This method allowed determining the concentration of bacteria spectrophotometrically in the concentration range from 107 to 103 CFU/mL. To address the observed effect, evaluations were made to determine the influence of bacteria concentration on hydrodynamic parameters of MNPs. It was revealed that the interaction of positively charged MNPs with negatively (−34 ± 3 mV) charged bacteria decreased zeta potential from 36 ± 2 to −10 ± 2 mV (Figure 4B) and resulted in coagulation of the system. The mechanism of inhibition seems to be connected with the electrostatic interaction of positively charged particles of magnetite and the negatively charged surface of *E.сoli* or/and waste products of bacteria. The same behavior was observed for pure MNPs with the pH level decrease (Figures S3 and S4). The isoelectric point of MNPs was supposedly defined as 8.3. Moreover, at pH 9, the hydrodynamic radius doubled, and then an almost exponential increase in the radius was observed, which corresponds to a faster aggregation rate. These results correlate with the literature data on decreasing of enzyme-like activity of magnetite nanoparticles in basic conditions [16].

#### *3.3. Inkjet Printing of Bacteria Sensors*

After preliminary evaluations with MNPs hydrosol, the efforts were made to prepare a model test system. The sensor was designed in the form of a ring with 7 mm in diameter; the line thickness was 1 mm. This design provides maximum convenience and practicality of the test system. The sensor arrays were formed by a soft lithographic approach via inkjet printing. Stable droplet formation is of great importance when formulating inks, determining their applicability not only for research material printers but also for conventional inkjet printers [35]. In our work, printing was provided by the selected waveform, at a drop rate of 7 m/s. To obtain a smooth layer, the distance between the centers of the drops was 20 microns. Patterns were printed in seven layers; the temperature of the object table was set at 45 °C for rapid solvent removal. As a substrate, white paper with density of 80 g/m3 was used; the paper was laminated with a PET film before printing.

Earlier it was demonstrated that rheologic parameters of the magnetite hydrosol could be optimized by mixing with diethylene glycol [28]. Figure 5A represents the main rheological parameters of the ink. The inks based on magnetite hydrosol showed good print quality (Figure 5C,D). Continuous printing was possible for 5 h, after which the cartridge was refilled and reused. The measured peroxidase-like activity of the prepared inks was 30% lower compared to pristine MNPs (ESI Figure S7). The decrease observed in the activity may be attributed to the formation of the DEG layer on the surface of MNPs, which was proved by ATR-IR. Two peaks (2857 and 2925 cm−1) of symmetric and asymmetric CH2 stretching bands are observed in the FTIR spectra of dried inks (See Figure S8).

<DESCRIPTION_FROM_IMAGE>The image is composed of four panels labeled A, B, C, and D.

Panel A: Depicts a schematic representation of a test system for bacteria sensing. It shows a computer monitor displaying three circles, connected to a device with a grid pattern, likely representing a sensor or detector.

Panel B: Contains two sections:
1. Ink composition: Listed as "1:1 MNPs/DFG"
2. Rheological properties:
   - μ = 4.6 cPs
   - σ = 40.3 mN/m
   - τ = 21.3 mv

Additionally, Panel B includes a graph showing "Intensity (a.u.)" on the y-axis and "Diameter (nm)" on the x-axis. The x-axis is logarithmic, ranging from 10 to 1000 nm. The graph displays a sharp peak at approximately 100 nm.

Panel C: Shows a microscopic image of circular structures arranged in a grid pattern. The scale bar indicates 50 μm.

Panel D: Presents a microscopic image of droplets or particles. A scale is shown at the bottom of the image, with markings at 5 μm intervals from 5 μm to 55 μm.

This image appears to be related to a study on bacterial sensing using a specific ink composition and analyzing its properties at various scales.</DESCRIPTION_FROM_IMAGE>

**Figure 5.** Inkjet printing ink based on magnetite hydrosol, basic rheological parameters (**A**); hydrodynamic radius of magnetite particles (**B**); SEM image of magnetite droplets on a roll substrate (**C**); life cycle of the droplet after leaving the nozzle (**D**).

In contrast to hydrosols, sol-gel matrices of magnetite demonstrated significantly lower peroxidase activity. Measured catalytic activity for the xerogel valued only 5% of the initial activity of the hydrosol (See Figure S7). Several factors determined the lower activity of xerogels. Firstly, in contrast with hydrosols, hydrogen peroxide decomposition was performed in heterogeneous conditions, which brought diffusional limitations to the system. In addition, it is known from the literature that the catalytic activity of iron oxide nanoparticles is strongly connected with its charge or surface modification. It was shown that due to the presence of the two negatively charged sulfonic acid groups ABTS better interact with the positively charged nanoparticles [36]. Moreover, there is a correlation between the rise of zeta potential of nanoparticle and catalytic activity of MNPs. In the case of the xerogel, the positive charge reduced to +14 mV, which probably led to a decrease in affinity for 2,2′-azino-bis(3-ethylbenzothiazoline-6-sulphonic acid). At the same time, the presence of DEG had a negligible effect on the catalytic activity of dried inks compared to MNPs-derived xerogels, resulting in almost equal catalytic activities of dried MNPs hydrosols and dried inks.

The initial assessments were done to determine the response linearity of the sensor to various concentrations of the substrate. For this purpose, ABTS solutions with concentrations of 0.2–1.2 mM were dropped in the center of the sensor arrays, and the analytical signal was taken after 10 min of incubation. In this work, we decided to rely on the visual analysis of the images without using special analytical equipment, and analyze the samples using a conventional digital camera. The digital images were taken and processed in similar conditions using Photoshop image processing programs (see Section 2 ). The brightness of the images was flattened, the green channel was desaturated, and the average luminance was measured in the grayscale mode (Figure 6A). As seen, the decrease of the ABTS concentration led to the lower coloration of the drops on the sensor and lower luminance of the processed images. The analysis of images showed linear independence of the luminance on the concentration of ABTS in the range 0.2–1.2 mmol/L with the adjusted r-squared value of 0.986 (Figure 6B).

<DESCRIPTION_FROM_IMAGE>This image is composed of four panels labeled A, B, C, and D.

Panel A:
This panel shows a series of circular spots arranged in a grid. There are 8 rows, each corresponding to a different concentration of a substance, ranging from 0.2 mM to 1.2 mM. The concentrations are labeled on the right side of the grid. Each row contains multiple replicates of spots at the same concentration. The spots appear to vary in intensity, with higher concentrations generally showing darker or more intense spots.

Panel B:
This panel presents a graph plotting Luminance, K% on the y-axis against C (ABTS), mM on the x-axis. The x-axis ranges from 0 to 1.2 mM, while the y-axis ranges from 0 to 50 K%. The graph shows a clear positive linear relationship between the concentration of ABTS and luminance. Data points are plotted with error bars, and a best-fit line is drawn through the points. The relationship appears to be approximately linear, with luminance increasing as ABTS concentration increases.

Panel C:
This panel is similar to Panel A, showing a grid of circular spots. However, instead of concentration, the rows are labeled with powers of 10, ranging from 10^8 to 10^4, likely representing colony-forming units (CFU) per mL. The bottom row is labeled "Control". As in Panel A, each row contains multiple replicates. The intensity of the spots appears to decrease from top to bottom, with the highest CFU/mL showing the most intense spots.

Panel D:
This panel presents another graph, this time plotting Luminance, K% on the y-axis against lg(CFU/mL) on the x-axis. The x-axis ranges from 4 to 8, while the y-axis ranges from 15 to 45 K%. Unlike the graph in Panel B, this one shows a negative linear relationship. As the log of CFU/mL increases, the luminance decreases. Data points are plotted with error bars, and a best-fit line is drawn through the points.

Overall, this image appears to be demonstrating the relationship between bacterial concentration (CFU/mL) and luminance, possibly in the context of a bioluminescence assay. The ABTS concentration in Panel B might be related to a standard curve or calibration for the assay.</DESCRIPTION_FROM_IMAGE>

**Figure 6.** Device-free evaluation of the printed sensors. Processed image of the sensor array with various ABTS concentrations (A); the dependence of the measured sample luminance on ABTS concentration after 10 min of incubation (B); processed image of the sensor array in the presence of various amounts of E. coli CFU, (C); the dependence of the measured sample luminance on E. coli concentration after 10 min of incubation (D).

The performance of the platform was validated against *E. coli.* As seen in Figure 6C, samples containing bacteria left were clearly brighter than control samples. All those test papers were recorded and then analyzed by the method described to calculate the average gray values, which are presented in Figure 6D. The sensor demonstrated linear dependence of the luminance on the concentration of model *E. coli* bacteria in the concentration range of 104–108 CFU with the adjusted rsquared value 0.976. The limit of detection (LOD) was calculated using the formula: *LOD = 3Sa/b*, where *S* is the value of the standard deviation of the response and b is the slope of the standard curve within the linear range. According to this formula, the LOD of the method proposed was 3.2 × 103 CFU/mL.

## **4. Conclusions**

Here, we have described the first example of a scalable inkjet-printed peroxide sensor based on magnetite and its application for the bacteria detection. After initial calibrations and verifications by the means of optical spectroscopy, the resulting sensors may be read without any specific equipment using a conventional CCD camera. The sensor was produced from stable magnetite hydrocolloids which were synthesized by the US-assisted coprecipitation procedure and consisted of 10 nm nanoparticles of magnetite. Pristinity of the nanoparticles surfaces determined the high catalytic activity of the system valued 6585 U/mg, the activity was described by the Michaelis–Menten model with calculated values of *Km* 1.22 mmol/L, *Vmax* 4.39 µmol/s, and *Kcat* 365.8 s−1. The inhibition of exhibited peroxidase activity was accompanied by reducing zeta potential, which is likely to be connected with interaction between nanoparticles and the *E. coli* membrane. The sensors were produced by inkjet printing on PET films and demonstrated linear response to model *E. coli* bacteria in the range of 104– 108 CFU with calculated LOD 3.2 × 103 CFU. Further studies will be aimed at automatization of the analytic system and integration with neural networks to design optical test systems.

**Supplementary Materials:** The following are available online at www.mdpi.com/xxx/s1, Figure S1. Lowtemperature nitrogen sorbtion-desorbtion isotherm of magnetite xerogel, Figure S2. Pore diameter distribution of magnetite xerogel calculated by BJH method, Figure S3. Hydrodynamic radius of MNPs as a function of pH, Figure S4. Zeta potential of MNPs as a function of pH, Figure S5. ABTS oxidation kinetics measured at various concentrations of substrate, Figure S6. ABTS oxidation kinetics measured at various concentrations of hydrogen peroxide, Figure S7. ATR-IR spectrum of xerogels, Figure S8. Comparative analysis of peroxidase activity hydrosol, Table S1: Literature of data analysis

**Author Contributions:** M.Z., D.S.K. and L.S. carried out the experiments; V.V.V. and A.S.D. conceived and planned the experiments, M.Z. A.S.D., V.V.V. prepared the manuscript; M.Z., D.S.K. and A.S.D. revised the manuscript. All authors have read and agreed to the published version of the manuscript.

**Funding:** Experiments connected with biomimetic activities and characterization of nanomaterials physical properties were supported by Russian Science Foundation Grant 16-13-00041. The engineering part of the experiments connected with inkjet printing was supported by the Ministry of Science and Higher Education of Russia (Project №075-15-2019-1896).

**Acknowledgments:** The X-ray powder diffraction studies were performed on Rigaku SmartLab 3 diffractometer of the Saint-Petersburg State Technological Institute (Technical University).

**Conflicts of Interest**: The authors declare no conflict of interest

# **References**

- 1. Kimberlin, D.W. *Red Book: 2018–2021 Report of the Committee on Infectious Diseases,* 31th ed.; American Academy of Pediatrics: *Elk Grove Village*, USA 2018.
- 2. Kirk, M.D.; Pires, S.M.; Black, R.E.; Caipo, M.; Crump, J.A.; Devleesschauwer, B.; Dopfer, D.; Fazil, A.; Fischer-Walker, C.L.; Hald, T.; et al. World Health Organization estimates of the global and regional disease burden of 22 foodborne bacterial, protozoal, and viral diseases, 2010: A data synthesis. *PLoS Med.* **2015**, *12*, e1001921.
- 3. Morens, D.M.; Folkers, G.K.; Fauci, A.S. The challenge of emerging and re-emerging infectious diseases. *Nature* **2004**, *430*, 242.
- 4. Deisingh, A.K.; Thompson, M. Detection of infectious and toxigenic bacteria. *Analyst* **2002**, *127*, 567–581.
- 5. Belgrader, P.; Benett, W.; Hadley, D.; Richards, J.; Stratton, P.; Mariella, R.; Milanovich, F. PCR detection of bacteria in seven minutes. *Science* **1999**, *284*, 449–450.
- 6. Shin, H.Y.; Park, T.J.; Kim, M.I. Recent research trends and future prospects in nanozymes. *J. Nanomater.*  **2015**, *7*, 756278.
- 7. Chen, J.; Andler, S.M.; Goddard, J.M.; Nugen, S.R.; Rotello, V.M. Integrating recognition elements with nanomaterials for bacteria sensing. *Chem. Soc. Rev.* **2017**, *46*, 1272–1283.
- 8. Chang, Z.; Wang, Z.; Lu, M.; Li, M.; Li, L.; Zhang, Y.; Shao, D.; Dong, W. Magnetic Janus nanorods for efficient capture, separation and elimination of bacteria. *RSC Adv.* **2017**, *7*, 3550–3553.
- 9. Zhou, H.; Yang, D.; Ivleva, N.P.; Mircescu, N.E.; Niessner, R.; Haisch, C. SERS detection of bacteria in water by in situ coating with Ag nanoparticles. *Anal. Chem.* **2014**, *86*, 1525–1533.
- 10. Zelada-Guillen, G.A.; Riu, J.; Duzgun, A.; Rius, F.X. Immediate detection of living bacteria at ultralow concentrations using a carbon nanotube based potentiometric aptasensor. *Angew. Chem. Int. Ed.* **2009**, *48*, 7334–7337.
- 11. Wang, R.; Xu, Y.; Jiang, Y.; Chuan, N.; Su, X.; Ji, J. Sensitive quantification and visual detection of bacteria

using CdSe/ZnS@SiO2 nanoparticles as fluorescent probes. *Anal. Methods* **2014**, *6*, 6802–6808.

- 12. Mocan, T.; Matea, C.T.; Pop, T.; Mosteanu, O.; Buzoianu, A.D.; Puia, C.; Iancu, C.; Mocan, L. Development of nanoparticle-based optical sensors for pathogenic bacterial detection. *J. Nanobiotechnol.* **2017**, *15*, 25.
- 13. Miranda, O.R.; Li, X.; Garcia-Gonzalez, L.; Zhu, Z.J.; Yan, B.; Bunz, U.H.; Rotello, V.M. Colorimetric bacteria sensing using a supramolecular enzyme-nanoparticle biosensor. *J. Am. Chem. Soc.* **2011**, *133*, 9650–9653.
- 14. Gao, L.; Fan, K.; Yan, X. Iron oxide nanozyme: A multifunctional enzyme mimetic for biomedical applications. *Theranostics* **2017**, *7*, 3207.
- 15. Ragg, R.; Tahir, M.N.; Tremel, W. Solids go bio: Inorganic nanoparticles as enzyme mimics. *Eur. J. Inorg. Chem.* **2016**, *13–14,* 1906–1915.
- 16. Gao, L.; Zhuang, J.; Nie, L.; Zhang, J.; Zhang, Y.;Gu, N.; Wang, T.; Feng, J.; Yang, D.; Perrett, S.; et al. Intrinsic peroxidase-like activity of ferromagnetic nanoparticles. *Nat. Nanotechnol. 2007, 2, 577.*
- 17. He, W.; Wamer, W.; Xia, Q.; Yin, J.J.; Fu, P.P. Enzyme-like activity of nanomaterials. *J. Environ. Sci. Health Part C* **2014**, *32*, 186–211.
- 18. Hu, X.; Liu, J.; Hou, S.; Wen, T.; Liu, W.; Zhang, K.; He, W.; Ji, Y.; Ren, H.; Wang, Q.; et al. Research progress of nanoparticles as enzyme mimetics. *Sci. China Phys. Mech. Astron.* **2011**, *54*, 1749.
- 19. Liu, B.; Han, X.; Liu, J. Iron oxide nanozyme catalyzed synthesis of fluorescent polydopamine for light-up Zn 2+ detection. *Nanoscale* **2016**, *8*, 13620–13626.
- 20. Chen, Y.; Cao, H.; Shi, W.; Liu, H.; Huang, Y. Fe-Co bimetallic alloy nanoparticles as a highly active peroxidase mimetic and its application in biosensing. *Chem. Commun.* **2013**, *49*, 5013–5015.
- 21. Wang, Q.; Zhang, L.; Shang, C.; Zhang, Z.; Dong, S. Triple-enzyme mimetic activity of nickel-palladium hollow nanoparticles and their application in colorimetric biosensing of glucose. *Chem. Commun.* **2016**, *52*, 5410–5413.
- 22. Su, H.; Zhao, H.; Qiao, F.; Chen, L.; Duan, R.; Ai, S. Colorimetric detection of Escherichia coli O157: H7 using functionalized Au@ Pt nanoparticles as peroxidase mimetics. *Analyst* **2013**, *138,* 3026–3031.
- 23. Mumtaz, S.; Wang, L.S.; Hussain, S.Z.; Abdullah, M.; Huma, Z.; Iqbal, Z.; Creran, B.; Rotello, V.M.; Hussain, I. Dopamine coated Fe3O4 nanoparticles as enzyme mimics for the sensitive detection of bacteria. *Chem. Commun.* **2017**, *53*, 12306–12308.
- 24. Wang, K.Y.; Bu, S.J.; Ju, C.J.; Li, C.T.; Li, Z.Y.; Han, Y.; Ma, C.Y.; Wang, C.Y.; Hao, Z.; Liu, W.S.; et al. Heminincorporated nanoflowers as enzyme mimics for colorimetric detection of foodborne pathogenic bacteria. *Bioorg. Med. Chem. Lett.* **2018**, *28*, 3802–3807.
- 25. Wu, S.; Duan, N.; Qiu, Y.; Li, J.; Wang, Z. Colorimetric aptasensor for the detection of Salmonella enterica serovar typhimurium using ZnFe2O4-reduced graphene oxide nanostructures as an effective peroxidase mimetics. *Int. J. Food Microbiol.* **2017**, *261*, 42–48.
- 26. Shapovalova, O.E.; Drozdov, A.S.; Bryushkova, E.A.; Morozov, M.I.; Vinogradov, V.V. Room-temperature fabrication of magnetite-boehmite sol-gel composites for heavy metal ions removal. *Arab. J. Chem.* **2020**, *13*, 1933–1944.
- 27. Shabanova, E.M.; Drozdov, A.S.; Fakhardo, A.F.; Dudanov, I.P.; Kovalchuk, M.S.; Vinogradov, V.V. Thrombin@Fe3O4 nanoparticles for use as a hemostatic agent in internal bleeding. *Sci. Rep.* **2018**, *8*, 233.
- 28. Kolchanov, D.S.; Slabov, V.; Keller, K.; Sergeeva, E.; Zhukov, M.V.; Drozdov, A.S.; Vinogradov, A.V. Solgel magnetite inks for inkjet printing. *J. Mater. Chem. C* **2019**, *7*, 6426–6432.
- 29. Andreeva, Y.I.; Drozdov, A.S.; Fakhardo, A.F.; Cheplagin, N.A.; Shtil, A.A.; Vinogradov, V.V. The controllable destabilization route for synthesis of low cytotoxic magnetic nanospheres with photonic response. *Sci. Rep.* **2017**, *7*, 11343.
- 30. Lee, Y.; Yoon, J.; von Gunten, U. Spectrophotometric determination of ferrate (Fe (VI)) in water by ABTS. *Water Res.* **2005**, *39*, 1946–1953.
- 31. Osman, A.; Wong, K.; Fernyhough, A. ABTS radical-driven oxidation of polyphenols: Isolation and structural elucidation of covalent adducts. *Biochem. Biophys. Res. Commun.* **2006**, *346*, 321–329.
- 32. Kadnikova, E.N.; Kostic, N.M. Oxidation of ABTS by hydrogen peroxide catalyzed by horseradish peroxidase encapsulated into sol-gel glass.: Effects of glass matrix on reactivity. *J. Mol. Catal. B Enzym.* **2002**, *18*, 39–48.
- 33. Lai, L.W.; Teo, C.L.; Wahidin, S.; Annuar, M. Determination of enzyme kinetic parameters on sago starch hydrolysis by linearized graphical methods. *Malays J. Anal. Sci.* **2014**, *18*, 527–533.
- 34. Hiner, A.N.; Hernandez-Rulz, J.; Arnao, M.B.; Garcla-Canovas, F.; Acosta, M. A comparative study of the purity, enzyme activity, and inactivation by hydrogen peroxide of commercially available horseradish

peroxidase isoenzymes A and C. *Biotechnol. Bioeng.* **1996**, *50*, 655–662.

- 35. Li, Y.; Dahhan, O.; Filipe, C.D.; Brennan, J.D.; Pelton, R.H. Optimizing piezoelectric inkjet printing of silica sols for biosensor production. *J. Sol-Gel Sci. Technol.* **2018**, *87*, 657–664.
- 36. Yu, F.; Huang, Y.; Cole, A.J.; Yang, V.C. The artificial peroxidase activity of magnetic iron oxide nanoparticles and its application to glucose detection. *Biomaterials* **2009**, *30*, 4716–4722.

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

© 2020 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license (http://creativecommons.org/licenses/by/4.0/).