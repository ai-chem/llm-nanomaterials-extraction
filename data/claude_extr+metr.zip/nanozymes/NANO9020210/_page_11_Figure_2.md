The image contains two graphs, labeled A and B, both showing the relationship between H2O2 concentration and absorbance at 652 nm.

Graph A:
This graph shows a non-linear relationship between H2O2 concentration and absorbance. The x-axis represents H2O2 concentration ranging from 0 to 300 μM, while the y-axis shows absorbance at 652 nm from 0.10 to 0.40. The data points follow a curve that appears to be approaching saturation, with a steep increase in absorbance at lower H2O2 concentrations and a gradual leveling off at higher concentrations. The curve fits well with the experimental data points. An inset image shows two vials, labeled 2μM and 0μM, presumably referring to H2O2 concentrations.

Graph B:
This graph displays a linear relationship between H2O2 concentration and absorbance. The x-axis represents H2O2 concentration from 0 to 100 μM, while the y-axis shows absorbance at 652 nm from 0.10 to 0.30. The data points fall closely along a straight line, indicating a direct proportional relationship between H2O2 concentration and absorbance in this range.

Both graphs use black dots to represent data points and red lines to show the fitted curves or lines. The graphs suggest that the relationship between H2O2 concentration and absorbance is linear at lower concentrations (as shown in Graph B) but becomes non-linear at higher concentrations (as shown in Graph A).