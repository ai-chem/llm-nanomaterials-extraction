<DESCRIPTION_FROM_IMAGE>This image represents the logo for a scientific journal or publication focused on nanomaterials. The logo consists of two main elements:

1. A graphical representation of a nanomaterial structure:
   - The structure appears to be a spherical molecule or nanoparticle.
   - It is composed of interconnected atoms or nodes, forming a three-dimensional lattice or network.
   - This structure is likely meant to represent a fullerene, carbon nanotube, or similar nanoscale material.

2. Text element:
   - The word "nanomaterials" is written in lowercase letters.
   - It is positioned to the right of the graphical element.

The combination of the molecular structure graphic and the text "nanomaterials" clearly indicates that this logo is associated with a scientific publication, journal, or organization dedicated to the study and research of nanomaterials and nanotechnology.

This logo effectively communicates the focus on nanoscale materials and structures that are central to the field of nanomaterials science and engineering.</DESCRIPTION_FROM_IMAGE>

*Article*

# **Fe3O4 Nanoparticles Loaded on Lignin Nanoparticles Applied as a Peroxidase Mimic for the Sensitively Colorimetric Detection of H2O2**

**Qingtong Zhang 1,2 [,](https://orcid.org/0000-0001-7959-9033) Mingfu Li 1,2, Chenyan Guo 1,2, Zhuan Jia 1,2, Guangcong Wan 1,2 , Shuangfei Wang 1,2 and Douyong Min 1,2,***

- 1 College of Light Industry and Food Engineering, Guangxi University, Nanning 530004, China; qingyutong110@163.com (Q.Z.); mingfuli@mail.gxu.cn (M.L.); guochenyan2017@163.com (C.G.); jiazhuan123@163.com (Z.J.); wanguangcong@163.com (G.W.); wangsf@gxu.edu.cn (S.W.)
- 2 Guangxi Key Lab of Clean Pulp & Papermaking and pollution Control, Nanning 530004, China
- ***** Correspondence: mindouyong@gxu.edu.cn

Received: 28 January 2019; Accepted: 1 February 2019; Published: 6 February 2019

<DESCRIPTION_FROM_IMAGE>This image does not contain scientific or chemistry-related content. Instead, it appears to be a logo or icon design. The image shows a stylized yellow checkmark or tick symbol inside a yellow circular shape. Next to this graphic are the words "check for updates" in black text. This type of image is commonly used for software update notifications or to indicate a task completion or verification process. As it does not convey information relevant to applied chemistry or scientific data, I will classify this as:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

**Abstract:** Lignin is the second largest naturally renewable resource and is primarily a by-product of the pulp and paper industry; however, its inefficient use presents a challenge. In this work, Fe3O4 nanoparticles loaded on lignin nanoparticles (Fe3O4@LNPs) were prepared by the self-assembly method and it possessed an enhanced peroxidase-like activity. Fe3O4@LNPs catalyzed the oxidation of 3,30 ,5,50 -tetramethylbenzidine (TMB) in the presence of H2O2 to generate a blue color, was observable by the naked eye. Under the optimal conditions, Fe3O4@LNPs showed the ability of sensitive colorimetric detection of H2O2within a range of 5–100 µM and the limit of detection was 2 µM. The high catalytic activity of Fe3O4@LNPs allows its prospective use in a wide variety of applications, including clinical diagnosis, food safety, and environmental monitoring.

**Keywords:** Fe3O4 nanoparticles; Lignin nanoparticles; peroxidase mimic; colorimetric; H2O2 detection

#### **1. Introduction**

Hydrogen peroxide (H2O2), as one of the most important reactive oxygen species (ROS), is widely used in the food and chemical industries, clinical medicine, and environmental monitoring [\[1](#page-11-0)[–3\]](#page-12-0). Studies have shown that long-term exposure to H2O2 can cause serious harm to a person's health, including poisoning, respiratory inflammation [\[4\]](#page-12-1), cancer, Alzheimer's disease, and Parkinson's disease [\[5\]](#page-12-2). Therefore, the substantial research efforts are devoted to develop methods for the detection of H2O2,such ashigh-performance liquid chromatography (HPLC) [\[6\]](#page-12-3), electrochemistry [\[1\]](#page-11-0), spectrometry [\[7\]](#page-12-4), chemiluminescence [\[8\]](#page-12-5), and colorimetric assays [\[9\]](#page-12-6). HPLC, electrochemistry, and chemiluminescence methods are sensitive, but their processes are complex and time-consuming. Spectrometry has the advantage of a simple and low-cost operation but exhibits the disadvantage of poor sensitivity. At present, colorimetric assay methods have been garnering attention due to their high sensitivity and simplicity. Furthermore, colorimetric assay results can be observed unaided and without the use of any sophisticated instruments. Horseradish peroxidase (HRP) is commonly used as a catalyst in conventional colorimetric assay methods to obtain the color signal. As a natural enzyme, HRP is easily affected by acidity, temperature, and inhibitors. In addition, the high cost associated with its preparation, purification and extreme storage conditions also inevitably limits its widespread application [\[10\]](#page-12-7).

<DESCRIPTION_FROM_IMAGE>This image depicts the logo of MDPI (Multidisciplinary Digital Publishing Institute), a publisher of open access scientific journals. The logo consists of the letters "MDPI" in a bold, sans-serif font. The letters are enclosed within a stylized hexagonal shape, reminiscent of a benzene ring or other molecular structures commonly used in chemistry and scientific illustrations. The hexagon is not fully closed, with an opening at the top left corner, giving it the appearance of a simplified house or roof shape. This design cleverly combines the concept of scientific publishing (represented by the molecular-like hexagon) with the idea of open access or accessibility (suggested by the house-like structure).

Given that this is a publisher's logo and does not contain specific scientific information, chemical structures, graphs, or data related to applied chemistry or science, the appropriate response according to the instructions is:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

**2. Experimental** 

Since the first report of Fe3O4 nanoparticles (Fe3O4 NPs) possessing peroxidase-like activity [\[11\]](#page-12-8), many other nanomaterials, including CeO2 nanoparticles [\[12\]](#page-12-9), NiO2 nanoparticles [\[13\]](#page-12-10) and MnO2 nanosheets [\[14\]](#page-12-11), have also demonstrated intrinsic peroxidase-like activity. These metal nanomaterials are low-cost, sensitive, and maintain their activities in a relatively wide range of environmental conditions, but they all present the problem of agglomeration [\[15\]](#page-12-12). To tackle this problem, researchers use graphene or graphene oxide as a structural support to prevent these metal nanomaterials from aggregating in solution [\[16,](#page-12-13)[17\]](#page-12-14). However, the high cost of graphene and graphene oxide seriously restricts the widespread application of metal nanozymes. Since the first report of Fe3O4 nanoparticles (Fe3O4 NPs) possessing peroxidase-like activity [11], many other nanomaterials, including CeO2 nanoparticles [12], NiO2 nanoparticles [13]and MnO2 nanosheets [14], have also demonstrated intrinsic peroxidase-like activity. These metal nanomaterials are low-cost, sensitive, and maintain their activities in a relatively wide range of environmental conditions, but they all present the problem of agglomeration [15]. To tackle this problem, researchers use graphene or graphene oxide as a structural support to prevent these metal nanomaterials from aggregating in solution [16,17]. However, the high cost of graphene and graphene oxide seriously restricts the widespread application of metal nanozymes.

*Nanomaterials* **2019**, *9*, 210 2 of 14

Lignin is the second most abundant organic macromolecular compound from biomass after cellulose [\[18\]](#page-12-15). The primary structure of lignin is composed of three different phenylpropane monomer units: guaiacyl (G), syringyl (S), and p–hydroxyphenol (H) units [\[19\]](#page-12-16). These monomer units are mainly linked by ether bonds (β-O-4, 4-O-5, α-O-4, α-O-γ, etc.) and carbon-carbon bonds (β-β, β-1, β-5, 5-5, β-6, etc.) [\[20,](#page-12-17)[21\]](#page-12-18). A proposed structural diagram of lignin is shown in Figure [1.](#page-1-0) Similar to graphene oxide, lignin molecules contain many functional groups, such as hydroxyl and carboxyl groups, which offers the possibility of a stable dispersion of lignin-based materials in aqueous solutions. Recent studies showed that lignin-based nanoparticles can disperse stably in aqueous solutions [\[18\]](#page-12-15). Therefore, metal nanozymes carried by lignin nanoparticles can be stably dispersed in solution. Nevertheless, the literature contains few reports of lignin nanoparticles being used to enhance the dispersity of metal nanozymes in the colorimetric detection of H2O2. Lignin is the second most abundant organic macromolecular compound from biomass after cellulose [18]. The primary structure of lignin is composed of three different phenylpropane monomer units: guaiacyl (G), syringyl (S), and p–hydroxyphenol (H) units [19]. These monomer units are mainly linked by ether bonds (β-O-4, 4-O-5, α-O-4, α-O-γ, etc.) and carbon-carbon bonds (β-β,β-1,β-5, 5-5,β-6, etc.) [20,21]. A proposed structural diagram of lignin is shown in Figure 1. Similar to graphene oxide, lignin molecules contain many functional groups, such as hydroxyl and carboxyl groups, which offers the possibility of a stable dispersion of lignin-based materials in aqueous solutions. Recent studies showed that lignin-based nanoparticles can disperse stably in aqueous solutions [18]. Therefore, metal nanozymes carried by lignin nanoparticles can be stably dispersed in solution. Nevertheless, the literature contains few reports of lignin nanoparticles being used to enhance the dispersity of metal nanozymes in the colorimetric detection of H2O2.

<DESCRIPTION_FROM_IMAGE>The image depicts the chemical structure of a complex lignin polymer and its constituent monomer units. The main structure shows a large, branched molecule composed of interconnected aromatic rings with various functional groups. The polymer contains multiple hydroxyl (OH), methoxy (OMe), and ether (O) linkages connecting the aromatic units.

At the bottom right of the image, three smaller structures are shown, representing the monomer units that make up the lignin polymer:

1. Coniferyl alcohol (red): 
SMILES: C=CC(CO)=CC=C1OC(C)=C(O)C=C1

2. Sinapyl alcohol (green):
SMILES: C=CC(CO)=CC=C1OC(C)=C(OC)C(OC)=C1O

3. p-Coumaryl alcohol (blue):
SMILES: C=CC(CO)=CC=C1C=CC(O)=CC1

These monomer units are the building blocks of the larger lignin polymer structure shown in the main part of the image. The polymer structure demonstrates how these units are connected through various types of bonds, creating a complex, three-dimensional network typical of lignin molecules.

The image illustrates the structural complexity and diversity of lignin, highlighting its composition from different phenylpropanoid monomers and the various linkages between them. This representation is crucial for understanding lignin's properties, its role in plant cell walls, and its potential applications in materials science and biotechnology.</DESCRIPTION_FROM_IMAGE>

**Figure 1.** The proposed structure of lignin. Inset: three primary units of lignin. **Figure 1.** The proposed structure of lignin. Inset: three primary units of lignin.

As a common mimetic enzyme of horseradish peroxidase, Fe3O4 NPs have high catalytic activity and stability during reactions [22]. However, Fe3O4 NPs also present the urgent problem of agglomeration in solution. In this work, we explored the influence of the preparation conditions on the morphology of Fe3O4@LNPs. Then, Fe3O4 NPs loaded on lignin nanoparticles (Fe3O4@LNPs) were prepared. The prepared Fe3O4@LNPs exhibited excellent dispersion stability in water and showed higher catalytic activity than Fe3O4 NPs. The prepared Fe3O4@LNPs effectively catalyzed H2O2 to generate hydroxyl radicals, followed by the oxidation of 3,3',5,5'-tetramethylbenzidine (TMB) [23]. The oxidized TMB had a characteristic absorbance at 652 nm [24]. Therefore, in the presence of H2O2, TMB, and Fe3O4@LNPs as catalyst, the reaction system changed from colorless to blue that was identified by the naked eye or quantified by UV-vis spectrophotometer. Because of its excellent dispersion stability in aqueous solution and sensitive peroxidase-like catalytic activity, Fe3O4@LNPs can be used in a diverse set of applications. As a common mimetic enzyme of horseradish peroxidase, Fe3O4 NPs have high catalytic activity and stability during reactions [\[22\]](#page-12-19). However, Fe3O4 NPs also present the urgent problem of agglomeration in solution. In this work, we explored the influence of the preparation conditions on the morphology of Fe3O4@LNPs. Then, Fe3O4 NPs loaded on lignin nanoparticles (Fe3O4@LNPs) were prepared. The prepared Fe3O4@LNPs exhibited excellent dispersion stability in water and showed higher catalytic activity than Fe3O4 NPs. The prepared Fe3O4@LNPs effectively catalyzed H2O2 to generate hydroxyl radicals, followed by the oxidation of 3,30 ,5,50 -tetramethylbenzidine (TMB) [\[23\]](#page-12-20). The oxidized TMB had a characteristic absorbance at 652 nm [\[24\]](#page-13-0). Therefore, in the presence of H2O2, TMB, and Fe3O4@LNPs as catalyst, the reaction system changed from colorless to blue that was identified by the naked eye or quantified by UV-vis spectrophotometer. Because of its excellent dispersion stability in aqueous solution and sensitive peroxidase-like catalytic activity, Fe3O4@LNPs can be used in a diverse set of applications.

#### **2. Experimental**

#### *2.1. Materials and Reagents*

Spruce chips were obtained from a Swedish farm. Tetrahydrofuran (THF), Fe3O4 NPs (average diameters: 20–30 nm), and TMB were purchased from Aladdin Industrial Co., Ltd. (Shanghai, China). The other analytical grade chemicals were purchased from Boyu Chemicals Company (Nanning, Guangxi, China), and were used without further purification.

The chips were cooked in a pressure vessel under the following conditions: the total titratable alkali value was 26%, the sulfidity was 20%, the solid-to-liquid ratio was 1:4, a residence time was 4.5 h, and the temperature was 165 ◦C. When the cooking was completed, the separated black liquor was adjusted to pH = 2 with 2 M H2SO4 while stirring to precipitate lignin. After standing for 3 h, the supernatant was removed. After centrifugation, washing, and freeze-drying, the crude Kraft lignin was obtained. The crude Kraft lignin was dissolved in THF and stirred for 30 min; the undissolved material was removed by filtering through a 0.45 µm organic filter membrane (Pall Scientific, New York, NY, USA). The lignin/THF solution was stirred under the fume hood until the THF evaporated completely. Then, the powder was dried at 40 ◦C under vacuum for 48 h to obtain the purified Kraft lignin.

#### *2.2. Statistical Analysis*

All the experiments were performed in triplicate, and the averaged values were reported in this study.

## *2.3. Preparation of Fe3O4@LNPs*

The purified lignin was dissolved in THF to prepare solutions of 0.5, 1.0, and 5.0, mg/mL. With vigorous mechanical stirring, 0.1 mg/mL Fe3O4 NPs suspension was added dropwise to the lignin/THF solutions using a microsyringe until the suspension with 20% consistency was obtained. The suspension was stirred for an additional 20 min to evaporate THF. Then, the suspension was transferred into a dialysis bag (MWCO: 6000, Union Carbide, Connecticut, CT, USA) and immersed in an excess of deionized water to remove the residual THF. Little trace of THF was detected after 24 h dialysis. Then, the suspension was centrifuged to achieve the solid part which was freeze-dried to obtain Fe3O4@LNPs. Fe3O4@LNPs prepared from the solution with 0.5, 1.0, and 5.0 mg/mL initial lignin concentration was respectively denoted as L1, L2, and L3.

## *2.4. Peroxidase-Like Activity of Fe3O4@LNPs*

The peroxidase-like activity of Fe3O4@LNPs was investigated by catalytically oxidizing TMB in the presence of H2O2.The concentrations of TMB and H2O2were respectively 4 mM and 100 mM, 0.1 M Citric acid-disodium hydrogen phosphate solution (CPBS) (pH = 3.0) was applied as the buffer, and the final volume of the mixture was 3 mL. The mixture was incubated at 50 ◦C for 30 min. As for the blank experiments, Fe3O4@LNPs was replaced by LNPs (lignin nanoparticles) or Fe3O4 NPs to complete the reaction under the same conditions. The oxidized TMB had a maximum absorbance at 652 nm [\[25\]](#page-13-1). Therefore, the peroxidase-like activity of Fe3O4@LNPs was evaluated through changes of the solution color and the absorbance at 652 nm.

### *2.5. Steady Kinetic Analysis of Fe3O4@LNPs*

The steady-state kinetic measurements were carried out to investigate the mechanism of the peroxidase-like activity of Fe3O4@LNPs at room temperature. Approximately 600 µL of Fe3O4@LNPs (264 µg/mL) was mixed with 1.8 mL CPBS (0.1 M, pH = 3.0). As for the first experiment, 300 µL H2O2 (100 mM) was used, while the TMB concentration was varied (0.4, 0.6, 0.8, 1.0, 1.5, 2.0, 3.0, 4.0 and 6.0 mM). As for the second experiment, 300 µL TMB (4.0 mM) was used, while the

concentration of H2O2 was varied (10, 15, 25, 30, 50, 100, 150, and 250 mM). TheMichaelis-Menten constant was calculated from the Lineweaver-Burk double reciprocal plot by the following equation: 1/ν = Km/νm(1/[S] + 1/Km), where ν is the initial velocity, Km is the Michaelis constant, νm is the maximum reaction rate, and [S] is the concentration of substrate [\[26\]](#page-13-2).

# *2.6. Colorimetric Detection of H2O2*

For the colorimetric analysis of H2O2, 600 µL Fe3O4@LNPs (264 µg/mL), 300 µL of TMB (4 mM) and 300 µL H2O2 (different concentrations) were mixed with 1.8 mL CPBS (0.1 M, pH = 3.0). The mixed solution was incubated at 50 ◦C for 30 min. The absorbance of the resulted sample measured by a UV-visible spectrophotometer at 652 nm was used to generate the standard curve for the detection of H2O2.

The limit of detection (LOD) of H2O2 was calculated based on previous literature [\[27\]](#page-13-3) via the following equation: LOD = 3S/M, where S is the standard deviation of blank samples and M is the slope of the linear curve between the absorbance at 652 nm and H2O2 concentration. Eleven blank experiments were carried out as follows: 600 µL Fe3O4@LNPs (264 µg/mL), 300 µL of TMB (4 mM) and the corresponding volume (300 µL) of H2O replacing H2O2 were mixed with 1.8 mL CPBS (0.1 M, pH = 3.0). The mixtures were incubated at 50 ◦C for 30 min. The absorbance of 11 blank experiments at 652 nm was collected to calculate S value.

## *2.7. Characterization*

The 31Pnuclear magnetic resonance (NMR) spectrum of lignin was acquired on an NMR spectrometer (AVANCE III 500 MHz, Bruker, Germany). The morphologies and element analysis of Fe3O4@LNPs were recorded by field emission transmission electron microscope (FE-TEM) (Tecnail G2F20, FEI Company, Hillsboro, OR, USA) with an accelerating voltage of 200 KV. UV-vis spectra were recorded with a UV-visible spectrophotometer (Agilent 8453, California, CA, USA). The size and zeta potential of the samples were analyzed with a Nanoparticle Size analyzer (Nano-ZS90X, Malvern, Malvern, UK).

#### **3. Results and Discussion**

## *3.1. Quantification of Hydroxyl Groups of Lignin*

The hydroxyl groups of lignin was quantified by 31P NMR according to the reported method [\[28\]](#page-13-4). Approximately 20 mg of lignin was placed in a 1 mL vial. Then, 500 µL of a prepared solution of anhydrous pyridine and CDCl3 (1.6:1, *v*/*v*) was added and magnetically stirred. Subsequently, 100 µL of chromium (III) acetylacetonate (5 mg/mL, dissolved in pyridine/CDCl3, 1.6:1, *v*/*v*) was added as a relaxation agent and 100 µL of cyclohexanol (30 mg/mL) was added as an internal standard. Finally, 85 µL of phosphitylation reagents was added. After stirring for 10 min, the resulting solution was transferred to a 5 mm NMR tube and tested by NMR spectrometer. The 31P NMR spectrum of lignin was shown in Figure [2.](#page-4-0) The result indicated that the hydroxyl group of guaiacylwas the most abundant in the lignin that is 3.76 mmol/g based on lignin, followed by the aliphatic hydroxyl that was 2.82 mmol/g, the condensed phenolic hydroxyl that was 1.90 mmol/g, and the carboxyl group that was 0.63 mmol/g. More hydroxyl groups indicated the lignin nanoparticles dispersed more stably in water [\[18\]](#page-12-15).

<DESCRIPTION_FROM_IMAGE>The image shows a 13C NMR spectrum of a complex organic compound, likely a lignin or lignin-derived material. The spectrum spans from approximately 135 to 150 ppm, indicating the presence of aromatic and other unsaturated carbon environments. The spectrum is annotated with labels for different functional groups:

1. Aliphatic OH: A broad peak centered around 148-149 ppm, indicating aliphatic hydroxyl groups.

2. Internal Standard: A sharp, intense peak at approximately 146 ppm, likely used for calibration and quantification.

3. Condensed phenolic OH: A series of small, broad peaks between 144-146 ppm, representing hydroxyl groups on condensed phenolic structures.

4. Guaiacyl OH: A prominent, sharp peak at about 141 ppm, characteristic of hydroxyl groups on guaiacyl units in lignin structures.

5. Carboxylic acid units: A smaller, somewhat broad peak at around 136 ppm, indicating the presence of carboxylic acid functionalities.

The relative intensities of these peaks provide information about the abundance of each functional group in the sample. The guaiacyl OH peak is the most intense after the internal standard, suggesting a significant presence of guaiacyl units in the structure. The aliphatic OH and carboxylic acid peaks are of moderate intensity, while the condensed phenolic OH signals are relatively weak.

This spectrum is typical for lignin analysis, providing information about the types and relative amounts of different hydroxyl and carboxylic acid groups present in the complex polymer structure.</DESCRIPTION_FROM_IMAGE>

<span id="page-4-0"></span>*Nanomaterials* **2019**, *9*, 210 5 of 14

**Figure 2.** 31P NMR spectra of the purified lignin. **Figure 2.** 31P NMR spectra of the purified lignin. **Figure 2.** 31P NMR spectra of the purified lignin.

#### *3.2. Optimization of Fe3O4@LNPs Formation 3.2. Optimization of Fe3O4@LNPs Formation 3.2. Optimization of Fe3O4@LNPs Formation*

preparation.

preparation.

The lignin hardly solubilized in water but dissolved in some organic solvents (e.g., THF). Therefore, Fe3O4NPs suspension used as the anti-solvent and THF used as the solvent were applied to prepare Fe3O4@LNPs through the lignin self-assembly. The initial concentration of lignin played a vital role in the morphology of lignin nanoparticles [29]. Figu[re](#page-4-1) 3 shows that Fe3O4@LNPs exhibited spherical shape. However, the size of Fe3O4@LNPs and its distribution varied with the initial concentration of lignin. Compared to L1 prepared from 0.5 mg/mL lignin solution, L2 and L3 respectively prepared from 1.0 mg/mL and 5.0 mg/mL were more homogenous. Furthermore, L2 had the highest load of Fe3O4 NPs. The lignin hardly solubilized in water but dissolved in some organic solvents (e.g., THF). Therefore, Fe3O4NPs suspension used as the anti-solvent and THF used as the solvent were applied to prepare Fe3O4@LNPs through the lignin self-assembly. The initial concentration of lignin played a vital role in the morphology of lignin nanoparticles [\[29\]](#page-13-5). Figure 3 shows that Fe3O4@LNPs exhibited spherical shape. However, the size of Fe3O4@LNPs and its distribution varied with the initial concentration of lignin. Compared to L1 prepared from 0.5 mg/mL lignin solution, L2 and L3 respectively prepared from 1.0 mg/mL and 5.0 mg/mL were more homogenous. Furthermore, L2 had the highest load of Fe3O4 NPs. The lignin hardly solubilized in water but dissolved in some organic solvents (e.g., THF). Therefore, Fe3O4NPs suspension used as the anti-solvent and THF used as the solvent were applied to prepare Fe3O4@LNPs through the lignin self-assembly. The initial concentration of lignin played a vital role in the morphology of lignin nanoparticles [29]. Figure 3 shows that Fe3O4@LNPs exhibited spherical shape. However, the size of Fe3O4@LNPs and its distribution varied with the initial concentration of lignin. Compared to L1 prepared from 0.5 mg/mL lignin solution, L2 and L3 respectively prepared from 1.0 mg/mL and 5.0 mg/mL were more homogenous. Furthermore, L2 had the highest load of Fe3O4 NPs.

<DESCRIPTION_FROM_IMAGE>The image presents three transmission electron microscopy (TEM) micrographs labeled A, B, and C, each showing nanoparticles at different stages of growth or aggregation. All three micrographs are presented at the same scale, with a scale bar of 1 μm (micrometer) shown in the bottom right corner of each image.

Image A: This micrograph shows a dispersion of small nanoparticles. The particles appear to be in the early stages of growth or nucleation. They are distributed unevenly across the field of view, with some areas of higher concentration and some areas of lower concentration. The particles vary in size but are generally very small, with most appearing to be less than 100 nm in diameter. Some particles appear to be forming small clusters or aggregates.

Image B: This micrograph depicts nanoparticles at a more advanced stage of growth compared to Image A. The particles are larger and more uniform in size than those in Image A. They appear to be forming larger clusters or aggregates, with many groups of particles visible. The overall distribution of particles is more even across the field of view compared to Image A. The individual particles seem to be in the range of 50-100 nm in diameter.

Image C: This micrograph shows the final stage of nanoparticle growth or aggregation. The particles are significantly larger and more uniform in size and shape compared to both Images A and B. They appear to be spherical and are tightly packed, forming a nearly continuous layer across the entire field of view. The particles are much larger, with diameters appearing to be in the range of 200-300 nm. There is very little space between the particles, suggesting a high degree of packing or aggregation.

The sequence of images A to C appears to represent a time series or different conditions of nanoparticle growth and aggregation, progressing from small, dispersed particles to large, uniform, and tightly packed particles. This series could be illustrating a controlled nanoparticle synthesis process, demonstrating how reaction conditions or time affect the size, uniformity, and aggregation state of the nanoparticles.</DESCRIPTION_FROM_IMAGE>

**Figure 3.** TEM images of Fe3O4@LNPs prepared by (**A**) L1: 0.5 mg/mL, (**B**) L2: 1.0 mg/mL, and (**C**) L3: 5.0 mg/mL lignin. **Figure 3.** TEM images of Fe3O4@LNPs prepared by (**A**) L1: 0.5 mg/mL, (**B**) L2: 1.0 mg/mL, and (**C**) L3: 5.0 mg/mL lignin. **Figure 3.** TEM images of Fe3O4@LNPs prepared by (**A**) L1 : 0.5 mg/mL, (**B**) L2 : 1.0 mg/mL, and (**C**) L3 : 5.0 mg/mL lignin.

The effect of lignin concentrations on the size and the size distribution of Fe3O4@LNPs were analyzed bydynamic light scattering (DLS). Figure 4 shows L2 possessed a narrow size distribution with an average size of 152.8 nm. Compared to L2, L1 possessed a wide size distribution with an average size of 181.8 nm, and L3 possessed a wide size distribution with an average size of 764.0 nm. The result indicated that 1.0 mg/mL was the optimum initial concentration of lignin for Fe3O4@LNPs The effect of lignin concentrations on the size and the size distribution of Fe3O4@LNPs were analyzed bydynamic light scattering (DLS). Fig[ure](#page-5-0) 4 shows L2 possessed a narrow size distribution with an average size of 152.8 nm. Compared to L2, L1 possessed a wide size distribution with an average size of 181.8 nm, and L3 possessed a wide size distribution with an average size of 764.0 nm. The result indicated that 1.0 mg/mL was the optimum initial concentration of lignin for Fe3O4@LNPs The effect of lignin concentrations on the size and the size distribution of Fe3O4@LNPs were analyzed bydynamic light scattering (DLS). Figure 4 shows L2 possessed a narrow size distribution with an average size of 152.8 nm. Compared to L2, L1 possessed a wide size distribution with an average size of 181.8 nm, and L3 possessed a wide size distribution with an average size of 764.0 nm. The result indicated that 1.0 mg/mL was the optimum initial concentration of lignin for Fe3O4@LNPs preparation.

In the process of adding water droplets to the lignin/THF solution, lignin as an amphiphilic polymer, with its hydrophilic and hydrophobic properties, gradually aggregates and forms particles, which comprises the "nucleation growth mechanism" [18]. Figure 3 demonstrates that the morphology of the formed nanoparticle was impacted by the initial concentration of lignin. For example, 0.5 mg/mL lignin was applied, the average diameter of L1 was only 181.8 nm but the size distribution was wide. The amount of lignin hardly meets the demand for the nanoparticles growth, resulting in the heterogeneous Fe3O4@LNPs (Figure 3A). However, when the high initial lignin concentration was applied, the extra lignin continued to aggregate on the surface of the formed

In the process of adding water droplets to the lignin/THF solution, lignin as an amphiphilic polymer, with its hydrophilic and hydrophobic properties, gradually aggregates and forms particles, which comprises the "nucleation growth mechanism" [18]. Figure 3 demonstrates that the morphology of the formed nanoparticle was impacted by the initial concentration of lignin. For example, 0.5 mg/mL lignin was applied, the average diameter of L1 was only 181.8 nm but the size distribution was wide. The amount of lignin hardly meets the demand for the nanoparticles growth, resulting in the heterogeneous Fe3O4@LNPs (Figure 3A). However, when the high initial lignin concentration was applied, the extra lignin continued to aggregate on the surface of the formed <span id="page-5-0"></span>as the starting material for the further analysis in this study.

<DESCRIPTION_FROM_IMAGE>The image presents a graph showing the size distribution of particles or structures measured in nanometers (nm). The x-axis represents the size distribution on a logarithmic scale from 10 nm to 10,000 nm. The y-axis shows the intensity as a percentage, ranging from 0% to 25%.

Three distinct curves are plotted on the graph, labeled as a, b, and c:

Curve a (black line):
- Peak centered around 200-300 nm
- Maximum intensity of approximately 12%
- Broader distribution compared to curves b and c
- Extends from about 100 nm to 1000 nm

Curve b (red line):
- Sharp peak centered at approximately 150 nm
- Highest maximum intensity of about 24%
- Narrowest distribution of the three curves
- Ranges from about 100 nm to 300 nm

Curve c (blue line):
- Peak centered around 700-800 nm
- Maximum intensity of about 22%
- Intermediate width distribution
- Extends from about 400 nm to 1500 nm

The graph suggests a comparison of three different samples or conditions, each resulting in a distinct particle size distribution. The differences in peak positions, intensities, and distribution widths indicate varying characteristics of the particles or structures being measured, potentially reflecting different synthesis methods, reaction conditions, or sample treatments.

This type of graph is commonly used in fields such as nanotechnology, colloid science, or materials characterization to analyze and compare particle size distributions obtained through techniques like dynamic light scattering (DLS) or nanoparticle tracking analysis (NTA).</DESCRIPTION_FROM_IMAGE>

nanoparticles, eventually leading to the large size Fe3O4@LNPs (e.g., L3) (Figure 3C). The homogeneous morphology of L2 indicated that 1.0 mg/mL was the optimum concentration for

The surface charge of Fe3O4@LNPs was evaluated by the zeta potential. The results indicated that L1, L2, and L3 possessed comparable negative zeta potentials of −29.2 mV, −32.4 mV and −32.4 mV, respectively, indicating that the initial lignin concentration had little effects on the surface charge of Fe3O4@LNPs. Therefore, L1, L2, and L3 dispersed stably in aqueous solutions for an extended time without aggregation due to the electrical double layer repulsion induced from the protonation of phenolic hydroxyl and carboxyl groups of lignin. The comparable result was reported

Fe3O4@LNPs preparation (Figure 3B). The result was consistent with the previous report [30].

**Figure 4.** Size distribution of Fe3O4@LNPs prepared by (a) L1: 0.5 mg/mL, (b) L2: 1.0 mg/mL, and (c) L3: 5mg/mL lignin. **Figure 4.** Size distribution of Fe3O4@LNPs prepared by (**a**) L1 : 0.5 mg/mL, (**b**) L2 : 1.0 mg/mL, and (**c**) L3 : 5mg/mL lignin.

*3.3. Characterization of Fe3O4 @LNPs*  Fe3O4@LNPs surface possessed the negative charge which was explained as follows. The abundant hydroxyl and carboxyl groups of LNPs provide Fe3O4@LNPs surface a negative charge. In addition, when the hydrophobic surface of LNPs contacts with water, the hydroxyl ions are absorbed by the hydrophobic surface of LNPs, resulting the generation of strong negative zeta potential on the surface of Fe3O4@LNPs [18]. Therefore, Fe3O4 NPs loaded on LNPs can stabilize Fe3O4 NPs and prevent the aggregation of Fe3O4 NPs in solution. The high resolution transmission electron microscope (HRTEM) image of individual Fe3O4@LNPs confirmed that Fe3O4NPs was loaded on the surface of LNPs (Figure 5A). The high-angle annular dark field (HAADF) image demonstrated the morphology of individual Fe3O4@LNPs, where C and Fe element respectively stands for LNPs and Fe3O4 NPs (Figure 5B and In the process of adding water droplets to the lignin/THF solution, lignin as an amphiphilic polymer, with its hydrophilic and hydrophobic properties, gradually aggregates and forms particles, which comprises the "nucleation growth mechanism" [\[18\]](#page-12-15). Figure [3](#page-4-1) demonstrates that the morphology of the formed nanoparticle was impacted by the initial concentration of lignin. For example, 0.5 mg/mL lignin was applied, the average diameter of L1 was only 181.8 nm but the size distribution was wide. The amount of lignin hardly meets the demand for the nanoparticles growth, resulting in the heterogeneous Fe3O4@LNPs (Figure [3A](#page-4-1)). However, when the high initial lignin concentration was applied, the extra lignin continued to aggregate on the surface of the formed nanoparticles, eventually leading to the large size Fe3O4@LNPs (e.g., L3) (Figure [3C](#page-4-1)). The homogeneous morphology of L2 indicated that 1.0 mg/mL was the optimum concentration for Fe3O4@LNPs preparation (Figure [3B](#page-4-1)). The result was consistent with the previous report [\[30\]](#page-13-6).

C). Thus, the HAADF and element mapping analysis confirmed the formation of Fe3O4@LNPs. The correlation of the size distribution of Fe3O4@LNPs and pH was investigated by DLS (Figure 6B). The result indicated that Fe3O4@LNPs had a narrow size distribution within pH from 3.0 to 10.5, confirming that Fe3O4@LNPs can stably disperse in aqueous solution with a wide pH range. This considerable dispersion ability of Fe3O4@LNPs was correlated with its zeta potential (approximately −30 mV) in solution within pH 3.0–10.5 (Figure 6C). When pH was below 3.0, the decrease of zeta potential induced the aggregation of Fe3O4@LNPs. On the other hand, when pH was above 11, the The surface charge of Fe3O4@LNPs was evaluated by the zeta potential. The results indicated that L1, L2, and L3 possessed comparable negative zeta potentials of −29.2 mV, −32.4 mV and −32.4 mV, respectively, indicating that the initial lignin concentration had little effects on the surface charge of Fe3O4@LNPs. Therefore, L1, L2, and L3 dispersed stably in aqueous solutions for an extended time without aggregation due to the electrical double layer repulsion induced from the protonation of phenolic hydroxyl and carboxyl groups of lignin. The comparable result was reported that LNPs dispersed stably in water for two months [\[18\]](#page-12-15). Based on the above results, L2 was applied as the starting material for the further analysis in this study.

### *3.3. Characterization of Fe3O4 @LNPs*

Fe3O4@LNPs surface possessed the negative charge which was explained as follows. The abundant hydroxyl and carboxyl groups of LNPs provide Fe3O4@LNPs surface a negative charge. In addition, when the hydrophobic surface of LNPs contacts with water, the hydroxyl ions are absorbed by the hydrophobic surface of LNPs, resulting the generation of strong negative zeta potential on the surface of Fe3O4@LNPs [\[18\]](#page-12-15). Therefore, Fe3O4 NPs loaded on LNPs can stabilize Fe3O4 NPs and prevent the aggregation of Fe3O4 NPs in solution.

The high resolution transmission electron microscope (HRTEM) image of individual Fe3O4@LNPs confirmed that Fe3O4NPs was loaded on the surface of LNPs (Figure [5A](#page-6-0)). The high-angle annular dark field (HAADF) image demonstrated the morphology of individual Fe3O4@LNPs, where C and Fe element respectively stands for LNPs and Fe3O4 NPs (Figure [5B](#page-6-0),C). Thus, the HAADF and element mapping analysis confirmed the formation of Fe3O4@LNPs. The correlation of the size distribution of Fe3O4@LNPs and pH was investigated by DLS (Figure [6B](#page-7-0)). The result indicated that Fe3O4@LNPs had a narrow size distribution within pH from 3.0 to 10.5, confirming that Fe3O4@LNPs can stably disperse in aqueous solution with a wide pH range. This considerable dispersion ability of Fe3O4@LNPs was correlated with its zeta potential (approximately −30 mV) in solution within pH 3.0–10.5 (Figure [6C](#page-7-0)). When pH was below 3.0, the decrease of zeta potential induced the aggregation of Fe3O4@LNPs. On the other hand, when pH was above 11, the surface charge decreased significantly which caused the aggregation of Fe3O4@LNPs enlarging the average diameter of nanoparticles. The surface charge of Fe3O4@LNPsdecreased with the increased concentration of Na+ counter ions associated with the addition of NaOH for the pH adjustment. The result was consistent to the reported result on the dispersion stability of polymer nanoparticles correlated with the pH change [\[18](#page-12-15)[,31\]](#page-13-7). *Nanomaterials* **2019**, *9*, 210 7 of 14 surface charge decreased significantly which caused the aggregation of Fe3O4@LNPs enlarging the average diameter of nanoparticles. The surface charge of Fe3O4@LNPsdecreased with the increased concentration of Na+ counter ions associated with the addition of NaOH for the pH adjustment. The result was consistent to the reported result on the dispersion stability of polymer nanoparticles correlated with the pH change [18,31].

<DESCRIPTION_FROM_IMAGE>The image presents a set of microscopy images labeled A, B, and C, showing nanoparticle structures and elemental mapping.

A: Transmission Electron Microscopy (TEM) image of a spherical nanoparticle with a diameter of approximately 100 nm. The particle appears to have a core-shell structure, with darker regions inside the lighter shell, suggesting the presence of higher atomic number elements in the core. The scale bar indicates 50 nm.

B: High-Angle Annular Dark-Field (HAADF) Scanning Transmission Electron Microscopy (STEM) image of the same or similar nanoparticle. The bright regions within the particle indicate areas of higher atomic number elements, corresponding to the darker regions in image A. The scale bar is 50 nm, and "HAADF" is labeled in the bottom right corner.

C: Elemental mapping of the nanoparticle using Energy-Dispersive X-ray Spectroscopy (EDS) or a similar technique. The image is divided into three panels:
1. Left panel: Carbon (C) distribution, shown in red, uniformly distributed throughout the particle.
2. Middle panel: Iron (Fe) distribution, shown in blue, concentrated in specific regions within the particle.
3. Right panel: Overlay of Carbon (C) and Iron (Fe) distributions, showing the spatial relationship between the two elements.

Each panel in C has a scale bar of 50 nm.

The images collectively suggest a carbon-based nanoparticle (possibly a carbon sphere or similar structure) with iron-rich regions embedded within it. This could represent a composite material or a functionalized carbon nanoparticle with iron-based components.</DESCRIPTION_FROM_IMAGE>

**Figure 5.** (**A**) HRTEM image of individual Fe3O4@LNPs; (**B**) High-angle annular dark field image (HAADF) and (**C**) element mapping analysis of Fe3O4@LNPs. **Figure 5.** (**A**) HRTEM image of individual Fe3O4@LNPs; (**B**) High-angle annular dark field image (HAADF) and (**C**) element mapping analysis of Fe3O4@LNPs.

solution.

<DESCRIPTION_FROM_IMAGE>The image contains three graphs labeled A, B, and C, each providing different information about a system's behavior at various pH levels.

Graph A:
This graph shows the relationship between pH and average diameter (nm) of particles or structures in a system. The x-axis represents pH values from 0 to 12, while the y-axis shows the average diameter from 0 to 1800 nm. Data points are represented by circles with error bars. The graph shows a general trend of decreasing average diameter as pH increases, with the largest diameter (around 1100 nm) observed at pH 1, and the smallest diameters (around 150-200 nm) observed between pH 4 and 10. There's a slight increase in diameter at pH 11 and 12.

Graph B:
This graph illustrates the size distribution of particles or structures at different pH levels. The x-axis represents size (nm) on a logarithmic scale from 10 to 10000 nm, while the y-axis shows intensity (%) from 0 to 30%. The graph contains multiple overlapping curves, each representing a different pH value ranging from 1.1 to 12.0. Each curve shows one or more peaks, indicating the presence of different size populations at various pH levels. The peaks shift and change in intensity across different pH values, suggesting pH-dependent changes in the size distribution of the particles or structures.

Graph C:
This graph depicts the relationship between pH and zeta potential (mV) of the system. The x-axis represents pH values from 0 to 12, while the y-axis shows zeta potential from 0 to -40 mV. Data points are represented by circles with error bars. The graph shows a general trend of decreasing (more negative) zeta potential as pH increases, with the highest (least negative) zeta potential around -5 mV at pH 1, and the lowest (most negative) zeta potential around -35 mV at pH 11. There's a slight increase in zeta potential at pH 12.

These graphs collectively provide information about how pH affects the size, size distribution, and surface charge (indicated by zeta potential) of particles or structures in the system being studied.</DESCRIPTION_FROM_IMAGE>

<span id="page-7-0"></span>*Nanomaterials* **2019**, *9*, 210 8 of 14

**Figure 6.** Effects of pH on (**A**) average size of Fe3O4@LNPs, (**B**) size distribution of Fe3O4@LNPs, and (**C**) zeta potential value of Fe3O4@LNPs. **Figure 6.** Effects of pH on (**A**) average size of Fe3O4@LNPs, (**B**) size distribution of Fe3O4@LNPs, and (**C**) zeta potential value of Fe3O4@LNPs.

#### *3.4. Optimizing the Reaction Conditions of H2O2 and TMB Catalyzed by Fe3O4@LNPs 3.4. Optimizing the Reaction Conditions of H2O2 and TMB Catalyzed by Fe3O4@LNPs*

To improve the catalytic activity of Fe3O4@LNPs, the main parameters, e.g., time, pH, and temperature, were optimized. The experiment was performed as following 600 μL Fe3O4@LNPs (264 μg/mL), 300 μL TMB (4 mM) and 300 μL H2O2 (100 mM) were applied as reagents in 1.8 mL CPBS buffer solution (0.1 M). The relative activity of Fe3O4@LNPs with different pH, time and temperature were defined by follows: the maximum absorbance of the solution after reaction at 652 nm was set as 100%, and the relative activities were calculated by the equation: R = (A/Amax) × 100%, where R was the relative activity; A was the absorbance of the solution at 652 nm; and Amax was the maximum absorbance at 652 nm. The impacts of reaction time, pH, and temperature on the activity of Fe3O4@LNPs were demonstrated in Figure 7. The correlation between the reactivity of Fe3O4@LNPs and time was demonstrated in Figure 7A. It was shown that the activity of Fe3O4@LNPs increased to the maximum within 30 min. Thus, 30 min was set as the optimal reaction time for the following investigations. Within pH = 2.0–4.5, the Fe3O4@LNPs possessed a high and stable activity and achieved the maximum activity at pH = 3.0 (Figure 7B) that was contributed to solubilization of TMB in the acidic medium [32]. The comparable peroxidase-like activity were reported from HRP and other metal nanoenzymes [10,25]. The catalytic activity was significantly decreased when Fe3O4@LNPs was applied without the optimal pH (Figure 7B) because of the inherent defect of Fenton reaction [33]. It was reported that the catalytic activity of Fe3O4NPs loaded on multi-welled carbon nanotubes retained from pH 1–10 [33]; however the high cost of multi-welled carbon nanotubes limited its application. The catalytic activity of Fe3O4@LNPs was also impacted by temperature, and the maximum activity was achieved at 50 °C (Figure 7C). Compared to natural To improve the catalytic activity of Fe3O4@LNPs, the main parameters, e.g., time, pH, and temperature, were optimized. The experiment was performed as following 600 µL Fe3O4@LNPs (264 µg/mL), 300 µL TMB (4 mM) and 300 µL H2O2 (100 mM) were applied as reagents in 1.8 mL CPBS buffer solution (0.1 M). The relative activity of Fe3O4@LNPs with different pH, time and temperature were defined by follows: the maximum absorbance of the solution after reaction at 652 nm was set as 100%, and the relative activities were calculated by the equation: R = (A/Amax) × 100%, where R was the relative activity; A was the absorbance of the solution at 652 nm; and Amax was the maximum absorbance at 652 nm. The impacts of reaction time, pH, and temperature on the activity of Fe3O4@LNPs were demonstrated in Figure [7.](#page-8-0) The correlation between the reactivity of Fe3O4@LNPs and time was demonstrated in Figure [7A](#page-8-0). It was shown that the activity of Fe3O4@LNPs increased to the maximum within 30 min. Thus, 30 min was set as the optimal reaction time for the following investigations. Within pH = 2.0–4.5, the Fe3O4@LNPs possessed a high and stable activity and achieved the maximum activity at pH = 3.0 (Figure [7B](#page-8-0)) that was contributed to solubilization of TMB in the acidic medium [\[32\]](#page-13-8). The comparable peroxidase-like activity were reported from HRP and other metal nanoenzymes [\[10](#page-12-7)[,25\]](#page-13-1). The catalytic activity was significantly decreased when Fe3O4@LNPs was applied without the optimal pH (Figure [7B](#page-8-0)) because of the inherent defect of Fenton reaction [\[33\]](#page-13-9). It was reported that the catalytic activity of Fe3O4NPs loaded on multi-welled carbon nanotubes retained from pH 1–10 [\[33\]](#page-13-9); however the high cost of multi-welled carbon nanotubes limited its application. The catalytic activity of Fe3O4@LNPs was also impacted by temperature, and the maximum activity was achieved at 50 ◦C (Figure [7C](#page-8-0)). Compared to natural enzymes and Fe3O4

enzymes and Fe3O4 nanozymes [11], Fe3O4@LNPs retained the catalytic activity within a wide temperature range from 30 °C to 60 °C because of its considerable dispersion ability in the aqueous

<DESCRIPTION_FROM_IMAGE>The image contains three graphs labeled A, B, and C, each showing the relationship between relative activity (%) and different parameters.

Graph A:
This graph shows the relationship between relative activity (%) and time (min). The x-axis ranges from 0 to 50 minutes, while the y-axis shows relative activity from 0% to 100%. The curve starts at about 20% relative activity at 0 minutes and increases rapidly in the first 20 minutes, reaching about 90% activity. After 20 minutes, the rate of increase slows down, approaching 100% activity asymptotically by 50 minutes.

Graph B:
This graph depicts the relationship between relative activity (%) and pH. The x-axis shows pH values from 2 to 8, and the y-axis represents relative activity from 0% to 100%. The curve shows a sharp peak at pH 3, reaching 100% relative activity. The activity drops rapidly on both sides of this optimum pH, with activity falling below 40% at pH 4 and below 20% at pH 5 and above.

Graph C:
This graph illustrates the relationship between relative activity (%) and temperature (°C). The x-axis ranges from 20°C to 70°C, while the y-axis shows relative activity from 0% to 100%. The curve starts at about 25% activity at 20°C, increases steadily to a maximum of 100% activity at 50°C, and then decreases rapidly, reaching about 35% activity at 70°C.

These graphs likely represent the characterization of an enzyme or similar biological catalyst, showing its activity dependence on time (possibly representing reaction progress), pH (indicating the optimal pH for the enzyme's function), and temperature (showing the temperature optimum and thermal stability of the enzyme).</DESCRIPTION_FROM_IMAGE>

nanozymes [\[11\]](#page-12-8), Fe3O4@LNPs retained the catalytic activity within a wide temperature range from 30 ◦C to 60 ◦C because of its considerable dispersion ability in the aqueous solution. *Nanomaterials* **2019**, *9*, 210 9 of 14

**Figure 7.** The catalytic activity of Fe3O4@LNPscorrelated with time (**A**), pH (**B**), and temperature (**C**). **Figure 7.** The catalytic activity of Fe3O4@LNPscorrelated with time (**A**), pH (**B**), and temperature (**C**).

#### *3.5. Peroxidase-liked Activity of Fe3O4@LNPs 3.5. Peroxidase-liked Activity of Fe3O4@LNPs*

The peroxidase-liked activity of Fe3O4@LNPs was confirmed and evaluated by the reaction between TMB and H2O2 under optimal conditions. Little color changes and absorbance peaks at 652 nm were observed from the reaction of LNPs + TMB and LNPs + TMB + H2O2 (Figure 8 curve a and b), which suggested that LNPs possessed little catalytic activity. Little color change and absorbance peak at 652 nm were observed from the reaction of Fe3O4 NPs + TMB, confirming that TMB could not be oxidized without the presence of H2O2. The color change and absorbance peak at 652 nm were respectively observed from the reaction of Fe3O4 NPs + TMB + H2O2 and Fe3O4@LNPs + TMB + H2O2, which indicated TMB was oxidized during the reaction. However, the absorbance peak of Fe3O4@LNPs + TMB + H2O2 at 652 nm was significantly higher than that of Fe3O4 + TMB + H2O2, indicating Fe3O4@LNPs possessed stronger peroxidase-liked catalytic activity than Fe3O4 NPs due to its considerable dispersion ability. It was consistent with the reported result that Fe3O4 NPs stabilized by chitosan exhibited strong catalytic activity than Fe3O4 NPs [34]. The peroxidase-liked activity of Fe3O4@LNPs was confirmed and evaluated by the reaction between TMB and H2O2 under optimal conditions. Little color changes and absorbance peaks at 652 nm were observed from the reaction of LNPs + TMB and LNPs + TMB + H2O2 (Figure [8](#page-9-0) curve a and b), which suggested that LNPs possessed little catalytic activity. Little color change and absorbance peak at 652 nm were observed from the reaction of Fe3O4 NPs + TMB, confirming that TMB could not be oxidized without the presence of H2O2. The color change and absorbance peak at 652 nm were respectively observed from the reaction of Fe3O4 NPs + TMB + H2O2 and Fe3O4@LNPs + TMB + H2O2, which indicated TMB was oxidized during the reaction. However, the absorbance peak of Fe3O4@LNPs + TMB + H2O2 at 652 nm was significantly higher than that of Fe3O4 + TMB + H2O2, indicating Fe3O4@LNPs possessed stronger peroxidase-liked catalytic activity than Fe3O4 NPs due to its considerable dispersion ability. It was consistent with the reported result that Fe3O4 NPs stabilized by chitosan exhibited strong catalytic activity than Fe3O4 NPs [\[34\]](#page-13-10).

<DESCRIPTION_FROM_IMAGE>The image presents a UV-Vis absorption spectrum along with an inset photograph of six sample vials labeled a through f. The graph shows the absorbance of these samples across a wavelength range of 450 to 775 nm.

The spectrum displays six curves corresponding to the six samples:

a) Black line: Shows minimal absorbance across the entire spectrum, staying close to 0.
b) Red line: Similar to 'a', very low absorbance throughout.
c) Blue line: Also exhibits minimal absorbance, overlapping with 'a' and 'b'.
d) Green line: Shows a broad absorption peak centered around 650 nm, with a maximum absorbance of about 0.28.
e) Pink line: Displays a slight decrease in absorbance from 450 to 775 nm, starting at about 0.1 and ending near 0.
f) Olive green line: Exhibits the strongest absorption, with a broad peak centered around 650 nm and a maximum absorbance of about 0.85.

The x-axis represents the wavelength in nanometers (nm), ranging from 450 to 775 nm. The y-axis shows the absorbance, scaled from 0 to 1.0.

The inset photograph shows six vials containing solutions, labeled 'a' through 'f'. Vials 'a', 'b', 'c', and 'e' appear to contain clear or slightly colored solutions, while vials 'd' and 'f' contain more intensely colored solutions, which correlates with their higher absorbance in the spectrum.

This spectral data suggests that samples 'd' and 'f' contain species that absorb strongly in the visible region, particularly around 650 nm, which corresponds to the red-orange part of the spectrum. The other samples show minimal absorption in this range, indicating they contain species that do not significantly interact with visible light or have very low concentrations of absorbing species.</DESCRIPTION_FROM_IMAGE>

<span id="page-9-0"></span>*Nanomaterials* **2019**, *9*, 210 10 of 14

**Figure 8.** The UV-vis spectra of LNPs + TMB (a); LNPs + TMB + H2O2 (b); Fe3O4 + TMB (c); Fe3O4 + TMB + H2O2 (d); Fe3O4@LNPs + TMB (e) and Fe3O4@LNPs + TMB+ H2O2 (f); Insert is the photograph of the corresponding solution. **Figure 8.** The UV-vis spectra of LNPs + TMB (**a**); LNPs + TMB + H2O2 (**b**); Fe3O4 + TMB (**c**); Fe3O4 + TMB + H2O2 (**d**); Fe3O4@LNPs + TMB (**e**) and Fe3O4@LNPs + TMB+ H2O2 (**f**); Insert is the photograph of the corresponding solution.

#### *3.6. Steady-State Kinetic Study of Fe3O4@LNPs 3.6. Steady-State Kinetic Study of Fe3O4@LNPs*

The steady-state kinetic mechanism of Fe3O4@LNPsNPs reacted with H2O2 and TMB was investigated. The concentration of TMB-derived oxidation products was calculated by A = ε × b × C (Beer-Lambert Law), where A is the absorbance value at 652 nm at room temperature and the molar absorption coefficient (ε) is 39,000 M−1cm−1 [35]. The Michaelis-Menten curves were obtained by following steps: the reaction rates of Fe3O4@LNPsNPs in different concentration of TMB or H2O2 were obtained by calculated the slope of the reaction system at 652 nm in the initial 5 min. Then, the reaction rates were plotted on the ordinate and the concentrations of TMB or H2O2 were plotted on the abscissa. The Lineweaver-Burk plots were obtained by taking the reciprocal of the reaction rate as the ordinate and the reciprocal of the concentration of TMB or H2O2. The reaction rate correlated with TMB concentration and H2O2 concentration was respectively demonstrated in Figure 9A and B. The Michaelis-Menten constant (Km) is considered to be a key criterion for evaluating the enzyme's affin[ity](#page-10-0) to a substrate [32]. The maximum velocity (Vm) and Km were obtained from the Lineweaver-Burk plots (Figure 9C and D) and summarized in Table 1. The Km values of Fe3O4@LNPs towards TMB and H2O2 was com[pa](#page-10-0)rable to that of HRP which indi[ca](#page-10-1)ted the Fe3O4@LNPsNPs could be used as an effective substitute for HRP. The Km value of Fe3O4@LNPsNPs with TMB as the substrate was higher than that of Fe3O4 NPs with TMB, indicating that the Fe3O4 NPs have a higher affinity to TMB. The Km value of the Fe3O4@LNPs with H2O2 was 29 times lower than that of the Fe3O4NPs with H2O2, suggesting that the Fe3O4@LNPs possessed significantly stronger affinity to H2O2 than the Fe3O4 NPs. However, the low Km value of Fe3O4@LNPswith H2O2is potentially due to the continuous release of Fe3O4NPs from the Fe3O4@LNPs, thus avoiding the aggregation of Fe3O4 NPs and providing more reactive sites which enhanced the peroxidase-like activity of Fe3O4@LNPs during the reaction. The higher Km value of Fe3O4NPs with H2O2 was consistent with the reported result that Fe3O4NPs needs a higher H2O2 concentration than Fe3O4@LNPs to obtain the comparable Vm [11]. Table 1 shows Fe3O4@LNPs possessed a comparable or stronger affinity to TMB or H2O2, compared to Fe3O4 NPs prepared by other methods [36–39]. Conclusively, the metal nanoparticles loaded on lignin nanoparticles improved its dispersion stability in solution and eventually increased its catalytic capacity. The steady-state kinetic mechanism of Fe3O4@LNPsNPs reacted with H2O2 and TMB was investigated. The concentration of TMB-derived oxidation products was calculated by A = ε × b × C (Beer-Lambert Law), where A is the absorbance value at 652 nm at room temperature and the molar absorption coefficient (ε) is 39,000 M−1 cm−1 [\[35\]](#page-13-11). The Michaelis-Menten curves were obtained by following steps: the reaction rates of Fe3O4@LNPsNPs in different concentration of TMB or H2O2 were obtained by calculated the slope of the reaction system at 652 nm in the initial 5 min. Then, the reaction rates were plotted on the ordinate and the concentrations of TMB or H2O2 were plotted on the abscissa. The Lineweaver-Burk plots were obtained by taking the reciprocal of the reaction rate as the ordinate and the reciprocal of the concentration of TMB or H2O2. The reaction rate correlated with TMB concentration and H2O2 concentration was respectively demonstrated in Figure 9A,B. The Michaelis-Menten constant (Km) is considered to be a key criterion for evaluating the enzyme's affinity to a substrate [\[32\]](#page-13-8). The maximum velocity (Vm) and Km were obtained from the Lineweaver-Burk plots (Figure 9C,D) and summarized in Table 1. The Km values of Fe3O4@LNPs towards TMB and H2O2 was comparable to that of HRP which indicated the Fe3O4@LNPsNPs could be used as an effective substitute for HRP. The Km value of Fe3O4@LNPsNPs with TMB as the substrate was higher than that of Fe3O4 NPs with TMB, indicating that the Fe3O4 NPs have a higher affinity to TMB. The Km value of the Fe3O4@LNPs with H2O2 was 29 times lower than that of the Fe3O4NPs with H2O2, suggesting that the Fe3O4@LNPs possessed significantly stronger affinity to H2O2 than the Fe3O4 NPs. However, the low Km value of Fe3O4@LNPswith H2O2is potentially due to the continuous release of Fe3O4NPs from the Fe3O4@LNPs, thus avoiding the aggregation of Fe3O4 NPs and providing more reactive sites which enhanced the peroxidase-like activity of Fe3O4@LNPs during the reaction. The higher Km value of Fe3O4NPs with H2O2 was consistent with the reported result that Fe3O4NPs needs a higher H2O2 concentration than Fe3O4@LNPs to obtain the comparable Vm [\[11\]](#page-12-8). Table [1](#page-10-1) shows Fe3O4@LNPs possessed a comparable or stronger affinity to TMB or H2O2, compared to Fe3O4 NPs prepared by other methods [\[36](#page-13-12)[–39\]](#page-13-13). Conclusively, the metal nanoparticles loaded on lignin nanoparticles improved its dispersion stability in solution and eventually increased its catalytic capacity.

<DESCRIPTION_FROM_IMAGE>This image appears to contain only text that reads "11 of 1". This text likely represents a page number or some form of enumeration within a larger document or series. Without additional context or visual elements related to chemistry or scientific content, I cannot provide a meaningful interpretation relevant to applied chemistry or scientific analysis. Therefore, I will respond with:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled A, B, C, and D, each showing different relationships in a chemical reaction system, likely involving the oxidation of TMB (3,3',5,5'-tetramethylbenzidine) by hydrogen peroxide (H2O2), possibly catalyzed by an enzyme.

Graph A:
X-axis: TMB Concentration (mM), ranging from 0 to 6 mM
Y-axis: V (10^-8 Ms^-1), ranging from 0.5 to 1.0
The graph shows a saturation curve, with the rate (V) increasing rapidly at low TMB concentrations and then leveling off at higher concentrations, following typical Michaelis-Menten kinetics.

Graph B:
X-axis: H2O2 Concentration (mM), ranging from 0 to 250 mM
Y-axis: V (10^-8 Ms^-1), ranging from 0.6 to 1.0
This graph also shows a saturation curve for H2O2, with the rate increasing sharply at low concentrations and then plateauing at higher concentrations.

Graph C:
X-axis: 1/TMB Concentration (mM^-1), ranging from 0 to 2.5 mM^-1
Y-axis: V^-1 (10^8 sM^-1), ranging from 1.0 to 2.4
This is a Lineweaver-Burk plot (double reciprocal plot) for TMB, showing a linear relationship between 1/V and 1/[TMB].

Graph D:
X-axis: 1/H2O2 Concentration (mM^-1), ranging from 0 to 0.1 mM^-1
Y-axis: V^-1 (10^8 sM^-1), ranging from 1.0 to 1.7
This is a Lineweaver-Burk plot for H2O2, also showing a linear relationship between 1/V and 1/[H2O2].

All graphs include error bars on the data points, indicating experimental uncertainty. The red lines in each graph represent the best fit to the data points.

These graphs collectively provide information about the enzyme kinetics of the reaction, including the apparent Km and Vmax values for both TMB and H2O2 substrates. The Lineweaver-Burk plots (C and D) can be used to determine these kinetic parameters more precisely.</DESCRIPTION_FROM_IMAGE>

<span id="page-10-0"></span>*Nanomaterials* **2019**, *9*, 210 11 of 14

**Figure 9.** The steady-state dynamic analysis and catalytic mechanism of Fe3O4@LNPs: the Michaelis-Menten curves (**A** and **B**) and the double reciprocal plots of the activity of Fe3O4@LNPs(**C Figure 9.** The steady-state dynamic analysis and catalytic mechanism of Fe3O4@LNPs: the Michaelis-Menten curves (**A**,**B**) and the double reciprocal plots of the activity of Fe3O4@LNPs(**C**,**D**).

| Catalyst   | Substrate | Km/mM  | Table 1. Comparisons of Km and Vm among Fe3O4@LNPs, Fe3O4 NPs, and HRP.<br>Vm/10−8 Ms−1 | Reference |
|------------|-----------|--------|-----------------------------------------------------------------------------------------|-----------|
| Fe3O4@LNPs | TMB       | 0.51   | 1.03                                                                                    | This work |
| Catalyst   | Substrate | Km/mM  | Vm/10−8 Ms−1                                                                            | Reference |
| Fe3O4@LNPs | H2O2      | 5.30   | 0.96                                                                                    | This work |
| Fe3O4@LNPs | TMB       | 0.51   | 1.03                                                                                    | This work |
| Fe3O4 NPs  | TMB       | 0.01   | 3.44                                                                                    | [11]      |
| Fe3O4@LNPs | H2O2      | 5.30   | 0.96                                                                                    | This work |
| Fe3O4 NPs  | H2O2      | 154    | 9.78                                                                                    | [11]      |
| HRP        | TMB       | 0.43   | 10.00                                                                                   | [11]      |
| Fe3O4 NPs  | TMB       | 0.01   | 3.44                                                                                    | [11]      |
| HRP        | H2O2      | 3.70   | 8.71                                                                                    | [11]      |
| Fe3O4 NPs  | H2O2      | 154    | 9.78                                                                                    | [11]      |
| His-Fe3O4  | H2O2      | 37.99  | -                                                                                       | [37]      |
| HRP        | TMB       | 0.43   | 10.00                                                                                   | [11]      |
| Ala-Fe3O4  | H2O2      | 226.60 | -                                                                                       | [37]      |
| HRP        | H2O2      | 3.70   | 8.71                                                                                    | [11]      |
| P-Fe3O4    | TMB       | 0.44   | -                                                                                       | [36]      |
| CDs-Fe3O4  | H2O2      | 56.97  | -                                                                                       | [38]      |
| His-Fe3O4  | H2O2      | 37.99  | -                                                                                       | [37]      |
| GO-Fe3O4   | H2O2      | 305.00 | 1.01                                                                                    | [40]      |
| Ala-Fe3O4  | H2O2      | 226.60 | -                                                                                       | [37]      |
|            |           |        |                                                                                         |           |

**Table 1.** Comparisons of Km and Vm among Fe3O4@LNPs, Fe3O4 NPs, and HRP.

P-Fe3O4 TMB 0.44 - [36] CDs-Fe3O4 H2O2 56.97 - [38] Note: His-Fe3O4: Histidine modified Fe3O4; Ala-Fe3O4: Alanine modified Fe3O4: Not given; P-Fe3O4: Porphyrin modified Fe3O4; CDs-Fe3O4: Carbon dots modified Fe3O4; GO-Fe3O4: Graphene oxide-based Fe2O3 hybrid.

#### GO-Fe3O4 H2O2 305.00 1.01 [40] *3.7. The Colorimetric Detection of H2O2*

<span id="page-10-1"></span>and **D**).

Note: His-Fe3O4: Histidine modified Fe3O4; Ala-Fe3O4:Alanine modified Fe3O4: Not given; P-Fe3O4: Porphyrin modified Fe3O4; CDs-Fe3O4: Carbon dots modified Fe3O4; GO-Fe3O4: Graphene oxide-based Fe2O3 hybrid. *3.7. The Colorimetric Detection of H2O2*  Because the inherent peroxidase-like activity of Fe3O4@LNPs was H2O2 concentration dependent, a colorimetric method was designed to detect H2O2. Under the optimal conditions, in a Because the inherent peroxidase-like activity of Fe3O4@LNPs was H2O2 concentration dependent, a colorimetric method was designed to detect H2O2. Under the optimal conditions, in a total reaction volume of 3 mL, 264 µg/mL Fe3O4@LNPs and 4 mM TMB mixed with various concentrations of H2O2 in a CPBS buffer (pH = 3.0), the reaction was completed at 50 ◦C for 30 min. It was demonstrated in Figure [10A](#page-11-1) the solution color and the absorbance were correlated with H2O2 concentration. For example, the solution color became darker and the absorbance increased, as the concentration of H2O2 increased. The LOD of H2O2 concentration corresponding to the color variation was as low as

total reaction volume of 3 mL, 264 μg/mL Fe3O4@LNPs and 4 mM TMB mixed with various concentrations of H2O2 in a CPBS buffer (pH = 3.0), the reaction was completed at 50 °C for 30 min. It was demonstrated in Figure 10A the solution color and the absorbance were correlated with H2O2

2 µM (Figure [10A](#page-11-1), inset). When the concentration of H2O2 was less than 100 µM, there was a linear relationship between the absorbance at 652 nm and the H2O2 concentration. Conclusively, there was the possibility of the rapid detection of H2O2 by the naked eye or a UV-visible spectrophotometer when the Fe3O4@LNPs was applied. The linear relationship between the absorbance at 652 nm and the H2O2 concentration was identified when the concentration of H2O2 ranged from 5 to 100 μM (Figure 10B). The linear regression equation was A652nm = 0.09993 + 0.00186C (where C is the concentration of H2O2), and the correlation coefficient (R2) is 0.99077 (*n* = 3). The LODwas 2 × 10−6M, which is lower than the counterpart of Fe3O4 NPs (3 × 10−6M) [39].

UV-visible spectrophotometer when the Fe3O4@LNPs was applied.

*Nanomaterials* **2019**, *9*, 210 12 of 14

concentration. For example, the solution color became darker and the absorbance increased, as the concentration of H2O2 increased. The LOD of H2O2 concentration corresponding to the color variation was as low as 2 μM (Figure 10A, inset). When the concentration of H2O2 was less than 100 μM, there was a linear relationship between the absorbance at 652 nm and the H2O2 concentration.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs, labeled A and B, both showing the relationship between H2O2 concentration and absorbance at 652 nm.

Graph A:
This graph shows a non-linear relationship between H2O2 concentration and absorbance. The x-axis represents H2O2 concentration ranging from 0 to 300 μM, while the y-axis shows absorbance at 652 nm from 0.10 to 0.40. The data points follow a curve that appears to be approaching saturation, with a steep increase in absorbance at lower H2O2 concentrations and a gradual leveling off at higher concentrations. The curve fits well with the experimental data points. An inset image shows two vials, labeled 2μM and 0μM, presumably referring to H2O2 concentrations.

Graph B:
This graph displays a linear relationship between H2O2 concentration and absorbance. The x-axis represents H2O2 concentration from 0 to 100 μM, while the y-axis shows absorbance at 652 nm from 0.10 to 0.30. The data points fall closely along a straight line, indicating a direct proportional relationship between H2O2 concentration and absorbance in this range.

Both graphs use black dots to represent data points and red lines to show the fitted curves or lines. The graphs suggest that the relationship between H2O2 concentration and absorbance is linear at lower concentrations (as shown in Graph B) but becomes non-linear at higher concentrations (as shown in Graph A).</DESCRIPTION_FROM_IMAGE>

**Figure 10.** The dose-response curve for H2O2 detection (**A**), the inset: the colored products of different concentration of H2O2 (2 μM and 0 μM); the liner correlation between absorbance and H2O2 concentration (**B**). **Figure 10.** The dose-response curve for H2O2 detection (**A**), the inset: the colored products of different concentration of H2O2 (2 µM and 0 µM); the liner correlation between absorbance and H2O2 concentration (**B**).

**4. Conclusion**  Fe3O4@LNPs were prepared from the purified Spruce lignin using the self-assembly method. TEM and DLS analysis indicated that when the initial concentration of lignin solution was 1.0 mg/mL, the homogeno[us F](#page-13-13)e3O4@LNPs was obtained, and the average size was 152.8 nm. The The linear relationship between the absorbance at 652 nm and the H2O2 concentration was identified when the concentration of H2O2 ranged from 5 to 100 µM (Figure [10B](#page-11-1)). The linear regression equation was A652nm = 0.09993 + 0.00186C (where C is the concentration of H2O2), and the correlation coefficient (R2 ) is 0.99077 (*n* = 3). The LODwas 2 × 10−6M, which is lower than the counterpart of Fe3O4 NPs (3 × 10−6 M) [39].

catalytic ability of Fe3O4@LNPs was optimized with the reaction time, pH, and temperature.

#### Fe3O4@LNPs exhibited better peroxidase mimic activity than Fe3O4 NPs due to its more stable **4. Conclusion**

dispersion in the reaction system. The catalytic activity of Fe3O4@LNPs allows its colorimetric detection of H2O2 at 2 μM limitation of concentration. **Author Contributions:** Q.Z., D.M., and S.W. originally conceived the idea and designed all the experiments. M.L., C.G., Z.J., and G.W. completed TEM, element mapping and DLS measurement. Q.Z., and D.M., wrote the manuscript. All the authors provided the discussion on the mechanism of Fe3O4@LNPs and reviewed the manuscript. **Funding:** This research was funded by Postdoctoral Fund of China [2015M570419], Natural Science Fund of Fe3O4@LNPs were prepared from the purified Spruce lignin using the self-assembly method. TEM and DLS analysis indicated that when the initial concentration of lignin solution was 1.0 mg/mL, the homogenous Fe3O4@LNPs was obtained, and the average size was 152.8 nm. The catalytic ability of Fe3O4@LNPs was optimized with the reaction time, pH, and temperature. Fe3O4@LNPs exhibited better peroxidase mimic activity than Fe3O4 NPs due to its more stable dispersion in the reaction system. The catalytic activity of Fe3O4@LNPs allows its colorimetric detection of H2O2 at 2 µM limitation of concentration.

China [31400514], South China University of Technology Pulp and Paper Engineering State Key Laboratory Open Fund [2015016], and Guangxi University Guangxi Key Laboratory of Clean Pulp & Papermaking and Pollution Control Open Fund [ZR201805-7]. **Author Contributions:** Q.Z., D.M., and S.W. originally conceived the idea and designed all the experiments. M.L., C.G., Z.J., and G.W. completed TEM, element mapping and DLS measurement. Q.Z., and D.M., wrote the manuscript. All the authors provided the discussion on the mechanism of Fe3O4@LNPs and reviewed the manuscript.

**Conflicts of Interest:** The authors declare no conflict of interest. **References Funding:** This research was funded by Postdoctoral Fund of China [2015M570419], Natural Science Fund of China [31400514], South China University of Technology Pulp and Paper Engineering State Key Laboratory Open Fund [2015016], and Guangxi University Guangxi Key Laboratory of Clean Pulp & Papermaking and Pollution Control Open Fund [ZR201805-7].

1. Muralikrishna, S.; Cheunkar, S.; Lertanantawong, B.; Ramakrishnappa, T.; Nagaraju, D.H.; Surareungchai, W.; Balakrishna, R.G.; Reddy, K.R. Graphene oxide-Cu(II) composite electrode for non-enzymatic **Conflicts of Interest:** The authors declare no conflict of interest.

#### determination of hydrogen peroxide. *J.Electroanal.Chem.***2016**, *776*, 59–65. **References**

- <span id="page-11-0"></span>1. Muralikrishna, S.; Cheunkar, S.; Lertanantawong, B.; Ramakrishnappa, T.; Nagaraju, D.H.; Surareungchai, W.; Balakrishna, R.G.; Reddy, K.R. Graphene oxide-Cu(II) composite electrode for non-enzymatic determination of hydrogen peroxide. *J. Electroanal. Chem.* **2016**, *776*, 59–65. [\[CrossRef\]](http://dx.doi.org/10.1016/j.jelechem.2016.06.034)
- 2. Zhang, X.; Bi, X.; Di, W.; Qin, W. A simple and sensitive Ce(OH)CO3/H2O2/TMB reaction system for colorimetric determination of H2O2 and glucose. *Sens. Actuators B Chem.* **2016**, *231*, 714–722. [\[CrossRef\]](http://dx.doi.org/10.1016/j.snb.2016.03.087)

- <span id="page-12-0"></span>3. Sun, L.; Ding, Y.; Jiang, Y.; Liu, Q. Montmorillonite-loaded ceria nanocomposites with superior peroxidase-like activity for rapid colorimetric detection of H2O2 . *Sens. Actuators B Chem.* **2017**, *239*, 848–856. [\[CrossRef\]](http://dx.doi.org/10.1016/j.snb.2016.08.094)
- <span id="page-12-1"></span>4. Zhang, Y.T.; Bai, S.J. An Improved Method for Determination of Trace Hydrogen Peroxide in Water. *J. Environ. Health* **2006**, *23*, 258–261.
- <span id="page-12-2"></span>5. Sun, J.; Li, C.; Qi, Y.; Guo, S.; Liang, X. Optimizing Colorimetric Assay Based on V2O5 Nanozymes for Sensitive Detection of H2O2 and Glucose. *Sensors* **2016**, *16*, 584. [\[CrossRef\]](http://dx.doi.org/10.3390/s16040584) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/27110794)
- <span id="page-12-3"></span>6. Chen, Y.H. Determination of Peroxides in Food Samples by High Performance Liquid Chromatography with Variable Wavelength Detector. *Chin. J. Spectrosc. Lab.* **2009**, *26*, 414–417.
- <span id="page-12-4"></span>7. Nasir, M.; Nawaz, M.H.; Latif, U.; Yaqub, M.; Hayat, A.; Rahim, A. An overview on enzyme-mimicking nanomaterials for use in electrochemical and optical assays. *Microchim. Acta* **2016**. [\[CrossRef\]](http://dx.doi.org/10.1007/s00604-016-2036-8)
- <span id="page-12-5"></span>8. Sheng, Y.; Yang, H.; Wang, Y.; Han, L.; Zhao, Y.; Fan, A. Silver nanoclusters-catalyzed luminol chemiluminescence for hydrogen peroxide and uric acid detection. *Talanta* **2017**, *166*, 268–274. [\[CrossRef\]](http://dx.doi.org/10.1016/j.talanta.2017.01.066)
- <span id="page-12-6"></span>9. Han, L.; Zhang, H.; Chen, D.; Li, F. Protein-Directed Metal Oxide Nanoflakes with Tandem Enzyme-Like Characteristics: Colorimetric Glucose Sensing Based on One-Pot Enzyme-Free Cascade Catalysis. *Adv. Funct. Mater.* **2018**, *28*, 1800018. [\[CrossRef\]](http://dx.doi.org/10.1002/adfm.201800018)
- <span id="page-12-7"></span>10. Zhao, K.; Gu, W.; Zheng, S.; Zhang, C.; Xian, Y. SDS–MoS2 nanoparticles as highly-efficient peroxidase mimetics for colorimetric detection of H2O2 and glucose. *Talanta* **2015**, *141*, 47–52. [\[CrossRef\]](http://dx.doi.org/10.1016/j.talanta.2015.03.055)
- <span id="page-12-8"></span>11. Gao, L.; Zhuang, J.; Nie, L.; Zhang, J.; Zhang, Y.; Gu, N.; Wang, T.; Feng, J.; Yang, D.; Perrett, S. Intrinsic peroxidase-like activity of ferromagnetic nanoparticles. *Nat. Nanotechnol.* **2007**, *2*, 577–583. [\[CrossRef\]](http://dx.doi.org/10.1038/nnano.2007.260) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/18654371)
- <span id="page-12-9"></span>12. Asati, A.; Santra, S.; Kaittanis, C.; Nath, S.; Perez, J.M. Oxidase-like activity of polymer-coated cerium oxide nanoparticles. *Angew. Chem.* **2009**, *48*, 2308–2312. [\[CrossRef\]](http://dx.doi.org/10.1002/anie.200805279) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/19130532)
- <span id="page-12-10"></span>13. Liu, Q.; Yang, Y.; Li, H.; Zhu, R.; Shao, Q.; Yang, S.; Xu, J. NiO nanoparticles modified with 5,10,15,20-tetrakis(4-carboxyl pheyl)-porphyrin: Promising peroxidase mimetics for H2O2 and glucose detection. *Biosens. Bioelectron.* **2015**, *64*, 147–153. [\[CrossRef\]](http://dx.doi.org/10.1016/j.bios.2014.08.062) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/25212068)
- <span id="page-12-11"></span>14. Liu, J.; Meng, L.; Fei, Z.; Dyson, P.J.; Jing, X.; Liu, X. MnO2 nanosheets as an artificial enzyme to mimic oxidase for rapid and sensitive detection of glutathione. *Biosens. Bioelectron.* **2017**, *90*, 69–74. [\[CrossRef\]](http://dx.doi.org/10.1016/j.bios.2016.11.046) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/27886603)
- <span id="page-12-12"></span>15. Ning, L.Y.; Guan, X.L.; Ma, J.W.; Wang, M.; Fan, X.B.; Zhang, G.L.; Zhang, F.B.; Peng, W.C.; Li, Y. A highly sensitive nonenzymatic H2O2 sensor based on platinum, ZnFe2O4 functionalized reduced graphene oxide. *J. Alloy. Compd.* **2018**, *738*, 317–322. [\[CrossRef\]](http://dx.doi.org/10.1016/j.jallcom.2017.12.161)
- <span id="page-12-13"></span>16. Yang, X.; Ouyang, Y.J.; Wu, F.; Hu, Y.J.; Zhang, H.F.; Wu, Z.Y. In situ controlled preparation of platinum nanoparticles dopping into graphene sheets@cerium oxide nanocomposites sensitized screen printed electrode for nonenzymatic electrochemical sensing of hydrogen peroxide. *J. Electroanal. Chem.* **2016**, *777*, 85–91. [\[CrossRef\]](http://dx.doi.org/10.1016/j.jelechem.2016.08.008)
- <span id="page-12-14"></span>17. Khan, M.E.; Khan, M.M.; Cho, M.H. Defected graphene nano-platelets for enhanced hydrophilic nature and visible light-induced photoelectrochemical performances. *J. Phys. Chem. Solids* **2017**, *104*, 233–242. [\[CrossRef\]](http://dx.doi.org/10.1016/j.jpcs.2017.01.027)
- <span id="page-12-15"></span>18. Lievonen, M.; Valle-Delgado, J.J.; Mattinen, M.L.; Hult, E.L.; Lintinen, K.; Kostiainen, M.A.; Paananen, A.; Szilvay, G.R.; Setälä, H.; Österberg, M. Simple process for lignin nanoparticle preparation. *Green Chem.* **2016**, *18*, 1416–1422. [\[CrossRef\]](http://dx.doi.org/10.1039/C5GC01436K)
- <span id="page-12-16"></span>19. Ragauskas, A.J.; Beckham, G.T.; Biddy, M.J.; Chandra, R.; Chen, F.; Davis, M.F.; Davison, B.H.; Dixon, R.A.; Gilna, P.; Keller, M. Lignin valorization: Improving lignin processing in the biorefinery. *Science* **2014**, *344*, 1246843. [\[CrossRef\]](http://dx.doi.org/10.1126/science.1246843)
- <span id="page-12-17"></span>20. Hilgers, R.; Vincken, J.-P.; Gruppen, H.; Kabel, M.A. Laccase/Mediator Systems: Their Reactivity toward Phenolic Lignin Structures. *ACS Sustain. Chem. Eng.* **2018**, *6*, 2037–2046. [\[CrossRef\]](http://dx.doi.org/10.1021/acssuschemeng.7b03451)
- <span id="page-12-18"></span>21. Zhang, H.; Bai, Y.; Zhou, W.; Chen, F. Color reduction of sulfonated eucalyptus kraft lignin. *Int. J. Biol. Macromol.* **2017**, *97*, 201–208. [\[CrossRef\]](http://dx.doi.org/10.1016/j.ijbiomac.2017.01.031) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/28082224)
- <span id="page-12-19"></span>22. Chang, Q.; Deng, K.; Zhu, L.; Jiang, G.; Yu, C.; Tang, H. Determination of hydrogen peroxide with the aid of peroxidase-like Fe3O4 magnetic nanoparticles as the catalyst. *Microchim. Acta* **2009**, *165*, 299. [\[CrossRef\]](http://dx.doi.org/10.1007/s00604-008-0133-z)
- <span id="page-12-20"></span>23. Jiang, B.; Duan, D.; Gao, L.; Zhou, M.; Fan, K.; Tang, Y.; Xi, J.; Bi, Y.; Tong, Z.; Gao, G.F.; et al. Standardized assays for determining the catalytic activity and kinetics of peroxidase-like nanozymes. *Nat. Protoc.* **2018**, *13*, 1506–1520. [\[CrossRef\]](http://dx.doi.org/10.1038/s41596-018-0001-1)

- <span id="page-13-0"></span>24. Zhu, M.; Dai, Y.; Wu, Y.; Liu, K.; Qi, X.; Sun, Y. Bandgap control of alpha-Fe2O3 nanozymes and their superior visible light promoted peroxidase-like catalytic activity. *Nanotechnology* **2018**, *29*, 465704. [\[CrossRef\]](http://dx.doi.org/10.1088/1361-6528/aaddc2) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/30160242)
- <span id="page-13-1"></span>25. Ding, Y.; Yang, B.; Liu, H.; Liu, Z.; Zhang, X.; Zheng, X.; Liu, Q. FePt-Au ternary metallic nanoparticles with the enhanced peroxidase-like activity for ultrafast colorimetric detection of H2O2 . *Sens. Actuators B Chem.* **2018**, *259*, 775–783. [\[CrossRef\]](http://dx.doi.org/10.1016/j.snb.2017.12.115)
- <span id="page-13-2"></span>26. Liu, Q.; Zhang, L.; Li, H.; Jia, Q.; Jiang, Y.; Yang, Y.; Zhu, R. One-pot synthesis of porphyrin functionalized γ-Fe2O3 nanocomposites as peroxidase mimics for H2O2 and glucose detection. *Mater. Sci. Eng. C* **2015**, *55*, 193–200. [\[CrossRef\]](http://dx.doi.org/10.1016/j.msec.2015.05.028) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/26117755)
- <span id="page-13-3"></span>27. Chen, Y.; Xianyu, Y.; Dong, M.; Zhang, J.; Zheng, W.; Qian, Z.; Jiang, X. Cascade Reaction-Mediated Assembly of Magnetic/Silver Nanoparticles for Amplified Magnetic Biosensing. *Anal. Chem.* **2018**, *90*, 6906–6912. [\[CrossRef\]](http://dx.doi.org/10.1021/acs.analchem.8b01138)
- <span id="page-13-4"></span>28. Zhao, W.; Xiao, L.P.; Song, G.; Sun, R.C.; He, L.; Singh, S.; Simmons, B.A.; Cheng, G. From lignin subunits to aggregates: Insights into lignin solubilization. *Green Chem.* **2017**, *19*, 3272–3281. [\[CrossRef\]](http://dx.doi.org/10.1039/C7GC00944E)
- <span id="page-13-5"></span>29. Xiong, F.; Han, Y.; Wang, S.; Li, G.; Qin, T.; Chen, Y.; Chu, F. Preparation and Formation Mechanism of Renewable Lignin Hollow Nanospheres with a Single Hole by Self-Assembly. *Acs Sustain. Chem. Eng.* **2017**, *5*, 2273–2281. [\[CrossRef\]](http://dx.doi.org/10.1021/acssuschemeng.6b02585)
- <span id="page-13-6"></span>30. Destrée, C.; Nagy, J.B. Mechanism of formation of inorganic and organic nanoparticles from microemulsions. *Adv. Colloid Interface Sci.* **2006**, *123–126*, 353–367.
- <span id="page-13-7"></span>31. Ishikawa, Y.; Katoh, Y.; Ohshima, H. Colloidal stability of aqueous polymeric dispersions: Effect of pH and salt concentration. *Colloids Surf. B-Biointerfaces* **2005**, *42*, 53–58. [\[CrossRef\]](http://dx.doi.org/10.1016/j.colsurfb.2005.01.006) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/15784326)
- <span id="page-13-8"></span>32. Liu, H.; Jiao, M.; Gu, C.; Zhang, M. Au@CuxOS yolk-shell nanomaterials with porous shells act as a new peroxidase mimic for the colorimetric detection of H2O2 . *J. Alloy. Compd.* **2017**, *741*, 197–204. [\[CrossRef\]](http://dx.doi.org/10.1016/j.jallcom.2017.12.354)
- <span id="page-13-9"></span>33. Wang, H.; Jiang, H.; Wang, S.; Shi, W.; He, J.; Liu, H.; Huang, Y. Fe3O4–MWCNT magnetic nanocomposites as efficient peroxidase mimic catalysts in a Fenton-like reaction for water purification without pH limitation. *RSC Adv.* **2014**, *4*, 45809–45815. [\[CrossRef\]](http://dx.doi.org/10.1039/C4RA07327D)
- <span id="page-13-10"></span>34. Jiang, J.; He, C.; Wang, S.; Jiang, H.; Li, J.; Li, L. Recyclable ferromagnetic chitosan nanozyme for decomposing phenol. *Carbohydr. Polym.* **2018**, *198*, 348–353. [\[CrossRef\]](http://dx.doi.org/10.1016/j.carbpol.2018.06.068) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/30093010)
- <span id="page-13-11"></span>35. Ding, Y.; Fan, F.R.; Tian, Z.Q.; Wang, Z.L. Sublimation-Induced Shape Evolution of Silver Cubes. *Small* **2009**, *5*, 2812–2815. [\[CrossRef\]](http://dx.doi.org/10.1002/smll.200901189) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/19882686)
- <span id="page-13-12"></span>36. Liu, Q.Y.; Li, H.; Zhao, Q.R.; Zhu, R.R.; Yang, Y.T.; Jia, Q.Y.; Bian, B.; Zhuo, L.H. Glucose-sensitive colorimetric sensor based on peroxidase mimics activity of porphyrin-Fe(3)O(4) nanocomposites. *Mater. Sci. Eng. C-Mater. Biol. Appl.* **2014**, *41*, 142–151. [\[CrossRef\]](http://dx.doi.org/10.1016/j.msec.2014.04.038) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/24907747)
- <span id="page-13-14"></span>37. Fan, K.; Wang, H.; Xi, J.; Liu, Q.; Meng, X.; Duan, D.; Gao, L.; Yan, X. Optimization of Fe3O4 nanozyme activity via single amino acid modification mimicking an enzyme active site. *Chem. Commun.* **2016**, *53*, 424–427. [\[CrossRef\]](http://dx.doi.org/10.1039/c6cc08542c)
- <span id="page-13-15"></span>38. Chen, S.; Chi, M.; Yang, Z.; Gao, M.; Wang, C.; Lu, X. Carbon dots/Fe3O4 hybrid nanofibers as efficient peroxidase mimics for sensitive detection of H2O2 and ascorbic acid. *Inorg. Chem. Front.* **2017**, *4*, 1621–1627. [\[CrossRef\]](http://dx.doi.org/10.1039/C7QI00308K)
- <span id="page-13-13"></span>39. Hui, W.; Erkang, W. Fe3O4 magnetic nanoparticles as peroxidase mimetics and their applications in H2O2 and glucose detection. *Anal. Chem.* **2008**, *80*, 2250–2254. [\[CrossRef\]](http://dx.doi.org/10.1021/ac702203f)
- <span id="page-13-16"></span>40. Song, L.; Huang, C.; Zhang, W.; Ma, M.; Chen, Z.; Gu, N.; Zhang, Y. Graphene oxide-based Fe2O3 hybrid enzyme mimetic with enhanced peroxidase and catalase-like activities. *Colloids Surf. A Physicochem. Eng. Asp.* **2016**, *506*, 747–755. [\[CrossRef\]](http://dx.doi.org/10.1016/j.colsurfa.2016.07.037)

<DESCRIPTION_FROM_IMAGE>This image depicts a Creative Commons license icon. It consists of two circular symbols side by side on a dark background:

1. The left circle contains the letters "CC" which stands for Creative Commons.

2. The right circle contains a stylized human figure icon.

Below these symbols is the text "BY" in capital letters.

This represents the Creative Commons Attribution license (CC BY), which allows others to distribute, remix, adapt, and build upon the work, even commercially, as long as they credit the original creator.

While this image is related to licensing and attribution rather than chemistry specifically, it provides important context about how scientific content may be shared and reused. The CC BY license is commonly used for open access scientific publications and datasets.</DESCRIPTION_FROM_IMAGE>

© 2019 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license [(http://creativecommons.org/licenses/by/4.0/)](http://creativecommons.org/licenses/by/4.0/.).