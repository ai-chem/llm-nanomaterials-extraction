The image shows a graph of infrared spectroscopy data for various nitrogen-containing compounds. The x-axis represents the wavenumber in cm^-1, ranging from 2000 to 400. The y-axis shows the percent transmittance (%T), ranging from approximately 25% to 55%.

The graph contains multiple overlapping spectral lines, each representing a different nitrogen compound:

1. Nnat (likely natural nitrogen)
2. NPEI (possibly polyethyleneimine)
3. NCMI (unspecified compound)
4. Nhep (possibly heparin)
5. NPLL (possibly poly-L-lysine)
6. Ngly (possibly glycine)
7. Ncit (possibly citrate)

Each spectral line shows characteristic absorption bands (dips in the transmittance) at various wavenumbers, indicating the presence of specific functional groups in the molecules.

Notable features include:
1. A broad absorption band for all compounds around 3400-3200 cm^-1 (not fully shown in the graph), likely corresponding to N-H or O-H stretching vibrations.
2. Sharp absorption peaks around 1600-1500 cm^-1, possibly indicating C=O stretching or N-H bending vibrations.
3. A specific absorption peak at 1402 cm^-1 is labeled on the graph, which could be attributed to C-H bending or C-N stretching vibrations.
4. Multiple absorption bands in the fingerprint region (1500-400 cm^-1) that are unique to each compound.
5. A strong absorption band for all compounds around 1100-1000 cm^-1, which could be due to C-O or C-N stretching vibrations.

The graph allows for comparison of the spectral features of these nitrogen-containing compounds, highlighting their structural similarities and differences based on their infrared absorption patterns.