Biomaterials 30 (2009) 4716–4722

Contents lists available at [ScienceDirect](www.sciencedirect.com/science/journal/01429612)

# Biomaterials

journal homepage: [www.elsevier.com/locate/biomaterials](http://www.elsevier.com/locate/biomaterials)

# The artificial peroxidase activity of magnetic iron oxide nanoparticles and its application to glucose detection

Faquan Yu a,c , Yongzhuo Huang a,b , Adam J. Cole a , Victor C. Yang a,b,*

aDepartment of Pharmaceutical Sciences, College of Pharmacy, University of Michigan, Ann Arbor, MI 48109, USA b Tianjin Key Laboratory of Modern Drug Delivery and High Efficiency, Tianjin University, Tianjin 300072, China c Key Laboratory for Green Chemical Process of Ministry of Education, Wuhan Institute of Technology, Wuhan 430073, China

# article info

Article history: Received 17 February 2009 Accepted 10 May 2009 Available online 9 June 2009

Keywords: Superparamagnetic nanoparticle Iron oxide Peroxidase Glucose detection

# abstract

Aside from their superparamagnetic properties exploited in clinical magnetic resonance imaging (MRI), it was recently discovered that magnetic, iron oxide nanoparticles could function as an artificial, inorganic peroxidase. In this paper, we studied the impact of coating on the peroxidase activity of these nanoparticles. Nanoparticles with six different coating structures were synthesized and characterized by FTIR, TGA, TEM, size, zeta potential, and SQUID; and evaluated for peroxidase activity. Catalysis was found to follow Michaelis–Menten kinetics and peroxidase activity varied with respect to electrostatic affinity between nanoparticles and substrates, evidenced by differences in determined kinetic parameters. Glucose detection was selected as a model system because glucose could be indirectly measured from the release of hydrogen peroxide after its oxidation. Nanoparticles with high peroxidase activity exhibited higher sensitivity toward glucose, showing a larger linear slope when compared with those of low activity. A significantly improved linear correlation and detection limit of measured glucose could be readily obtained by manipulating the nanoparticle coating. Our findings suggest that iron oxide nanoparticles can be tailor-made to possess improved peroxidase-like activity. Such enhancements could further widen nanoparticle scope in glucose detection and extend its peroxidase functionality to other biomedical applications.

> -2009 Elsevier Ltd. All rights reserved.

# 1. Introduction

Magnetic, iron oxide nanoparticles have found in-roads to numerous biomedical applications including magnetic resonance imaging (MRI) [\[1\];](#page-6-0) magnetic targeting and drug delivery [\[2\];](#page-6-0) protein isolation and purification [\[3\];](#page-6-0) and magnetic hyperthermia [\[4\].](#page-6-0) Recently, it was also reported that iron oxide nanoparticles could function like an artificial peroxidase [\[5\],](#page-6-0) a finding of great significance. Compared to naturally occurring peroxidase enzymes, nanoparticles are considerably more stable and possess an almost unchanged catalytic activity over a wide range of temperature and pH [\[5\].](#page-6-0) Peroxidase enzymes, prone to proteolytic degradation, are difficult to produce in large quantities. In contrast, iron oxide nanoparticles can be readily synthesized in mass yield (via chemical means) and at relatively low cost.

In light of such advantages, nanoparticles could potentially replace peroxidases in various applications, including those dependent on the detection of hydrogen peroxide. For instance,

E-mail address: [vcyang@umich.edu](mailto:vcyang@umich.edu) (V.C. Yang).

glucose can be monitored indirectly by of the release of hydrogen peroxide following its oxidation by glucose oxidase (GOx) [\[6,7\].](#page-6-0) Immunoenzyme assays [\[8,9\]](#page-6-0) are also primarily based on the detection of hydrogen peroxide [\[10,11\].](#page-6-0) Peroxidase catalyzes oxidation of certain substrates to produce characteristic color in the presence of hydrogen peroxide. Such chromogenic reactions have become a powerful tool in analytical detection.

The catalytic power of iron oxide nanoparticles, however, has not been thoroughly explored. Peroxidase-like activity dictates detection sensitivity and, thus, the practical applicability of nanoparticles to function like an enzyme. Clearly, nanoparticles would have little use if activity were too low. When considering factors that might contribute to activity, several questions arise: a) does the structure (e.g. coating, iron oxide content) of the nanoparticle influence its activity? b) is activity related to the structure of substrates? and c) is activity affected by sodium azide, an inhibitor of horseradish peroxidase (HRP) and common preservative used in the storage of biological reagents?

It was reported that peroxidase activity stems from superficial ferrous atoms of nanoparticles [\[5\].](#page-6-0) Unfortunately, little improvement in surface ferrous content can be made once nanoparticles are synthesized. Activity, however, might be improved by optimizing affinity toward substrate. A nanoparticle must first form an

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be the logo of Elsevier, a major academic publishing company. While it contains an artistic depiction of a tree and human figures, it does not convey specific scientific or chemical information relevant to the context of applied chemistry or scientific research. Therefore, a detailed scientific analysis is not applicable for this particular image.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image appears to be the cover of a scientific journal titled "Biomaterials". The background of the cover features a blurred, circular pattern that resembles a molecular or cellular structure, which is appropriate given the journal's focus on materials used in biological and medical applications. 

The journal title "Biomaterials" is prominently displayed in large text at the top of the cover. In the upper left corner, there is a small logo that likely represents the publisher of the journal, which appears to be Elsevier based on the recognizable tree-like symbol.

This cover image serves to visually represent the journal's subject matter, combining text and a scientific-looking background image to convey the focus on biomaterials research. However, as this is a journal cover rather than a specific scientific diagram or chemical structure, I cannot provide SMILES notation or detailed graph analysis for this particular image.</DESCRIPTION_FROM_IMAGE>

<sup>*</sup> Corresponding author. Albert B. Prescott Professor of Pharmaceutical Sciences, College of Pharmacy, University of Michigan, 428 Church Street, MI 48109-1065, USA. Tel.: þ1 734 764 4273; fax: þ1 734 763 9772.

<sup>0142-9612/\$ –</sup> see front matter - 2009 Elsevier Ltd. All rights reserved. doi:10.1016/j.biomaterials.2009.05.005

intermediate complex with its substrate before catalysis can occur. Therefore, a higher affinity to its substrate could lead to a higher catalytic activity.

Affinity may be improved by enhancing electrostatic interaction between substrate and the nanoparticle surface. Two substrates that would be useful to evaluate this hypothesis are 2,20 -azinobis(3-ethylbenzthiazoline-6-sulfonic acid) diammonium salt (ABTS) and 3,30 ,5,5'-tetramethylbenzidine (TMB). Both substrates undergo distinguishable color change when enzymatically oxidized with hydrogen peroxide. TMB carries two amine groups, likely yielding stronger affinity toward a negatively charged nanoparticle surface. Conversely, ABTS possesses two sulfonic acid groups, likely exhibiting higher affinity toward a positively charged nanoparticle surface. Therefore, modification of the nanoparticle surface with different charge and charge intensity could enhance (or hinder) observed activity. Modifying nanoparticles with different coatings is one way to alter surface charge.

This work evaluated the impact of surface charge, charge intensity, and coating thickness on the ability of an iron oxide nanoparticle to function as an artificial peroxidase. Our aim was to develop a strategy to synthesize nanoparticles with improved activity and yield higher sensitivity in various biomedical applications. As a model, hydrogen peroxide produced from oxidation of glucose by GOx was measured to indirectly measure glucose.

#### 2. Materials and methods

#### 2.1. Chemicals and reagents

All materials were purchased and used as received without further treatment. Materials used include sodium citrate dihydrate (Fisher Scientific), ferrous chloride tetrahydrate (Fluka), iron chloride hexahydrate (Sigma–Aldrich), carboxymethyl dextran (CMD, 14,400 Da, Fluka), polylysine (PLL, 4000–15,000 Da, Sigma–Aldrich), poly(ethyleneimine) (PEI, 10,000 Da, Polysciences, Inc), heparin (Sigma), 3,30 ,5,50 tetramethylbenzidine, (TMB, KPL), 2,20 -azino-bis(3-ethylbenzthiazoline-6-sulfonic acid) diammonium salt (ABTS, BioChemika) ([http://en.wikipedia.org/wiki/IUPAC_](http://en.wikipedia.org/wiki/IUPAC_nomenclature) [nomenclature](http://en.wikipedia.org/wiki/IUPAC_nomenclature)), hydrogen peroxide (Sigma–Aldrich), b-D-glucose (TCI America), glucose oxidase (GOx, from Aspergillus niger, Sigma), and horseradish peroxidase(HRP, Sigma–Aldrich).

#### 2.2. Preparation of iron oxide nanoparticles

#### 2.2.1. Unmodified iron oxide nanoparticles (Nnat)

Iron oxide nanoparticles were synthesized according to a modified procedure by Kim et al. [\[12\]](#page-6-0). Briefly, a solution containing 0.76 mol/L of ferric chloride and 0.4 mol/ L of ferrous chloride (molar ratio of ferric to ferrous was approximately 2:1) was prepared in pH 1.7 water under nitrogen protection. The iron solution was then added drop-wise to 1.5 mol/L NaOH under vigorous mechanical stirring. This reaction mixture was gradually heated (1 -C/min) to 78 -C and held at this temperature for 1 h under stirring and nitrogen protection. After separation of the supernatant with a permanent magnet, the wet solid was treated with 0.01 mol/L HCl and then sonicated for 1 h. The acidified suspension was filtered through 0.45 mm and 0.22 mm membranes. Concentration was then adjusted to 0.7 mg Fe/mL.

#### 2.2.2. Citrate- and glycine-modified iron oxide nanoparticles (Ncit, Ngly)

To 200 mL of 1 mg/mL sodium citrate, 200 mL of 0.7 mg Fe/mL iron oxide nanoparticles were added under stirring. The mixture was sonicated for 20 min and then further stirred for 2 hours. After ultrafiltration to remove free sodium citrate, the concentration was adjusted to 0.35 mg Fe/mL. An analogous procedure was used to obtain glycine-modified nanoparticles (Ngly).

### 2.2.3. Polylysine- and poly(ethyleneimine)-coated iron oxide nanoparticles (NPLL, NPEI)

To 100 mL of 1 mg/mL PLL solution, 100 mL of 0.35 mg Fe/mL Ncit were added under stirring. The mixture was sonicated for 20 min and then further stirred for 2 h. The NPLL product was obtained by removing free PLL via ultrafiltration. An analogous procedure was used to obtain PEI-modified nanoparticles (NPEI).

### 2.2.4. Carboxymethyl dextran- and heparin-coated iron oxide nanoparticles (NCMD, Nhep)

To 100 mL of 1 mg/mL CMD solution, 100 mL of 0.35 mg Fe/mL Ngly were added under stirring. The mixture was sonicated for 20 min and then further stirred for 2 h. The NCMD product was obtained by removing free CMD via ultrafiltration. An analogous procedure was used to obtain heparin-modified nanoparticles (Nhep).

#### 2.3. Characterization of synthesized iron oxide nanoparticles

Particle size and zeta potential were measured on a NICOMP 380 ZLS dynamic light scattering (DLS) instrument (PSS, Santa Barbara, CA, USA) equipped with a HeNe laser at 632 nm as the incident light. For size measurements, a volumeweighted distribution was obtained. Zeta potential measurements were taken after nanoparticles were diluted and dispersed with deionized water. High-resolution transmission electron microscopy (HRTEM) was conducted using a JEOL 3011 highresolution electron microscope (JEOL Tokyo, Japan) operated at an accelerated voltage of 300 kV. Samples were prepared by applying diluted particle suspensions to formvar film-coated copper grids (01813-F, Ted Pella, Inc, USA) followed by drying preparations at room temperature. A thermogravimetric analyzer (TGA; TA Instruments Q50, New Castle, DE, USA) calibrated with nickel and alumel standards was employed to determine coating content of nanoparticles. Samples were analyzed in a nitrogen atmosphere with a heating rate of 20 -C/min. Superparamagnetic properties were assessed at 25 -C using a superconducting quantum interference device (SQUID) (Quantum Design Inc., San Diego, CA, USA). Iron content of nanoparticles was measured by inductively coupled plasma-optical emission spectroscopy (ICP-OES) on an Optima 2000 DV instrument (Perkin–Elmer, Inc., Boston, MA, USA). Samples were spiked with yttrium internal standard and calibrated with water dilutions of an iron standard (GFS Chemicals, Columbus, OH). FTIR was performed on lyophilized samples after compression into w1 mm thick discs containing spectroscopic grade potassium bromide.

#### 2.4. Measurement of peroxidase-like activity

In triplicate, 100 mL of 530 mmol/L hydrogen peroxide containing varied concentrations of chromogenic substrate (TMB or ABTS) were added to 50 mL of the different prepared nanoparticles (0.35 mg Fe/mL). The blue (TMB) or green (ABTS) color that developed as reactions proceeded was monitored kinetically at room temperature using a PowerWave X340 spectrophotometer (BioTek, Winooski, VT). TMB conversion was measured at 655 nm and ABTS at 415 nm. Catalytic parameters were determined by fitting the absorbance data to the Michaelis–Menten equation. Activity was also evaluated in the presence of varied concentrations (0–0.08 wt%) of sodium azide. HRP was also tested for comparison purposes.

#### 2.5. Glucose detection

40 mL of 10 mg/mL GOx were added to 200 mL of glucose at varied concentrations in 10 mmol/L phosphate buffered saline (PBS, pH 7.4) and incubated at 37 -C for 30 min. 360 mL of 4.0 mmol/L ABTS and 400 mL of 0.13 mg Fe/mL nanoparticles (both in 0.2 mol/L acetate buffer, pH 4.0) were then added to the oxidized glucose solution above and incubated at 45 -C for 45 min. The reaction mixture was then subject to centrifugation at 15,000 rpm for 10 min to remove nanoparticulate material. 300 mL of the supernatant were analyzed at 417 nm to determine ABTS conversion. Control experiments were conducted using blank (no glucose) PBS.

# 3. Results

# 3.1. Synthesis and characterization of iron oxide nanoparticles

FTIR spectra of Ncit and Ngly show a peak at 1402 cm1 , which was not found on the spectra of Nnat [(Fig. 1](#page-2-0)). This peak was assigned to the Fe–O–C(O) linkage [\[13\]](#page-6-0), indicating chemical adsorption of citrate/glycine carboxylate groups onto superficial iron atoms found on the nanoparticle surface. Unbound carboxylate groups render Ncit negatively charged, whereas unbound amine groups result in a positively charged Ngly. Taking advantage of these surface charges, NPLL and NPEI were prepared by electrostatic coating of Ncit with positively charged PLL or PEI, respectively. Analogously, NCMD and Nhep were synthesized by coating Ngly with negatively charged CMD or heparin. Zeta potential results shown in [Table 1](#page-2-0) show that iron oxide nanoparticles with different coatings – three anionic (Ncit, NCMD, Nhep) and three cationic (Ngly, NPLL, NPEI) – were successfully synthesized. Nhep yielded the highest negative zeta potential of 51.2 mV whereas NPEI showed the highest positive zeta potential of þ47.1 mV.

Size measurements by DLS showed that all synthesized nanoparticles possessed similar diameters in the range of 35–46 nm (shown in [Table 1](#page-2-0)), indicating that size would not be a confounding variable in subsequent experiments. Moreover, the relative thickness of coating can be determined by weight loss estimated in a TGA analysis. TGA analyses of NPLL, NCMD, NPEI, and Nhep show

<DESCRIPTION_FROM_IMAGE>The image shows a graph of infrared spectroscopy data for various nitrogen-containing compounds. The x-axis represents the wavenumber in cm^-1, ranging from 2000 to 400. The y-axis shows the percent transmittance (%T), ranging from approximately 25% to 55%.

The graph contains multiple overlapping spectral lines, each representing a different nitrogen compound:

1. Nnat (likely natural nitrogen)
2. NPEI (possibly polyethyleneimine)
3. NCMI (unspecified compound)
4. Nhep (possibly heparin)
5. NPLL (possibly poly-L-lysine)
6. Ngly (possibly glycine)
7. Ncit (possibly citrate)

Each spectral line shows characteristic absorption bands (dips in the transmittance) at various wavenumbers, indicating the presence of specific functional groups in the molecules.

Notable features include:
1. A broad absorption band for all compounds around 3400-3200 cm^-1 (not fully shown in the graph), likely corresponding to N-H or O-H stretching vibrations.
2. Sharp absorption peaks around 1600-1500 cm^-1, possibly indicating C=O stretching or N-H bending vibrations.
3. A specific absorption peak at 1402 cm^-1 is labeled on the graph, which could be attributed to C-H bending or C-N stretching vibrations.
4. Multiple absorption bands in the fingerprint region (1500-400 cm^-1) that are unique to each compound.
5. A strong absorption band for all compounds around 1100-1000 cm^-1, which could be due to C-O or C-N stretching vibrations.

The graph allows for comparison of the spectral features of these nitrogen-containing compounds, highlighting their structural similarities and differences based on their infrared absorption patterns.</DESCRIPTION_FROM_IMAGE>

Fig. 1. FTIR spectra of the synthesized nanoparticles. FTIR spectra of both Ncit and Ngly showed a new peak at 1402 cm1 , which corresponds to symmetric stretching of Fe– O–C(O) bonds. This band confirms successful coating. As a comparison, Nnat (no coating) showed no such peak.

relatively high weight losses (see Table 1 and Fig. 2), corresponding to thicker coatings. Conversely, TGA revealed a relatively low weight loss for Ncit and Ngly (and thinner coating) due to the size of the small molecules, glycine and citrate. Additionally, HRTEM images in [Fig. 3](#page-3-0) provide visual confirmation that polymer coating of the nanoparticles was successfully achieved. All tested nanoparticles were found to exhibit superparamagnetic behavior (i.e. no hysteresis in demagnetization curves) when examined by SQUID [(Fig. 4](#page-3-0)), rendering them suitable for magnetic-mediated, biomedical applications. Coating processes did not appear to alter the magnetic properties of these nanoparticles. Overall, findings consistently support the notion that desired nanoparticles were obtained as designed. In addition, our surface modification procedures for nanoparticles were much simpler than methods described in the literature [\[14\]](#page-6-0). Processes were also highly consistent and reproducible. More importantly, no aggregation of nanoparticles was observed for any of the coating processes, and the recovery yield was almost 100%.

# 3.2. Surface charge dependence on peroxidase activity

The peroxidase-like behavior of the synthesized nanoparticles was examined at room temperature using either TMB or ABTS as a chromogenic substrate. Absorbance data were back-calculated to concentration by the Beer–Lambert Law using a molar absorption coefficient of 39000 M1 cm1 for TMB-derived [\[15\]](#page-6-0) or 36000 Ml cm1 for ABTS-derived [\[16\]](#page-6-0) oxidation products. Apparent steadystate reaction rates at different concentrations of substrate were obtained by calculating the slopes of initial absorbance changes with time. Data shown in [Fig. 5](#page-4-0) indicate that all nanoparticles displayed

#### Table 1

Properties of iron oxide nanoparticles with different coatings.

| Nanoparticle | Coating  | Size by DLS | Weight % of coating | Zeta potential |
|--------------|----------|-------------|---------------------|----------------|
|              | material | (nm)        | shell by TGA        | (mV)           |
| Ncit         | Citrate  | 34.4        | 2.0                 | 22.7           |
| NCMD         | CMD      | 42.1        | 12.1                | 23.8           |
| Nhep         | Heparin  | 40.6        | 13.5                | 51.2           |
| Ngly         | Glycine  | 40.1        | 1.6                 | þ25.0          |
| NPLL         | PLL      | 46.2        | 10.5                | þ28.9          |
| NPEI         | PEI      | 43.7        | 18.7                | þ47.1          |

CMD: carboxymethyl dextran, PLL: polylysine, PEI: poly(ethyleneimine).

<DESCRIPTION_FROM_IMAGE>This image presents a thermogravimetric analysis (TGA) graph showing the weight loss of different materials as a function of temperature. The graph displays the weight remaining (%) on the y-axis, ranging from 80% to 100%, and the temperature (°C) on the x-axis, ranging from 50°C to 550°C.

The graph includes six different curves, each representing a different material:

1. Ngly (likely glycine-based nanoparticles)
2. Ncit (likely citrate-based nanoparticles)
3. NPLL (likely poly-L-lysine nanoparticles)
4. Nhep (likely heparin nanoparticles)
5. NCMC (likely carboxymethyl cellulose nanoparticles)
6. NPEI (likely polyethyleneimine nanoparticles)

Key observations from the graph:

1. All materials start at 100% weight at 50°C.
2. Ngly and Ncit show the highest thermal stability, with minimal weight loss up to 550°C.
3. NPLL, Nhep, and NCMC show similar degradation patterns, with significant weight loss starting around 250°C and stabilizing around 87-88% weight remaining at 550°C.
4. NPEI exhibits the most significant weight loss, starting around 200°C and continuing to decrease to about 81% weight remaining at 550°C.

The graph provides information on the thermal stability of these different nanoparticle systems, which is crucial for understanding their behavior under various temperature conditions and potential applications in fields such as drug delivery or materials science.</DESCRIPTION_FROM_IMAGE>

Fig. 2. TGA analyses of the synthesized nanoparticles. TGA of polymer-coated particles (NPLL, NCMD, Nhep, and NPEI) displayed a higher weight loss than small-molecule-coated particles (Ncit and Ngly). Heating rate was controlled at 20 -C/min in a nitrogen atmosphere. Higher weight losses suggest relatively thicker coatings.

hyperbolic kinetics, yet curve characteristics varied with the type of coating. Data were fit to the Michaelis–Menten equation (curves shown in [Fig. 5)](#page-4-0) and model parameters (Vmax and KM) extracted. The catalytic constant (kcat; Vmax normalized for enzyme content) was also calculated according to Equation (1):

$$k_{\text{cat}} = \mathcal{V}_{\text{max}} / [\mathbf{E}] \tag{1}$$

where [E] was taken as the nanoparticle iron concentration. Catalytic parameters for each of the nanoparticles tested are summarized in [Table 2](#page-4-0).

[Fig. 6](#page-5-0) illustrates the dependency of peroxidase activity on superficial charge. ABTS catalysis (curve A) increased rapidly with increasing zeta potential. In a less dramatic fashion, TMB catalysis (curve B) decreased with increasing zeta potential. Indeed, the nanoparticle with the strongest negative surface charge (Nhep) exhibited a 5.9-fold higher peroxidase activity than that with the most positive (NPEI) when TMB was the substrate. Conversely, NPEI displayed an 11.5-fold increase in catalytic activity over Nhep when ABTS was the substrate.

# 3.3. Coating thickness dependence on peroxidase activity

The effect of coating thickness on peroxidase activity was also studied. The pairs Ncit/NCMD and Ngly/NPLL served to meet this purpose. The pair Ncit/NCMD had similar negative surface charge (shown in Table 1), allowing for controlled comparison of the effect of coating thickness on activity. Ncit exhibited a higher kcat than NCMD with both TMB and ABTS substrates [(Table 2](#page-4-0)). Because NCMD has a thicker coating than Ncit, steric effects might account for its lower activity for both substrates. As expected, Ngly displayed a higher kcat than that of the similarly charged NPLL with TMB as the substrate. Interestingly, the kcat of Ngly was lower than that of NPLL with ABTS as the substrate. Although this finding appears contradictory to the observed trends for thickness, competition between thickness and charge effects might explain this discrepancy. NPLL did have a slightly higher positive zeta potential thanNgly. ABTS catalysis was favored by a higher positive surface charge [(Fig. 6](#page-5-0)). Hence, a slightly higher positive charge would have greater effect on activity than a thicker coating, as suggested by the steep curve (A) observed for ABTS in [Fig. 6](#page-5-0). It should be noted that neither NPEI nor Nhep was included in the above comparison because both nanoparticles exhibited distinct zeta potentials from other samples tested.

<DESCRIPTION_FROM_IMAGE>The image consists of three transmission electron microscopy (TEM) micrographs labeled A, B, and C, showing nanostructures at different magnifications.

A: This micrograph shows a wide-field view with a scale bar of 50 nm. It depicts a distribution of nanoparticles or nanoclusters scattered across the field. The particles appear as darker spots against a lighter background, with varying sizes and degrees of aggregation. Some particles are isolated while others form small clusters.

B: This image presents a higher magnification view with a scale bar of 5 nm. It reveals the detailed structure of the nanoparticles. The particles appear to have a crystalline structure, evidenced by the visible lattice fringes. The particles are not perfectly spherical but have slightly irregular shapes. The background shows a granular texture, which may be due to the supporting substrate or imaging artifacts.

C: The final micrograph, also at 5 nm scale, shows an even more detailed view of the nanoparticles. This image clearly demonstrates the crystalline nature of the particles, with well-defined lattice planes visible in several particles. One particle in particular, near the center of the image, shows a highly ordered atomic arrangement, indicating a single-crystalline structure. The surrounding particles appear to be in various orientations, some showing clear lattice fringes while others appear more amorphous.

These TEM images provide valuable information about the size, distribution, and crystalline structure of the nanoparticles under study. The progression from A to C allows for a comprehensive understanding of the material's morphology from the nanoscale distribution to the atomic-level structure.</DESCRIPTION_FROM_IMAGE>

Fig. 3. TEM images of (A) NPLL on a copper grid coated with a continuous formvar film at lower magnification. Nanoparticles are clearly well dispersed. (B) NPLL on a copper grid coated with a continuous formvar film at higher magnification. A shell-type coating can be observed on nanoparticles. The coating, however, is hard to see due to interference from the carbon film background; (C) NPLL on a copper grid coated with a lacey network support film to minimize background interference, yielding higher resolution. The image better demonstrates the core/shell structure of NPLL.

# 3.4. Effect of sodium azide on peroxidase activity

Experimental results with sodium azide are shown in [Fig. 7.](#page-5-0) The presence of sodium azide resulted in significantly greater loss of activity with HRP when compared to any of the evaluated nanoparticles. For instance, when sodium azide concentration increased to 0.02% (typical for bacteriostatic storage), HRP lost over 99% of its activity. In sharp contrast, tested nanoparticles retained at least 93% activity at the same concentration of sodium azide. In fact, nanoparticles remained relatively active even with a four-fold increase in sodium azide concentration (0.08%). As shown in [Fig. 7,](#page-5-0) between 54 and 82% of activity remained depending on the coating. Retained activity, even in the presence of high sodium azide concentration, further suggests that iron oxide nanoparticles are durable and might be useful in environments where peroxidases (like HRP) can significantly lose function.

<DESCRIPTION_FROM_IMAGE>The image presents a graph showing the relationship between induced magnetization (emu/g Fe) and applied magnetic field strength (G) for various nanoparticle samples. The x-axis represents the applied magnetic field strength ranging from 0 to 25000 G, while the y-axis shows the induced magnetization from 0 to 80 emu/g Fe.

The graph includes data for seven different nanoparticle samples, each represented by a different symbol and color:

1. N_nat (red diamond)
2. N_cit (light blue diamond)
3. N_CMD (purple triangle)
4. N_gly (blue square)
5. N_PLL (purple circle)
6. N_PEI (green circle)
7. N_hep (brown square)

All samples show a similar trend of increasing induced magnetization as the applied magnetic field strength increases. The curves demonstrate rapid initial growth at lower field strengths, followed by a more gradual increase and eventual plateau at higher field strengths.

The N_gly sample (blue squares) appears to reach the highest magnetization values, approaching 70 emu/g Fe at the maximum field strength. The N_PLL and N_PEI samples (purple and green circles) show very similar behavior, reaching slightly lower magnetization values than N_gly.

The N_hep sample (brown squares) follows a similar trend but with slightly lower magnetization values compared to N_gly, N_PLL, and N_PEI.

The N_CMD sample (purple triangles) shows lower magnetization values throughout the range of applied field strengths, reaching approximately 65 emu/g Fe at the maximum field strength.

The N_nat and N_cit samples (red and light blue diamonds) are only represented by single data points at the lowest field strength, both showing very low induced magnetization values close to 0 emu/g Fe.

This graph likely represents the magnetic behavior of various functionalized iron oxide nanoparticles, comparing their magnetization responses to an applied magnetic field. The different samples may represent nanoparticles with different surface modifications or preparation methods, which affect their magnetic properties.</DESCRIPTION_FROM_IMAGE>

Fig. 4. SQUID magnetization/demagnetization curves of the six different nanoparticle products. The lack of hysteresis in demagnetization curves demonstrates superparamagnetic behavior of the nanoparticle products.

# 3.5. Glucose detection by iron oxide nanoparticles

Glucose content could be readily detected by utilizing the same chromogenic substrates studied above. In principle, hydrogen peroxide evolved from GOx oxidation of glucose can oxidize ABTS in the presence of a peroxidase. The color change from converted ABTS can be used to indirectly measure glucose. Based on the findings above, it was thought that NPEI would yield the highest sensitivity among the tested nanoparticles, since it yielded the highest activity toward ABTS. Unfortunately, intense precipitation occurred when NPEI was exposed to glucose/GOx. To this regard, Ngly, which also possessed favorable activity toward ABTS [(Table 2](#page-4-0)), was used as a substitute. For comparison, the least active nanoparticle, Nhep, was also examined.

Sensitivity results are presented in [Fig. 8](#page-5-0). As shown, absorbance linearly correlated to glucose concentration for both Ngly and Nhep. The absorbance, though, gradually leveled off and even decreased after glucose concentration exceeded 500 mmol/L (data not shown). Nevertheless, linear ranges of these two types of nanoparticles varied in their slopes, a prime indicator of sensitivity toward glucose. A higher slope would represent a higher sensitivity to glucose. The higher slope for Ngly predicts the same absorbance value at a lower glucose concentration when compared to the shallower curve for Nhep. Indeed, Ngly displayed a slope of 1.251 as opposed to 0.910 from Nhep [(Fig. 8A](#page-5-0)).

At very low concentrations, Ngly still demonstrated good linearity toward glucose (R2 ¼ 0.993), as shown in [Fig. 8](#page-5-0)B. Nhep, however, lost some of its linearity as evidenced by a much lower correlation (R2 ¼ 0.771). This result shows that Nhep is unable to provide a linear response to glucose in such a low range of concentrations. The detection limits for Ngly and Nhep, calculated as three times background absorbance divided by the corresponding line slopes, were estimated to be 8.5 mmol/L and 15.8 mmol/L, respectively. Our data indicate that Ngly is more sensitive than Nhep when ABTS is chosen as a substrate to detect glucose.

# 4. Discussion

Functionalizing iron oxide nanoparticles usually involves a complicated, multi-step process that often results in precipitation. In this study, a facile and efficient methodology was established. Iron oxide nanoparticles with six different coatings – three anionic (Ncit, NCMD,Nhep) and three cationic (Ngly,NPLL,NPEI) – were synthesized and evaluated to determine the effect of surface charge on peroxidase-like activity. In addition, nanoparticle pairs – having similar charge but different coating thickness – were assessed to understand the effect of coating thickness on peroxidase activity. Of important note, we planned to use Nnat as a control in experiments. Nnat, though, were

<DESCRIPTION_FROM_IMAGE>The image contains two graphs, labeled A and B, showing the relationship between velocity and concentration for different substrates.

Graph A:
X-axis: Concentration of TMB (mmol/L), ranging from 0 to 3.0
Y-axis: Velocity (10^-7 Ms^-1), ranging from 0 to 2.5

The graph shows six curves labeled (a) to (f), each representing a different experimental condition. All curves show a general trend of increasing velocity with increasing TMB concentration, but with different rates and plateaus:

(a) Highest initial rate and plateau around 2.2 x 10^-7 Ms^-1
(b) Second highest initial rate, plateauing around 1.6 x 10^-7 Ms^-1
(c) Moderate initial rate, plateauing around 1.2 x 10^-7 Ms^-1
(d) Lower initial rate, plateauing around 0.8 x 10^-7 Ms^-1
(e) and (f) Lowest initial rates, both plateauing around 0.3 x 10^-7 Ms^-1

Graph B:
X-axis: Concentration of ABTS (mmol/L), ranging from 0 to 2.5
Y-axis: Velocity (no units specified), ranging from 0 to 6.0

This graph also shows six curves labeled (a) to (f), but with a different pattern:

(f) Highest initial rate and maximum velocity, reaching about 5.8
(e) Second highest, reaching about 4.2
(d) Third highest, reaching about 2.8
(b) and (c) Similar curves, both reaching about 1.2
(a) Lowest curve, reaching about 0.6

All curves in Graph B show a steep initial increase followed by a plateau, characteristic of enzyme kinetics following Michaelis-Menten behavior.

These graphs likely represent enzyme kinetics studies comparing the activity of different enzyme variants or conditions with two different substrates (TMB and ABTS). The differences in curve shapes and maximum velocities indicate varying affinities and catalytic efficiencies for each condition tested.</DESCRIPTION_FROM_IMAGE>

Fig. 5. Kinetic analyses of (a) Nhep, (b) Ncit, (c) NCMD, (d) Ngly, (e) NPLL, and (f) NPEI. Steady-state catalysis rates were calculated from the initial slopes of absorbance versus time curves. Experiments were conducted by adding 50 mL of nanoparticle suspensions (0.35 mg Fe/mL) into solutions containing 100 mL of 530 mmol/L H2O2 and different concentrations of (A) TMB; and (B) ABTS substrate at room temperature. Points represent experimental data and color curves correspond to calculated fits using the Michaelis–Menten model.

unstable at the experimental conditions utilized, quickly precipitating when tested. Therefore, they were not included in analyses.

To prepare nanoparticles with different coatings, Ncit and Ngly were used as parent materials. Citrate was chemically linked to superficial iron atoms on Nnat via its carboxylate groups. The remaining residual carboxylate groups render Ncit negatively charged [\[17,18\]](#page-6-0). The aminated nanoparticle, Ngly, was synthesized analogously. Since the carboxylate group of glycine bound to nanoparticles as those from citrate, free glycine amino group rendered a net positive surface charge for Ngly. To our knowledge, this strategy has not yet been applied to synthesize an aminated nanoparticle. Based on our observations, our methodology is far simpler, more reproducible, and most importantly, without nanoparticle aggregation.

Highly branched PEI consists of primary, secondary, and tertiary amine groups in an approximate 25/50/25 ratio according to information from the manufacturer. PLL has an abundance of lysine groups that contain amine moieties. PEI and PLL can both be anchored to the surface of Ncit via electrostatic interactions between amine groups on the polymer and free carboxylate groups of Ncit. In a similar fashion, NCMD and Nhep were prepared by electrostatically coating Ngly with CMD or heparin, respectively. CMD provides free carboxylate and heparin provides both free carboxylate and sulfate groups that can bind free amine groups on Ngly. Characterization of these nanoparticles confirmed that coatings were successfully achieved as designed.

Previous results [\[5\]](#page-6-0) indicate that superficial ferrous atoms are a contributing factor to observed peroxidase activity. Structurewise, a large area-to-volume ratio (characteristic of a small particle size) would favor an enhanced catalytic activity. In this work, a group of iron oxide nanoparticles was prepared, all with similar size. Size was carefully controlled in order to keep it from confounding experiments. It is also important to mention that catalytic constants were expressed in terms of iron atom instead of particle number. If constants were calculated in terms of particle number, a large particle would yield a larger catalytic constant because of its larger surface area – the source of catalytic activity. Catalytic constants based on mass or atom number, though, provide a more normalized basis by which to evaluate activity.

Michaelis–Menten kinetics can be described by Equation (2):

$$E + \mathbb{S} \overset{k_1}{\underset{k_{-1}}{\rightleftharpoons}} ES \overset{k_2}{\to} E + P \tag{2}$$

According to Equation (2), increasing k1 and decreasing k-1 could improve enzyme activity. One route to do so would be to enhance affinity between enzyme and substrate. To achieve this purpose, electrostatic interaction appeared to be the simplest and most efficient strategy, as our results support. ABTS and TMB were chosen because they possess opposite charge characteristics. ABTS contains negatively charged sulfonic groups, giving it a strong electrostatic affinity toward a positively charged nanoparticle. As our results demonstrate, such an enhanced affinity results in a significantly improved peroxidase activity. Conversely, TMB contains two amine groups, yielding a strong affinity toward a negatively charged nanoparticle. Analogous to the reaction between ABTS and a positively charged nanoparticle, an anionic nanoparticle will exhibit a strong affinity and high activity with TMB as the reaction substrate. Experimental data were in strong support of these claims, as demonstrated by the calculated catalytic parameters shown in Table 2.

The Michaelis constant (KM) is an indicator of enzyme affinity for its substrate. A high KM represents a weak affinity whereas a low value suggests a high affinity [\[19\].](#page-6-0) In Table 2, this relationship is clearly illustrated. Cationic nanoparticles yielded lower KM values

| Table 2 |  |  |
|---------|--|--|
|         |  |  |

| Michaelis–Menten parameters of tested nanoparticles. |  |  |
|------------------------------------------------------|--|--|
|                                                      |  |  |

| Nanoparticle | TMB         |                |                        |             | ABTS           |                        |  |
|--------------|-------------|----------------|------------------------|-------------|----------------|------------------------|--|
|              | KM (mmol/L) | Vmax (107 M/s) | kcata (104 s<br>1<br>) | KM (mmol/L) | Vmax (107 M/s) | kcata (104 s<br>1<br>) |  |
| Ncit         | 0.24        | 1.70           | 0.81                   | 0.73        | 1.45           | 0.69                   |  |
| NCMD         | 0.30        | 1.25           | 0.60                   | 0.81        | 1.15           | 0.55                   |  |
| Nhep         | 0.22        | 2.40           | 1.14                   | 0.96        | 0.52           | 0.25                   |  |
| Ngly         | 0.55        | 0.96           | 0.46                   | 0.20        | 2.97           | 1.41                   |  |
| NPLL         | 0.69        | 0.46           | 0.22                   | 0.19        | 4.50           | 2.14                   |  |
| NPEI         | 0.71        | 0.42           | 0.20                   | 0.12        | 6.10           | 2.90                   |  |

a Catalytic constant derived from kcat ¼ Vmax/[E], where Vmax is the maximum reaction rate reached with increasing TMB or ABTS concentration, as shown in Fig. 5; [E] is the nanoparticle iron concentration measured by inductively coupled plasma-optical emission spectroscopy (ICP-OES).

<DESCRIPTION_FROM_IMAGE>The image presents a graph showing the relationship between two variables, labeled as (A) and (B), plotted against a common x-axis. The x-axis represents a range from -60 to 60, likely indicating temperature in degrees Celsius or a similar scale. The y-axis is labeled "catalytic constant, kcat (s^-1)", ranging from 0 to 3.0.

Two distinct trends are plotted:

1. Curve A (represented by square markers):
   This curve shows an exponential-like increase from left to right. The data points are:
   - At approximately -50 on the x-axis, the y-value is close to 0.25
   - At about -20, the y-value is around 0.5
   - At 20, the y-value is about 2.2
   - At 50, the y-value reaches nearly 3.0

2. Curve B (represented by circular markers):
   This curve shows a decreasing trend from left to right. The data points are:
   - At about -50 on the x-axis, the y-value is approximately 1.2
   - At -20, the y-value is around 0.8
   - At 20, the y-value decreases to about 0.4
   - At 50, the y-value is close to 0.2

The two curves intersect at a point near x = -20, where both y-values are approximately 0.6.

This graph likely represents the temperature dependence of catalytic activity for two different enzymes or two different conditions of the same enzyme. Curve A shows increasing catalytic activity with temperature, while Curve B shows decreasing activity, suggesting different temperature optima or stability profiles for the catalysts in question.</DESCRIPTION_FROM_IMAGE>

Fig. 6. Plots of catalytic constant (kcat) versus zeta potential for the different nanoparticle products, with ABTS (curve A) or TMB (curve B) as the substrate. Zeta potentials were derived from [Table 1.](#page-2-0) For an ABTS substrate, kcat increases rapidly with increasing zeta potential. In a much less pronounced manner, kcat decreases with increasing zeta potential for a TMB substrate.

toward negatively charged ABTS, and the opposite occurred for TMB as the substrate. Therefore, the rationale for varied activity was that affinity was altered by changes in electrostatic interaction between particle and substrate. Moreover, the intensity of superficial charge on nanoparticles appeared to also influence the degree to which catalytic activity was altered, as peroxidase activity varied with varied zeta potential (Fig. 6). Among the nanoparticles studied, Nhep had the highest negative charge and NPEI the highest positive charge. In support of our claim, Nhep showed the highest activity with TMB and the lowest with ABTS as the substrate. Conversely, NPEI showed the highest activity with ABTS and the lowest with TMB as the substrate (see Fig. 6).

Although electrostatic affinity exerted by superficial charge could enhance catalytic activity, the physical presence of a coating

<DESCRIPTION_FROM_IMAGE>The image presents a graph showing the relative activity (%) of various compounds as a function of the concentration of sodium azide (NaN3) in weight percent (wt%). The x-axis represents the concentration of NaN3 from 0 to 0.08 wt%, while the y-axis shows the relative activity from 0 to 100%.

The graph includes seven different curves, each representing a different compound or enzyme:

1. Nhep (red diamond markers)
2. NPEI (light green square markers)
3. Ngly (blue star markers)
4. NCMD (brown triangle markers)
5. Ncit (light blue circle markers)
6. NPLL (pink triangle markers)
7. HRP (dark green square markers)

All curves except HRP show a similar trend: starting at around 90-100% relative activity at 0 wt% NaN3, then slightly increasing or maintaining activity up to 0.02 wt% NaN3, followed by a gradual decrease in activity as the NaN3 concentration increases.

The HRP curve shows a dramatically different behavior: it starts at 100% relative activity at 0 wt% NaN3, then rapidly drops to near 0% activity at 0.02 wt% NaN3 and remains at this level for higher concentrations.

Key observations:

1. NPEI maintains the highest relative activity across all NaN3 concentrations.
2. Nhep shows the second-highest activity retention.
3. Ngly, NCMD, Ncit, and NPLL show similar trends, with activities decreasing to around 60% at 0.08 wt% NaN3.
4. HRP is completely inhibited by NaN3 at concentrations above 0.02 wt%.

This graph likely represents a study on the effect of sodium azide on the activity of various enzymes or compounds, with HRP (possibly Horseradish Peroxidase) being particularly sensitive to NaN3 inhibition.</DESCRIPTION_FROM_IMAGE>

Fig. 7. Inhibition of peroxidase activity by azide for the different nanoparticle products. For comparison, horseradish peroxidase (HRP) was tested. As shown, all products tested retained relatively high activity even at high azide concentrations. Conversely, almost all peroxidase activity was lost when HRP was exposed to even small levels of azide.

<DESCRIPTION_FROM_IMAGE>The image presents two graphs (A and B) showing the relationship between glucose concentration and absorbance at 417 nm for two different systems, labeled as Ngly and Nhep.

Graph A:
This graph shows the full range of measurements for both Ngly and Nhep systems.
X-axis: Glucose concentration (mmol/L), ranging from 0 to 0.3 mmol/L
Y-axis: Absorbance at 417 nm, ranging from 0 to 0.3

For Ngly:
- Linear equation: y = 1.251x + 0.003
- R² value: 0.998
- The line has a steeper slope compared to Nhep

For Nhep:
- Linear equation: y = 0.910x - 0.001
- R² value: 0.996
- The line has a less steep slope compared to Ngly

Both systems show a strong linear correlation between glucose concentration and absorbance.

Graph B:
This graph is a magnified view of the lower concentration range for both Ngly and Nhep systems.
X-axis: Glucose concentration (mmol/L), ranging from 0 to 0.03 mmol/L
Y-axis: Absorbance at 417 nm, ranging from 0 to 0.05

For Ngly:
- Linear equation: y = 1.343x + 0.001
- R² value: 0.993
- The line maintains a strong linear relationship even at lower concentrations

For Nhep:
- Linear equation: y = 0.724x - 0.0007
- R² value: 0.771
- The line shows more variability at lower concentrations, as indicated by the lower R² value

Error bars are present in both graphs, particularly noticeable in Graph B, indicating the precision of the measurements.

The graphs demonstrate that the Ngly system consistently shows higher absorbance values for the same glucose concentrations compared to the Nhep system, suggesting it may be more sensitive for glucose detection. The strong linear relationships, especially for Ngly, indicate that these systems could potentially be used for quantitative glucose measurements in the given concentration ranges.</DESCRIPTION_FROM_IMAGE>

Fig. 8. Glucose detection using Ngly and Nhep (ABTS substrate). Response curves for Ngly and Nhep at (A) high; and (B) low (i.e. <31.2 mmol/L) glucose concentrations are shown. Ngly showed higher sensitivity when compared to Nhep as evidenced by a higher slope. Where Nhep lost its linearity in the low glucose concentration range shown (B), Ngly retained it across both ranges tested suggesting a better detection limit.

could also shield active iron domains on the surface of particles. This effect was observed when comparing particles of similar charge, but different coating thickness. As noted, however, steric effects on affinity were relatively weak compared with the dramatic changes seen with varied zeta potentials.

A common challenge to the application of peroxidases (such as HRP) lies in their easy inactivation by standard antibacterial preservatives, such as sodium azide [\[20\]](#page-6-0). The catalytic turnover of sodium azide by peroxidase into azidyl radical results in peroxidase inactivation [\[20\]](#page-6-0). Inactivation cripples the applicability of peroxidases in applications. Nanoparticles, regardless of superficial charge or the coating, however, exhibited robust resistance against sodium azide. Activity of nanoparticles was virtually unaffected by the presence of sodium azide, especially at commonly utilized concentrations. To this regard, iron oxide nanoparticles offer a durable alternative to peroxidases by their ability to function even in harsh environments detrimental to protein enzymes.

The utility and applicability of the synthesized nanoparticles were further demonstrated through their sensitivity and detection limit in glucose measurements. Compared with Nhep, Ngly displayed a larger linear slope of ABTS absorbance with glucose concentrations, suggesting better sensitivity for glucose detection. In addition, a better linear correlation was observed in the low concentration <span id="page-6-0"></span>range, suggesting an improved detection limit. The low detection limit observed for Ngly could be useful to applications that measure low levels of glucose. For example, it was reported that the glucose concentration in tear fluid is correlated to that in the blood [21,22]. An accurate analysis of glucose in tear fluid could be a viable, noninvasive alternative for diabetes mellitus patients. The glucose concentration in tear fluid is relatively low (w28 mmol/L) [22] and more than 100-fold less than in blood. Our data suggest that an iron oxide nanoparticle might be a good candidate to assay glucose in tears, or in other applications that require analysis of trace levels of glucose. Excellent sensitivity, detection limit, and linearity in our model glucose assay support the use of iron oxide nanoparticles in other quantitative assays dependent on peroxidase activity.

# 5. Conclusion

The peroxidase-like activity of iron oxide nanoparticles was explored and found to be dependent on the surface attributes of nanoparticles. Six nanoparticles were synthesized with distinct surface charge, charge intensity, and coating thickness. With TMB as a substrate, anionic nanoparticles had a high affinity and exhibited a high catalytic activity. The activity gradually decreased when varying the zeta potential from negative to positive. Nhep exhibited a 5.9-fold higher catalytic activity than NPEI. With ABTS as the substrate, cationic nanoparticles displayed a high affinity and subsequently a high peroxidase activity. The activity increased dramatically in varying the zeta potential from negative to positive. NPEI displayed an 11.5-fold higher activity than Nhep. The intrinsic peroxidase activity of these nanoparticles was virtually unaffected by the presence of standard antibacterial preservative of sodium azide. Particles yielding a high activity toward an ABTS as a substrate, such as Ngly, exhibited a much higher sensitivity and a much lower limit in glucose detection than Nhep, a particle of low catalytic activity.

# Acknowledgements

This research was in part supported by NIH grants CA114612 and RNS066945 as well as a Hartwell Biomedical Research Award. Dr. Faquan Yu is a recipient of the Hubei Natural Science Fund for Distinguished Young Scholars (2005ABB031), Hubei, China. Mr. Adam J. Cole is the recipient of an NIH Pharmacological Sciences and Bio-related Chemistry Training Program grant (GM007767 from NIGMS) and of an American Foundation of Pharmaceutical Education (AFPE) Pre-Doctoral Fellowship. Dr. Victor C. Yang is currently a Cheung Kong Scholar appointed by Chinese Ministry of Education.

# References

- [1] Lewin M, Carlesso N, Tung CH, Tang XW, Cory D, Scadden DT, et al. Tat peptidederivatized magnetic nanoparticles allow in vivo tracking and recovery of progenitor cells. Nat Biotechnol 2000;18(4):410–4.
- [2] Cheng J, Teply BA, Jeong SY, Yim CH, Ho D, Sherifi I, et al. Magnetically responsive polymeric microparticles for oral delivery of protein drugs. Pharm Res 2006;23(3):557–64.
- [3] Hancock JP, Kemshead JT. A rapid and highly selective approach to cell separations using an immunomagnetic colloid. J Immunol Methods 1993;164(1): 51–60.
- [4] Matteucci ML, Anyarambhatla G, Rosner G, Azuma C, Fisher PE, Dewhirst MW, et al. Hyperthermia increases accumulation of technetium-99m-labeled liposomes in feline sarcomas. Clin Cancer Res 2000;6(9):3748–55.
- [5] Gao L, Zhuang J, Nie L, Zhang J, Zhang Y, Gu N, et al. Intrinsic peroxidase-like activity of ferromagnetic nanoparticles. Nat Nanotechnol 2007;2(9):577–83.
- [6] Geschke O, Klank H, Telleman P. Microsystem engineering of lab-on-a-chip devices. Wiley-VCH Verlag GmbH & Co. KGaA; 2004. p. 220.
- [7] Jin Z, Chen R, Colon LA. Determination of glucose in submicroliter samples by CE-LIF using precolumn or on-column enzymatic reactions. Anal Chem 1997; 69(7):1326–31.
- [8] Boorsma DM, Van Bommel J, Vanden Heuvel J. Avidin-HRP conjugates in biotin–avidin immunoenzyme cytochemistry. Histochem Cell Biol 1986; 84(4–6):333–7.
- [9] Dhawan S. Signal amplification systems in immunoassays: implications for clinical diagnostics. Expert Rev Mol Diagn 2006;6(5):749–60.
- [10] El-Essi FA, Zuhri AZA, Al-Khalil SI, Abdel-Latif MS. Spectrophotometric determination of enzymatically generated hydrogen peroxide using sol–gel immobilized horseradish peroxidase. Talanta 1997;44(11):2051–8.
- [11] Fernandes KF, Lima CS, Lopes FM, Collins CH. Hydrogen peroxide detection system consisting of chemically immobilised peroxidase and spectrometer. Process Biochem 2005;40(11):3441–5.
- [12] Kim DK, Zhang Y, Voit W, Rao KV, Muhammed M. Synthesis and characterization of surfactant-coated superparamagnetic monodispersed iron oxide nanoparticles. J Magn Magn Mater 2001;225(1–2):30–6.
- [13] Yu S, Chow GM. Carboxyl group (–CO2H) functionalized ferrimagnetic iron oxide nanoparticles for potential bio-applications. J Mater Chem 2004; 14(18):2781–6.
- [14] Sun EY, Josephson L, Kelly KA, Weissleder R. Development of nanoparticle libraries for biosensing. Bioconjugate Chem 2006;17(1):109–13.
- [15] Karaseva EI, Losev YP, Metelitsa DI. Peroxidase-catalyzed oxidation of 3,3005,500 tetramethylbenzidine in the presence of 2,4-dinitrosoresorcinol and polydisulfide derivatives of resorcinol and 2,4-dinitrosoresorcinol. Russ J Bioorg Chem 2002;28(2):128–35.
- [16] Forni LG, Mora-Arellano VO, Packer JE, Willson RL. Nitrogen dioxide and related free radicals: electron-transfer reactions with organic compounds in solutions containing nitrite or nitrate. J Chem Soc, Perkin Trans 1986;2:1–6.
- [17] Bacri J-C, Perzynski R, Salin D, Cabuil V, Massart R. Ionic ferrofluids: a crossing of chemistry and physics. J Magn Magn Mater 1990;85(1–3):27–32.
- [18] Fauconnier N, Bee A, Massart R, Dardoize F. Direct determination of organic acids in a ferrofluid (g-Fe2O3) by high-performance liquid chromatography. J Liq Chromatogr Relat Technol 1996;19(5):783–97.
- [19] Berg JM, Tymoczko JL, Stryer L. Biochemistry. 6th ed. New York: W.H. Freeman; 2007. p. 221.
- [20] Brill AS, Weinryb I. Reactions of horseradish peroxidase with azide. Evidence for a methionine residue at the active site. Biochemistry 1967;6(11):3528–35.
- [21] Giardini A, Roberts JRE. Concentration of glucose and total chloride in tears. Br J Ophthalmol 1950;34(12):737–43.
- [22] Baca JT, Taormina CR, Feingold E, Finegold DN, Grabowski JJ, Asher SA. Mass spectral determination of fasting tear glucose concentrations in nondiabetic volunteers. Clinic Chem 2007;53(7):1370–2.