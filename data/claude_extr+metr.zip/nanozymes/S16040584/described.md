<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo for a publication or organization related to sensors. It consists of two main elements:

1. A stylized icon representing an electronic chip or sensor component
2. The word "sensors" written in lowercase letters

While this logo is related to the field of sensors, which can have applications in chemistry and scientific instrumentation, the image itself does not contain any specific chemical or scientific information to interpret in detail. It serves as a graphical representation or branding element rather than conveying technical data.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image appears to be a logo for MDPI (Multidisciplinary Digital Publishing Institute). The logo consists of the letters "MDPI" in a bold, sans-serif font. The letters are enclosed within a stylized outline of a house or building shape, with the roof represented by two angled lines above the letters.

As this logo does not convey specific scientific or chemical information, and is instead a branding element, the appropriate response is:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

# *Article* **Optimizing Colorimetric Assay Based on V2O5 Nanozymes for Sensitive Detection of H2O2 and Glucose**

# **Jiaheng Sun, Chunyan Li, Yanfei Qi *, Shuanli Guo and Xue Liang**

School of Public Health, Jilin University, Changchun 130021, China; sunjh15@mails.jlu.edu.cn (J.S.); licy14@mails.jlu.edu.cn (C.L.); guosl15@mails.jlu.edu.cn (S.G.); liangxue2714@mails.jlu.edu.cn (X.L.) ***** Correspondence: qiyanfei@jlu.edu.cn; Tel.: +86-431-8561-9441

Academic Editors: Jong Seung Kim and Min Hee Lee Received: 1 March 2016; Accepted: 19 April 2016; Published: 22 April 2016

**Abstract:** Nanozyme-based chemical sensing is a rapidly emerging field of research. Herein, a simple colorimetric assay for the detection of hydrogen peroxide and glucose based on the peroxidase-like activity of V2O5 nanozymes has been established. In this assay, the effects of pH, substrate, nanozyme concentrations and buffer solution have been investigated. It was found that compared with 3,31 ,5,51 -tetramethylbenzidine (TMB), the enzyme substrate *o*-phenylenediamine (OPD) seriously interfered with the H2O2 detection. Under the optimal reaction conditions, the resulting sensor displayed a good response to H2O2 with a linear range of 1 to 500 µM, and a detection limit of 1 µM at a signal-to-noise ratio of 3. A linear correlation was established between absorbance intensity and concentration of glucose from 10 to 2000 µM, with a detection limit of 10 µM. The current work presents a simple, cheap, more convenient, sensitive, and easy handling colorimetric assay.

**Keywords:** V2O5 nanozymes; variation; substrates; H2O2; glucose

### **1. Introduction**

Nanozymes, as the next-generation artificial enzymes, have attracted wide interest in recent years. Compared with natural enzymes, nanozymes, with their advantages of high stability against denaturing, low-cost, easy storage and treatment are attractive and promising candidates in chemical sensing, immunoassay development, cancer diagnostics and therapy, and environmental protection [\[1\]](#page-8-0). At present, a large number of nanoparticle (NP) artificial enzymes have been constructed to mimic natural enzymes, including iron oxide-based NPs with peroxidase and catalase-like activities [\[2](#page-8-1)[,3\]](#page-8-2), cerium oxide-based nanomaterials with oxidase, catalase and SOD mimetic properties [\[4](#page-8-3)[,5\]](#page-8-4), cobalt oxide ones that are peroxide and catalase mimics [\[6,](#page-8-5)[7\]](#page-8-6), copper oxide and manganese dioxide nanomaterials that display oxidase-like activity [\[8](#page-8-7)[,9\]](#page-8-8), vanadium pentoxide peroxidase mimics [\[10\]](#page-8-9), and metal/bimetal-based [\[11\]](#page-8-10) and carbon-based NPs [\[12\]](#page-8-11) with oxidase, peroxidase, and SOD mimetic activity. Thereinto, vanadium pentoxide nanowires had aroused special attention due to their activity towards peroxidase substrates and long-term antibiofouling capabilities [\[13,](#page-8-12)[14\]](#page-9-0). However, to date, no facile, fast and ultrasensitive detection methods have been developed based on the peroxidase catalytic activity of vanadium pentoxide nanowires. Additionally, more research is needed on the nanozyme catalytic reaction for biological and chemical analysis.

Hydrogen peroxide (H2O2), an essential oxidizing agent, plays an important role in the food production, biomedicine, pharmaceutical, industrial and environmental fields [\[15\]](#page-9-1). It was proved to be a byproduct of metabolic oxidation processes, and it is immediately dangerous to life and health when its concentration reaches 75 ppm [\[16\]](#page-9-2). Glucose is one of the essential nutrients and an important source of energy for human life via its *in vivo* metabolism. Blood glucose levels in healthy humans stay within narrow limits throughout the day (4.0–8.0 mmol/L) [\[17\]](#page-9-3). Glucose is also widely used in the food and pharmaceutical industry, therefore, quantitative determination of glucose is significant for industrial quality control and processing applications [\[18\]](#page-9-4). Most glucose biosensors are based on the oxidation or reduction of enzymatically produced H2O2 [\[19–](#page-9-5)[22\]](#page-9-6). Hence, the detection of H2O2 concentrations has attracted the interest of many chemists for a long time. Until now, several techniques have been developed for a reliable and sensitive determination of H2O2, such as chemiluminescence [\[23\]](#page-9-7), fluorometry [\[24\]](#page-9-8), liquid chromatography [\[25\]](#page-9-9) and electrochemistry [\[26\]](#page-9-10). Among these methods, sensitive spectrometric methods for the H2O2 determination based on the horseradish peroxidase (HRP)-catalyzed enzymatic reactions have attracted substantial attention owing to the rapid response, and low fabrication cost characteristics [\[27](#page-9-11)[,28\]](#page-9-12). Although HRP has high specificity and sensitivity, the application of the free natural enzyme is limited by its poor stability, and high cost [\[29\]](#page-9-13).

In this paper, a simple colorimetric assay for the detection of hydrogen peroxide and glucose based on the peroxidase-like activity of V2O5 nanozymes has been established. In this assay, the effects of pH, substrate, nanozymes concentrations and buffer solution have been investigated. Under the optimal reaction conditions, the resulting biosensor displayed a good response to H2O2 and glucose. In addition, it exhibited excellent anti-interference ability and fast response. The colorimetric assay based on V2O5 nanozymes may be broadly applicable in clinical diagnoses and monitoring environmental water pollution.

### **2. Materials and Methods**

### *2.1. Chemicals and Materials*

All the chemicals were of analysis grade and used without further purification. 3,31 ,5,51 -Tetramethylbenzidine (TMB) was purchased from Tokyo Chemical Industry Co., Ltd. (Tokyo, Japan). Glucose oxidase (GOx) was purchased from Aladdin Reagent Co., Ltd. (Shanghai, China). *o*-Phenylenediamine (OPD) was purchased from Tianjin Guangfu Fine Chemical Research Institute (Tianji, China). VOSO4, KBrO3, glucose and 30% H2O2, *etc.* were purchased from Beijing Chemical Works (Beijing, China).

### *2.2. Synthesis of V2O5 Nanozymes*

V2O5 nanozymes were synthesized according to a literature procedure [\[30\]](#page-9-14), with minor adjustments. In brief, VOSO4¨ nH2O (2.4 mmol) and KBrO3 (1.5 mmol) were dissolved in distilled water (9 mL) and stirred for 30 min at room temperature. Then the solution was transferred to a Teflon-lined stainless steel autoclave, which was maintained at 180 ˝C for 24 h. After the sample was cooled to room temperature naturally, the resulting dark yellow precipitates were filtered off, washed with distilled water and ethanol several times, and dried in an oven at 80 ˝C.

### *2.3. Physical Characterization*

The V2O5 nanozymes were thoroughly characterized by various methods. Transmission electron microscopy (TEM) observation was performed using a 100CX transmission electron microscope (JEOL, Tokyo, Japan) with an acceleration voltage of 100 kV. The Fourier Transform Infrared (FTIR) spectra were recorded in the range 400–4000 cm´1 on an Alpha Centauri FT/IR spectrophotometer (Nicolet, Denver, CO, USA) using KBr pellets. The X-ray powder diffraction method was carried out in a D/max-rA power diffractometer (Rigaku, Tokyo, Japan) using Cu-Kα monochromatic radiation (λ = 1.5418 Å).

# *2.4. H2O2 Detection Using V2O5 Nanozymes*

With OPD or TMB as substrate, the H2O2 sensing assay was performed as follows: V2O5 nanozymes solution (1 mM, 60 µL) was added into NaOAc-HOAc buffer solution (pH = 4.0, 2400 µL), followed by the addition of TMB (or OPD) solution (1.5 mM in ethanol, 480 µL) and H2O2 (30%, 60 µL).

The UV/Vis spectra were recorded at 660 nm for TMB and 450 nm for OPD after reaction for 5 min *vs.* a blank containing only the substrate solution. The buffer solutions from pH 3.0 to 8.0 and different reaction buffers were investigated, under conditions identical to those used above. All assays were done at 25 ˝C unless otherwise indicated, and analysed with a UV-Vis spectrophotometer (Metash Instruments Inc., Shanghai, China). 60 μL). The UV/Vis spectra were recorded at 660 nm for TMB and 450 nm for OPD after reaction for 5 min *vs.* a blank containing only the substrate solution. The buffer solutions from pH 3.0 to 8.0 and different reaction buffers were investigated, under conditions identical to those used above. All assays were done at 25 °C unless otherwise indicated, and analysed with a UV-Vis spectrophotometer (Metash Instruments Inc., Shanghai, China).

### *2.5. Glucose Detection Using V2O5 Nanozymes 2.5. Glucose Detection Using V2O5 Nanozymes*

Glucose detection was performed as follows: GOx (1 mg/mL, 200 µL), glucose of different concentrations (200 µL), and PBS (pH = 7.0, 400 µL) were incubated at 37 ˝C for 60 min. TMB (1.5 mM in ethanol, 400 µL), V2O5 nanozymes solution (50 µL), and NaOAc-HOAc buffer solution (pH = 4.0, 1750 µL) were added to the above glucose reaction solution. Then the concentrations of glucose were measured after the mixed solution incubated for 5 min *vs.* a blank containing only the substrate solution. For glucose detection in blood, the blood sample was firstly centrifuged at 12,000 rpm for 5 min. Then, the supernatant (200 µL) was diluted to 400 µL using PBS (pH = 7.0) before subsequent use. These diluted supernatants were then used with GOx for glucose detection as described above instead of glucose aqueous solution. Glucose detection was performed as follows: GOx (1 mg/mL, 200 μL), glucose of different concentrations (200 μL), and PBS (pH = 7.0, 400 μL) were incubated at 37 °C for 60 min. TMB (1.5 mM in ethanol, 400 μL), V2O5 nanozymes solution (50 μL), and NaOAc-HOAc buffer solution (pH = 4.0, 1750 μL) were added to the above glucose reaction solution. Then the concentrations of glucose were measured after the mixed solution incubated for 5 min *vs.* a blank containing only the substrate solution. For glucose detection in blood, the blood sample was firstly centrifuged at 12,000 rpm for 5 min. Then, the supernatant (200 μL) was diluted to 400 μL using PBS (pH = 7.0) before subsequent use. These diluted supernatants were then used with GOx for glucose detection as described above instead of glucose aqueous solution.

#### **3. Results and Discussion 3. Results and Discussion**

#### *3.1. Characterization of V2O5 Nanozymes 3.1. Characterization of V2O5 Nanozymes*

The physical characterization data of the V2O5 nanozymes is shown in Figure 1. The FTIR spectrum can be seen in Figure 1a. The bands at about 1000 cm´1 come from bending vibrations of the V-O bridge bonds. The formation of orthorhombic V2O5 nanozymes is confirmed from the X-ray diffraction pattern (Figure 1b). Transmission electron microscopy (TEM) images indicate nanozymes of different sizes with lengths of ~500 nm (Figure 1c). The physical characterization data of the V2O5 nanozymes is shown in Figure [1.](#page-2-0) The FTIR spectrum can be seen in Figure 1[a.](#page-2-0) The bands at about 1000 cm−1 come from bending vibrations of the V-O bridge bonds. The formation of orthorhombic V2O5 nanozymes is confirmed from the X-ray diffraction pattern (Figure [1b](#page-2-0)). Transmission electron microscopy (TEM) images indicate nanozymes of different sizes with lengths of ~500 nm (Figure [1c](#page-2-0)).

<DESCRIPTION_FROM_IMAGE>The image consists of three panels labeled (a), (b), and (c), each representing different analytical techniques used to characterize a material.

(a) Infrared (IR) Spectroscopy:
This panel shows an IR spectrum with wavenumber (cm^-1) on the x-axis ranging from 4000 to 500 cm^-1, and transmittance on the y-axis. The spectrum displays several characteristic absorption bands:
- A broad, strong band around 3400-3200 cm^-1, likely corresponding to O-H stretching
- Sharp peaks around 2900-2800 cm^-1, possibly due to C-H stretching
- A strong peak around 1650-1600 cm^-1, which could be attributed to C=O stretching or N-H bending
- Multiple peaks in the fingerprint region (1500-500 cm^-1)

(b) X-ray Diffraction (XRD):
This panel presents an XRD pattern with 2θ (degree) on the x-axis ranging from 10° to 80°, and intensity on the y-axis. Several distinct peaks are labeled:
- 021 peak at approximately 22°
- 041 peak at about 24°
- 101 peak around 28°
- 131 peak at about 36°
- 060 peak near 47°
- 200 peak close to 50°
- 011 peak around 60°
- 072 peak at about 68°
These peaks indicate a crystalline structure and can be used to identify the material's crystal phase.

(c) Transmission Electron Microscopy (TEM):
This panel shows a TEM image of the material's microstructure. The image reveals:
- Elongated, rod-like structures with varying lengths and widths
- The structures appear to be randomly oriented and overlapping
- A scale bar is provided, indicating 500 nm
- The structures seem to have a high aspect ratio, with lengths significantly greater than their widths

This combination of analytical techniques (IR spectroscopy, XRD, and TEM) provides comprehensive information about the material's chemical composition, crystal structure, and morphology at the nanoscale.</DESCRIPTION_FROM_IMAGE>

**Figure 1.** Characterizations of V2O5 nanozymes: (**a**) FTIR spectrum; (**b**) XRD pattern; (**c**) TEM images. **Figure 1.** Characterizations of V2O5 nanozymes: (**a**) FTIR spectrum; (**b**) XRD pattern; (**c**) TEM images.

### *3.2. Principle 3.2. Principle*

In pH 4 NaOAc-HOAc buffer solutions at 25 °C, V2O5 nanozymes of 500 nm mean size catalyzed the oxidation of 3,3′,5,5′-tetramethylbenzidine (TMB) and *o*-phenylenediamine (OPD) enzyme substrates in the presence of H2O2 to produce blue and orange colors, respectively. With increased H2O2 increased concentration more TMB and OPD will be oxidized by more H2O2, so the absorbance intensity becomes stronger. The absorbance intensity shows a linear dependence on the concentration of H2O2 and related materials. In pH 4 NaOAc-HOAc buffer solutions at 25 ˝C, V2O5 nanozymes of 500 nm mean size catalyzed the oxidation of 3,31 ,5,51 -tetramethylbenzidine (TMB) and *o*-phenylenediamine (OPD) enzyme substrates in the presence of H2O2 to produce blue and orange colors, respectively. With increased H2O2 increased concentration more TMB and OPD will be oxidized by more H2O2, so the absorbance intensity becomes stronger. The absorbance intensity shows a linear dependence on the concentration of H2O2 and related materials.

The UV/vis spectra are shown in Figure 2. It can be seen that substrate solutions in the presence of H2O2 or V2O5 exhibit no strong absorption, however, strong absorption peaks were found at 452 nm, 660 nm for TMB (Figure 2a), and 450 nm for OPD (Figure 2b) when the H2O2 and V2O5 were added into the system. The UV/vis spectra are shown in Figure [2.](#page-3-0) It can be seen that substrate solutions in the presence of H2O2 or V2O5 exhibit no strong absorption, however, strong absorption peaks were found at 452 nm, 660 nm for TMB (Figure [2a](#page-3-0)), and 450 nm for OPD (Figure [2b](#page-3-0)) when the H2O2 and V2O5 were added into the system.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (a) and (b), both showing UV-Vis absorption spectra for different chemical systems involving V2O5 and H2O2. Each graph also includes an inset image of a vial containing a solution.

Graph (a):
- X-axis: Wavelength (nm), ranging from 400 to 750 nm
- Y-axis: Absorbance, ranging from 0 to 3.5
- Three spectra are shown:
  1. V2O5 without H2O2 (red line): Nearly flat line with very low absorbance across the spectrum
  2. H2O2 without V2O5 (black line): Slightly higher absorbance than V2O5 alone, but still relatively flat
  3. V2O5 with H2O2 (blue line): Shows a significant broad absorption peak
    - Peak maximum at approximately 640 nm
    - Absorbance reaches about 2.6 at the peak
    - Secondary smaller peak or shoulder around 450 nm
- Inset image shows a vial with a turquoise-colored solution

Graph (b):
- X-axis: Wavelength (nm), ranging from 350 to 750 nm
- Y-axis: Absorbance, ranging from 0.4 to 1.5
- Three spectra are shown:
  1. V2O5 with H2O2 (blue line): Highest absorbance, broad peak with maximum around 400 nm
  2. V2O5 without H2O2 (red line): Lower absorbance, gradually decreasing from 350 to 750 nm
  3. H2O2 without V2O5 (gray line): Lowest and flattest absorbance across the spectrum
- Inset image shows a vial with a yellow-colored solution

The graphs demonstrate the spectral changes that occur when V2O5 and H2O2 are combined, indicating a chemical reaction or interaction between these species. The dramatic increase in absorbance and the appearance of new absorption peaks in the presence of both V2O5 and H2O2 suggest the formation of a new chemical species or complex.</DESCRIPTION_FROM_IMAGE>

*Sensors* **2016**, *16*, 584 4 of 10

<span id="page-3-0"></span>*Sensors* **2016**, *16*, 584 4 of 10

**Figure 2.** The catalytic effect of V2O5 nanozymes with TMB (**a**) and OPD (**b**) as the substrate in the presence of H2O2. **Figure 2.** The catalytic effect of V2O5 nanozymes with TMB (**a**) and OPD (**b**) as the substrate in the presence of H2O2 . **Figure 2.** The catalytic effect of V2O5 nanozymes with TMB (**a**) and OPD (**b**) as the substrate in the presence of H2O2.

#### *3.3. Effect of pH 3.3. Effect of pH 3.3. Effect of pH*

The effect of pH value (pH 3.0–8.0) on the OD660nm for TMB and OD450nm for OPD was studied, as shown in Figure 3a,b. Both the OD660nm for TMB and the OD450nm for OPD reached their maximum values when the pH value was 4.0. This optimum pH for the reaction of V2O5 nanozymes with TMB is consistent with the value reported in the literature [10]. Therefore, pH 4.0 was selected for H2O2 and glucose detection. The effect of pH value (pH 3.0–8.0) on the OD660nm for TMB and OD450nm for OPD was studied, as shown in Figure 3a,b. Both the OD660nm for TMB and the OD450nm for OPD reached their maximum values when the pH value was 4.0. This optimum pH for the reaction of V2O5 nanozymes with TMB is consistent with the value reported in the literature [\[10\]](#page-8-9). Therefore, pH 4.0 was selected for H2O2 and glucose detection. The effect of pH value (pH 3.0–8.0) on the OD660nm for TMB and OD450nm for OPD was studied, as shown in Figure 3[a,](#page-3-1)b. Both the OD660nm for TMB and the OD450nm for OPD reached their maximum values when the pH value was 4.0. This optimum pH for the reaction of V2O5 nanozymes with TMB is consistent with the value reported in the literature [10]. Therefore, pH 4.0 was selected for H2O2 and glucose detection.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (a) and (b), both showing the relationship between pH and absorbance.

Graph (a):
This graph depicts the relationship between pH (x-axis) and absorbance (y-axis). The pH range is from 3 to 8, while the absorbance range is from 0 to 3.5. The curve shows a bell-shaped trend with the following key features:
1. At pH 3, the absorbance is approximately 2.4.
2. The absorbance increases to a maximum of about 3.1 at pH 4.
3. After the peak, there's a sharp decrease in absorbance as pH increases.
4. At pH 6, the absorbance drops to around 0.5.
5. Beyond pH 7, the absorbance approaches zero.

Graph (b):
This graph also shows the relationship between pH (x-axis) and absorbance (y-axis). The pH range is the same as in graph (a), from 3 to 8, but the absorbance range is from 0 to 2.5. The curve shows a similar bell-shaped trend with these key features:
1. At pH 3, the absorbance starts at about 1.2.
2. The absorbance reaches a maximum of approximately 2.2 at pH 4.
3. There's a gradual decrease in absorbance as pH increases beyond 4.
4. At pH 6, the absorbance is around 1.0.
5. The absorbance continues to decrease, reaching about 0.3 at pH 8.

Both graphs demonstrate a pH-dependent absorbance profile, likely representing the behavior of a pH-sensitive compound or system. The peak absorbance at around pH 4 in both cases suggests an optimal pH for the measured property. The main difference between the two graphs is the magnitude of the absorbance values and the rate of decrease after the peak, with graph (a) showing a more dramatic drop in absorbance compared to graph (b).</DESCRIPTION_FROM_IMAGE>

**Figure 3.** Effects of pH with TMB (**a**) and OPD (**b**) substrate, respectively. The error bars represent the standard deviation of three measurements. **Figure 3.** Effects of pH with TMB (**a**) and OPD (**b**) substrate, respectively. The error bars represent the standard deviation of three measurements. **Figure 3.** Effects of pH with TMB (**a**) and OPD (**b**) substrate, respectively. The error bars represent the standard deviation of three measurements.

### *3.4. Effect of Buffers* As shown in Figure 4, V2O5 nanozymes were incubated for as long as 300 s in pH 4.0, 0.2 M *3.4. Effect of Buffers 3.4. Effect of Buffers*

buffers, including acetat[e, p](#page-4-0)hosphate, and citrate. The V2O5 nanozymes were more active in 0.2 M NaOAc-HOAc buffer solutions than in other buffers. Up to 300 s, the buffer order of peroxidase activity of V2O5 nanozymes is acetate > citrate > phosphate for the TMB substrate, whereas the order is acetate ≈ phosphate > citrate for the OPD substrate. Thus, the acetate buffer solution was taken as the optimal reaction solution for H2O2 and glucose determination. As shown in Figure 4, V2O5 nanozymes were incubated for as long as 300 s in pH 4.0, 0.2 M buffers, including acetate, phosphate, and citrate. The V2O5 nanozymes were more active in 0.2 M NaOAc-HOAc buffer solutions than in other buffers. Up to 300 s, the buffer order of peroxidase activity of V2O5 nanozymes is acetate > citrate > phosphate for the TMB substrate, whereas the order is acetate ≈ phosphate > citrate for the OPD substrate. Thus, the acetate buffer solution was taken as the optimal reaction solution for H2O2 and glucose determination. As shown in Figure 4, V2O5 nanozymes were incubated for as long as 300 s in pH 4.0, 0.2 M buffers, including acetate, phosphate, and citrate. The V2O5 nanozymes were more active in 0.2 M NaOAc-HOAc buffer solutions than in other buffers. Up to 300 s, the buffer order of peroxidase activity of V2O5 nanozymes is acetate > citrate > phosphate for the TMB substrate, whereas the order is acetate « phosphate > citrate for the OPD substrate. Thus, the acetate buffer solution was taken as the optimal reaction solution for H2O2 and glucose determination.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (a) and (b), both showing the relationship between absorbance and time for three different compounds: acetate, phosphate, and citrate.

Graph (a):
This graph shows absorbance measurements over time from 0 to 300 seconds. The y-axis ranges from 0 to 4.0 absorbance units, while the x-axis represents time in seconds.

Three curves are presented:
1. Acetate (green squares): Shows a rapid increase in absorbance up to about 150 seconds, then plateaus around 3.0 absorbance units.
2. Phosphate (black circles): Follows a similar trend to acetate, with a slightly lower final absorbance of about 2.8 units.
3. Citrate (red triangles): Exhibits a more gradual increase, reaching about 2.8 absorbance units by 300 seconds.

All three curves show an initial rapid increase followed by a leveling off, with acetate and phosphate reaching their plateau faster than citrate.

Graph (b):
This graph also shows absorbance measurements over time from 0 to 300 seconds. The y-axis ranges from 0 to 2.5 absorbance units.

Three curves are presented:
1. Acetate (green squares): Shows a steady increase in absorbance, reaching about 2.0 units by 300 seconds.
2. Phosphate (black squares): Follows a similar trend to acetate but with slightly lower values, reaching about 1.9 units by 300 seconds.
3. Citrate (red circles): Shows the slowest increase, reaching about 1.7 absorbance units by 300 seconds.

In this graph, all three compounds show a more gradual, continuous increase in absorbance over time, without reaching a clear plateau within the 300-second timeframe.

The differences between graphs (a) and (b) suggest that the experiments were conducted under different conditions, possibly varying concentrations or reaction environments, leading to different absorbance profiles for the same compounds.</DESCRIPTION_FROM_IMAGE>

*Sensors* **2016**, *16*, 584 5 of 10

<span id="page-4-0"></span>*Sensors* **2016**, *16*, 584 5 of 10

**Figure 4.** Activities of V2O5 nanozymes in, pH 4.0, 0.2 M buffers, with TMB (**a**) and OPD (**b**), respectively. The error bars represent the standard deviation of three measurements. **Figure 4.** Activities of V2O5 nanozymes in, pH 4.0, 0.2 M buffers, with TMB (**a**) and OPD (**b**), respectively. The error bars represent the standard deviation of three measurements. **Figure 4.** Activities of V2O5 nanozymes in, pH 4.0, 0.2 M buffers, with TMB (**a**) and OPD (**b**), respectively. The error bars represent the standard deviation of three measurements.

#### *3.5. Effect of V2O5 Nanozymes Concentrations 3.5. Effect of V2O5 Nanozymes Concentrations 3.5. Effect of V2O5 Nanozymes Concentrations*

As shown in Figure 5, the OD660nm and OD450nm values of the system increased gradually with the concentration of V2O5 nanozymes. Then the system reached its maximum OD660 value when the concentration was 1 mM. Hence, 1 mM V2O5 nanozymes was chosen for the assay system. As shown in Figure 5, the OD660nm and OD450nm values of the system increased gradually with the concentration of V2O5 nanozymes. Then the system reached its maximum OD660 value when the concentration was 1 mM. Hence, 1 mM V2O5 nanozymes was chosen for the assay system. As shown in Figure [5,](#page-4-1) the OD660nm and OD450nm values of the system increased gradually with the concentration of V2O5 nanozymes. Then the system reached its maximum OD660 value when the concentration was 1 mM. Hence, 1 mM V2O5 nanozymes was chosen for the assay system.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs, labeled (a) and (b), showing the relationship between absorbance and time for different concentrations of a substance.

Graph (a):
This graph shows absorbance versus time for five different concentrations: 0 mM, 0.1 mM, 0.25 mM, 0.5 mM, and 1 mM. The x-axis represents time in seconds, ranging from 0 to 300 seconds. The y-axis represents absorbance, ranging from 0 to 3.0.

The curves for each concentration show different rates of increase in absorbance over time:
- 1 mM: Rapid initial increase, reaching a plateau around 3.0 absorbance units by 150 seconds.
- 0.5 mM: Steady increase throughout, reaching about 2.5 absorbance units at 300 seconds.
- 0.25 mM: Gradual increase, reaching about 1.0 absorbance units at 300 seconds.
- 0.1 mM: Slight increase, reaching about 0.5 absorbance units at 300 seconds.
- 0 mM: Negligible change, staying close to 0 absorbance units throughout.

Graph (b):
This graph also shows absorbance versus time for the same five concentrations. The x-axis represents time in seconds, ranging from 0 to 300 seconds. The y-axis represents absorbance, but with a different scale ranging from 0 to 0.6.

The curves in this graph show similar trends to graph (a), but with lower overall absorbance values:
- 1 mM: Steady increase, reaching about 0.6 absorbance units at 300 seconds.
- 0.5 mM: Gradual increase, reaching about 0.2 absorbance units at 300 seconds.
- 0.25 mM, 0.1 mM, and 0 mM: Slight increases, all staying below 0.1 absorbance units throughout the 300 seconds.

Both graphs demonstrate concentration-dependent changes in absorbance over time, with higher concentrations generally showing greater increases in absorbance. The different scales of the y-axes suggest that the graphs may be representing different aspects of the same experiment or different experimental conditions.</DESCRIPTION_FROM_IMAGE>

NaOAc-HOAc buffer solution, with TMB (**a**) and OPD (**b**) respectively. *3.6. Calibration Curve for H2O2 Detection*  **Figure 5.** Effects of the V2O5 nanozymes concentrations ranging from 0 up to 1 mM in pH 4.0 NaOAc-HOAc buffer solution, with TMB (**a**) and OPD (**b**) respectively. **Figure 5.** Effects of the V2O5 nanozymes concentrations ranging from 0 up to 1 mM in pH 4.0 NaOAc-HOAc buffer solution, with TMB (**a**) and OPD (**b**) respectively.

#### In a certain range of H2O2 concentrations, typical Michaelis-Menten curves (Figure 6) can be *3.6. Calibration Curve for H2O2 Detection 3.6. Calibration Curve for H2O2 Detection*

obtained for V2O5 nanozymes. *K*M and *V*max were obtained using a Lineweaver-Burk plot. A comparison of the kinetic parameters of V2O5 nanozymes, Fe3O4 magnetic nanoparticles (MNPs), and HRP is given in Table 1. The *K*M and *V*max of V2O5 nanozymes with TMB are 0.738 mM and 1.85 × 10−5 M·s−1, respectively. The *K*M and *V*max of V2O5 nanozymes with H2O2 are 0.232 mM and 1.29 × 10−5 M·s−1, respectively. The *K*cat of V2O5 nanozymes with TMB and H2O2 are 18.46 s−1 and 12.91 s−1, respectively, and the *K*cat/*K*M values of V2O5 nanozymes with TMB and H2O2 are 25.02 mM−1·s−1 and 55.55 mM−1·s−1, respectively. The *K*M values show that V2O5 nanozymes have higher affinity for hydrogen peroxide compared with HRP, but less affinity to TMB compared with HRP. The apparent Km value of V2O5 nanozymes with TMB as the substrate was higher than that for HRP, consistent with the observation that a higher TMB concentration was required to achieve the maximal activity for V2O5 nanozymes. The apparent *K*M value of V2O5 nanozymes with H2O2 as the substrate was significantly lower than HRP and Fe3O4 MNPs. From the Table data, it can be concluded that the V2O5 nanozymes have a higher activity than HRP and Fe3O4 MNPs. In a certain range of H2O2 concentrations, typical Michaelis-Menten curves (Figure 6) can be obtained for V2O5 nanozymes. *K*M and *V*max were obtained using a Lineweaver-Burk plot. A comparison of the kinetic parameters of V2O5 nanozymes, Fe3O4 magnetic nanoparticles (MNPs), and HRP is given in Table 1. The *K*M and *V*max of V2O5 nanozymes with TMB are 0.738 mM and 1.85 × 10−5 M·s−1, respectively. The *K*M and *V*max of V2O5 nanozymes with H2O2 are 0.232 mM and 1.29 × 10−5 M·s−1, respectively. The *K*cat of V2O5 nanozymes with TMB and H2O2 are 18.46 s−1 and 12.91 s−1, respectively, and the *K*cat/*K*M values of V2O5 nanozymes with TMB and H2O2 are 25.02 mM−1·s−1 and 55.55 mM−1·s−1, respectively. The *K*M values show that V2O5 nanozymes have higher affinity for hydrogen peroxide compared with HRP, but less affinity to TMB compared with HRP. The apparent Km value of V2O5 nanozymes with TMB as the substrate was higher than that for HRP, consistent with the observation that a higher TMB concentration was required to achieve the maximal activity for V2O5 nanozymes. The apparent *K*M value of V2O5 nanozymes with H2O2 as the substrate was significantly lower than HRP and Fe3O4 MNPs. From the Table data, it can be concluded that the V2O5 nanozymes have a higher activity than HRP and Fe3O4 MNPs. In a certain range of H2O2 concentrations, typical Michaelis-Menten curves (Figure [6)](#page-5-0) can be obtained for V2O5 nanozymes. *K*M and *V*max were obtained using a Lineweaver-Burk plot. A comparison of the kinetic parameters of V2O5 nanozymes, Fe3O4 magnetic nanoparticles (MNPs), and HRP is given in Table [1.](#page-5-1) The *K*M and *V*max of V2O5 nanozymes with TMB are 0.738 mM and 1.85 ˆ 10´5 M¨ s ´1 , respectively. The *K*M and *V*max of V2O5 nanozymes with H2O2 are 0.232 mM and 1.29 ˆ 10´5 M¨ s ´1 , respectively. The *K*cat of V2O5 nanozymes with TMB and H2O2 are 18.46 s´1 and 12.91 s´1 , respectively, and the *K*cat/*K*M values of V2O5 nanozymes with TMB and H2O2 are 25.02 mM´1 ¨ s ´1 and 55.55 mM´1 ¨ s ´1 , respectively. The *K*M values show that V2O5 nanozymes have higher affinity for hydrogen peroxide compared with HRP, but less affinity to TMB compared with HRP. The apparent Km value of V2O5 nanozymes with TMB as the substrate was higher than that for HRP, consistent with the observation that a higher TMB concentration was required to achieve the maximal activity for V2O5 nanozymes. The apparent *K*M value of V2O5 nanozymes with H2O2 as the substrate was significantly lower than HRP and Fe3O4 MNPs. From the Table data, it can be concluded that the V2O5 nanozymes have a higher activity than HRP and Fe3O4 MNPs.

<DESCRIPTION_FROM_IMAGE>The image contains two main graphs labeled (a) and (b), each with an inset graph. I will describe each graph in detail.

Graph (a):
The main graph shows the relationship between Absorbance (y-axis) and [H2O2] concentration in mM (x-axis). The absorbance ranges from 0 to 2.5, while the [H2O2] concentration ranges from 0 to 7 mM. The curve shows a non-linear relationship, starting at the origin and increasing rapidly at first, then gradually leveling off as it approaches an absorbance of about 2.3. There are several data points plotted on the curve.

The inset graph in (a) shows 1/A (reciprocal of absorbance) on the y-axis versus 1/[H2O2] (mM) on the x-axis. The 1/A values range from 0 to 14, while 1/[H2O2] ranges from 0 to 45 mM^-1. This graph appears to be a linearization of the main graph, showing a roughly linear relationship between the reciprocal values.

Graph (b):
The main graph shows the relationship between Absorbance (y-axis) and [TMB] concentration in mM (x-axis). The absorbance ranges from 0 to 0.5, while the [TMB] concentration ranges from 0 to 0.8 mM. The curve shows a non-linear relationship, starting at the origin and increasing with a decreasing slope as [TMB] increases. There are several data points plotted on the curve.

The inset graph in (b) shows 1/A (reciprocal of absorbance) on the y-axis versus 1/[TMB] (mM) on the x-axis. The 1/A values range from 0 to 16, while 1/[TMB] ranges from 0 to 20 mM^-1. This graph appears to be a linearization of the main graph, showing a linear relationship between the reciprocal values.

Both graphs (a) and (b) seem to represent enzyme kinetics studies, possibly showing substrate concentration effects on reaction rates. The main graphs likely represent Michaelis-Menten kinetics, while the inset graphs are likely Lineweaver-Burk plots used for determining kinetic parameters such as Km and Vmax.</DESCRIPTION_FROM_IMAGE>

<span id="page-5-0"></span>*Sensors* **2016**, *16*, 584 6 of 10

<span id="page-5-1"></span>**Figure 6.** Steady-state kinetic assay and catalytic mechanism of V2O5 nanozymes as peroxidase mimic. **Figure 6.** Steady-state kinetic assay and catalytic mechanism of V2O5 nanozymes as peroxidase mimic.

|                                    |                              | Vmax (M·s−1)                         |
|------------------------------------|------------------------------|--------------------------------------|
| Substrate<br>V2O5 nanozymes<br>TMB | KM (mM)<br>0.738             | ´1<br>Vmax (M¨ s<br>)<br>1.85 × 10−5 |
| V2O5 nanozymes<br>H2O2<br>TMB      | 0.232<br>0.738               | 1.29 × 10−5<br>1.85 ˆ 10´5           |
| TMB                                | 0.434<br>0.232               | 10.00 × 10−8<br>1.29 ˆ 10´5          |
| H2O2<br>TMB                        | 154<br>0.434                 | 10.00 ˆ 10´8<br>9.78 × 10−8          |
| TMB                                | 0.434<br>154                 | 9.78 ˆ 10´8<br>1.24 × 10−8           |
| TMB                                | 0.434                        | 1.24 ˆ 10´8<br>2.46 × 10−8           |
|                                    | 3.70                         | 2.46 ˆ 10´8                          |
|                                    | H2O2<br>H2O2<br>H2O2<br>H2O2 | Substrate<br>KM (mM)<br>3.70         |

**Table 1.** Comparison of the Km and Vmax of V2O5 nanozymes, Fe3O4 MNPs, and HRP. **Table 1.** Comparison of the Km and Vmax of V2O5 nanozymes, Fe3O4 MNPs, and HRP.

correlations of absorbance intensity with all H2O2 concentrations were obtained at 660 nm for TMB substrate and 450 nm for OPD substrate. There relationships between the absorbance intensities and the concentrations of H2O2 are linear over the range of 0–10 mM (TMB), and 0–0.2 M (OPD) with Under the optimized reaction conditions, calibration curves of H2O2 were plotted (Figure [7)](#page-6-0). The correlations of absorbance intensity with all H2O2 concentrations were obtained at 660 nm for TMB substrate and 450 nm for OPD substrate. There relationships between the absorbance intensities

correlation coefficients 0.9996 (*p* < 0.05) and 0.9788 (*p* < 0.05), respectively. The results show that TMB as substrate exhibited a better response. It is supposed that the maximum absorbance peak of the oxidation of OPD is nearly equal to that of V2O5 nanozymes, so the absorbance peak of V2O5 interferes

Under the optimized reaction conditions, calibration curves of H2O2 were plotted (Figure 7). The

and the concentrations of H2O2 are linear over the range of 0–10 mM (TMB), and 0–0.2 M (OPD) with correlation coefficients 0.9996 (*p* < 0.05) and 0.9788 (*p* < 0.05), respectively. The results show that TMB as substrate exhibited a better response. It is supposed that the maximum absorbance peak of the oxidation of OPD is nearly equal to that of V2O5 nanozymes, so the absorbance peak of V2O5 interferes with the H2O2 sensing. The limit of detection (3σ, LOD) is 1 µM. In addition, the analytical performance of V2O5 nanozymes as peroxidase mimetics was compared with other nanozymes, as summarized in Table [2.](#page-7-0) By comparing with other nanozymes, it was revealed that the sensor has a wider linear range and higher sensitivity. *Sensors* **2016**, *16*, 584 7 of 10 with the H2O2 sensing. The limit of detection (3σ, LOD) is 1 μM. In addition, the analytical performance of V2O5 nanozymes as peroxidase mimetics was compared with other nanozymes, as summarized in Table 2. By comparing with other nanozymes, it was revealed that the sensor has a wider linear range and higher sensitivity.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (a) and (b), both showing the relationship between absorbance and hydrogen peroxide concentration [H2O2].

Graph (a):
- Main plot: X-axis shows [H2O2] in μM, ranging from 0 to 500 μM. Y-axis shows absorbance, ranging from 0 to 0.7.
- The data points form a linear trend with a very high correlation coefficient (R=0.9996).
- The linear fit (red line) passes through most data points, indicating a strong linear relationship.
- Error bars are visible on some data points, particularly noticeable for the point around 300 μM.
- Inset plot: Shows the same relationship over a wider range of [H2O2] (0 to 10000 μM). The trend appears to become non-linear at higher concentrations.

Graph (b):
- Main plot: X-axis shows [H2O2] in μM, ranging from 0 to 1000 μM. Y-axis shows absorbance, ranging from 0 to 0.18.
- The data points follow a linear trend, but with more scatter than in graph (a). The correlation coefficient is R=0.9788.
- Error bars are visible on several data points, particularly for higher concentrations.
- The linear fit (red line) doesn't pass through all data points as closely as in graph (a), suggesting more variability in the measurements.
- Inset plot: Shows the same relationship over a wider range of [H2O2] (0 to 200000 μM). The trend appears to plateau at higher concentrations.

Both graphs demonstrate a linear relationship between absorbance and [H2O2] at lower concentrations, with graph (a) showing a stronger correlation. The inset plots in both cases reveal non-linear behavior at higher concentrations, suggesting a saturation effect or limitation in the measurement technique at elevated [H2O2] levels.</DESCRIPTION_FROM_IMAGE>

**Figure 7.** Linear calibration plot for H2O2 from 1 to 500 μM in, pH 4.0, 0.2 M NaOAc-HOAc buffers, with TMB (**a**) and OPD (**b**) respectively (*p* < 0.05). The inset shows dependence of the absorbance on the concentration of H2O2. **Figure 7.** Linear calibration plot for H2O2 from 1 to 500 µM in, pH 4.0, 0.2 M NaOAc-HOAc buffers, with TMB (**a**) and OPD (**b**) respectively (*p* < 0.05). The inset shows dependence of the absorbance on the concentration of H2O2 .

| Table 2. Comparison of analytical performance for H2O2 detection of various nanozymes.<br>Nanozymes | Linear Range  | Limit of Detection | Ref.      |
|-----------------------------------------------------------------------------------------------------|---------------|--------------------|-----------|
| Nanozymes                                                                                           | Linear Range  | Limit of Detection | Ref.      |
| H4SiW12O40                                                                                          | 1–20 µM       | 0.4 µM             | [31]      |
| H4SiW12O40                                                                                          | 1–20 μM       | 0.4 μM             | [31]      |
| H3PW12O40                                                                                           | 0.134–67 µM   | 0.134 µM           | [32]      |
| H3PW12O40                                                                                           | 0.134–67 μM   | 0.134 μM           | [32]      |
| Fe3O4 MNPs                                                                                          | 1–100 µM      | 0.5 µM             | [33]      |
| Fe3O4 MNPs                                                                                          | 1–100 μM      | 0.5 μM             | [33]      |
| Pt-DNA complexes                                                                                    | 0.979–17.6 mM | 0.392 mM           | [34]      |
| Pt-DNA complexes                                                                                    | 0.979–17.6 mM | 0.392 mM           | [34]      |
| HRP                                                                                                 | 1–60 µM       | 1 µM               | [35]      |
| HRP                                                                                                 | 1–60 μM       | 1 μM               | [35]      |
| V2O5 nanozymes                                                                                      | 1–500 µM      | 1 µM               | This work |
| V2O5 nanozymes                                                                                      | 1–500 μM      | 1 μM               | This work |

<span id="page-7-0"></span>**Table 2.** Comparison of analytical performance for H2O2 detection of various nanozymes. *Sensors* **2016**, *16*, 584 8 of 10

#### *3.7. Calibration Curve for Glucose Detection 3.7. Calibration Curve for Glucose Detection*

It is well known that glucose oxidase (GOx) catalyzes the oxidation of glucose to gluconolactone and this property has been developed for the fabrication of glucose sensors with high sensitivity and selectivity. Due to the fact that GOx would be denatured in pH 4.0 buffer, the glucose detection was performed in two separate steps as mentioned in the Methods section. The inset of Figure [8](#page-7-1) shows the dependence of the absorbance at 660 nm on the concentration of glucose from 0 to 4 mM. The corresponding calibration plot was shown in Figure [8.](#page-7-1) The linear detection range is from 10 to 2000 µM with the correlation coefficients, 0.9959 (*p* < 0.05). The limit of detection (3σ, LOD) is 10 µM. It is well known that glucose oxidase (GOx) catalyzes the oxidation of glucose to gluconolactone and this property has been developed for the fabrication of glucose sensors with high sensitivity and selectivity. Due to the fact that GOx would be denatured in pH 4.0 buffer, the glucose detection was performed in two separate steps as mentioned in the Methods section. The inset of Figure 8 shows the dependence of the absorbance at 660 nm on the concentration of glucose from 0 to 4 mM. The corresponding calibration plot was shown in Figure 8. The linear detection range is from 10 to 2000 μM with the correlation coefficients, 0.9959 (*p* < 0.05). The limit of detection (3σ, LOD) is 10 μM.

<span id="page-7-1"></span>Using this method, glucose was detected in patients' blood samples. According to the linear calibration curve, the concentration of glucose in the diabetic blood sample is 15.396 mM. The general range of random plasma glucose concentration in diabetic persons is more than 11.1 mM. Therefore, this colorimetric method is applicable to real samples to determine glucose concentration. Using this method, glucose was detected in patients' blood samples. According to the linear calibration curve, the concentration of glucose in the diabetic blood sample is 15.396 mM. The general range of random plasma glucose concentration in diabetic persons is more than 11.1 mM. Therefore, this colorimetric method is applicable to real samples to determine glucose concentration.

<DESCRIPTION_FROM_IMAGE>The image presents a calibration curve for glucose concentration measurement using absorbance spectroscopy. The main graph shows the relationship between glucose concentration (x-axis) and absorbance (y-axis). The x-axis ranges from 0 to 2.0 mM of glucose, while the y-axis ranges from 0 to 0.45 absorbance units.

The data points are represented by black squares with error bars. A red line represents the linear fit of the data. The correlation coefficient (R) is given as 0.9959, indicating a strong linear relationship between glucose concentration and absorbance.

The graph demonstrates a clear linear increase in absorbance as glucose concentration increases. The equation of the line is not provided, but can be inferred from the data points.

An inset graph is present in the lower right corner, showing the same data on different scales. The x-axis of the inset graph is labeled as "[Glucose] (mM)" and ranges from 0 to 5 mM. The y-axis represents absorbance and ranges from 0 to 0.50 units. This inset provides a wider view of the data, including higher glucose concentrations.

The main graph focuses on the linear range of the calibration curve, while the inset shows the potential deviation from linearity at higher concentrations.

This calibration curve can be used to determine unknown glucose concentrations in samples by measuring their absorbance and interpolating from the linear relationship established in this graph.

The high R-value suggests that this method provides a reliable means of quantifying glucose concentrations within the range shown on the main graph (0-2.0 mM).</DESCRIPTION_FROM_IMAGE>

**Figure 8.** Linear calibration plot for glucose from 10 to 2000 μM (*p* < 0.05). The inset shows dependence of the absorbance on the concentration of glucose in the range from 0 to 4 mM. **Figure 8.** Linear calibration plot for glucose from 10 to 2000 µM (*p* < 0.05). The inset shows dependence of the absorbance on the concentration of glucose in the range from 0 to 4 mM.

#### **4. Conclusions 4. Conclusions**

In summary, a new V2O5 nanozymes-based colorimetric assay has been developed for H2O2 and glucose detection. Under the optimal reaction conditions, the method showed good responses toward H2O2 with a linear range from 1 to 500 μM. The LOD value is 1 μM. Determination of glucose was achieved from 10 to 2000 μM with a LOD of 10 μM. The result shows that the proposed assay method for H2O2 and glucose based on V2O5 nanozymes has a wide linear range, and is simple, fast, and sensitive. In summary, a new V2O5 nanozymes-based colorimetric assay has been developed for H2O2 and glucose detection. Under the optimal reaction conditions, the method showed good responses toward H2O2 with a linear range from 1 to 500 µM. The LOD value is 1 µM. Determination of glucose was achieved from 10 to 2000 µM with a LOD of 10 µM. The result shows that the proposed assay method for H2O2 and glucose based on V2O5 nanozymes has a wide linear range, and is simple, fast, and sensitive.

**Acknowledgments:** This work was financially supported by NSFC (81402719), Norman Bethune Program of Jilin University (2015228), and Young Scholars Program of Norman Bathune Health Science Center of Jilin University (2013202015).

**Author Contributions:** Yanfei Qi conceived and designed the experiments; Jiaheng Sun performed the experiments; Jiaheng Sun analyzed the data; Yanfei Qi contributed reagents/materials/analysis tools; Jiaheng Sun, Shuanli Guo, Chunyan Li, Xue Liang and Yanfei Qi wrote the paper.

**Conflicts of Interest:** The authors declare no conflict of interest. The funding sponsors had no role in the design of the study; in the collection, analyses, or interpretation of data; in the writing of the manuscript, and in the decision to publish the results.

### **Abbreviations**

| GOx  | glucose oxidase                        |
|------|----------------------------------------|
| HRP  | horseradish peroxidase                 |
| OPD  | o-phenylenediamine                     |
| TMB  | 3,31<br>,5,51<br>-tetramethylbenzidine |
| LOD  | limit of detection                     |
| Vmax | maximum initial velocity               |
| Km   | Michaelis-Menten constant              |
|      |                                        |

## **References**

- <span id="page-8-0"></span>1. Wei, H.; Wang, E.K. Nanomaterials with enzyme-like characteristics (nanozymes): Next-generation artificial enzymes. *Chem. Soc. Rev.* **2013**, *42*, 6060–6093. [\[CrossRef\]](http://dx.doi.org/10.1039/c3cs35486e) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/23740388)
- <span id="page-8-1"></span>2. Gao, L.Z.; Zhuang, J.; Nie, L.; Zhang, J.B.; Zhang, Y.; Gu, N.; Wang, T.H.; Feng, J.; Yang, D.; Perrete, S.; *et al.* Intrinsic peroxidase-like activity of ferromagnetic nanoparticles. *Nat. Nanotechnol.* **2007**, *2*, 577–583. [\[CrossRef\]](http://dx.doi.org/10.1038/nnano.2007.260) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/18654371)
- <span id="page-8-2"></span>3. Perez, J.M. Iron oxide nanoparticles: Hidden talent. *Nat. Nanotechnol.* **2007**, *2*, 535–536. [\[CrossRef\]](http://dx.doi.org/10.1038/nnano.2007.282) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/18654361)
- <span id="page-8-3"></span>4. Comotti, M.; Pina, C.D.; Matarrese, R.; Rossi, M. The Catalytic Activity of "Naked" Gold Particles. *Angew. Chem. Int. Ed.* **2004**, *43*, 5812–5815. [\[CrossRef\]](http://dx.doi.org/10.1002/anie.200460446) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/15523721)
- <span id="page-8-4"></span>5. Pirmohamed, T.; Dowding, J.M.; Singh, S.; Wasserman, B.; Heckert, E.; Karakoti, A.S.; King, J.E.S.; Seal, S.; Self, W.T. Nanoceria exhibit redox state-dependent catalase mimetic activity. *Chem. Commun.* **2010**, *46*, 2736–2738. [\[CrossRef\]](http://dx.doi.org/10.1039/b922024k) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/20369166)
- <span id="page-8-5"></span>6. Mu, J.S.; Wang, Y.; Zhao, M.; Zhang, L. Intrinsic peroxidase-like activity and catalase-like activity of Co3O4 nanoparticles. *Chem. Commun.* **2012**, *48*, 2540–2542. [\[CrossRef\]](http://dx.doi.org/10.1039/c2cc17013b) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/22288077)
- <span id="page-8-6"></span>7. Yin, J.F.; Cao, H.Q.; Lu, Y.X. Self-assembly into magnetic Co3O4 complex nanostructures as peroxidase. *J. Mater. Chem.* **2012**, *22*, 527–534. [\[CrossRef\]](http://dx.doi.org/10.1039/C1JM14253D)
- <span id="page-8-7"></span>8. Chen, W.; Chen, J.; Feng, Y.B.; Hong, L.; Chen, Q.Y.; Wu, L.F.; Lin, X.H.; Xia, X.H. Peroxidase-like activity of water-soluble cupric oxide nanoparticles and its analytical application for detection of hydrogen peroxide and glucose. *Analyst* **2012**, *137*, 1706–1712. [\[CrossRef\]](http://dx.doi.org/10.1039/c2an35072f) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/22349179)
- <span id="page-8-8"></span>9. Wan, Y.; Qi, P.; Zhang, D.; Wu, J.J.; Wang, Y. Manganese oxide nanowire-mediated enzyme-linked immunosorbent assay. *Biosens. Bioelectron.* **2012**, *33*, 69–74. [\[CrossRef\]](http://dx.doi.org/10.1016/j.bios.2011.12.033) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/22326701)
- <span id="page-8-9"></span>10. André, R.; Natálio, F.; Humanes, M.; Leppin, J.; Heinze, K.; Wever, R.; Schröder, H.-C.; Müller, W.E.G.; Tremel, W. V2O5 Nanowires with an Intrinsic Peroxidase-Like Activity. *Adv. Funct. Mater.* **2011**, *21*, 501–509. [\[CrossRef\]](http://dx.doi.org/10.1002/adfm.201001302)
- <span id="page-8-10"></span>11. Shi, W.B.; Wang, Q.L.; Long, Y.J.; Cheng, Z.L.; Chen, S.H.; Zheng, H.Z.; Huang, Y.M. Carbon nanodots as peroxidase mimetics and their applications to glucose detection. *Chem. Commun.* **2011**, *7*, 6695–6697. [\[CrossRef\]](http://dx.doi.org/10.1039/c1cc11943e) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/21562663)
- <span id="page-8-11"></span>12. Song, Y.J.; Qu, K.G.; Zhao, C.; Ren, J.S.; Qu, X.G. Graphene Oxide: Intrinsic Peroxidase Catalytic Activity and Its Application to Glucose Detection. *Adv. Mater.* **2010**, *22*, 2206–2210. [\[CrossRef\]](http://dx.doi.org/10.1002/adma.200903783) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/20564257)
- <span id="page-8-12"></span>13. Wei, H.; Wang, E. Fe3O4 magnetic nanoparticles as peroxidase mimetics and their applications in H2O2 and glucose detection. *Anal. Chem.* **2008**, *80*, 2250–2254. [\[CrossRef\]](http://dx.doi.org/10.1021/ac702203f) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/18290671)

- <span id="page-9-0"></span>14. Jv, Y.; Li, B.X.; Cao, R. Positively-charged gold nanoparticles as peroxidiase mimic and their application in hydrogen peroxide and glucose detection. *Chem. Commun.* **2010**, *46*, 8017–8019. [\[CrossRef\]](http://dx.doi.org/10.1039/c0cc02698k) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/20871928)
- <span id="page-9-1"></span>15. Tao, Y.; Ju, E.G.; Ren, J.S.; Qu, X.G. Polypyrrole nanoparticles as promising enzyme mimics for sensitive hydrogen peroxide detection. *Chem. Commun.* **2014**, *50*, 3030–3032. [\[CrossRef\]](http://dx.doi.org/10.1039/c4cc00328d) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/24504489)
- <span id="page-9-2"></span>16. Ludwig, H.R.; Cairelli, S.G.; Whalen, J.J. *Documentation for Immediately Dangerous to Life or Health Concentrations (IDLHs)*; National Institute for Occupational Safety and Health: Washington, DC, USA, 1994.
- <span id="page-9-3"></span>17. Nagaraja, P.; Shivakumar, A.; Shrestha, A.K. Quantification of hydrogen peroxide and glucose using 3-methyl-2-benzothiazolinonehydrazone hydrochloride with 10,11-dihydro-5H-benz(b,f)azepine as chromogenic probe. *Anal. Biochem.* **2009**, *395*, 231–236. [\[CrossRef\]](http://dx.doi.org/10.1016/j.ab.2009.07.053) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/19686697)
- <span id="page-9-4"></span>18. Chang, Q.; Tang, H.Q. Optical determination of glucose and hydrogen peroxide using a nanocomposite prepared from glucose oxidase and magnetite nanoparticles immobilized on graphene oxide. *Microchim. Acta.* **2014**, *181*, 527–534. [\[CrossRef\]](http://dx.doi.org/10.1007/s00604-013-1145-x)
- <span id="page-9-5"></span>19. Guilbault, G.G.; Brignac, P.J.; Zimmer, M. Homovanillic acid as a fluorometric substrate for oxidative enzymes. Analytical applications of the peroxidase, glucose oxidase, and xanthine oxidase systems. *Anal. Chem.* **1968**, *40*, 190–196. [\[CrossRef\]](http://dx.doi.org/10.1021/ac60257a002) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/5634544)
- 20. Lan, D.; Li, B.X.; Zhang, Z.J. Chemiluminescence flow biosensor for glucose based on gold nano particle-enhanced activities of glucose oxidase and horseradish peroxidase. *Biosens. Bioelectron.* **2008**, *24*, 934–938. [\[CrossRef\]](http://dx.doi.org/10.1016/j.bios.2008.07.064) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/18783937)
- 21. Chang, Q.; Zhu, L.H.; Jiang, G.D.; Tang, H.Q. Sensitive fluorescent probes for determination of hydrogen peroxide and glucose based on enzyme-immobilized magnetite/silica nanoparticles. *Anal. Bioanal. Chem.* **2009**, *395*, 2277–2385. [\[CrossRef\]](http://dx.doi.org/10.1007/s00216-009-3118-9) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/19777218)
- <span id="page-9-6"></span>22. Fink, D.; Klinkovich, I.; Bukelman, O.; Marks, R.S.; Kiv, A.; Fuks, D.; Fahrner, W.R.; Alfonta, L. Glucose determination using a re-usable enzyme-modified ion track membrane sensor. *Biosens. Bioelectron.* **2009**, *24*, 2702–2706. [\[CrossRef\]](http://dx.doi.org/10.1016/j.bios.2008.12.001) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/19138511)
- <span id="page-9-7"></span>23. Lin, J.M.; Arakawa, H.; Yamada, M. Flow injection chemiluminescent determination of trace amounts of hydrogen peroxide in snow-water using KIO4–K2CO3 system. *Anal. Chim. Acta* **1998**, *371*, 171–176. [\[CrossRef\]](http://dx.doi.org/10.1016/S0003-2670(98)00304-3)
- <span id="page-9-8"></span>24. Li, Y.Z.; Townshend, A. Evaluation of the adsorptive immobilisation of horseradish peroxidase on PTFE tubing in flow systems for hydrogen peroxide determination using fluorescence detection. *Anal. Chim. Acta* **1998**, *359*, 149–156. [\[CrossRef\]](http://dx.doi.org/10.1016/S0003-2670(97)00710-1)
- <span id="page-9-9"></span>25. Xu, J.R.; Chen, Z.M. Determination of Peroxides in Environmental Samples by High Performance Liquid Chromatography. *Chin. J. Chromatogr.* **2005**, *23*, 366–369.
- <span id="page-9-10"></span>26. Wang, C.H.; Yang, C.; Song, Y.Y.; Gao, W.; Xia, X.H. Adsorption and Direct Electron Transfer from Hemoglobin into a Three-Dimensionally Ordered Macroporous Gold Film. *Adv. Funct. Mater.* **2005**, *15*, 1267–1275. [\[CrossRef\]](http://dx.doi.org/10.1002/adfm.200500048)
- <span id="page-9-11"></span>27. Tarpey, M.M.; Wink, D.A.; Grisham, M.B. Methods for detection of reactive metabolites of oxygen and nitrogen: *In vitro* and *in vivo* considerations. *Am. J. Physiol. Regul. Integr. Comp. Physiol.* **2004**, *286*, R431–R444. [\[CrossRef\]](http://dx.doi.org/10.1152/ajpregu.00361.2003) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/14761864)
- <span id="page-9-12"></span>28. Ozalp, V.C.; Zeydanli, U.S.; Lunding, A.; Kavruk, M.; Oz, M.T.; Eyidogan, F.; Olsen, L.F.; Oktem, H.A. Nanoparticle embedded enzymes for improved lateral flow sensors. *Analyst* **2013**, *138*, 4255–4259. [\[CrossRef\]](http://dx.doi.org/10.1039/c3an00733b) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/23730687)
- <span id="page-9-13"></span>29. Shoji, E.; Freund, M.S. Potentiometric sensors based on the inductive effect on the pK(a) of poly(aniline): A nonenzymatic glucose sensor. *J. Am. Chem. Soc.* **2001**, *123*, 3383–3384. [\[CrossRef\]](http://dx.doi.org/10.1021/ja005906j) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/11457081)
- <span id="page-9-14"></span>30. Zhou, F.; Zhao, X.M.; Yuan, C.G.; Li, L. Vanadium Pentoxide Nanowires: Hydrothermal Synthesis, Formation Mechanism, and Phase Control Parameters. *Cryst. Growth Des.* **2008**, *8*, 723–727. [\[CrossRef\]](http://dx.doi.org/10.1021/cg060816x)
- <span id="page-9-15"></span>31. Liu, S.; Tian, J.Q.; Wang, L.; Zhang, Y.W.; Luo, Y.L.; Li, H.Y.; Asiri, A.M.; Al-Youbi, A.O.; Sun, X. Fast and Sensitive Colorimetric Detection of H2O2 and Glucose: A Strategy Based on Polyoxometalate Clusters. *Chempluschem* **2012**, *77*, 541–544. [\[CrossRef\]](http://dx.doi.org/10.1002/cplu.201200051)
- <span id="page-9-16"></span>32. Wang, J.J.; Han, D.X.; Wang, X.H.; Qi, B.; Zhao, M.S. Polyoxometalates as peroxidase mimetics and their applications in H2O2 and glucose detection. *Biosens. Bioelectron.* **2012**, *36*, 18–21. [\[CrossRef\]](http://dx.doi.org/10.1016/j.bios.2012.03.031) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/22560441)
- <span id="page-9-17"></span>33. Kim, M.I.; Shim, J.; Li, T.; Lee, J.; Park, H.G. Fabrication of Nanoporous Nanocomposites Entrapping Fe3O4 Magnetic Nanoparticles and Oxidases for Colorimetric Biosensing. *Chem. Eur. J.* **2011**, *17*, 10700–10707. [\[CrossRef\]](http://dx.doi.org/10.1002/chem.201101191) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/21837719)

- <span id="page-10-0"></span>34. Chen, X.; Zhou, X.D.; Hu, J. Pt-DNA complexes as peroxidase mimetics and their applications in colorimetric
- <span id="page-10-1"></span>detection of H2O2 and glucose. *Anal. Methods* **2012**, *4*, 2183–2187. [\[CrossRef\]](http://dx.doi.org/10.1039/c2ay25250c) 35. Edgar, P.; Yona, K. A Simple Colorimetric Method for the Measurement of Hydrogen Peroxide Produced by Cells in Culture. *J. Immunol. Methods* **1980**, *38*, 161–170.

<DESCRIPTION_FROM_IMAGE>This image depicts a Creative Commons license badge. It contains two circular icons side by side on a rectangular background:

1. On the left is the standard Creative Commons "CC" logo, consisting of two interlocking C letters.

2. On the right is an "i" icon, typically used to represent information or attribution.

This specific combination indicates a Creative Commons Attribution license (CC BY). This license allows others to distribute, remix, adapt, and build upon the work, even commercially, as long as they credit the original creator.

While this image is relevant to licensing and copyright information, it does not contain any specific chemistry-related content or scientific data. Therefore, in the context of chemistry or scientific articles, this would be considered an ABSTRACT_IMAGE.</DESCRIPTION_FROM_IMAGE>

© 2016 by the authors; licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC-BY) license [(http://creativecommons.org/licenses/by/4.0/)](http://creativecommons.org/licenses/by/4.0/).