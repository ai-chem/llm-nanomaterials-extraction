This image is a composite of several microscopy and spectroscopy results, labeled from (a) to (f), providing detailed characterization of gold-platinum (Au-Pt) nanoparticles.

(a) Scanning electron microscopy (SEM) image showing spherical nanoparticles with a scale bar of 20 nm. The particles appear to have a rough surface texture.

(b) Energy-dispersive X-ray spectroscopy (EDS) mapping of the nanoparticles. The main image shows a composite of Au and Pt signals, with Au appearing yellow and Pt appearing purple. Two inset images show the individual elemental maps for Au and Pt separately. Scale bar is 100 nm.

(c) Transmission electron microscopy (TEM) image of the nanoparticles with a 50 nm scale bar. An inset graph shows size distribution data for the Au core and whole nanoparticle (NP). The Au core size ranges from about 20-30 nm, while the whole NP size ranges from about 40-60 nm.

(d) X-ray diffraction (XRD) pattern of the nanoparticles. The graph shows intensity vs. 2θ (degrees) from 20° to 90°. Peaks are labeled with Miller indices for Au (red dots) and Pt (black dots). Reference patterns for Au and Pt are shown below the main graph.

(e) X-ray photoelectron spectroscopy (XPS) spectrum for the Pt 4f region. The binding energy range is 84-70 eV. The spectrum shows peaks for Pt 4f7/2 and Pt 4f5/2, with contributions from Pt⁰ and Pt²⁺ oxidation states. An inset graph shows the etching time vs. atomic percentage of Pt and Au.

(f) XPS spectrum for the Au 4f region. The binding energy range is 90-82 eV. The spectrum shows peaks corresponding to Au⁰.

This comprehensive characterization provides information on the size, structure, composition, and chemical state of the Au-Pt nanoparticles.