## RSC Advances

## 

Cite this: RSC Adv., 2017, 7, 52210

Received 18th September 2017 Accepted 6th November 2017

DOI: 10.1039/c7ra10370k

rsc.li/rsc-advances

### Introduction

Natural enzymes, which have efficient catalytic activity and substrate specicity under mild conditions, are the true biocatalysts mediating each biological process in living organisms. They are able to accelerate chemical reactions up to 1019 times for specic substrates and reactions and have been commercially used in various areas such as sewage treatment, textile nishing, household product preparation, and energy conversion.1–5 However, the widespread practical applications of natural enzymes have been severely hampered by their intrinsic drawbacks, i.e., low stability, high costs in preparation, difficulty in purication, and high sensitivity of catalytic activity to environments. Therefore, a lot of efforts have been made to extend the natural enzymes to enzyme mimetics.6–8

As a promising candidate for articial enzymes, nanomaterials with intrinsic enzyme-like activity known as nanozymes ignite intensive research interest due to their ability to replace specic enzymes in enzyme-based applications.9–13 The design and development of novel nanostructured materials mimicking the catalytic role of natural enzymes has emerged as a promising eld for both fundamental and applied research. Since the discovery by Yan and coworkers that Fe3O4 nanoparticles possess intrinsic peroxidase-

# Mimicking horseradish peroxidase and oxidase using ruthenium nanomaterials† **[View Article Online](http://dx.doi.org/10.1039/c7ra10370k) [View Journal](http://pubs.rsc.org/en/journals/journal/RA) [| View Issue](http://pubs.rsc.org/en/journals/journal/RA?issueid=RA007082)**

Gao-Juan Cao,ab Xiumei Jiang,b Hui Zhang,b Timothy R. Croleyb and Jun-Jie Yin *b

Although important progress has been achieved for the study of noble metal-based enzyme-like catalysts, there are rare reports on the enzyme mimicking applications of ruthenium nanoparticles (Ru NPs). In this work, we investigated the horseradish peroxidase (HRP) and oxidase mimetic activity of Ru NPs. Mimicking HRP, Ru NPs could catalyze the oxidation of substrates 3,3,5,5-tetramethylbenzidine (TMB), o-phenylenediamine (OPD) and dopamine hydrochloride (DA) in the presence of exogenously added H2O2 to generate the products with blue, yellow and orange colors, respectively. We also report the first evidence that Ru NPs possess intrinsic oxidase-like activity, which could catalyze the oxidization of TMB and sodium L-ascorbate (NaA) by dissolved oxygen. The HRP-like and oxidase-like activities of Ru NPs were found to be related to the concentrations of Ru NPs. The catalytic mechanism was analyzed by electron spin resonance spectroscopy (ESR), which suggested that the enzyme mimicking activities of the Ru NPs might originate from their characteristic of accelerating electron transfer between substrates and H2O2 or O2. Our findings offer a better understanding of enzyme-mimicking Ru NPs and should provide important insights for future applications.

> like activity and show potential to replace natural peroxidase in bioassays,14 substantial research is directed toward the development of nanomaterial catalysts that mimic functions of peroxidase, oxidase or other natural enzymes with the advantages of low cost, controlled synthesis, tunable catalytic activities, and high stability even under severe reaction conditions. Till now, a variety of nanoscale materials have been developed as the efficient enzyme alternatives15–29 and their diverse applications cover from sensing, imaging, and therapeutics, to pollutant removal, water treatment and beyond.30–32 Among these, much work is centered on the noble metal-based nanozymes, particularly gold, platinum, palladium, and iridium, because of their well-developed synthesis techniques, easy modication of surface, excellent catalytic activity, good bio-compatibility and so on.33–48 For instance, gold nanoparticles with different surface modications or their combined nanomaterials have been reported to demonstrate different enzyme-like activities. Platinum nanostructures are outstanding catalysts and have been found to possess diverse functional activities similar to peroxidase, catalase, superoxide dismutase, polyphenol oxidase, ascorbate oxidase and ferroxidase.

> Compared with other noble metal-based enzyme mimics, there is a large space for us to explore the potential of Ru NPs as nanozymes, which is limited by the relatively less research activities. Recently, Ru nanoframes are found to show peroxidase-like properties for the rst time.49 Very recently, our group reported that Ru NPs have catalase-like and superoxide dismutase-like activities by scavenging hydrogen peroxide and superoxide, which may play important roles in maintaining redox balance in living organisms by scavenging excess reactive oxygen species.50 In this work, we discovered that Ru NPs

PAPER

a Department of Applied Chemistry, College of Life Sciences, Fujian Agriculture and Forestry University, Fuzhou, Fujian 350002, China

b Division of Analytical Chemistry, Office of Regulatory Science, Center for Food Safety and Applied Nutrition, U.S. Food and Drug Administration, College Park, Maryland 20740, USA. E-mail: junjie.yin@fda.hhs.gov

<sup>†</sup> Electronic supplementary information (ESI) available: Scheme, table and gures. See DOI: 10.1039/c7ra10370k

possess intrinsic HRP-like and oxidase-like mimetic activities. The Ru NPs could catalyze the oxidation of the substrates 3,3,5,5-tetramethylbenzidine (TMB), o-phenylenediamine (OPD) and dopamine hydrochloride (DA) by H2O2 to produce the color products in aqueous solution. More interestingly, we found that Ru NPs could catalyze the oxidation of the colorless substrate TMB to the blue-colored product in the absence of H2O2. This study also demonstrated that the Ru NPs mimicking ascorbic acid oxidase (AAO) can oxidize NaA under ambient condition, as measured by using both UV-vis and ESR spectroscopy. It was speculated that the nature of enzyme mimicking activities of Ru NPs were attributed to their ability of facilitating electron transfer between substrates and H2O2 or O2. **[View Article Online](http://dx.doi.org/10.1039/c7ra10370k)**

### Experimental

### Chemicals and materials

All chemicals were from commercial suppliers without further purication unless otherwise mentioned. Ruthenium nanopowder (Ru NPs, 20–30 nm) was purchased from US Research Nanomaterials Inc. (Houston, TX). Hydrogen peroxide (H2O2, 30%), horseradish peroxidase (HRP), ascorbate oxidase (AAO), 3,3,5,5-tetramethylbenzidinedihydrochloride (TMB\$2HCl), ophenylenediamine (OPD), dopamine hydrochloride (DA), sodium L-ascorbate (NaA), 3-carbamoyl-2,5-dihydro-2,2,5,5-tetramethyl-1H-pyrrol-1-yloxyl (CTPO) were all purchased from Sigma-Aldrich (St. Louis, MO). 5-tert-Butoxycarbonyl-5-methyl-1-pyrroline-N-oxide (BMPO) was purchased from Bioanalytical Labs (Sarasota, FL). 5,5-Dimethyl-1-pyrroline-N-oxide (DMPO) was obtained from Dojindo Molecular Technologies, Inc. (Rockville, MD). PBS 7.4 buffer, 1-hydroxy-3-carboxy-2,2,5,5 tetramethylpyrrolidine hydrochloride (CPH) were obtained from Enzo Life Sciences (Farmingdale, NY). The concentration of buffer stock solution (pH 1.12 HCl–KCl, pH 3.2 HAc–NaAc, pH 10.96 KOH–KCl) was 0.1 M.

#### Characterization

The hydrodynamic size (dynamic light scattering, DLS) and surface charge (zeta potential, mV) were detected using a Zeta-Sizer Nano series Nano-ZS (Malvern, UK). Scanning electron microscopy (SEM) and transmission electron microscopy (TEM) images were captured on a Hitachi SU-70 SEM (Hitachi, USA) and a Jeol JEM 2100 TEM (Jeol, USA), respectively. The dispersity of Ru NPs is not good but Ru NPs are commercially used (see Table S1 and images in Fig. S1 and S2†). UV-vis absorption spectra were obtained using a Varian Cary 300 spectrophotometer (Santa Clara, CA) (Fig. 1–5 and S3†). Electron spin resonance (ESR) measurements were carried out using a Bruker EMX ESR spectrometer (Billerica, MA) (Fig. 6, 7 and S7†).

### TMB oxidation studies

In order to investigate the enzyme-like activities of Ru NPs, the absorbance variation of the reaction solution was monitored in a time-scan mode at 652 nm. Similar to HRP and oxidase, Ru NPs can catalyze the oxidation of substrate TMB in the presence or absence of H2O2 to produce a blue-colored product with maximum absorbance at 652 nm (3 ¼ 39 000 M-1 cm-1 ). The HRP-like activity of Ru NPs was studied by catalyzing the oxidation of TMB in the presence of H2O2. For a typical oxidation reaction, the time-dependent absorbance of the solution of 0.1 mM TMB and 0.1 mM H2O2 with 1 mg mL-1 HRP or variable concentrations of Ru NPs (2.5, 5, 10, 15, 20 mg mL-1 ) was recorded for 15 min. The control experiments were carried out in the absence of Ru NPs. The steady-state kinetic assays were conducted at room temperature in a reaction solution with 10 mg mL-1 Ru NPs as catalyst in the presence of H2O2 and TMB. The kinetic assays of Ru NPs with TMB as the substrate were performed with 0.1 mM H2O2 and different amounts of TMB (0.05, 0.075, 0.1, 0.15 mM) aqueous solution. The kinetic assays of Ru NPs with H2O2 as the substrate were performed with 0.1 mM TMB and different amounts H2O2 solution (0.05, 0.1, 0.15, 0.2 mM). Reaction systems containing 0.1 mM TMB and Ru NPs at different concentrations (10, 25, 50, 75, 100 mg mL-1 ) were used to show the chromogenic reactions implying oxidaselike activity. The steady-state kinetic assays of 50 mg mL-1 Ru NPs with TMB (0.05, 0.1, 0.2, 0.5 mM) as the substrate were performed at room temperature. The kinetic parameters were calculated using Lineweaver–Burk plots of the double reciprocal of Michaelis–Menten equation: 1/v ¼ (Km/Vmax) {1/[S] + 1/Km}, where v is the initial velocity, Vmax is the maximal reaction velocity, [S] is the concentration of substrate and Km is the Michaelis constant.

#### OPD and DA oxidation studies

The HRP-like activity of Ru NPs was also investigated by the catalytic oxidation of the HRP substrate OPD in the presence of H2O2. The absorbance of the color reaction at 417 nm for OPD was recorded to express the HRP-like activity. For a typical oxidation reaction, the time-dependent absorbance of the solution of 0.2 mM OPD and 1 mM H2O2 with 1 mg mL-1 HRP or variable concentrations of Ru NPs (10, 25, 50, 75, 100 mg mL-1 ) was recorded during 20 min. Steady-state kinetics assays of Ru NPs toward OPD oxidation were carried out with varied concentrations of the substrate OPD or H2O2 at room temperature. The control experiments were carried out in the absence of Ru NPs. The kinetic assays of 75 mg mL-1 RuNPs with OPD as the substrate were performed with 1 mM H2O2 and different amounts of OPD aqueous solution (0.05, 0.1, 0.15, 0.2, 0.25, 0.3 mM). The kinetic assays of 25 mg mL-1 Ru NPs with H2O2 as substrate were performed with 0.2 mM OPD and different amounts H2O2 solution (1, 2, 3, 4, 6 mM).

The Ru NPs were then applied as catalyst for the oxidation of DA to aminochrome (AC) by H2O2. The time-scan mode measurements were performed by monitoring the absorbance change of DA at 480 nm. In a typical experiment, 1 mg mL-1 HRP or various concentrations of Ru NPs (10, 25, 50, 75, 100 mg mL-1 ) were respectively reacted with 0.1 mM DA and 1 mM H2O2. The control experiments were carried out in the absence of Ru NPs. The kinetics behavior of Ru NPs was also evaluated by applying the same procedure described. The kinetic assays of 25 mg mL-1 Ru NPs with DA as the substrate were performed with 1 mM H2O2 and different amounts of DA (0.25, 0.5, 0.75, 1, 2 mM) in 10 mM PBS 7.4 buffer solution. The kinetic assays of 25 mg mL-1 Ru NPs with H2O2 as the substrate were performed with 0.1 mM DA and different amounts H2O2 solution (0.5, 1, 2, 3 mM).

#### NaA oxidation studies

The oxidation of NaA catalyzed by AAO (1 U mL-1 ) or Ru NPs (25, 50, 75, 100, 150 mg mL-1 ) in 10 mM PBS 7.4 were performed at room temperature. The absorbance variation of the reaction solution was monitored in a time-scan mode at lmax (265 nm, 3 ¼ 54 200 M-1 cm-1 ). The apparent steady-state kinetic parameters were determined by varying the concentration of NaA (25, 50, 100, 150, 200 mM) in presence of 50 mg mL-1 Ru NPs.

#### ESR spectroscopic measurements

All ESR measurements were carried out using a Bruker EMX ESR spectrometer (Billerica, MA) at ambient temperature (27 C). 50 mL of aliquots of control or sample solutions were taken in glass capillary tubes with internal diameters of 1 mm and sealed. The capillary tubes were inserted in the ESR cavity, and the spectra were recorded at selected times.

The oxidation of NaA can also be monitored by ESR spectroscopy. The ascorbyl radical is an intermediate formed during the oxidation of NaA by molecular oxygen. ESR can directly detect this radical which has a 10 min half-life. Ru NPs at different concentrations were added to 5 mM NaA to start the reaction. The peak-to-peak value of the rst line of ascorbyl radical ESR spectrum was recorded to indicate the amount of ascorbyl formed. Spectra were recorded under the following conditions: 20 mW microwave power, 1 G eld modulation, and 25 G scan width.

The catalytic mechanism of Ru NPs was rst evaluated in the H2O2/DMPO or H2O2/BMPO system in the presence and absence of Ru NPs. Samples containing 50 mM DMPO, 10 mM H2O2, and different concentrations of the Ru NPs (25, 50, 75, 100 mg mL-1 ) were prepared in pH 1.12, 3.2, 7.4 and 10.96 buffer, then transferred to a quartz capillary tube and placed in the ESR cavity for spectra recording. The H2O2/BMPO system was applied the same procedure but varying the BMPO concentration (25 mM). The instrument settings (20 mW microwave power, 1 G modulation amplitude, and 100 G scan range) were used for the present ESR experiment.

ESR spectra were recorded from the sample mixture, containing spin probe 200 mM CPH and Ru NPs at different concentration (25, 50, 75, 100 mg mL-1 ). The ESR measurements were carried out using the following settings: 20 mW microwave power, 100 G scan range, and 1 G eld modulation.

### Results and discussion

Noble metal nanoparticles were reported to act as catalysts mimicking the native enzyme. Currently, research is highly focused on mimicking peroxidases and oxidase. HRP, a widely recognized peroxidase, has been largely explored as a sensor for H2O2 detection, a tracer in enzyme-linked immunosorbent assay (ELISA), and for detection of some peroxidase inhibitors.

<DESCRIPTION_FROM_IMAGE>The image contains four chemical reaction schemes labeled a), b), c), and d), depicting various oxidation reactions catalyzed by ruthenium nanoparticles (Ru NPs) or H2O2. I will describe each reaction and provide SMILES notations for the compounds involved.

a) Oxidation of TMB to oxTMB:
TMB (3,3',5,5'-tetramethylbenzidine) is oxidized to oxTMB using Ru NPs/H2O2 or Ru NPs/O2.
TMB SMILES: Cc1cc(C)c(Nc2ccc(C)c(C)c2N)cc1C
oxTMB SMILES: Cc1cc(C)c(N=c2ccc(C)c(C)c2N)cc1C

b) Oxidation of OPD to DAP:
Two molecules of OPD (o-phenylenediamine) are oxidized to form DAP (2,3-diaminophenazine) using Ru NPs/H2O2.
OPD SMILES: Nc1ccccc1N
DAP SMILES: Nc1ccc2nc3ccc(N)cc3nc2c1N

c) Oxidation of DA to AC:
DA (dopamine) is oxidized to AC (aminochrome) using Ru NPs/H2O2.
DA SMILES: NCCc1ccc(O)c(O)c1
AC SMILES: O=C1C=CC2=NC(=O)CC2=C1

d) Oxidation of Ascorbate:
Ascorbate (Vitamin C) is oxidized in two steps: first to Ascorbyl radical, then to Dehydroascorbate, using Ru NPs/O2.
Ascorbate SMILES: O=C1O[C@H]([C@H](O)CO)C(O)=C1O
Ascorbyl radical SMILES: O=C1O[C@H]([C@H](O)CO)C(O)=C1[O]
Dehydroascorbate SMILES: O=C1O[C@H]([C@H](O)CO)C(=O)C1=O

The image also contains text describing experimental conditions for various oxidation studies, including:

1. H2O2 and DA concentrations in PBS buffer for kinetic assays with Ru NPs.
2. NaA oxidation studies catalyzed by AAO or Ru NPs, including concentration ranges and absorbance measurement conditions.
3. ESR spectroscopic measurements using a Bruker EMX ESR spectrometer at ambient temperature (27 °C).

These details provide context for the chemical reactions depicted in the image and the experimental methods used to study them.</DESCRIPTION_FROM_IMAGE>

Scheme 1 Ru NPs catalyzed oxidation of TMB (a), OPD (b), DA (c) and ascorbate (d).

Oxidases that can catalyze the oxidation of substrates by simply employing molecular oxygen as the electron acceptor are more facile, economic and environment friendly. In this study, the catalytic activity of Ru NPs and their ability of mimicking HRP were evaluated using the chromogenic substrates TMB, OPD and DA (Scheme 1a–c). We also report the rst evidence that Ru NPs possess intrinsic oxidase-like activity, which could catalyze the oxidization of TMB and NaA by dissolved oxygen (Scheme 1a and d).

#### Enzyme-like activity of Ru NPs during oxidation of TMB

The Ru NPs were subjected to reaction conditions typical for HRP and oxidase. TMB is a chromophoric substrate commonly used in HRP mimetic studies and was rstly selected as a substrate to be oxidized in this study. The Ru NPs with varied concentrations can quickly catalyze the oxidation of TMB to produce a typical blue color either in the presence or absence of H2O2. Control reactions in the absence of Ru NPs were performed and showed negligible color changes over the same time period. The TMB cation free radical, a one-electron oxidation product, would be formed during the reaction procedure, which is responsible for the blue color (maximum absorbance at 652 nm), similar to the phenomena observed for the commonly used HRP enzyme. Time- and dose-dependent absorbance changes at 652 nm were measured as shown in Fig. 1a and b, 2a and b. The observed color changes also support UV-vis spectral analysis. The results showed that Ru NPs could catalyze the oxidation of TMB by H2O2 or dissolved O2 to produce a blue colored product, suggesting HRP-like and oxidase-like activity.

In order to regulate enzyme activity and understand the relationship between nanomaterials and enzyme kinetic parameters, the Michaelis–Menten behaviors of Ru NPs were studied with H2O2 and TMB as substrates (Fig. 1c, d, 2c, d, S4

<DESCRIPTION_FROM_IMAGE>This image contains four separate graphs labeled a), b), c), and d), each presenting different data related to a chemical experiment involving ruthenium nanoparticles (Ru NPs).

a) This graph shows the absorbance at 652 nm over time (0-15 minutes) for different concentrations of Ru NPs (2.5, 5, 10, 15, 20 μg/mL) and a control. The curves show increasing absorbance over time, with higher concentrations of Ru NPs resulting in steeper curves. Inset images show color changes in solutions over time.

b) This graph displays UV-Vis absorption spectra from 550-750 nm wavelength range at different time points (2, 4, 6, 8, 10, 12, 14 min). The spectra show a peak around 650 nm that increases in intensity over time.

c) This is a Lineweaver-Burk plot showing the inverse of initial velocity (1/V) versus the inverse of TMB concentration (1/[TMB]). The linear equation is Y = 47.322X + 0.202 with an R² value of 0.991. The graph also provides Vmax (4.95 μM/min) and Km (0.234 mM) values.

d) This is another Lineweaver-Burk plot, likely for a different substrate (H2O2). The linear equation is Y = 63.098X + 0.029 with an R² value of 0.989. The graph provides Vmax (34.96 μM/min) and Km (2.206 mM) values.

These graphs collectively provide kinetic and spectroscopic data for the catalytic activity of Ru NPs, likely in the context of a peroxidase-like reaction involving TMB (3,3',5,5'-tetramethylbenzidine) and hydrogen peroxide.</DESCRIPTION_FROM_IMAGE>

Fig. 1 HRP-like activity of Ru NPs during oxidation of TMB. (a) Timedependent absorbance changes upon oxidation of TMB to oxTMB by H2O2 using 1 mg mL-1 HRP or variable concentrations of Ru NPs in presence of 0.1 mM TMB and 0.1 mM H2O2. Insets are color evolution of TMB oxidation by 0.1 mM H2O2 and different concentrations of Ru NPs or 1 mg mL-1 HRP. (b) Time-dependent absorbance spectra of oxTMB generated upon the oxidation of 0.1 mM TMB in presence of 20 mg mL-1 Ru NPs and 0.1 mM H2O2. (c) Lineweaver–Burk plot of the activity in the presence of 10 mg mL-1 Ru NPs, 0.1 mM H2O2 and different concentrations of TMB. (d) Lineweaver–Burk plot of the activity in the presence of 10 mg mL-1 Ru NPs, 0.1 mM TMB and different concentrations of H2O2.

and S5†). A series of experiments were performed by changing the concentration of one substrate and keeping the other constant. The reaction rates of TMB oxidation both in the

<DESCRIPTION_FROM_IMAGE>This image contains four separate graphs labeled a), b), c), and d), each presenting different data related to a chemical experiment. I'll describe each graph in detail:

a) This graph shows the absorbance at 652 nm over time (0-20 minutes) for different concentrations of Ru NPs (ruthenium nanoparticles). The legend indicates six different conditions:
- Control
- 5 μg/mL Ru NPs
- 25 μg/mL Ru NPs
- 50 μg/mL Ru NPs
- 75 μg/mL Ru NPs
- 100 μg/mL Ru NPs

The absorbance increases linearly with time for all conditions, with higher concentrations of Ru NPs showing steeper slopes. The control has the lowest slope, while 100 μg/mL Ru NPs has the highest.

An inset image shows five vials with increasing color intensity from left to right, likely corresponding to increasing Ru NP concentrations.

b) This graph displays absorbance spectra from 550-750 nm at different time points (2-20 minutes, in 2-minute intervals). The spectra show a peak around 650 nm, with the peak intensity increasing over time. The highest peak corresponds to the 20-minute time point, while the lowest corresponds to the 2-minute time point.

c) This graph is similar to graph a), showing absorbance at 652 nm over time (0-20 minutes) for different concentrations of TMB (3,3',5,5'-tetramethylbenzidine). The legend indicates four conditions:
- Control
- 0.05 mM TMB
- 0.1 mM TMB
- 0.2 mM TMB
- 0.5 mM TMB

As in graph a), the absorbance increases linearly with time for all conditions, with higher TMB concentrations showing steeper slopes.

d) This graph presents a Lineweaver-Burk plot, showing 1/V (y-axis) vs 1/[TMB] (x-axis). The plot is linear with the equation Y = 97.20X + 1.77 and R² = 0.996. From this plot, two important kinetic parameters are derived:
- Vmax = 0.57 μM/min
- Km = 54.92 μM

These graphs collectively represent a kinetic study of an enzyme reaction, likely involving the oxidation of TMB catalyzed by Ru NPs acting as a peroxidase mimic.</DESCRIPTION_FROM_IMAGE>

Fig. 2 Oxidase-like activity of Ru NPs during oxidation of TMB. (a) Time-dependent absorbance changes upon oxidation of TMB using variable concentrations of Ru NPs in presence of 0.1 mM TMB. Insets are color evolution of TMB oxidation by different concentrations of Ru NPs. (b) Time-dependent absorbance spectra of oxTMB generated upon the oxidation of 0.1 mM TMB in presence of 100 mg mL-1 Ru NPs. (c) Time-dependent absorbance changes corresponding to the 50 mg mL-1 Ru NPs-catalyzed oxidation of TMB using variable concentrations of TMB. (d) Lineweaver–Burk plot of the activity in the presence of 50 mg mL-1 Ru NPs and different concentrations of TMB.

presence and absence of H2O2 were calculated. Typical Michaelis–Menten curves were received in a certain concentration range of TMB and H2O2 (Fig. S4 and S5†). Lineweaver–Burk plots of 1/v vs. Vmax were constructed and tted to the Michaelis–Menten equation to calculate the Michaelis constant Km and the maximal reaction velocity Vmax. From the Lineweaver–Burk plots, the kinetic parameters Vmax and Km were obtained and shown in Table 1, Fig. 1d and 2d. In natural enzyme, Km is an indicator of affinity between the enzyme and substrate where a lower Km value indicates a higher affinity and catalytic activity. In the case of the nanostructure enzyme mimetics, the Km value is oen used to compare the enzyme-like performance of the nanoparticles. The Km value of Ru NPs with TMB as the substrate is higher than that of Ru frames,49 Pd nanoplates42 and Fe3O4 NPs.14 The Km value of Ru NPs with H2O2 as the substrate is much lower than that of Ru frames and Fe3O4 NPs, and comparable with Pd nanoplates. These results indicated that Ru NPs had a low binding affinity towards TMB, and high binding affinity towards H2O2. It is also obvious that the oxidase-like activity of Ru NPs was much lower than its HRP-like activity. **[View Article Online](http://dx.doi.org/10.1039/c7ra10370k)**

### Enzyme-like activity of Ru NPs during oxidation of OPD and DA

Typically, HRP as the catalyst via H2O2 for the oxidation of OPD to 2,3-diaminophenazine (DAP) has been successfully applied for more than a century.51,52 In the presence of HRP and H2O2, OPD is oxidized to DAP by H2O2, resulting in a yellow solution. The oxidation of chromogenic OPD has been employed for evaluating the HRP-like activity of Ru NPs, which is also investigated by UV-vis spectroscopy (Fig. 3). Similar to the enzymatic peroxidase activity observed from the HRP, OPD can be oxidized to a yellow reaction product in the presence of H2O2 upon addition of Ru NPs catalysts. Moreover, the color deepened with increasing reaction time and the concentration of Ru NPs. This process was also conrmed by absorption spectra. The catalytic reaction can be monitored by following the changing of absorbance at 417 nm, which originates from the oxidation products DAP. Fig. 3a and b presented the time course curves of the absorbance at 417 nm within 20 min. The reaction was also

| Comparison of the kinetic parameters of different catalysts<br>Table 1 |           |         |                        |           |
|------------------------------------------------------------------------|-----------|---------|------------------------|-----------|
| Catalyst                                                               | Substrate | Km (mM) | 1<br>Vmax (mM min<br>) | Reference |
| Ru NPs                                                                 | TMB       | 0.234   | 4.95                   | This work |
|                                                                        | H2O2      | 2.206   | 34.96                  | This work |
| Ru frames                                                              | TMB       | 0.0603  | 8.04                   | 49        |
|                                                                        | H2O2      | 318     | 4.45                   |           |
| Pd nanoplates                                                          | TMB       | 0.1098  | 3.492                  | 42        |
|                                                                        | H2O2      | 4.398   | 3.906                  |           |
| Fe3O4 NPs                                                              | TMB       | 0.098   | 2.064                  | 14        |
|                                                                        | H2O2      | 154     | 5.868                  |           |
| Ru NPs                                                                 | TMB       | 54.92   | 0.57                   | This work |
| Pt NPs                                                                 | TMB       | 0.6     | 16.2                   | 38        |
| Ru NPs                                                                 | NaA       | 0.155   | 2.331                  | This work |
| Pt NPs (30 nm)                                                         | NaA       | 0.022   | 12                     | 40        |
|                                                                        |           |         |                        |           |

<DESCRIPTION_FROM_IMAGE>This image contains four graphs labeled a), b), c), and d), each presenting different experimental results related to chemical reactions or spectroscopic measurements.

a) This graph shows the absorbance at 417 nm over time (0-20 minutes) for different concentrations of Ru NPs (ruthenium nanoparticles) and HRP (likely horseradish peroxidase). The legend indicates concentrations from 10 μg/mL to 1 μg/mL of Ru NPs, and a control. The curves show increasing absorbance over time, with higher concentrations generally resulting in higher absorbance. An inset image shows vials with varying colors, likely corresponding to the different concentrations tested.

b) This graph displays absorption spectra from 360 to 510 nm, with multiple curves representing different time points from 2 to 20 minutes. The spectra show a prominent peak around 420-430 nm, with the peak intensity increasing over time.

c) This graph plots absorbance at 417 nm against time (0-20 minutes) for different concentrations of OPD (likely o-phenylenediamine). Concentrations range from 50 μM to 300 μM OPD, with a control. Higher OPD concentrations generally result in higher absorbance values over time.

d) This graph shows absorbance at 417 nm over time (0-20 minutes) for different concentrations of H2O2 (hydrogen peroxide). Concentrations range from 1 mM to 6 mM H2O2, with a control. Higher H2O2 concentrations generally lead to higher absorbance values over time.

All graphs demonstrate time-dependent changes in absorbance, likely related to the progress of chemical reactions or the formation of colored products. The specific experimental conditions and the nature of the reactions would need to be provided for a more detailed interpretation.</DESCRIPTION_FROM_IMAGE>

Fig. 3 HRP-like activity of Ru NPs during oxidation of OPD. (a) Timedependent absorbance changes upon oxidation of OPD by H2O2 using 1 mg mL-1 HRP or variable concentrations of Ru NPs in presence of 0.2 mM OPD and 1 mM H2O2. Insets are color evolution of 0.2 mM OPD oxidation by 1 mM H2O2 and different concentrations of Ru NPs or 1 mg mL-1 HRP. (b) Time-dependent absorbance spectra generated upon the oxidation of 0.2 mM OPD in presence of 75 mg mL-1 Ru NPs and 1 mM H2O2. (c) Time-dependent absorbance changes corresponding to the 75 mg mL-1 Ru NPs-catalyzed oxidation of OPD using variable concentrations of OPD in presence of 1 mM H2O2. (d) Timedependent absorbance changes corresponding to the 25 mg mL-1 Ru NPs-catalyzed oxidation of 0.2 mM OPD using variable concentrations of H2O2.

monitored while changing the substrate concentration of OPD or H2O2 and xing the other two concentrations (Fig. 3c and d).

Dopamine (DA) is a neurotransmitter in the catecholamine and phenethylamine families that plays a number of important roles in the brain and body of animals. HRP/H2O2 couple is commonly selected as a biomimetic oxidizing agent to examine the early stages of dopamine oxidation.53 The Ru NPs can catalyze the H2O2-driven oxidation of DA to aminochrome (AC), in analogy to HRP. The time-dependent absorbance change of AC, generated upon oxidation of dopamine, was shown in Fig. 4. Fig. 4a and b depicted the absorption spectra corresponding to AC generated within a xed time interval using HRP or Ru NPs in the presence of DA and H2O2. There was an obvious increase of absorbance intensity at 480 nm with the increasing of the Ru NPs concentration, accompanying the progression of the orange color. With the increase of the concentration of Ru NPs, the oxidation reaction proceeded faster, resulted in the enhanced oxidation of dopamine. Fig. 4c illustrated the timedependent absorbance changes of AC upon oxidation of dopamine using variable concentrations of dopamine and a xed concentration of Ru NPs and H2O2. Evidently, the Ru NPs catalyzed oxidation of dopamine was controlled by the concentration of H2O2, and as its concentration increased, the rate of the oxidation of dopamine was enhanced (Fig. 4d).

#### Enzyme-like activity of Ru NPs during oxidation of NaA

NaA is an essential nutrient and a well-known antioxidant that protects other important biological structures against oxidative

<DESCRIPTION_FROM_IMAGE>This image contains multiple graphs and data plots related to the HRP-like activity of Ru NPs (Ruthenium Nanoparticles) during the oxidation of OPD (o-Phenylenediamine). The image is divided into two main sections, each containing four subfigures labeled a), b), c), and d). I'll describe each section in detail:

Left Section:

a) Time-dependent absorbance curves at 417 nm for different concentrations of Ru NPs (0-100 μg/mL) and HRP (1 μg/mL) as a control. The graph shows increasing absorbance over time (0-20 minutes) with higher concentrations of Ru NPs producing steeper curves. The control (HRP) shows minimal activity.

b) UV-Vis absorption spectra measured at different time points (2-20 min) during the oxidation reaction. The spectra show a peak around 420-430 nm, with increasing intensity over time.

c) Time-dependent absorbance curves at 417 nm for different concentrations of OPD (50-300 μM). The graph shows increasing absorbance over time (0-20 minutes) with higher concentrations of OPD producing steeper curves.

d) Time-dependent absorbance curves at 417 nm for different concentrations of H2O2 (1-6 mM). The graph shows increasing absorbance over time (0-20 minutes) with higher concentrations of H2O2 producing steeper curves. The control shows minimal activity.

Right Section:

a) Similar to the left section's (a), but with different concentrations of Ru NPs (0-100 μg/mL) and HRP (1 μg/mL) as a control. The graph shows absorbance at 460 nm over time (0-20 minutes).

b) UV-Vis absorption spectra measured at different time points (2-20 min) during the oxidation reaction. The spectra show two peaks, one around 420-430 nm and another around 580-600 nm, with increasing intensity over time.

c) Time-dependent absorbance curves at 460 nm for different concentrations of DA (Dopamine, 0.25-2 mM). The graph shows increasing absorbance over time (0-20 minutes) with higher concentrations of DA producing steeper curves.

d) Time-dependent absorbance curves at 460 nm for different concentrations of H2O2 (0.5-3 mM). The graph shows increasing absorbance over time (0-20 minutes) with higher concentrations of H2O2 producing steeper curves. The control shows minimal activity.

The figure caption reads: "Fig. 3 HRP-like activity of Ru NPs during oxidation of OPD. (a) Time-"

This image provides comprehensive data on the catalytic activity of Ru NPs in oxidation reactions, comparing their performance to HRP and showing the effects of various reactant concentrations and reaction conditions.</DESCRIPTION_FROM_IMAGE>

Fig. 4 HRP-like activity of Ru NPs during oxidation of DA. (a) Timedependent absorbance changes upon oxidation of DA by H2O2 using 1 mg mL-1 HRP or variable concentrations of Ru NPs in presence of 1 mM DA and 1 mM H2O2. Insets are color evolution of DA oxidation by 1 mM H2O2 and different concentrations of Ru NPs or 1 mg mL-1 HRP. (b) Time-dependent absorbance spectra generated upon the oxidation of 1 mM DA in presence of 100 mg mL-1 Ru NPs and 1 mM H2O2. (c) Timedependent absorbance changes corresponding to the 50 mg mL-1 Ru NPs-catalyzed oxidation of DA using variable concentrations of OPD in presence of 1 mM H2O2. (d) Time-dependent absorbance changes corresponding to the 50 mg mL-1 Ru NPs-catalyzed oxidation of 0.2 mM DA using variable concentrations of H2O2.

damage by many oxidants. Numerous studies have shown the benecial effects of NaA on human health.54–56 However, NaA can be oxidized very slowly by dioxygen to produce ascorbyl

<DESCRIPTION_FROM_IMAGE>The image contains four separate graphs labeled a), b), c), and d). I will describe each in detail:

a) Graph of Absorbance at 340nm vs Time (min)
- X-axis: Time (min), range 0-25 minutes
- Y-axis: Absorbance at 340nm, range 0.0-1.0
- Multiple curves shown, each representing a different concentration:
  - Control (constant at ~1.0 absorbance)
  - 25 μg/mL
  - 50 μg/mL
  - 75 μg/mL
  - 100 μg/mL
  - 150 μg/mL
- Curves show decreasing absorbance over time, with higher concentrations decreasing more rapidly

b) Graph of Absorbance vs Wavelength (nm)
- X-axis: Wavelength (nm), range 220-320 nm
- Y-axis: Absorbance, range 0.0-1.0
- Multiple overlapping spectra shown
- Peak absorbance around 260-270 nm
- Spectra decrease in intensity over time (0 min to 20 min)

c) Graph of The remaining of NaA (%) vs Time (min)
- X-axis: Time (min), range 0-25 minutes
- Y-axis: The remaining of NaA (%), range 0-100%
- Multiple curves shown, each representing a different NaA concentration:
  - 25 μM NaA
  - 50 μM NaA
  - 100 μM NaA
  - 150 μM NaA
  - 200 μM NaA
- Curves show decreasing percentage remaining over time, with lower concentrations decreasing more rapidly

d) Linear regression graph
- X-axis: 1/CNaA (μM^-1), range 0-0.05
- Y-axis: 1/V (min/μM), range 0-3.0
- Linear fit equation: Y = 66.646X + 0.429
- R² value: 0.991
- Additional information provided:
  - Vmax = 2.331 μM/min
  - Km = 0.155 mM

This image appears to be analyzing the kinetics of an enzymatic reaction, possibly the degradation of sodium alginate (NaA) or a similar compound, using various concentrations and measurement techniques.</DESCRIPTION_FROM_IMAGE>

Fig. 5 AAO-like activity of Ru NPs during oxidation of NaA. (a) Timedependent absorbance changes upon oxidation of NaA using 1 U mL-1 AAO or variable concentrations of Ru NPs in presence of 100 mM NaA. (b) Time-dependent absorbance spectra generated upon the oxidation of 100 mM NaA in presence of 150 mg mL-1 Ru NPs. (c) Timedependent amount of NaA remaining in different NaA dispersions containing 50 mg mL-1 Ru NPs. (d) Lineweaver–Burk plot of the activity in the presence of 50 mg mL-1 Ru NPs and different concentrations of NaA.

radical (AAc). The presence of AAO greatly accelerated this process. Here, we investigated whether Ru NPs possess AAO-like enzyme-mimetic properties by oxidizing NaA (Fig. 5 and S6†). The oxidation of NaA to AAc is accompanied by a decrease in the characteristic absorption of NaA at 265 nm. Therefore, we used the absorbance change of NaA at 265 nm to monitor its oxidation. A typical set of experiment investigating Ru NPs with NaA was shown in Fig. 5a. No evident change at 265 nm was observed in Ru NPs-free reference solution during a 20 min monitoring. While mixing of NaA with Ru NPs (25, 50, 75, 100, 150 mg mL-1 ) resulted in decreased absorbance at 265 nm during time monitoring measurements (Fig. 5a and b). It is obvious that Ru NPs exhibited a signicant ability to oxidize NaA in a time and dose- dependent manner. We determined the apparent steady-state kinetic parameters by varying the concentration of NaA in the presence of Ru NPs (Fig. 5c). The Km value of Ru NPs with NaA as a substrate was higher than that of AAO and Pt NPs (30 nm),40 suggesting that Ru NPs have a lower affinity than NaA (Fig. 5d). **[View Article Online](http://dx.doi.org/10.1039/c7ra10370k)**

We further demonstrated that Ru NPs can mimic the activity of AAO by using ESR spectroscopy, which is the most reliable and direct method for identication and quantication of short-lived free radicals. The intermediate AAc is an indicator for the oxidation of the active reducing agent NaA. AAc can be easily detected by ESR spectroscopy at room temperature without using any spin trap or spin label. The ESR spectra of AAc were shown in Fig. 6. There was no ESR signal in the pure NaA solution which indicates that NaA itself has not been oxidized within 3 min. However, signicant ESR signals were detected when mixing NaA with different concentrations of Ru NPs or 1 U mL-1 AAO. The oxidation of NaA to AAc was dependent on the concentration of Ru NPs (Fig. 6a and b). At low NaA concentrations, the ESR signal rapidly increased. At high NaA

<DESCRIPTION_FROM_IMAGE>This image does not contain any visual elements such as graphs, chemical structures, or diagrams. Instead, it is a text excerpt from a scientific article discussing the use of CTPO (3-Carbamoyl-2,2,5,5-tetramethyl-3-pyrroline-1-yloxy) in ESR (Electron Spin Resonance) oximetry and its application in detecting oxygen concentration changes.

The text describes that:

1. The ESR signal of CTPO slowly increases with increasing concentrations (referring to Figure 6c, which is not shown in this image).

2. CTPO is a stable, water-soluble nitroxide widely used for ESR oximetry.

3. The resolution of the super hyperfine structure of the low-field line in the ESR spectrum of CTPO depends on the oxygen concentration in the sample solution.

4. CTPO is commonly used to detect changes in oxygen concentration.

5. Figure 6d (not shown in this image) demonstrated that samples containing Ru NPs (Ruthenium Nanoparticles) showed more super hyperfine splitting in the ESR spectra of CTPO compared to the control sample, indicating more oxygen consumption.

6. A higher increase in super hyperfine splitting was observed for samples with a high concentration of Ru NPs.

7. These results suggest that Ru NPs exhibit intrinsic AAO-like (Ascorbic Acid Oxidase-like) activity.

This text provides important context for understanding the experimental results and their interpretation in the study of Ru NPs and their oxygen-consuming properties using ESR spectroscopy with CTPO as a probe.</DESCRIPTION_FROM_IMAGE>

#### Catalytic mechanism of Ru NPs mimicking HRP and oxidase

The enzyme-like catalytic mechanisms of noble metal nanoparticles have been reported in related literature.41,42,48 Generation of hydroxyl radical and accelerating electron transfer process are two most possible mechanisms responsible for the enzyme mimic activities of Ru NPs (Scheme S1†). To test the hypothesis, we applied two models to measure the hydroxyl radical generation and electron transfer process. First, Ru/ H2O2/DMPO and Ru/DMPO systems were applied to examine whether the enzyme mimicking property of Ru NPs was related to the generation of the hydroxyl radical, which could oxidize the substrate molecules. The catalytic mechanism of Ru NPs was evaluated in pH conditions of 1.12, 3.2, 7.4 and 10.96, respectively. The sample solution contains 5 mM DMPO, and different concentrations of Ru NPs (25, 50, 75, 100, 150 mg mL-1 ) in the absence or presence of 1 mM or 0.1 mM H2O2. All of these samples showed no ESR signal of DMPO–OH adduct (Fig. S7a†). The above results are further supported by ESR measurements

<DESCRIPTION_FROM_IMAGE>This image contains four panels labeled a), b), c), and d), each presenting different data related to Ruthenium nanoparticles (Ru NPs) and their effects on ESR (Electron Spin Resonance) signals.

a) This panel shows ESR spectra for different concentrations of Ru NPs and a control. The x-axis represents the magnetic field in Gauss (G) ranging from 3355 to 3385 G. Four spectra are shown:
- Control (no label on y-axis)
- 50 μg/mL Ru NPs
- 100 μg/mL Ru NPs
- 150 μg/mL Ru NPs
- 1 U/mL AAO (likely Ascorbate Oxidase)
Each spectrum shows characteristic peaks and troughs, with the intensity and shape varying between samples.

b) This graph shows the relationship between Ru NPs concentration (x-axis, 0-150 μg/mL) and ESR signal intensity (y-axis, 0-1200 a.u.). The plot shows a non-linear increase in ESR signal intensity with increasing Ru NPs concentration, with the curve appearing to approach saturation at higher concentrations.

c) This graph depicts the relationship between NaX concentration (x-axis, 0-5 mM) and ESR signal intensity (y-axis, 0-1200 a.u.). The curve shows a rapid initial increase in ESR signal intensity at low NaX concentrations, followed by a more gradual increase at higher concentrations.

d) This panel presents ESR spectra for different Ru NPs concentrations, similar to panel a), but with a narrower magnetic field range (3352-3356 G). Three spectra are shown:
- Control
- 50 μg/mL Ru NPs
- 100 μg/mL Ru NPs
The spectra show distinct peaks and troughs, with the intensity and complexity increasing with Ru NPs concentration.

Overall, these graphs and spectra demonstrate the concentration-dependent effects of Ru NPs on ESR signals, as well as the influence of NaX concentration on the ESR signal intensity.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image contains two graphs labeled a) and b), both related to the analysis of Ruthenium nanoparticles (Ru NPs) at different concentrations.

a) The first graph shows Electron Paramagnetic Resonance (EPR) spectra for different concentrations of Ru NPs. The x-axis represents the magnetic field strength in Gauss (G), ranging from 3320 to 3420 G. The y-axis is not labeled but presumably represents the EPR signal intensity. There are five spectra shown:

1. Control (no Ru NPs)
2. 25 μg/mL Ru NPs
3. 50 μg/mL Ru NPs
4. 75 μg/mL Ru NPs
5. 100 μg/mL Ru NPs

Each spectrum, except for the control, shows three distinct peaks characteristic of EPR signals. The intensity of these peaks appears to increase with increasing Ru NP concentration.

b) The second graph shows the change in EPR signal intensity over time for different concentrations of Ru NPs. The x-axis represents time in minutes, ranging from 0 to 10 minutes. The y-axis represents the EPR signal intensity, labeled as "CP ESR signal intensity (a.u.)" ranging from 0 to 2000 arbitrary units.

The graph contains five plots:

1. Control (black squares)
2. 25 μg/mL Ru NPs (red circles)
3. 50 μg/mL Ru NPs (blue triangles)
4. 75 μg/mL Ru NPs (green inverted triangles)
5. 100 μg/mL Ru NPs (pink diamonds)

All plots start at 0 intensity at 0 minutes. The control shows no significant change over time. The other plots show an increase in signal intensity over time, with the rate and maximum intensity increasing with Ru NP concentration. The 100 μg/mL concentration shows the steepest increase and highest final intensity, while the 25 μg/mL concentration shows the slowest increase and lowest final intensity among the Ru NP samples.

This data suggests a concentration-dependent effect of Ru NPs on the EPR signal intensity, potentially indicating their influence on the generation or stability of paramagnetic species in the system.</DESCRIPTION_FROM_IMAGE>

Fig. 6 (a) ESR spectra upon oxidation of NaA using 1 U mL-1 AAO or variable concentrations of Ru NPs in presence of 5 mM NaA after 3 min incubation. (b) Effect of Ru NP concentration on NaA oxidation after incubation for 3 min. (c) Effect of NaA concentration on the oxidation in presence of 50 mg mL-1 Ru NPs after incubation for 3 min. (d) ESR spectra of samples containing 0.1 mM CTPO, 5 mM NaA, 10 mM PBS 7.4 and different concentrations of Ru NPs after mixing for 5 min.

Fig. 7 (a) ESR spectra of CPc obtained from samples containing 20 mM CPH and variable concentrations of Ru NPs after mixing for 10 min. (b) CPc ESR signal intensity vs. time in the absence and presence of Ru NPs with different concentrations.

using BMPO as a spin trap (Fig. S7b†). Thus, the catalytic behavior of Ru NPs can not be assumed to the cOH generation. It is very likely that Ru NPs act as an efficient electron transfer intermediate and facilitate the electron transfer between substrates and H2O2 or O2. Substrates were absorbed onto the surface of Ru NPs and donated electrons to Ru NPs, resulting in increased of electron density on Ru NPs. Then the electrons transferred from Ru NPs to H2O2 or O2 and facilitated the oxidation of substrates. This assumption is supported by ESR measurements using CPH as a spin probe, which is oen used in ESR studies of electron transfer in biological system.58,59 CPH is an ESR silent probe, and can be oxidized to form CP-nitroxide radicals (CPc) with a typical ESR spectrum of three lines with intensity ratios of 1 : 1 : 1. As shown in Fig. 7a, CPH itself is ESR silent. Upon addition of Ru NPs, a triplet ESR signal appeared with hyperne splitting constant aN ¼ 16.2 G, implying of the oxidation of CPH. The signal intensity increased in a time and dose-dependent manner (Fig. 7b). **[View Article Online](http://dx.doi.org/10.1039/c7ra10370k)**

### Conclusions

In summary, this study has introduced Ru NPs mimicking HRP and oxidase functionalities. Ru NPs could catalyze the oxidation of substrate TMB, OPD and DA in the presence of H2O2 to produce the color products. We also report for the rst time that Ru NPs possess intrinsic oxidase-like activity, which could catalyze the oxidization of TMB and NaA by dissolved molecular oxygen. The HRP-like and oxidase-like activities of Ru NPs were found to be relevant to the concentrations of Ru NPs. The enzyme mimicking activities of the Ru NPs might originate from their characteristic of accelerating electron transfer between substrates and H2O2 or O2. Our ndings offer a better understanding of enzyme-mimicking activities of Ru NPs and should provide important insights for future applications.

### Conflicts of interest

There are no conicts of interest to declare.

### Acknowledgements

G.-J. Cao appreciates the National Natural Science Foundation of China (Grant No. 21601035) and Natural Science Foundation of Fujian Province (Grant No. 2016J01043) for partial support. This work was also supported by a regulatory science grant under the FDA Nanotechnology CORES Program. This paper is not an official U.S. FDA guidance or policy statement. No official support or endorsement by the U.S. FDA is intended or should be inferred.

### Notes and references

- 1 S. J. Benkovic and S. Hammes-Schiffer, Science, 2003, 301, 1196–1202.
- 2 S. J. Benkovic and S. Hammes-Schiffer, Science, 2006, 312, 208–209.
- 3 J. Barber, Chem. Soc. Rev., 2009, 38, 185–196.

- 4 T. Matsuo, A. Hayashi, M. Abe, T. Matsuda, Y. Hisaeda and T. Hayashi, J. Am. Chem. Soc., 2009, 131, 15124–15125.
- 5 Y. Xianyu, Y. Chen and X. Jiang, Anal. Chem., 2015, 87, 10688–10692.
- 6 Y. Lin, J. Ren and X. Qu, Acc. Chem. Res., 2014, 47, 1097–1105.
- 7 Y. Lin, J. Ren and X. Qu, Adv. Mater., 2014, 26, 4200–4217.
- 8 W. He, W. Wamer, Q. Xia, J.-J. Yin and P. P. Fu, J. Environ. Sci. Health, Part A: Toxic/Hazard. Subst. Environ. Eng., 2014, 32, 186–211.
- 9 J. Huang, L. Lin, D. Sun, H. Chen, D. Yang and Q. Li, Chem. Soc. Rev., 2015, 44, 6330–6374.
- 10 L. Gao, M. Liu, G. Ma, Y. Wang, L. Zhao, Q. Yuan, F. Gao, R. Liu, J. Zhai, Z. Chai, Y. Zhao and X. Gao, ACS Nano, 2015, 9, 10979–10990.
- 11 Y. Liu, D. L. Purich, C. Wu, Y. Wu, T. Chen, C. Cui, L. Zhang, S. Cansiz, W. Hou, Y. Wang, S. Yang and W. Tan, J. Am. Chem. Soc., 2015, 137, 14952–14958.
- 12 C.-P. Liu, T.-H. Wu, Y.-L. Lin, C.-Y. Liu, S. Wang and S.-Y. Lin, Small, 2016, 12, 4127–4135.
- 13 Y. Hu, H. Cheng, X. Zhao, J. Wu, F. Muhammad, S. Lin, J. He, L. Zhou, C. Zhang, Y. Deng, P. Wang, Z. Zhou, S. Nie and H. Wei, ACS Nano, 2017, 11, 5558–5566.
- 14 L. Gao, J. Zhuang, L. Nie, J. Zhang, Y. Zhang, N. Gu, T. Wang, J. Feng, D. Yang, S. Perrett and X. Yan, Nat. Nanotechnol., 2007, 2, 577–583.
- 15 X. Yan, Y. Song, X. Wu, C. Zhu, X. Su, D. Du and Y. Lin, Nanoscale, 2017, 9, 2317–2323.
- 16 H. Jia, D. Yang, X. Han, J. Cai, H. Liu and W. He, Nanoscale, 2016, 8, 5938–5945.
- 17 W. Zhang, S. Hu, J.-J. Yin, W. He, W. Lu, M. Ma, N. Gu and Y. Zhang, J. Am. Chem. Soc., 2016, 138, 5860–5865.
- 18 T. Naganuma, Nano Res., 2017, 10, 199–217.
- 19 A. A. Vernekar, D. Sinha, S. Srivastava, P. U. Paramasivam, P. D'Silva and G. Mugesh, Nat. Commun., 2014, 5, 5301.
- 20 S. Wang, R. Cazelles, W.-C. Liao, M. V´azquez-Gonz´alez, A. Zoabi, R. Abu-Reziq and I. Willner, Nano Lett., 2017, 17, 2043–2048.
- 21 M. V´azquez-Gonz´alez, W.-C. Liao, R. Cazelles, S. Wang, X. Yu, V. Gutkin and I. Willner, ACS Nano, 2017, 11, 3247–3253.
- 22 A. M. Fracaroli, P. Siman, D. A. Nagib, M. Suzuki, H. Furukawa, F. D. Toste and O. M. Yaghi, J. Am. Chem. Soc., 2016, 138, 8352–8355.
- 23 S. Singh, K. Mitra, A. Shukla, R. Singh, R. K. Gundampati, N. Misra, P. Maiti and B. Ray, Anal. Chem., 2017, 89, 783–791.
- 24 Y. Wang, Y. Zhu, A. Binyam, M. Liu, Y. Wu and F. Li, Biosens. Bioelectron., 2016, 86, 432–438.
- 25 H.-H. Zeng, W.-B. Qiu, L. Zhang, R.-P. Liang and J.-D. Qiu, Anal. Chem., 2016, 88, 6342–6348.
- 26 H. Yang, J. Xiao, L. Su, T. Feng, Q. Lv and X. Zhang, Chem. Commun., 2017, 53, 3882–3885.
- 27 S. Zhang, D. Zhang, X. Zhang, D. Shang, Z. Xue, D. Shan and X. Lu, Anal. Chem., 2017, 89, 3538–3544.
- 28 L. Jiang, S. Fernandez-Garcia, M. Tinoco, Z. Yan, Q. Xue, G. Blanco, J. J. Calvino, A. B. Hungria and X. Chen, ACS Appl. Mater. Interfaces, 2017, 9, 18595–18608.
- 29 K. Wang, N. Li, J. Zhang, Z. Zhang and F. Dang, Biosens. Bioelectron., 2017, 87, 339–344.

- 30 H.-B. Noh and Y.-B. Shim, J. Mater. Chem. A, 2016, 4, 2720– 2728.
- 31 J. Xie, X. Zhang, H. Wang, H. Zheng, Y. Huang and J. Xie, TrAC, Trends Anal. Chem., 2012, 39, 114–129.
- 32 X. Wang, Y. Hu and H. Wei, Inorg. Chem. Front., 2016, 3, 41– 60.
- 33 Y. Jv, B. Li and R. Cao, Chem. Commun., 2010, 46, 8017–8019.
- 34 C. Wang, Y. Shi, Y.-Y. Dan, X.-G. Nie, J. Li and X.-H. Xia, Chem.– Eur. J., 2017, 23, 6717–6723.
- 35 M. C. Ortega-Liebana, J. L. Hueso, R. Arenal and J. Santamaria, Nanoscale, 2017, 9, 1787–1792.
- 36 W. He, Y. Liu, J. Yuan, J.-J. Yin, X. Wu, X. Hu, K. Zhang, J. Liu, C. Chen, Y. Ji and Y. Guo, Biomaterials, 2011, 32, 1139–1147.
- 37 Y.-T. Zhou, W. He, W. G. Wamer, X. Hu, X. Wu, Y. M. Lo and J.-J. Yin, Nanoscale, 2013, 5, 1583–1591.
- 38 W. He, X. Han, H. Jia, J. Cai, Y. Zhou and Z. Zheng, Sci. Rep., 2017, 7, 40103.
- 39 U. Carmona, L. Zhang, L. Li, W. Munchgesang, E. Pippel and ¨ M. Knez, Chem. Commun., 2014, 50, 701–703.
- 40 C. Chen, S. Fan, C. Li, Y. Chong, X. Tian, J. Zheng, P. P. Fu, X. Jiang, W. G. Wamer and J.-J. Yin, J. Mater. Chem. B, 2016, 4, 7895–7901.
- 41 L. Jin, Z. Meng, Y. Zhang, S. Cai, Z. Zhang, C. Li, L. Shang and Y. Shen, ACS Appl. Mater. Interfaces, 2017, 9, 10027–10033.
- 42 J. Wei, X. Chen, S. Shi, S. Mo and N. Zheng, Nanoscale, 2015, 7, 19018–19026.
- 43 T. Wen, W. He, Y. Chong, Y. Liu, J.-J. Yin and X. Wu, Phys. Chem. Chem. Phys., 2015, 17, 24937–24943.
- 44 C. Ge, G. Fang, X. Shen, Y. Chong, W. G. Wamer, X. Gao, Z. Chai, C. Chen and J.-J. Yin, ACS Nano, 2016, 10, 10436– 10445.
- 45 Q. Wang, L. Zhang, C. Shang, Z. Zhang and S. Dong, Chem. Commun., 2016, 52, 5410–5413.

- 46 X. Xia, J. Zhang, N. Lu, M. J. Kim, K. Ghale, Y. Xu, E. McKenzie, J. Liu and H. Ye, ACS Nano, 2015, 9, 9994– 10004. **[View Article Online](http://dx.doi.org/10.1039/c7ra10370k)**
  - 47 H. Su, D.-D. Liu, M. Zhao, W.-L. Hu, S.-S. Xue, Q. Cao, X.-Y. Le, L.-N. Ji and Z.-W. Mao, ACS Appl. Mater. Interfaces, 2015, 7, 8233–8242.
  - 48 M. Cui, J. Zhou, Y. Zhao and Q. Song, Sens. Actuators, B, 2017, 243, 203–210.
  - 49 H. Ye, J. Mohar, Q. Wang, M. Catalano, M. J. Kim and X. Xia, Science Bulletin, 2016, 61, 1739–1745.
  - 50 G.-J. Cao, X. Jiang, H. Zhang, J. Zheng, T. R. Croley and J.-J. Yin, J. Environ. Sci. Health, Part C: Environ. Carcinog. Ecotoxicol. Rev., 2017, DOI: 10.1080/10590501.2017.1391516.
  - 51 P. J. Tarcha, V. P. Chu and D. Whittern, Anal. Biochem., 1987, 165, 230–233.
  - 52 C. Zhao, Z. Jiang, R. Mu and Y. Li, Talanta, 2016, 159, 365– 370.
  - 53 M. V´azquez-Gonz´alez, R. M. Torrente-Rodr´ıguez, A. Kozell, W.-C. Liao, A. Cecconello, S. Campuzano, J. M. Pingarr´on and I. Willner, Nano Lett., 2017, 17, 4958–4963.
  - 54 E. Gitto, D.-X. Tan, R. J. Reiter, M. Karbownik, L. C. Manchester, S. Cuzzocrea, F. Fulia and I. Barberi, J. Pharm. Pharmacol., 2001, 53, 1393–1401.
  - 55 S. J. Padayatty, A. Katz, Y. Wang, P. Eck, O. Kwon, J.-H. Lee, S. Chen, C. Corpe, A. Dutta, S. K. Dutta and M. Levine, J. Am. Coll. Nutr., 2003, 22, 18–35.
  - 56 M. Karajibani, M. Hashemi, F. Montazerifar and M. Dikshit, J. Nutr. Sci. Vitaminol., 2010, 56, 436–440.
  - 57 Y.-T. Zhou, J.-J. Yin and Y. M. Lo, Magn. Reson. Chem., 2011, 49, S105–S112.
  - 58 S. I. Dikalov, I. A. Kirilyuk, M. Voinov and I. A. Grigor'ev, Free Radical Res., 2011, 45, 417–430.
  - 59 W. He, H.-K. Kim, W. G. Wamer, D. Melka, J. H. Callahan and J.-J. Yin, J. Am. Chem. Soc., 2014, 136, 750–757.