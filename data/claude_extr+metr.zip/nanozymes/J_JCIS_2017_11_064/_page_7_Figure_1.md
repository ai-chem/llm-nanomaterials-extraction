This image contains four graphs (A, B, C, and D) and a series of vials at the top, presenting data on the effects of various nanoparticles on peroxidase activity under different conditions.

Top image: Eight vials numbered 1-8 containing solutions of varying shades, likely corresponding to the different nanoparticle treatments listed in the legend.

Graph A: UV-Vis absorption spectra from 500-750 nm for different nanoparticle treatments. The legend indicates:
Control (1)
30 μg CSNPs (2)
60 μg CSNPs (3)
90 μg CSNPs (4)
120 μg CSNPs (5)
150 μg CSNPs (6)
150 μg AuNPs (7)
150 μg CeO2 NPs (8)

The graph shows varying absorption peaks around 650 nm, with 150 μg CSNPs showing the highest absorbance.

Graph B: Time-dependent normalized absorbance at 652 nm for different nanoparticle treatments over 20 minutes. The legend indicates:
Control
30 μg CSNPs
60 μg CSNPs
90 μg CSNPs
120 μg CSNPs
150 μg CSNPs
150 μg CeO2 NPs
150 μg AuNPs

The graph shows increasing absorbance over time, with 150 μg CSNPs exhibiting the highest increase.

Graph C: pH-dependent peroxidase activity (%) for pH values ranging from 2 to 12. The graph shows a bell-shaped curve with maximum activity around pH 4-5.

Graph D: Temperature-dependent peroxidase activity (%) for temperatures ranging from 20°C to 90°C. The graph shows a peak in activity at 40°C, with decreasing activity at higher and lower temperatures.

These graphs collectively demonstrate the effects of different nanoparticle concentrations, pH, and temperature on peroxidase activity, with CSNPs (likely chitosan nanoparticles) showing the most significant impact.