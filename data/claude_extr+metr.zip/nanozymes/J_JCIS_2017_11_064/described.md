<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Contents lists available at [ScienceDirect](http://www.sciencedirect.com/science/journal/00219797)

# Journal of Colloid and Interface Science

journal homepage: [www.elsevier.com/locate/jcis](http://www.elsevier.com/locate/jcis)

Regular Article

## Gold core/ceria shell-based redox active nanozyme mimicking the biological multienzyme complex phenomenon

<DESCRIPTION_FROM_IMAGE>This image depicts a pie chart showing the distribution of different components or categories. The chart is divided into four distinct sections, each represented by a different color. The sections are as follows:

1. A blue section occupying approximately 40% of the chart.
2. A yellow section occupying approximately 30% of the chart.
3. A red section occupying approximately 20% of the chart.
4. A green section occupying approximately 10% of the chart.

The pie chart appears to be three-dimensional, with a slight perspective effect giving it depth. There is a white background behind the chart, and a thin gray border surrounds the entire image.

Without additional context or labels, it's not possible to determine what specific data or categories these sections represent. However, this type of chart is commonly used to display proportional or percentage data, where the whole pie represents 100% of a dataset, and each colored section represents a fraction of that whole.</DESCRIPTION_FROM_IMAGE>

Stuti Bhagat a , N.V. Srikanth Vallabani a , Vaithiyalingam Shutthanandan b , Mark Bowden b , Ajay S. Karakoti a,c,⇑ , Sanjay Singh a,⇑⇑

aDivision of Biological and Life Sciences, School of Arts and Sciences, Ahmedabad University, Central Campus, Navrangpura, Ahmedabad 380009, Gujarat, India b Environmental Molecular Sciences Laboratory, Pacific Northwest National Laboratory, Richland, WA 99354, United States c School of Engineering and Applied Science, Ahmedabad University, GICT Building, Central Campus, Navrangpura, Ahmedabad 380009, Gujarat, India

## graphical abstract

<DESCRIPTION_FROM_IMAGE>This image depicts a schematic representation of the catalytic activities of a nanoparticle, likely a cerium oxide-based nanozyme with a gold core. The nanoparticle is shown as a bowl-shaped structure with three distinct layers, as indicated in the key:

1. Au (Core): Gold core
2. Ce³⁺ (Shell): Cerium in its +3 oxidation state forming the outer shell
3. Ce⁴⁺ (Interface): Cerium in its +4 oxidation state at the interface between the core and shell

The nanoparticle exhibits three types of enzyme-like activities:

1. Peroxidase-like activity: Shown at the top of the bowl, converting TMB (3,3',5,5'-tetramethylbenzidine) and H₂O₂ to oxidized TMB (TMB (ox)) and water.
   Reaction: TMB + H₂O₂ → TMB (ox) + 2H₂O

2. Catalase-like activity: Also shown at the top of the bowl, converting hydrogen peroxide to oxygen and water.
   Reaction: 2H₂O₂ → O₂ + 2H₂O

3. SOD-like activity: Shown at the bottom of the bowl, likely referring to superoxide dismutase-like activity, converting superoxide (O₂⁻) to oxygen and hydrogen peroxide.
   Reaction: 2O₂⁻ + 2H⁺ → O₂ + H₂O₂

The image illustrates the multi-enzyme mimetic properties of this nanoparticle, showcasing its potential applications in catalysis and biomedicine. The different activities are represented by arrows of different colors, indicating the conversion of substrates to products.

SMILES notations for the molecules shown:
1. H₂O₂ (Hydrogen peroxide): OO
2. H₂O (Water): O
3. O₂ (Oxygen): O=O

TMB is not shown structurally, so a SMILES notation cannot be provided for it based solely on this image.</DESCRIPTION_FROM_IMAGE>

## article info

Article history: Received 6 October 2017 Revised 21 November 2017 Accepted 21 November 2017 Available online 22 December 2017

Keywords: Multienzyme complex mimicking nanozymes Superoxide dismutase Catalase Peroxidase Enzyme kinetics

## abstract

Catalytically active individual gold (Au) and cerium oxide (CeO2) nanoparticles (NPs) are well known to exhibit specific enzyme-like activities, such as natural catalase, oxidase, superoxide dismutase, and peroxidase enzymes. These activities have been maneuvered to design several biological applications such as immunoassays, glucose detection, radiation and free radical protection and tissue engineering. In biological systems, multienzyme complexes are involved in catalyzing important reactions of essential metabolic processes such as respiration, biomolecule synthesis, and photosynthesis. It is well known that metabolic processes linked with multienzyme complexes offer several advantages over reactions catalyzed by individual enzymes. A functional nanozyme depicting multienzyme like properties has eluded the researchers in the nanoscience community for the past few decades. In the current report, we have designed a functional multienzyme in the form of Gold (core)-CeO2 (shell) nanoparticles (Au/CeO2 CSNPs) exhibiting excellent peroxidase, catalase, and superoxide dismutase enzyme-like activities that are controlled simply by tuning the pH. The reaction kinetic parameters reveal that the peroxidase-like activity of this core-shell nanozyme is comparable to natural horseradish peroxidase (HRP) enzyme. Unlike peroxidase-like activity exhibited by other nanomaterials, Au/CeO2 CSNPs showed a decrease in hydroxyl radical formation, suggesting that the biocatalytic reactions are performed by efficient electron transfers. A significant enzyme-like activity of this core-shell nanoparticle was conserved at extreme pH (2–11) and temperatures (up to 90 C), clearly suggesting the superiority over natural enzymes. Further,

⇑ Corresponding author at: Division of Biological and Life Sciences, School of Arts and Sciences, Central Campus, Navrangpura, Ahmedabad 380009, Gujarat, India. ⇑⇑ Corresponding author.

E-mail addresses: [ajay.karakoti@ahduni.edu.in](mailto:ajay.karakoti@ahduni.edu.in) (A.S. Karakoti), [sanjay.singh@ahduni.edu.in](mailto:sanjay.singh@ahduni.edu.in) (S. Singh).

the utility of peroxidase-like activity of this core-shell nanoparticles was extended for the detection of glucose, which showed a linear range of detection between (100 µM to 1 mM). It is hypothesized that the proximity of the redox potentials of Au+ /Au and Ce (III)/Ce (IV) may result in a redox couple promoting the multienzyme activity of core-shell nanoparticles. Au/CeO2 CSNPs may open new directions for development of single platform sensors in multiple biosensing applications.

2017 Elsevier Inc. All rights reserved.

#### 1. Introduction

Nanomaterials exhibiting biological enzyme-like activity (Nanozymes) are inevitably employed in multiple biomedical applications such as biosensing, immunoassays, organic pollutant degradation, magnetic separation and protection of cells from reactive oxygen species (ROS) [\[1–6\].](#page-11-0) The superior enzyme-like response and affluent synthesis, storage and overall low cost of production have attracted enormous excitement of the researchers worldwide. Significant efforts have been made towards developing efficient nanozymes by controlling the particle size, shape, composition and redox states of materials [\[7,8\].](#page-11-0) Recently, gold nanoparticles (AuNPs) were reported to exhibit peroxidase enzyme-like properties, which have been used to design and develop several applications in bionics, biosensing, and biomedicines [\[9,10\].](#page-11-0) The biological peroxidase-like activity of AuNPs is considered due to their unique physicochemical and optoelectronic properties. It is suggested that peroxidase-like activity of AuNPs also depends on the speedy degradation of hydrogen peroxide used in the reaction. However, the AuNPs-based peroxidase mimetic system suffers from many shortcomings such as lower substrate affinity and specificity, compared with the natural biological enzyme, probably due to inorganic nature of the Au-based catalyst. This issue leads to the lower catalytic performance of AuNPs-based peroxidase nanozymes, which further limits their biomedical applicability. Several efforts made to address this concern have met with limited success. Therefore, additional efforts are imperative to improve the catalytic efficiency of AuNPs as peroxidase nanozyme.

CeO2 nanoparticles are attractive for several applications ranging from wafer polishing to biomedicines [\[11,12\].](#page-11-0) Among its biomedical uses, antioxidant therapy has been tested in several diseases involving ROS such as autoimmune diseases that involve oxidative stress and multiple sclerosis [\[13\].](#page-11-0) CeO2 NPs exhibit redox state-dependent enzyme-like activities wherein ''Ce" (III) and ''Ce" (IV) oxidation states show biological superoxide dismutase (SOD) like and catalase-like activities, respectively [\[14,15\].](#page-11-0) Self and coworkers first observed this activity and reported that analogous to biological SOD enzyme, CeO2 NPs catalyzes the disproportionation of superoxide radicals into hydrogen peroxide and molecular oxygen [\[16,17\]](#page-11-0).

In biological systems, multienzyme complexes are involved in catalyzing important reactions of essential metabolic processes such as respiration, biomolecule synthesis, and photosynthesis. It has been clearly observed that metabolic processes linked with multienzyme complexes offer several advantages over reactions catalyzed by individual enzymes [\[18,19\].](#page-11-0) These natural complexes are generally assembled into sophisticated three-dimensional arrangements with well-controlled geometries that lead to a sequential catalytic conversion of respective substrates into products [\[20,21\]](#page-11-0). Although the individual enzyme reactions are well orchestrated, the lack of spatial proximity synergy may diminish the cascade activities. These issues may decrease the overall efficiency of substrate catalysis as well as the end and intermediate products. Within this context, an inorganic nanozyme exhibiting multienzyme-like activities is expected to be a better alternative for controlling the metabolic processes. Hydrogen peroxide and superoxide radicals are two important ROS controlling the redox nature of cell cytoplasm. Therefore, in the context of enzyme-like activities of AuNPs and CeO2 NPs, it is expected that intimate integration of AuNPs and CeO2 NPs in form of core-shell would perform their respective nanozyme activities efficiently. Various core-shell or nanocomposites of varying materials have been developed showing biological peroxidase and oxidase-like activities. Both of these activities produce hydroxyl radicals, needed to oxidize the substrate at similar pH (4.0). Synthesizing an artificial structure that mimics the complexity and function of a natural multienzyme system are considered as a significant challenge. In this context, Lin et al. [\[22\]](#page-11-0) have developed a self-activated, enzyme-mimetic catalytic cascade consisting of mesoporous silica-encapsulated gold nanoparticles (EMSN-AuNPs) as both glucose oxidase and peroxidase mimetic enzymes. Although authors were able to demonstrate the oxidase-peroxidase coupled enzyme system, the developed method is complicated with limited sensitivity. Zheng et al. [\[23\]](#page-11-0) have reported the self-assembled three-dimensional graphene-magnetic palladium nanohybrids exhibiting intrinsic peroxidase-like and oxidase-like activity. Chen et al. have demonstrated the peroxidase and catalase-like activities in iron oxide nanoparticles [\[24\].](#page-11-0) It was revealed that the peroxidase and catalase-like activity was pH-dependent and exposure to human glioma cells NPs showed a concentration-dependent cytotoxicity by enhancing H2O2-induced cell damage. Additionally, the catalase-like activity in NPs was activated at neutral pH and degraded the excess of H2O2 leading to significantly reduced toxicity to cells. Both peroxidase (Eqs. (1a) and (1b)) and catalase (Eq. (2)) mimetic activities use hydrogen peroxide as a substrate and either break it down to benign water and oxygen molecules (in catalase activity) or generate a cascade of hydroxyl and perhydroxyl radicals (in peroxidase activity) at acidic pH values.

$$\cdot \text{AuNPs} + \text{H}_2\text{O}_2 \rightarrow \cdot \text{OH} + \cdot \text{OH} \tag{1a}$$

$$\text{TMB(red.)} \text{+ } \text{\textdegree OH} \rightarrow \text{ TMB(ox.)} \text{+ } \text{H}_2\text{O} \tag{1b}$$

$$2\mathbf{C}\mathbf{e}^{4+} + \mathbf{H}_2\mathbf{O}_2 + 2\mathbf{OH}^- \rightarrow 2\mathbf{C}\mathbf{e}^{3+} + 2\mathbf{H}_2\mathbf{O} + \mathbf{O}_2 \tag{2}$$

The subtle changes in pH of the medium can control the redox potential of participating nanomaterials that can engage in single electron oxidation or reduction of the hydrogen peroxide. We have now demonstrated a third enzymatic activity from a single nanoparticle system to reduce the superoxide radicals (Eq. (3)) to less harmful peroxide ions.

$$\text{C}_2\text{O}_2^- + \text{C}\text{e}^{3+} + 2\text{H}^+ \rightarrow \text{H}_2\text{O}_2 + \text{C}\text{e}^{4+} \tag{3}$$

Inorganic materials showing a combination of peroxidase, catalase, and SOD enzyme-like properties, as those demonstrated in the current study have not been reported so far. Additionally, this study could be helpful in providing a better understanding of the electron transfer mechanism of inorganic nanomaterials mimicking multienzymes-like properties and their potential applications in the biomedical fields.

Apart from multi-enzyme activity, such hybrid nanomaterials could also be used for the sensitive detection of multiple analytes simultaneously [\[25,26\].](#page-11-0) Au and carbon nanotubes based hybrid material is shown to detect quercetin and rutin together [\[27\].](#page-11-0) A composites of Au and graphene oxides are used for quantitative determination of nitrophenol compounds, triclosan, curcumin, and tyrosine in milk [\[28–31\].](#page-11-0) Composite material consisting of Au and iron oxide with graphene oxide are shown to sense DNA, cefixime and nitrophenol compounds [\[32–34\].](#page-11-0)

In this study, we have demonstrated a general approach for the synthesis of Au core and CeO2 shell nanoparticles (Au/CeO2 CSNPs) through a process of heterogeneous nucleation and growth. The core-shell nanostructures were stable in aqueous suspension and exhibited activities similar to biological peroxidase, catalase, and SOD enzymes. The reaction kinetic parameters suggest that these core-shell nanostructures have comparable Km and Vmax values to the natural horseradish peroxidase (HRP) enzyme. The pH and temperature dependent catalytic activity showed that Au/CeO2 CSNPs can retain significant enzyme-like activity even at extreme physiological conditions. We also showed that this method could detect glucose linearly from 100 µM to 1 mM, a physiologically pertinent concentration found in human serum.

### 2. Materials and methods

Chemicals: Chloroauric acid (HAuCl43H2O, 49%), Hydrogen peroxide (H2O2) 30% and Sodium borohydride (NaBH4) were purchased from SD fine chemicals (Mumbai, India). Cerium (III) nitrate hexahydrate (Ce(NO3)36H2O) 99.99%, 3,30 ,5,5-tetramethyl benzidine (TMB) 99%, xanthine oxidase, catalase, ferricytochrome-C 95% and Glucose oxidase (GOx, from Aspergillus niger) were purchased from Sigma-Aldrich (St. Louis, MO USA). Tri-sodium citrate dehydrate 98%, citric acid monohydrate 99%, Tris hydrochloride 98%, cetyltrimethylammonium bromide (CTAB) 99%, Hypoxanthine 99%, Ethylenediaminetetraacetic acid (EDTA) 98%, Dimethyl sulfoxide (DMSO) 99.8%, phosphate buffer saline (PBS), terephthalic acid 98%, Dulbeco's minimum essential medium (DMEM:F12), and LB broth were purchased from Hi-media Pvt. Ltd. (Mumbai, India). Ammonium solution (NH4OH) 25% was obtained from Rankem (New Delhi, India). Glucose solution was purchased from Gibco (Life Technologies Pvt Ltd. India). All chemicals were used as received.

Synthesis of nanoparticles: Au/CeO2 CSNPs was synthesized in 2 step:-Synthesis of Au seed: In 5 mL of 5 mM HAuCl43H2O, 5 mL (0.2 M) CTAB and 0.6 mL (0.1 M) NaBH4 (ice cold) were added, respectively. HAuCl4 was reduced by NaBH4 and gave brown color solution. This solution was aged for 4 days and further used to synthesize Au/CeO2 CSNPs. Synthesis of Au/CeO2 CSNPs: Au/CeO2 CSNPs were synthesized according to the method reported by Li, Benxia et al. [\[35\]](#page-11-0) with slight modifications. In brief, 0.6 mM of Au seed was re-dispersed into 0.025 M (8 mL) CTAB solution followed by 0.8 mL of EDTA-NH3 solution was added to this mixture. (EDTA-NH3 solution was prepared by adding 0.45 mL of 25% NH3 solution by dissolving 10 mM of EDTA in 40 mL of Milli-Q water). Next, 0.6 mM of Ce(NO3)36H2O solution was added to the above solution. The total volume of solution was adjusted 10 mL. This solution is mixed by repeated by gentle inversion for 1 min and then kept in an oven at 90 C for 5 h. The resultant Au/CeO2 CSNPs was centrifuged at 10,000g for 5 min. The precipitate was re-dispersed into 1 mL water for further use.

Characterization of nanoparticles: Absorbance spectra of AuNPs, CeO2 NPs, and Au/CeO2 CSNPs were acquired using a UV–visible spectrophotometer (Biotek, Synergy HT spectrophotometer). Zeta potential and hydrodynamic diameters of nanoparticles were carried out using dynamic light scattering measurement (DLS) from Zeta sizer nano (Malvern instruments) using a laser with a wavelength of 633 nm. The size and shape of nanoparticles were analyzed by using transmission electron microscope (TEM) equipped with 20–120 kV (JEM1400 plus, JEOL). Samples used for TEM imaging were dialyzed for purification. The Fourier Transformed Infra-Red (FTIR) spectroscopy of AuNPs, CeO2 NPs, and Au/CeO2 CSNPs was carried out by using Spectrum two FT-IR spectrometer (L160000A, PerkinElmer). Samples were dried in Potassium bromide (KBr) powder in 2:1 ratio and analyzed using attenuated total reflectance (ATR) mode. Elemental chemical analysis of AuNPs, CeO2 NPs, Au/CeO2 CSNPs was performed using Scanning electron microscope (SEM) equipped with energy dispersive X-ray (EDX) (JEOL JSM 6010LA JEOL). 1 mL of AuNPs and Au/CeO2 CSNPs was calcined overnight at 90 C and CeO2 NPs were directly dried on glass-slide with 2 nm sputtering of Au-Pd. These nanoparticles were analyzed by placing on a carbon coated copper stub.

XPS measurements were performed on Kratos Axis Ultra spectrophotometer using a monochromatic focused Al Ka X-ray (1486.7 eV) source connected to a glove box for sample preparation in the clean environment prior to loading. The charging shifts were referenced to 916.6 eV peak from cerium 3d3/2 core level peak for calcined samples while they were referenced to Br 3d peak at 68 eV. The survey spectra were collected at 160 eV pass energy and the high-resolution scans for individual elements were collected at a pass energy of 40 eV with 0.1 eV resolution at a dwell time of 300 s. The binding energy of the instrument was calibrated prior to sample characterization and referenced to an energy scale with binding energies for Cu 2p3/2 at 932.67 ± 0.05 eV and Au 4f at 84.0 ± 0.05 eV. The base pressure of the main chamber was maintained at 1.8 10-8 torr and it dropped to 5 10-8 torrs during the sputtering of the sample for XPS measurements. Ar ion sputtering was conducted using an ion gun source operated at 5 kV and 10 mA current for 15 min.

A Rigaku D/MAX RAPID II micro-diffractometer with a curved 2D image plate detector and a rotating Cr anode operating at 35 kV and 25 mA was used for the X-ray diffraction measurements. A parallel incident beam collimated to 300 µm diameter was directed onto the samples which were loaded into 500 µm diameter glass capillaries. Powder samples were examined without further treatment; however, the suspension samples were centrifuged at 2800 RPM for 1 h to settle the particles at the bottom of the capillary. The 2D images were integrated between 30 and 150 2h to give powder traces, and compounds identified by comparison to reference patterns in the ICSD database. Whole-pattern fitting using Topas (v5, Bruker AXS) was used to estimate crystallite sizes based on Scherrer broadening.

Preparation of buffers: Citrate buffer was prepared by dissolving citric acid and trisodium citrate solution in 59:41 ratio in 100 mL of Milli-Q water to obtain 0.1 M solution which was used to determine the peroxidase-like activity of nanoparticles. The buffer was further diluted to get the concentration of 0.01 M which was used in glucose detection. Different pH range (2.0– 12.0) was prepared by using 1 N HCl and 1 N NaOH in Milli-Q water.

Peroxidase-like activity: Oxidation of TMB was used to measure the peroxidase-like activity of Au/CeO2 CSNPs in presence of H2O2. In a typical reaction, TMB (1mM) accompanied by the different concentration of Au/CeO2 CSNPs was mixed. H2O2 (2M) was added at the end to start the catalytic reaction. The total reaction volume of 500 µL was maintained and the resultant increase in absorbance was monitored at 652 nm for 20 min.

Kinetic analysis: Kinetics of the experiments were performed at 37 C using 40 µg/mL Au/CeO2 CSNPs, 1 mM TMB with varying concentration of H2O2 (0.06–3 M) and a fixed concentration of H2O2 (2M) with varying concentrations of TMB (0.05–5 mM) in 0.1 M citrate buffer at pH 4.0. The total reaction volume of 500 µL was maintained and the absorption was recorded at 652 nm with 30 s interval at kinetics mode. The kinetic parameters Km and Vmax were calculated by Lineweaver-Burk plots, as

$$\frac{1}{\nu} = \frac{K_m}{V_{\text{max}}} \left( \frac{1}{[S]} + \frac{1}{Km} \right)^2$$

where v is the initial velocity, Km is Michaelis constant, Vmax represents the maximal reaction velocity and [s] is the substrate concentration.

Effect of temperature and pH on peroxidase-like activity of Au/CeO2 CSNPs: Experiments were carried using 40 µg/mL of Au/CeO2 CSNPs, 1 mM TMB and 2 M H2O2 in 0.1 M citrate buffer (pH-4.0). For pH dependent study, Au/CeO2 CSNPs were incubated overnight at different pH (range 2–12) and the temperature was maintained at 37 C. For temperature studies, the reaction was carried a wide range of temperature (20–90 C) at pH 4.0. The absorbance at 652 nm was measured after 10 min of intervals.

SOD mimetic activity: SOD activity was measured, as described by Korsvik et al. [\[16\].](#page-11-0) In brief, ferri-cytochrome-C was reduced in presence of superoxide radical. Superoxide radical was generated by the reaction between 5 mM hypoxanthine and xanthine oxidase. Here, catalase was added to remove hydrogen peroxide formed in the system. The reaction was carried out in 96 well plates with total volume of 100 µL and the reaction was buffered with 10 mM tris (pH-7.5) and absorbance was monitored at 550 nm for 20 min.

Effect of different biological relevant buffer and pH on SOD-like activity of Au/CeO2 CSNPs: To check the stability of Au/CeO2 CSNPs in biologically relevant buffers, Au/CeO2 CSNPs were incubated overnight in DMEM: F12 (with and without FBS), PBS buffer, LB broth, Milli-Q water and different pH solutions (range 2–12). The reaction was carried using 150 µg/mL Au/CeO2 CSNPs and buffered with 10 mM tris (pH-7.5) and absorbance was measured at 550 nm.

Glucose detection: Detection of glucose was performed in following steps- (1) Different concentrations (0.1–1 mM) of glucose were incubated with glucose oxidase (GOx, 40 Units) in 100 µL of PBS (pH-7.4) at 37 C for 30 min. (2) After incubation, 1 mM TMB, 40 µg/ml Au/CeO2 CSNPs and 10 mM of citrate buffer (pH-4.0) were added into above solution and incubated at 37 C for 30 min. followed by absorbance at 652 nm. The reaction was performed in a final volume of 500 µL.

Test for hydroxyl radicals ( OH) by photoluminescence spectrophotometer: The formation of hydroxyl radicals ( OH) was detected by photoluminescence spectroscopy using terephthalic acid as a probe molecule. 200 mM H2O2, 0.5 mM terephthalic acid and different concentrations of the Au/CeO2 CSNPs were incubated in 10 mM citrate buffer (pH 4.0) for 20 min at ambient temperature and centrifuged at 10,000 rpm for 5 min. After centrifugation, the supernatants were used for fluorometric measurement by using Cary Eclipse fluorescence spectrophotometer (Agilent technologies) with 315 nm excitation and 430 nm emission.

Catalase-like activity measurement: Catalase mimetic activity of Au/CeO2 CSNPs was measured by the decrease in the absorbance of H2O2 at 240 nm, by UV–visible spectrophotometer. A total 1 mL sample volume was used for kinetics measurements containing H2O2 (5 mM) and different concentration of Au/CeO2 CSNPs and 1 mM DTPA (diethylene triamine pentaacetic acid), in order to avoid any potential interference by the metals. This reaction mixture was buffered using 50 mM Tris (pH-7.0).

#### 3. Results and discussion

## 3.1. Evidence of Au core/CeO2 shell nanoparticle synthesis and physicochemical characterization

The monometallic spherical AuNPs were synthesized using CTAB and sodium borohydride resulting in the formation of a brownish red color suspension of CTAB coated AuNPs, which were used as a core to synthesize the core-shell nanoparticles. The aqueous suspension of AuNPs exhibited a typical plasmon peak at 525 nm, suggesting the formation of spherical AuNPs [(Fig. 1A](#page-4-0), black curve). For growing the shell of CeO2 over Au core, Ce(NO3)3, EDTA, and the appropriate amount of ammonia were added to the CTABstabilized AuNP suspension. Ce (III) ions are known to be rapidly hydrolyzed in presence of ammonia, however, the presence of EDTA formation of an anionic complex of Ce (III)-EDTA, which prevents the fast hydrolysis of Ce (III) [\[36\].](#page-11-0) This step is critical for the formation of core-shell because the anionic complex of Ce (III)-EDTA is rapidly adsorbed on the cationic AuNP surface by simple electrostatic attraction [\[37\].](#page-11-0) The above mixture was heated to 90 C to ensure the slow hydrolysis and condensation of Ce (III) from the Ce (III)-EDTA complex. This reaction is further supported by dissolved O2 leading to the preferential heterogeneous nucleation and growth of CeO2 shell around the AuNP spheres. It has been reported that similar reaction conditions produce CeO2 from the oxidation of Ce (III) species [\[38,39\]](#page-11-0). The representative plasmon absorbance peak of AuNPs from Au core/CeO2 shell nanoparticles (Au/CeO2 CSNPs) results in a bathochromic shift of 29 nm, which could be ascribed to the increase in the refractive index of the surrounding medium [(Fig. 1](#page-4-0)A, red curve). Similarly, the change in the absorbance pattern of CeO2 was also followed [(Fig. 1](#page-4-0)B). A typical hydrolysis of Ce (III) by ammonia results in the formation of CeO2 NPs exhibiting the distinct absorbance at 252 nm. However, the absorbance spectrum of the CeO2 present (as shell) on the surface of AuNPs show a bathochromic shift of 27 nm, suggesting the interaction between Cerium and Gold in form of a core-shell. Transmission electron microscopy (TEM) was performed to study the morphology of AuNPs, CeO2 NPs, and Au/CeO2 CSNPs. Core-shell morphology is clearly evident from TEM images shown in [Fig. 1](#page-4-0)C and D depicting a core (AuNPs) shell (CeO2 NPs) arrangement in the resulting nanoparticles. The dense core suggests the presence of Au with high atomic number, whereas light amorphous structure represents the presence of CeO2 NPs around the Au core. Additionally, few nanostructures have a void core, which could be due to incomplete formation of core-shell in some of the structures. Average particle size distribution [(Fig. 1](#page-4-0)C, inset) shows that the average particle size of Au/CeO2 CSNPs is 75 nm. We also examined the morphology and size distribution of CTAB coated AuNPs [(Fig. 1](#page-4-0)E) and CeO2 NPs [(Fig. 1F](#page-4-0)). The TEM images of these NPs suggest that the particles are well dispersed with an average particle size of 12 nm and 19 nm for AuNPs and CeO2 NPs, respectively. Further, the hydrodynamic diameter and zeta potential of aqueous suspensions of AuNPs, CeO2 NPs, and Au/CeO2 CSNPs were also analyzed [(Table 1)](#page-4-0). The average hydrodynamic diameter of AuNPs was 22.68 nm. However, the average size of CeO2 NPs was found 226.7 nm, much higher than the size distribution (19 nm) obtained from TEM images. It has been reported that aqueous suspended CeO2 NPs prefer to be present in form of clusters, which are made up of several individual crystals [\[40\]](#page-11-0). The cluster arrangement may offer high colloidal stability to CeO2 NPs in aqueous suspension. The hydrodynamic size of Au/CeO2 CSNPs was found to be 187.5 nm, 112 nm higher than average particle size distribution obtained from TEM. This could also be ascribed due to the loose agglomeration of Au/CeO2 CSNPs. The zeta potential value of CTAB coated AuNPs and CeO2 NPs was observed to be +41.16 mV and +30.8 mV, respectively. The zeta potential value of Au/CeO2 CSNPs was measured to be +30.0 mV that is slightly higher than the stable suspension regime of zeta potential values suggesting that these nanostructures are in stable colloidal suspension at relatively physiological pH (7.2). The positive zeta potential values at physiological pH also suggest that the CTAB molecules are adsorbed on surfaces of CeO2 giving them a positive charge.

We also studied the morphology and elemental composition of Au/CeO2 CSNPs using scanning electron microscope (SEM) and

<DESCRIPTION_FROM_IMAGE>This image contains six panels labeled A through F, presenting various spectroscopic and microscopic data related to gold (Au) and cerium oxide (CeO2) nanoparticles (NPs) and their core-shell structures (CSNPs).

Panel A: UV-Vis absorption spectra
- X-axis: Wavelength (nm) from 400 to 800 nm
- Y-axis: Normalized absorbance from 0 to 1.2
- Two spectra: AuNPs (black line) and Au/CeO2 CSNPs (red line)
- Both spectra show a peak at around 529 nm with a 29 nm difference in peak position
- Au/CeO2 CSNPs show higher absorbance at longer wavelengths

Panel B: UV-Vis absorption spectra
- X-axis: Wavelength (nm) from 220 to 400 nm
- Y-axis: Normalized absorbance from 0 to 1.2
- Two spectra: CeO2 NPs (blue line) and Au/CeO2 CSNPs (red line)
- CeO2 NPs show a sharp peak at around 250 nm
- Au/CeO2 CSNPs show a broader absorption profile with a peak at around 280 nm
- 27 nm difference in peak position is highlighted

Panel C: TEM image of Au/CeO2 CSNPs
- Scale bar: 50 nm
- Spherical core-shell structures visible
- Inset: Size distribution histogram
  - X-axis: Diameter (nm) from 50 to 150 nm
  - Y-axis: Count from 0 to 30
  - Normal distribution with peak around 85-90 nm

Panel D: TEM image of Au/CeO2 CSNPs
- Scale bar: 100 nm
- Larger field of view showing multiple core-shell structures
- Varying sizes of particles visible

Panel E: TEM image of CeO2 NPs
- Scale bar: 25 nm
- Smaller, more uniform particles visible
- Inset: Size distribution histogram
  - X-axis: Diameter (nm) from 5 to 25 nm
  - Y-axis: Count from 0 to 20
  - Normal distribution with peak around 12-15 nm

Panel F: TEM image of AuNPs
- Scale bar: 200 nm
- Larger, spherical particles visible
- Inset: Size distribution histogram
  - X-axis: Diameter (nm) from 25 to 55 nm
  - Y-axis: Count from 0 to 30
  - Normal distribution with peak around 40-45 nm

This image provides comprehensive characterization of the nanoparticles, including their optical properties and size distributions, demonstrating the successful synthesis of core-shell structures and the individual components.</DESCRIPTION_FROM_IMAGE>

Fig. 1. UV–Visible spectra of as prepared Au/CeO2 CSNPs showing shift in absorbance of AuNPs (A) and CeO2 NPs (B). Transmission electron micrographs of Au/CeO2 CSNPs (C and D), inset shows average particle size distribution (C) and high resolution TEM micrograph (D) of Au/CeO2 CSNPs. TEM micrograph of CTAB coated AuNPs (E) and pristine CeO2 NPs (F), inset shows the average particle size distribution of corresponding nanoparticles.

### Table 1

Hydrodynamic size and zeta potential values of CTAB coated AuNPs, CeO2 NPs and Au/CeO2 CSNPs measured by Dynamic Light Scattering (DLS) at their corresponding pH of the suspension. Data expressed as SD calculated from three independent (n = 3) experiments.

| Nanoparticle type | Size (d.nm)  | Polydispersity index (PDI) | Zeta potential (mV) | pH  |
|-------------------|--------------|----------------------------|---------------------|-----|
| AuNPs             | 22.68 ± 0.2  | 0.50 ± 0.01                | +41.16 ± 3.6        | 7.2 |
| CeO2 NPs          | 226.7 ± 0.2  | 0.33 ± 0.05                | +30.8 ± 1.2         | 4.6 |
| Au/CeO2 CSNPs     | 187.53 ± 9.7 | 0.368 ± 0.01               | +30 ± 1.2           | 7.2 |

energy dispersive analysis of X-rays (EDX), respectively [(Fig. 2A](#page-5-0) and B). The elemental mapping pattern shows characteristic peaks of Au, Ce, and O strongly suggesting the presence of these elements in Au/CeO2 CSNPs. Additionally, the presence of a CeO2 shell in Au/CeO2 CSNPs was also confirmed by FTIR spectroscopy. The FTIR data obtained from pristine CeO2 NPs [(Fig. 2](#page-5-0)C, red curve)

<DESCRIPTION_FROM_IMAGE>This image is composed of four panels labeled A, B, C, and D, each providing different analytical data for a material that appears to be Au/CeO2 core-shell nanoparticles (CSNPs).

Panel A: Shows a scanning electron microscope (SEM) image of the nanoparticles. The scale bar indicates 1 μm. The image was taken on January 12, 2017, with a magnification of x10,000 at 20kV. The nanoparticles appear as light-colored, clustered structures against a darker background.

Panel B: Presents an energy-dispersive X-ray spectroscopy (EDX) spectrum and elemental analysis table. The spectrum shows peaks corresponding to different elements:
- Major peaks: Ce (around 0.9, 4.8, and 5.6 keV)
- Smaller peaks: C (around 0.3 keV), O (around 0.5 keV), Au (around 2.1, 9.7, 11.5, and 13.4 keV)

The table shows atomic percentages:
C: 56.1%
O: 30.3%
Ce: 9.12%
Au: 4.40%

Panel C: Displays FTIR spectra in the range of 1100-1400 cm^-1 for three samples:
1. AuNPs (black line)
2. CeO2NPs (red line)
3. Au/CeO2 CSNPs (green line)

A significant peak is highlighted at 1384 cm^-1, which is most prominent in the Au/CeO2 CSNPs spectrum.

Panel D: Shows X-ray diffraction (XRD) patterns for two samples:
1. As-prepared Au/CeO2 CSNPs (blue line)
2. Calcined Au/CeO2 CSNPs (black line)

The peaks are labeled with Miller indices for CeO2 (blue stars) and Au (red triangles). Notable peaks include:
CeO2: (111), (200), (220), (311), (222), (400), (331), (420)
Au: (111), (200), (220), (311)

The calcined sample shows higher intensity and sharper peaks compared to the as-prepared sample, indicating improved crystallinity after heat treatment.</DESCRIPTION_FROM_IMAGE>

Fig. 2. Scanning electron micrograph of as prepared Au/CeO2 CSNPs (A) and energy dispersive X-ray pattern analysis of corresponding region (B). Inset table shows atom % and mass % of element present in Au/CeO2 CSNPs. Fourier transformation infrared spectra of Au/CeO2 CSNPs (green), AuNPs (black), CeO2 NPs (red) (C). X-ray diffraction pattern of as prepared (blue curve) and calcined (black curve) Au/CeO2 CSNPs (D). (For interpretation of the references to color in this figure legend, the reader is referred to the web version of this article.)

showed the characteristic CeAO bond stretching band at 1384 cm-1 [\[41\]](#page-11-0). The peak corresponding to CeAO bond stretching in Au/CeO2 CSNPs (Fig. 2C, green curve) further supports the characterization data obtained from EDX pattern. As expected CTAB coated AuNPs did not show any signs of CeAO bond stretching (Fig. 2C, black curve).

X-ray diffraction (XRD) patterns of the Au/CeO2 CSNPs are shown in Fig. 2D. The small analysis area (300 lm) and high sensitivity of the X-ray microbeam instrument allowed collection of diffraction data directly from the centrifuged nanoparticles in their as-synthesized condition in aqueous suspension. The raw data (Fig. ESI 1) contained broad signals from the water and glass capillary, these have been subtracted from the pattern shown in Fig. 2D. The as-prepared sample showed relatively broad peaks characteristic of nanocrystalline compounds which could be identified as the cubic phase of CeO2 (ICDD No. 04- 0593) and metallic Au (ICDD No. 04-784). After correcting for instrumental broadening, the crystallite sizes of the compounds were estimated from the peak widths as 5 nm and 10 nm for CeO2 and Au, respectively. Upon calcination the peaks sharpened noticeably, corresponding to crystallite sizes of 10 nm for CeO2 and 90 nm for Au. The larger increase in Au crystallite size is consistent with its higher diffusivity and lower melting temperature compared to CeO2, a refractory material with a high melting point. Several additional weak diffraction peaks were also observed in the pattern of the calcined sample, which could not be matched to any compounds in the ICDD database within the expected range of elemental composition. They were consistent, however, with a primitive cubic lattice with a = 4.94 Å and were presumed to arise from a compound formed during calcination, for example, AuCe intermetallic or mixed metal oxide. The ICDD database does contain patterns of a number of AB3 compounds (A, B = metallic element) with a similar cubic lattice.

X-ray photoelectron spectroscopy (XPS) analysis was performed to understand the surface composition and oxidation states of participating cerium and Au ions in as-synthesized Au/CeO2 CSNPs. [Fig. 3](#page-6-0) shows the core level Au 4f [(Fig. 3](#page-6-0)A and B) and Ce 3d [(Fig. 3](#page-6-0)C) photoelectron spectra. The XPS spectra from calcined Au/CeO2 CSNPs sample [(Fig. 3A](#page-6-0)) show Au 4f core level spectrum containing a single spin-orbit pair (spin-orbit splitting 3.4 eV) of 4f7/2 and 4f5/2 at binding energies of 84.21 and 87.61 eV, respectively; which are in agreement with the values reported for metallic gold. The XPS spectra from as-prepared Au/CeO2 CSNPs sample did not show any signature of Au, however, after Argon (Ar) ion sputtering small contributions could be observed from Au 4f core level spectrum [(Fig. 3B](#page-6-0)), which could be decomposed into a single spin-orbit pair (spin-orbit splitting 3.4 eV) with 4f7/2 and 4f5/2 binding energies of 84.11 and 87.51 eV, respectively. The survey scans collected at 160 eV pass energy showed the presence of participating cerium, bromine (from CTAB), carbon, nitrogen and oxygen ions on the surface (ESI 2A) resulting from the synthesis process. The absence of any noticeable signal of Au in asprepared sample confirms that the gold particles are mostly present as core encapsulated within the core-shell morphology. Even if some of the AuNPs were dislodged from the core-shell morphology its concentration was minimal within the given sample size analyzed using XPS. It is clearly evident from [Fig. 3C](#page-6-0) that in as prepared pristine Au/CeO2 CSNPs sample, cerium ions on the surface are present in trivalent, Ce (III), oxidation state and there is no evidence of Ce (IV) oxidation state on the surface. XPS analysis following Ar ion sputtering resulted in a reduction in the total concentration of carbon, nitrogen, oxygen, and bromine (ESI 2A) though only resulted in a marginal decrease in cerium signal. Sputtering the sample for longer duration resulted in the appearance of peaks corresponding to Au 4f core-level electrons. It must be noted that the presence of Br 3d and Ce 3d peaks on either side of Au 4f

<DESCRIPTION_FROM_IMAGE>The image contains three X-ray photoelectron spectroscopy (XPS) graphs labeled A, B, and C, showing the binding energy spectra of different samples.

Graph A:
Title: "Calcined"
X-axis: Binding energy (eV), range 94-78 eV
Y-axis: Intensity (a.u.)
The graph shows a spectrum before sputtering with two distinct peaks:
1. 4f5/2 peak at approximately 88 eV
2. 4f7/2 peak at approximately 84 eV, with higher intensity than 4f5/2

Graph B:
Title: "As prepared"
X-axis: Binding energy (eV), range 94-78 eV
Y-axis: Intensity (a.u.)
The graph compares two spectra:
1. Before sputtering (black line)
2. After sputtering (red line)
Both spectra show less distinct peaks compared to Graph A. The 4f5/2 and 4f7/2 peaks are labeled, occurring at approximately 88 eV and 84 eV respectively. The intensity of the spectrum before sputtering is higher than after sputtering.

Graph C:
X-axis: Binding energy (eV), range 920-870 eV
Y-axis: Intensity (a.u.)
The graph compares three spectra:
1. Calcined before sputtering (black line)
2. Calcined after sputtering (red line)
3. As prepared (green line)
Several peaks are labeled:
- 3d3/2 peaks at approximately 918 eV, 908 eV, and 900 eV
- 3d5/2 peaks at approximately 888 eV and 880 eV
The calcined after sputtering spectrum shows the highest intensity, followed by calcined before sputtering, and the as prepared sample shows the lowest intensity.

These XPS spectra provide information about the electronic states of the elements present in the samples, showing how the binding energies and intensities change with different sample preparations and treatments (calcination and sputtering).</DESCRIPTION_FROM_IMAGE>

Fig. 3. XPS spectra from Au 4f core levels obtained from calcined (A) and as prepared (B) sample of Au/CeO2 CSNPs. XPS spectra from Ce 3d core levels recorded from as prepared (green curve), calcined-before sputtering (black curve) and calcined-after sputtering (red curve) (C). (For interpretation of the references to color in this figure legend, the reader is referred to the web version of this article.)

resulted in a non-linear baseline making it difficult to interpret the Au photoemission spectra. Even though the signal intensity of Br 3d went down but it did not disappear even after the peaks from Au 4f started to appear. This shows that the CTAB was integrated within the CeO2 shell in addition to being present on the surface during the formation of core-shell morphology and plays a critical role in creating core-shell morphology. It must be noted that cerium ions did not show any changes in Ce (III)/Ce (IV) ratio upon sputtering that may suggest a homogenous distribution of cerium oxidation state, however, it is known that sputtering cerium oxide samples usually results in the reduction of perfectly stoichiometric cerium oxide samples from Ce (IV) to Ce (III) oxidation state due to preferential sputtering of oxygen ions. Thus the presence of Ce (IV) ions (if any) at the interface of Au and CeO2 cannot be determined by XPS. Survey spectrum and high-resolution scans were also collected from Au/CeO2 CSNPs calcined at 550 C (ESI 2B). It was found that the calcination resulted in oxidation of cerium ions on the surface and a mixture of Ce (III) and Ce (IV) oxidation states was found. In addition, calcination resulted in removing all the CTAB from the CSNPs characterized by complete absence of peaks corresponding to nitrogen (ESI 2B, inset-a) and bromine (ESI 2B, inset-b) in the survey spectra.

### 3.2. Au/CeO2 CSNPs exhibit peroxidase-like activity

We and others have reported that Au and several other nanoparticles exhibit activities similar to biological enzymes in certain reactions. For example, AuNPs are reported to show biological peroxidase and catalase enzyme-like activity, whereas Fe3O4 and CeO2 NPs can demonstrate activities like biological peroxidase, superoxide dismutase and oxidase enzymes [\[5,10,42–44\].](#page-11-0) Utilizing these properties several biomedical and biosensing applications have been recently reported. However, there are limited reports offering multiple enzyme-like characteristics from single nanostructure. We first explored the enzymatic activity of Au/CeO2 CSNPs as biological peroxidase mimic. To achieve this, different concentrations of Au/CeO2 CSNPs were subjected to reaction condition typical for peroxidase enzyme and the activity of NPs was evaluated. We used 3,30 ,5,50 -Tetramethylbenzidine (TMB), a chromophoric substrate commonly used in peroxidase mimetic studies. It is a colourless substrate which upon oxidation produces blue colored product (absorbance maxima at 652 nm). It is evident from [Fig. 4](#page-7-0)A that Au/CeO2 CSNPs can quickly catalyse the oxidation of TMB to produce a typical blue color in presence of H2O2 and a concomitant increase in absorbance at 652 nm. The control reaction performed in absence of Au/CeO2 CSNPs did not give color change. As expected, pristine CeO2 NPs also did not induce any oxidation of TMB suggesting that the peroxidase-like activity is solely due to the AuNPs present in the Au/CeO2 CSNPs. The comparative change in the extent of oxidation was clearly evident from the resultant solution of oxidized TMB (Inset [Fig. 4A](#page-7-0)). Further, it was interesting to see that same concentration (150 µg) of Au/CeO2 CSNPs showed better (>2-fold) peroxidase-like activity than pristine AuNPs. The reaction kinetics of varied concentration of Au/CeO2 CSNPs was also followed for 20 min [(Fig. 4B](#page-7-0)). We further examined the pHdependent peroxidase-like activity of Au/CeO2 CSNPs [(Fig. 4C](#page-7-0)). The results show that the optimum pH of this nanozyme is 4.0, however, a significant enzyme-like activity is preserved at pH 5.0 (>80%) and 6.0 (>70%). Unlike natural peroxidase enzyme, the Au/CeO2 CSNPs retain >30% of the enzyme-like activity even at alkaline pH. The enzyme-like activity at neutral and alkaline pH increases the possibility to use Au/CeO2 CSNPs in several biomedical and sensing applications. Since, temperature is another factor which is central to the natural enzymes and beyond a certain optimum temperature range (between 25 and 40 C), the enzyme activity drops significantly. Therefore, we studied the effect of temperature over the peroxidase-like activity of Au/CeO2 CSNPs [(Fig. 4](#page-7-0)D). Although, the optimum temperature was found to be 40 C, but a significantly high (>40%) peroxidase-like activity was observed even at higher temperatures (50–90 C). Natural enzymes undergo irreversible agglomeration when exposed to elevated

<DESCRIPTION_FROM_IMAGE>This image contains four graphs (A, B, C, and D) and a series of vials at the top, presenting data on the effects of various nanoparticles on peroxidase activity under different conditions.

Top image: Eight vials numbered 1-8 containing solutions of varying shades, likely corresponding to the different nanoparticle treatments listed in the legend.

Graph A: UV-Vis absorption spectra from 500-750 nm for different nanoparticle treatments. The legend indicates:
Control (1)
30 μg CSNPs (2)
60 μg CSNPs (3)
90 μg CSNPs (4)
120 μg CSNPs (5)
150 μg CSNPs (6)
150 μg AuNPs (7)
150 μg CeO2 NPs (8)

The graph shows varying absorption peaks around 650 nm, with 150 μg CSNPs showing the highest absorbance.

Graph B: Time-dependent normalized absorbance at 652 nm for different nanoparticle treatments over 20 minutes. The legend indicates:
Control
30 μg CSNPs
60 μg CSNPs
90 μg CSNPs
120 μg CSNPs
150 μg CSNPs
150 μg CeO2 NPs
150 μg AuNPs

The graph shows increasing absorbance over time, with 150 μg CSNPs exhibiting the highest increase.

Graph C: pH-dependent peroxidase activity (%) for pH values ranging from 2 to 12. The graph shows a bell-shaped curve with maximum activity around pH 4-5.

Graph D: Temperature-dependent peroxidase activity (%) for temperatures ranging from 20°C to 90°C. The graph shows a peak in activity at 40°C, with decreasing activity at higher and lower temperatures.

These graphs collectively demonstrate the effects of different nanoparticle concentrations, pH, and temperature on peroxidase activity, with CSNPs (likely chitosan nanoparticles) showing the most significant impact.</DESCRIPTION_FROM_IMAGE>

Fig. 4. Peroxidase-like activity monitoring of different concentrations of Au/CeO2 CSNPs by UV–vis spectrophotometer (A). Inset tubes represents the color intensity of oxidized TMB under different reaction conditions: TMB + H2O2 (tube-1), 30, 60, 90, 120 and 150 µg of Au/CeO2 CSNPs in presence of TMB + H2O2 are represented respectively by tubes 2, 3, 4, 5 and 6. Tubes 7 and 8, respectively represent the color of oxidized TMB after incubation with 150 µg of CTAB coated AuNPs and CeO2 NPs in presence of TMB + H2O2. The peroxidase reaction kinetics of different concentrations of Au/CeO2 CSNPs was followed by recording the changes in absorbance of TMB at 652 nm (B). pH (C) and temperature (D) depended peroxidase like activity of Au/CeO2 CSNPs was also followed keeping the rest of reaction conditions same as above. Data expressed as standard deviation (SD) calculated from three independent (n = 3) experiments.

temperatures, therefore undergo complete loss of enzyme activity. We also examined the peroxidase-like activity of Au/CeO2 CSNPs in different biologically relevant media and buffers such as phosphate buffer saline (PBS) and cell culture media (Fig. ESI 3A). No significant drop in peroxidase activity of Au/CeO2 CSNPs was observed after dispersion in PBS and cell culture media (with or without supplementation with 10% serum). Only CTAB molecules (capping molecules of AuNPs and Au/CeO2 CSNPs) did not show any peroxidase-like activity (ESI3B).

## 3.3. Study of kinetic parameters (Km and Vmax)

Similar to typical Michaelis-Menten reaction, the steady state kinetics study of TMB oxidation by Au/CeO2 CSNPs and H2O2 resulted in a hyperbolic relationship between the substrate concentration and rate of reaction [(Fig. 5A](#page-8-0)). The kinetic parameters, Km and Vmax, were calculated from Lineweaver-Burk plots [(Fig. 5](#page-8-0)B). Similarly, the kinetic study of the degradation of H2O2 by Au/CeO2 CSNPs in presence of TMB also resulted in a hyperbolic, <span id="page-8-0"></span>Michaelis-Menten reaction type relation (Fig. 5C), however, the Lineweaver-Burk plot showed a linear relationship between substrate concentration and velocity of reaction (Fig. 5D). From the kinetic analysis, it was found that at pH 4.0, the Km value for the affinity between Au/CeO2 CSNPs and substrate (TMB) is 0.29 mM, much lower than the reported substrate affinity with HRP (Km = 0.43) [(Table 2](#page-9-0)). However, the Km value of Au/CeO2 CSNPs for H2O2 (Km = 44.69) was found higher than HRP (Km = 3.70), suggesting that higher concentration of H2O2 is needed to obtain same peroxidase activity as HRP [\[1\].](#page-11-0) The maximum velocity (Vmax) of the reaction was also analyzed and compared with the natural HRP enzyme. The Vmax of Au/CeO2 CSNPs for TMB oxidation was 3.9 10-5 mMS-1 in presence of H2O2, about 2.5 times slower than HRP. Similarly, the Vmax of Au/CeO2 CSNPs mediated peroxidase reaction for H2O2 was 2.23 10-5 mMS-1 , about 3.9 times slower than HRP enzyme. These observations suggest that the Au/CeO2 CSNPs offer better substrate affinity than HRP, however, show comparable Vmax at normal physiological conditions. As evident from pH and temperature dependent study, it must also be noted that Au/CeO2 CSNPs may exhibit better peroxidase-like activity at extreme conditions of pH and temperatures than natural HRP enzyme.

## 3.4. Au/CeO2 CSNPs exhibit superoxide dismutase-like activity

Superoxide dismutase (SOD) is an excellent antioxidant enzyme, which catalyzes the dismutation of superoxide radicals into O2 or H2O2. In the biological system, superoxides are generated as a by-product of oxygen metabolism and their levels in cells need to be balanced. Uncontrolled production of superoxide radicals can cause damage and diseases in the cells. There are limited reports about nanomaterials exhibiting SOD-like activity. Among them, CeO2 NPs are the only inorganic material showing comparable dismutation of superoxide radicals than natural SOD enzyme. Self and co-workers have reported that the CeO2 NPs exhibit oxidation state dependent biological enzyme-like activities [\[15\].](#page-11-0) Surface

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled A, B, C, and D, each representing different aspects of a chemical reaction kinetics study.

Graph A:
This graph shows the relationship between TMB (3,3',5,5'-Tetramethylbenzidine) concentration and reaction velocity. The x-axis represents TMB concentration in mM, ranging from 0 to 5 mM. The y-axis shows velocity in mM.sec^-1, scaled by 10^-5, ranging from 0 to 4 x 10^-5 mM.sec^-1. The data points follow a typical Michaelis-Menten kinetics curve, with velocity increasing rapidly at low substrate concentrations and then leveling off at higher concentrations, approaching a maximum velocity.

Graph B:
This is a Lineweaver-Burk plot derived from the data in Graph A. The x-axis shows 1/TMB in mM^-1, ranging from 0 to 20 mM^-1. The y-axis represents 1/V (inverse velocity) in Sec.mM^-1, scaled by 10^5, ranging from 0.2 to 2.2 x 10^5 Sec.mM^-1. The plot shows a linear relationship between 1/V and 1/TMB, which is characteristic of Lineweaver-Burk analysis. The R^2 value of 0.9823 indicates a strong linear correlation.

Graph C:
This graph depicts the relationship between H2O2 (hydrogen peroxide) concentration and reaction velocity. The x-axis shows H2O2 concentration in mM, ranging from 0 to 3000 mM. The y-axis represents velocity in mM.sec^-1, scaled by 10^-5, ranging from 1.2 to 2.4 x 10^-5 mM.sec^-1. The curve resembles Michaelis-Menten kinetics, similar to Graph A, but with a much higher substrate concentration range.

Graph D:
This is a Lineweaver-Burk plot for the H2O2 data from Graph C. The x-axis shows 1/H2O2 in mM^-1, ranging from 0 to 0.02 mM^-1. The y-axis represents 1/V in Sec.mM^-1, scaled by 10^4, ranging from 4 to 8 x 10^4 Sec.mM^-1. The plot shows a linear relationship between 1/V and 1/H2O2, with an R^2 value of 0.9539, indicating a strong linear correlation.

These graphs collectively provide information about the enzyme kinetics of a reaction involving TMB and H2O2, likely catalyzed by an enzyme such as peroxidase. The Michaelis-Menten plots (A and C) and their corresponding Lineweaver-Burk plots (B and D) allow for the determination of important kinetic parameters such as Km (Michaelis constant) and Vmax (maximum velocity) for both substrates.</DESCRIPTION_FROM_IMAGE>

Fig. 5. Study of kinetic parameters (km and Vmax): The Michaelis-Menten curves for the peroxidase-like activity of Au/CeO2 CSNPs of TMB (A) and H2O2 (C). For TMB the concentration of H2O2 was fixed to 2 M while TMB was varied from 0.05 to 5 mM. For H2O2, the concentration of TMB was fixed to 1 mM and a concentration of H2O2 was varied from 0.06 to 3 M. Double reciprocal plots of TMB (B) and H2O2 (D) was made from the respective Michaelis-Menten curves.

#### <span id="page-9-0"></span>Table 2

Comparison of kinetic parameters (Km and Vmax) between Au/CeO2 CSNPs and horseradish peroxidase (HRP) for TMB and H2O2.

|               | Substrate   | km (mM)       | 1<br>Vmax (mM S<br>)            |
|---------------|-------------|---------------|---------------------------------|
| Au/CeO2 CSNPs | TMB<br>H2O2 | 0.29<br>44.69 | 5<br>3.900  10<br>5<br>2.23  10 |
| HRP           | TMB<br>H2O2 | 0.43<br>3.70  | 5<br>10.00  10<br>5<br>8.71  10 |

''Ce" atoms from CeO2 NPs are present in a ratio of the two stable oxidation states, Ce (III) or (IV). High Ce (III)/(IV) surface atoms are reported to show SOD enzyme-like activity, however, high Ce (IV)/ (III) ratio gives biological catalase-like activity. The redox switching ability of CeO2 NPs provides autocatalytic property, which enables it to auto regenerate the surface and thereby act catalytically.

Therefore, we examined any potential SOD enzyme-like activity in the Au/CeO2 CSNPs. As evident from the reaction kinetics (Fig. 6A), the core-shell nanoparticles showed excellent concentration-dependent SOD enzyme-like activity. We varied the concentration of Au/CeO2 CSNPs from 30 to 300 µg/mL and the enzyme-like activity was obtained at all the concentrations. The role of AuNPs in SOD enzyme-like activity was also investigated, and as expected, a very high concentration of (300 µg/mL) of AuNPs did not show any enzyme activity, suggesting that the SOD enzyme-like activity is solely due to the CeO2 present in the shell. It is expected that a nanoparticle, designed for biomedical applications, would be exposed to varying pH environment present in the biological system [\[45\].](#page-11-0) This altered pH may induce changes in the surface properties of NPs, thereby alteration in enzyme-like activities as well. Further, the pH of cytoplasm remains near neutral, but the pH in subcellular organelles can be acidic or basic. In human body itself, the range of pH varies from 2 (stomach) to 9 (intestine) [\[45–47\]](#page-11-0). Therefore, it is imperative to study the potential alteration in enzyme-like activity of Au/CeO2 CSNPs. To test this, we incubated the Au/CeO2 CSNPs in at different pH for 24 h followed by estimating their SOD enzyme-like activity (ESI 4). The optimum pH for maximum enzyme activity was found 8.0, however, >70% of SOD enzyme-like activity was retained from a broad range of pH (from 2 to 11). Further, as discussed above, the maximum range of pH variation in the human body is 2–9, however, Au/CeO2 CSNPs can tolerate the pH range from 2 to 11, suggesting that this nanostructure may be well suited for oral or intravenous administration to a human body. Au/CeO2 CSNPs suspended in cell culture media supplemented with 10% serum, showed a significant decrease in SOD activity (Fig. ESI 5), however, when suspended in PBS or cell culture media without serum, showed no drop in activity. It is well documented that nanomaterials undergo ''protein corona" formation when suspended in protein-rich suspension [\[48\]](#page-11-0). The electrostatic adsorption of negatively charged serum proteins over positively charged Au/CeO2 CSNPs could be the major factor for inhibition of SOD activity. This interaction was further supported by the complete drop in zeta potential value after suspension of Au/CeO2 CSNPs in serumcontaining cell culture media (ESI Table 1), than dispersion in PBS and cell culture media without serum proteins.

## 3.5. Catalase-like activity of Au/CeO2 CSNPs

We also examined the biological catalase-like activity in Au/ CeO2 CSNPs (Fig. 6B). It is clearly evident that Au/CeO2 CSNPs exhibited a concentration-dependent hydrogen peroxide degradation, measured by following absorbance at 240 nm by UV-vis spectrophotometer. The nanoparticle suspensions of either CeO2 NPs or

<DESCRIPTION_FROM_IMAGE>The image contains two graphs showing the normalized absorbance of different nanoparticle samples over time.

Graph 1 (Top):
This graph shows the normalized absorbance at 550 nm over a 20-minute period for various nanoparticle samples.

X-axis: Time (min), ranging from 0 to 20 minutes
Y-axis: Normalized absorbance (550 nm), ranging from 0 to approximately 0.3

The graph includes 8 different samples:
1. Control (highest absorbance)
2. 300μg CeO₂NPs (lowest absorbance)
3. 300μg AuNPs
4. 30μg CSNPs
5. 45μg CSNPs
6. 75μg CSNPs
7. 150μg CSNPs
8. 300μg CSNPs

All samples show an increase in absorbance over time, with the control sample reaching the highest absorbance of about 0.28 at 20 minutes. The 300μg CeO₂NPs sample shows the lowest absorbance, remaining close to 0 throughout the experiment. The other samples fall between these two extremes, with varying degrees of absorbance increase.

Graph 2 (Bottom):
This graph shows the normalized absorbance at 240 nm over a 20-minute period for different concentrations of CSNPs (Core-Shell Nanoparticles).

X-axis: Time (min), ranging from 0 to 20 minutes
Y-axis: Normalized absorbance (240 nm), ranging from -0.08 to 0.00

The graph includes 5 different samples:
1. Control
2. 50 μg CSNPs
3. 75 μg CSNPs
4. 100 μg CSNPs
5. 150 μg CSNPs

Unlike the first graph, this one shows a decrease in absorbance over time for all CSNP samples. The control sample remains relatively constant near 0 absorbance. The 150 μg CSNPs sample shows the most significant decrease, reaching about -0.07 absorbance at 20 minutes. The other CSNP samples show intermediate decreases in absorbance, with the magnitude of decrease correlating with the concentration of CSNPs.

Both graphs include error bars for each data point, indicating the variability or uncertainty in the measurements.

These graphs likely represent a study on the optical properties or interactions of different nanoparticles, particularly focusing on Core-Shell Nanoparticles (CSNPs) at different concentrations and wavelengths.</DESCRIPTION_FROM_IMAGE>

Fig. 6. Time and concentration depended SOD activity of Au/CeO2 CSNPs was measured by the reduction of ferri-cytochrome C by superoxide and measuring the absorbance at 550 nm. 300 µg of CeO2 NPs was taken as positive control, whereas 300 µg of CTAB coated AuNPs was also tested for any SOD activity. Time dependent catalase-like activity of different concentrations of Au/CeO2 CSNPs was monitored by following the decrease in absorbance of H2O2 at 240 nm using a UV–vis spectrophotometer. Data expressed as SD calculated from three independent (n = 3) experiments.

AuNPs alone did not exhibit any significant catalase-like enzyme activity (ESI 6). Although, it is reported that CeO2 NPs with high (IV) oxidation state of surface ''Ce" atoms show catalase-like activity, however, in this study the CeO2 NPs (shell) with high (III) oxidation state surface ''Ce" atoms exhibited the activity. We have earlier reported that CeO2 NPs (III) readily reacts with phosphate anions to form cerium phosphate [\[49\].](#page-11-0) In this reaction, the oxidation state of surface ''Ce" atoms are expected to be blocked in Ce (III) oxidation state by formation of cerium phosphate. The catalase activity of Au/CeO2 CSNPs at neutral pH suggests that it can scavenge H2O2 through a non-radical bearing pathway. At higher pH the redox potential for oxidation of H2O2 to O2 is low and its decomposition can be catalyzed by Ce (IV)/Ce (III) redox couple [\[50\]](#page-11-0). It is clear from XPS data that the oxidation state of cerium ions on the surface of Au/CeO2 CSNPs is predominantly Ce (III) that explains the high SOD activity of the CSNPs however it cannot explain the origin of catalase activity. The high catalase mimetic activity depicted by Au/CeO2 CSNPs suggests a strong coupling of Au/Ce redox couple resulting in the formation of Ce (IV) at the interface of Au core and CeO2 shell and within the matrix. Since information from XPS is limited only to the surface of materials it depicts the oxidation state of only surface cerium ions. The sputtering of cerium oxide is not used for estimating the Ce (IV)/Ce (III) ratio at a higher depth due to the preferential sputtering of oxygen resulting in the reduction of any Ce (IV) ions present in the matrix. It was directly observed from XRD that cerium oxide crystallizes in fluorite lattice of CeO2 as opposed to the hexagonal lattice Ce2O3 confirming an octahedral coordination of cerium with oxygen ions and suggesting a Ce (IV) oxidation state within the bulk of the structure. This shows that Au/CeO2 CSNPs can take as well as give electrons to the hydrogen peroxide and other oxidizing species depending upon the pH of the medium functioning like a true enzyme.

## 3.6. Peroxidase-like activity of Au/CeO2 CSNPs can be exploited for glucose detection

The use of peroxidase-like activity of Au/CeO2 CSNPs for biosensing application was carried out by sensitive detection of glucose. The biosensing was performed in two steps; the first step was performed at neutral pH, involving the reaction between glucose oxidase (GOx) and glucose to produce H2O2 followed by peroxidase reaction in presence of Au/CeO2 CSNPs to oxidize the substrate (TMB) at acidic pH. As clearly shown in Fig. 7A, glucose

<DESCRIPTION_FROM_IMAGE>This image contains two parts: a photograph of test tubes and two graphs labeled A and B.

The photograph shows 8 test tubes numbered from 1 to 8, containing solutions with gradually changing hues from clear to more intense.

Graph A:
This graph shows normalized absorbance (y-axis) versus wavelength (x-axis) for various glucose concentrations.
- X-axis: Wavelength (nm), ranging from 550 to 750 nm
- Y-axis: Normalized absorbance (650 nm), ranging from 0.6 to 1.4
- The graph contains multiple curves representing different glucose concentrations:
  1. Control (1mM Glucose) (1)
  2. Control (GOx) (2)
  3. 0.1mM Glucose (3)
  4. 0.2mM Glucose (4)
  5. 0.4mM Glucose (5)
  6. 0.6mM Glucose (6)
  7. 0.8mM Glucose (7)
  8. 1mM Glucose (8)
- The curves show varying absorbance peaks, with higher glucose concentrations generally showing higher peak absorbance values.
- The peak absorbance for most curves occurs around 650-660 nm.

Graph B:
This graph shows absorbance at 652 nm (y-axis) versus glucose concentration (x-axis).
- X-axis: Glucose concentration (mM), ranging from 0 to 1 mM
- Y-axis: Absorbance at 652 nm, ranging from 0.14 to 0.23
- The graph shows a linear relationship between glucose concentration and absorbance
- Data points are plotted with error bars
- A linear trendline is fitted to the data
- The coefficient of determination (R²) is given as 0.9963, indicating a strong linear correlation

This image demonstrates the relationship between glucose concentration and absorbance, likely in the context of a glucose sensing or quantification experiment. The linear relationship in Graph B suggests that this method could be used for quantitative glucose determination within the tested concentration range.</DESCRIPTION_FROM_IMAGE>

Fig. 7. Detection of different concentrations of glucose using the peroxidase-like activity of Au/CeO2 CSNPs (A). Inset tubes 3, 4, 5, 6, 7 and 8 respectively represent the color of oxidized TMB generated in presence of different glucose concentration (0, 0.1, 0.2, 0.4, 0.6, 0.8, 1 mM) and TMB and H2O2 and glucose oxidase. Tube 1 and 2 contain only glucose and glucose oxidase, respectively in similar reaction conditions as above. Linear detection range (0.01–1 mM) of glucose was obtained when detected using peroxidase-like activity of Au/CeO2 CSNPs. Data expressed as SD calculated from three independent (n = 3) experiments.

concentration (0, 0.1, 0.2, 0.4, 0.6, 0.8, 1 mM) dependent oxidation of TMB was obtained. The resultant color of oxidized TMB is shown in tubes labeled from 1 to 8 (Fig. 7A, inset), which corresponds to only glucose, GOx, 0.1, 0.2, 0.4, 0.6, 0.8, 1 mM of glucose. A linear relationship was obtained for glucose detection from 100 µM to 1 mM in quick time (5 min) (Fig. 7B). Therefore, it can be concluded that this Au/CeO2 CSNPs can be applied for easy and rapid monitoring of blood glucose level in normal as well as diabetic persons. Higher peroxidase activity displayed by CSNPs as compared to bare Au NPs suggests that the ceria shell structure is porous that allows the hydrogen peroxide to access AuNPs encapsulated within a 40–50 nm shell of CeO2. In addition to fast diffusion kinetics of radicals in and out of the shell structure resulting in oxidation of TMB, it is also suggested that there is another mechanism of action than the generation of hydroxyl radicals. It is known that the action of hydroxyl radical is diffusion limited and thus cannot explain the high activity of Au/CeO2 CSNPs as compared to AuNPs.

It has been reported that hydroxyl radicals formed from the decomposition of H2O2 by the nanoparticles result in the peroxidase-like activity [\[51\].](#page-11-0) Therefore, we also investigated the significance of hydroxyl radicals in the peroxidase-like activity of Au/CeO2 CSNPs. Surprisingly, an increase in hydroxyl radical generation was not observed when terephthalic acid was used as a fluorescence probe (Fig. ESI 7). An increase in the concentration (35.5, 75 and 150 µg/mL) of Au/CeO2 CSNPs did not result in the formation of 2-hydroxylterephthalic acid, a fluorescent by-product, during a reaction between hydroxyl radical and terephthalic acid.

Thus it is clear that mechanism of action of TMB by Au/CeO2 CSNPs is different than the mechanism displayed by pure AuNPs. It was recently shown by Zhang et al. that Prussian blue nanoparticles (PBNPs) show a similarly high peroxidase activity in an acidic medium that is not mediated through the classical Fenton mechanism. Instead, it was hypothesized that the oxidation of TMB proceeds through a mechanism where TMB is oxidized directly by the H2O2 in presence of PBNPs [\[50\].](#page-11-0) We hypothesize that a similar mechanism may lead to oxidation of TMB in present study however the exact mechanism and the proximity of TMB to H2O2 for carrying out this reaction are not very well understood at present. It can be hypothesized that even though the peroxidase chemistry is carried out by Au, the presence of CeO2 shell with a Ce (IV)/Ce (III) redox potential of 1.71 V facilitates the H2O2/H2O chemistry (1.776 V) instead of the usual H2O2/O2 (0.695 V) chemistry thus suppressing the formation of hydroxyl radicals. The Au/CeO2 redox couple is one of the most studied catalysts for the CO oxidation and WGS shift reaction. It has been documented that the redox coupling between Au and CeO2 can result in the formation of different oxidation states such as Au3+/Au+ on cerium oxide surfaces resulting in partial oxidation of Ce (III) [\[52\].](#page-11-0) This chemistry is facilitated by close redox potential values of Au3+/Au (1.498 V), Au+ /Au (1.69 V) and Ce (IV)/Ce (III) (1.71 V) suggesting that the reactions are highly reversible especially because the cerium redox couple is highly sensitive to changes in pH and type of acid (redox potential values in HClO4 – 1.71 V, HNO3 – 1.44 V, H2SO4 – 1.61 V, HCl – 1.28 V). Thus a continuous redox coupling can occur between the two materials facilitating catalytic reactions.

### 4. Conclusion

Au/CeO2 CSNPs represent a unique biomimetic multienzyme complex, which could be used for several biomedical applications, especially related to peroxidase, catalase and SOD enzymes. The characterization data reveal that Au/CeO2 CSNPs are colloidally stable at physiological conditions and typical synthesis does not require extreme conditions of pH and temperature. The SOD and catalase enzyme-like activities of Au/CeO2 CSNPs are maximum <span id="page-11-0"></span>at neutral pH, whereas the peroxidase-like activity at acidic pH. The calculated kinetic parameters (km and Vmax) suggest that these nanostructures have better substrate affinity but lower reaction velocity than HRP enzyme. These nanostructures were also used for the efficient detection of glucose from 100 µM to 1 mM in quick time (5 min). Contrasting to the majority of nanocatalysts, these nanostructures retain their enzyme-like activity at broad pH range. Although it is expected that AuNPs (core) and CeO2 NPs (shell) respectively exhibit peroxidase and SOD enzyme-like activities, however, the catalase enzyme-like activity is a novel feature of this nanocatalyst which is expected to be originating from the redox cycling occurring at the interface of the two materials. These catalytically active core-shell nanostructures are very promising for applications in direct detection of glucose and other biosensing methodologies. A more in-depth investigation is needed to exploit the full potential of Au/CeO2 CSNPs for antioxidant therapy and other biomedical applications.

#### Acknowledgement

The financial assistance for the centre for Nanotechnology Research and Applications (CENTRA) by the Gujarat Institute for Chemical Technology (GICT), Gandhinagar and the funding from the Science and Engineering Research Board (SERB), India, Grant No. ILS/SERB/2015-2016/01 to Dr Sanjay Singh under the scheme of start-up research grant in Life Sciences is also acknowledged. The Early Carrier Research grant Award (ECRA) to Dr Ajay S. Karakoti (Grant No. ECR/2016/000055) is also gratefully acknowledged. A portion of research was performed using Environmental Molecular Sciences Laboratory (EMSL), a DOE Office of Science User Facility sponsored by the Office of Biological and Environmental Research and located at Pacific Northwest National Laboratory. This work was supported by the EMSL intramural program.

#### Conflict of interest

Authors declare no conflict of interest.

#### Appendix A. Supplementary material

Supplementary data associated with this article can be found, in the online version, at <https://doi.org/10.1016/j.jcis.2017.11.064>.

#### References

- [1] [L. Gao, J. Zhuang, L. Nie, J. Zhang, Y. Zhang, N. Gu, T. Wang, J. Feng, D. Yang, S.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0005) [Perrett, X. Yan, Nat. Nanotechnol. 2 (9) (2007) 577–583](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0005).
- [2] [J.M. Perez, Nat. Nanotechnol. 2 (9) (2007) 535–536](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0010).
- [3] [S. Zhang, X. Zhao, H. Niu, Y. Shi, Y. Cai, G. Jiang, J. Hazard Mater. 167 (1–3)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0015) [(2009) 560–566.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0015)
- [4] [Y. Lin, J. Ren, X. Qu, Acc. Chem. Res. 47 (4) (2014) 1097–1105.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0020)
- [5] [S. Singh, Biointerphases 11 (4) (2016) 04B202](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0025).
- [6] [R. Singh, A.S. Karakoti, W. Self, S. Seal, S. Singh, Langmuir 32 (46) (2016)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0030) [12202–12211.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0030)
- [7] [N. Tian, Z.Y. Zhou, S.G. Sun, Y. Ding, Z.L. Wang, Science 316 (5825) (2007) 732–](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0035) [735.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0035)
- [8] [G.A. Somorjai, J.Y. Park, Angew. Chem. Int. Ed. Engl. 47 (48) (2008) 9212–9228](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0040).
- [9] [Y. Lin, J. Ren, X. Qu, Adv. Mater. 26 (25) (2014) 4200–4217](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0045).
- [10] [J. Shah, R. Purohit, R. Singh, A.S. Karakoti, S. Singh, J. Colloid Interface Sci. 456](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0050) [(2015) 100–107.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0050)

- [11] [A. Karakoti, S. Singh, J.M. Dowding, S. Seal, W.T. Self, Chem. Soc. Rev. 39 (11)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0055) [(2010) 4422–4432](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0055).
- [12] [A.S. Karakoti, S. Singh, A. Kumar, M. Malinska, S.V. Kuchibhatla, K. Wozniak, W.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0060) [T. Self, S. Seal, J. Am. Chem. Soc. 131 (40) (2009) 14144–14145.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0060)
- [13] [K.L. Heckman, W. DeCoteau, A. Estevez, K.J. Reed, W. Costanzo, D. Sanford, J.C.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0065) [Leiter, J. Clauss, K. Knapp, C. Gomez, P. Mullen, E. Rathbun, K. Prime, J. Marini, J.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0065) [Patchefsky, A.S. Patchefsky, R.K. Hailstone, J.S. Erlichman, ACS Nano 7 (12)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0065) [(2013) 10582–10596](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0065).
- [14] [T. Pirmohamed, J.M. Dowding, S. Singh, B. Wasserman, E. Heckert, A.S.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0070) [Karakoti, J.E. King, S. Seal, W.T. Self, Chem. Commun. (Camb.) 46 (16) (2010)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0070) [2736–2738](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0070).
- [15] [E.G. Heckert, A.S. Karakoti, S. Seal, W.T. Self, Biomaterials 29 (18) (2008) 2705–](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0075) [2709.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0075)
- [16] [C. Korsvik, S. Patil, S. Seal, W.T. Self, Chem. Commun. (Camb.) 10 (2007) 1056–](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0080) [1058.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0080)
- [17] [C. Walkey, S. Das, S. Seal, J. Erlichman, K. Heckman, L. Ghibelli, E. Traversa, J.F.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0085) [McGinnis, W.T. Self, Environ. Sci. Nano 2 (1) (2015) 33–53.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0085)
- [18] [D.J. Lieber, J. Catlett, N. Madayiputhiya, R. Nandakumar, M.M. Lopez, W.W.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0090) [Metcalf, N.R. Buan, PLoS One 9 (9) (2014) e107563](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0090).
- [19] [C.M. Agapakis, P.M. Boyle, P.A. Silver, Nat. Chem. Biol. 8 (6) (2012) 527–535.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0095)
- [20] [P.A. Srere, Annu. Rev. Biochem. 56 (1987) 89–124](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0100).
- [21] [R.N. Perham, Annu. Rev. Biochem. 69 (2000) 961–1004](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0105).
- [22] [Y. Lin, Z. Li, Z. Chen, J. Ren, X. Qu, Biomaterials 34 (11) (2013) 2600–2610](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0110). [23] [X. Zheng, Q. Zhu, H. Song, X. Zhao, T. Yi, H. Chen, X. Chen, A.C.S. Appl, Mater.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0115) [Interfaces 7 (6) (2015) 3480–3491](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0115).
- [24] [Z. Chen, J.J. Yin, Y.T. Zhou, Y. Zhang, L. Song, M. Song, S. Hu, N. Gu, ACS Nano 6](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0120) [(5) (2012) 4001–4012.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0120)
- [25] [R. Savaliya, D. Shah, R. Singh, A. Kumar, R. Shanker, A. Dhawan, S. Singh, Curr.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0125) [Drug. Metab. 16 (8) (2015) 645–661](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0125).
- [26] [R. Savaliya, P. Singh, S. Singh, Curr. Pharm. Des. 22 (11) (2016) 1506–1520.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0130)
- [27] [M.L. Yola, N. Atar, Electrochim. Acta 119 (2014) 24–31.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0135)
- [28] [P. Guo, L. Tang, J. Tang, G. Zeng, B. Huang, H. Dong, Y. Zhang, Y. Zhou, Y. Deng, L.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0140) [Ma, J. Colloid inter. Sci. 469 (2016) 78–85](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0140).
- [29] [M.L. Yola, N. Atar, T. Eren, H. Karimi-Maleh, S. Wang, RSC Adv. 5 (81) (2015)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0145) [65953–65962.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0145)
- [30] [G. Kotan, F. Karda](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0150)s[, Ö.A. Yoku](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0150)s[, O. Akyıldır](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0150)ı[m, H. Saral, T. Eren, M.L. Yola, N.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0150) [Atar, Anal. Methods 8 (2) (2016) 401–408](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0150).
- [31] [M.L. Yola, T. Eren, N. Atar, Sens. Actuators B Chem. 210 (2015) 149–157](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0155).
- [32] [M.L. Yola, T. Eren, N. Atar, Electrochim. Acta 125 (2014) 38–47.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0160)
- [33] [M.L. Yola, T. Eren, N. Atar, Biosens. Bioelectron. 60 (2014) 277–285](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0165).
- [34] [V.K. Gupta, N. Atar, M.L. Yola, Z. Üstündag˘, L. Uzun, Water Res. 48 (2014) 210–](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0170) [217](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0170).
- [35] [B. Li, T. Gu, T. Ming, J. Wang, P. Wang, J. Wang, J.C. Yu, ACS Nano 8 (8) (2014)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0175) [8152–8162](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0175).
- [36] [F. Luo, C.-J. Jia, W. Song, L.-P. You, C.-H. Yan, Cryst. Growth Des. 5 (1) (2005)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0180) [137–142.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0180)
- [37] [H. Chen, L. Shao, Q. Li, J. Wang, Chem. Soc. Rev. 42 (7) (2013) 2679–2724.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0185)
- [38] [T. Yu, B. Lim, Y. Xia, Angew. Chem. Int. Ed. Engl. 49 (26) (2010) 4484–4487](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0190). [39] [J. Zhen, X. Wang, D. Liu, S. Song, Z. Wang, Y. Wang, J. Li, F. Wang, H. Zhang,](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0195)
- [Chemistry 20 (15) (2014) 4469–4473.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0195)
- [40] [S. Singh, A. Kumar, A. Karakoti, S. Seal, W.T. Self, Mol. Biosyst. 6 (10) (2010)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0200) [1813–1820](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0200).
- [41] [R. Singh, S. Singh, Colloids Surf. B Biointerfaces 132 (2015) 78–84](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0205).
- [42] [W. He, Y.T. Zhou, W.G. Wamer, X. Hu, X. Wu, Z. Zheng, M.D. Boudreau, J.J. Yin,](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0210) [Biomaterials 34 (3) (2013) 765–773](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0210).
- [43] [N.V. Vallabani, A.S. Karakoti, S. Singh, Colloids Surf. B Biointerfaces 153 (2017)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0215) [52–60](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0215).
- [44] [A. Asati, C. Kaittanis, S. Santra, J.M. Perez, Anal. Chem. 83 (7) (2011) 2547–](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0220) [2553.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0220)
- [45] [R.R. Rodriguez, N.T. Basta, S.W. Casteel, L.W. Pace, Environ. Sci. Technol. 33 (4)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0225) [(1999) 642–649](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0225).
- [46] [D.G. Beak, N.T. Basta, K.G. Scheckel, S.J. Traina, Environ. Sci. Technol. 40 (4)](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0230) [(2006) 1364–1370.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0230)
- [47] [A.M. Gatti, D. Tossini, A. Gambarelli, S. Montanari, F. Capitani, Crit. Rev. Food](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0235) [Sci. Nutr. 49 (3) (2009) 275–282](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0235).
- [48] [C. Corbo, R. Molinaro, A. Parodi, N.E. Toledano Furman, F. Salvatore, E. Tasciotti,](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0240) [Nanomedicine (Lond.) 11 (1) (2016) 81–100](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0240).
- [49] [S. Singh, T. Dosani, A.S. Karakoti, A. Kumar, S. Seal, W.T. Self, Biomaterials 32](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0245) [(28) (2011) 6745–6753](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0245).
- [50] [W. Zhang, S. Hu, J.J. Yin, W. He, W. Lu, M. Ma, N. Gu, Y. Zhang, J. Am. Chem. Soc.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0250) [138 (18) (2016) 5860–5865](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0250).
- [51] [W.P. Kwan, B.M. Voelker, Environ. Sci. Technol. 37 (6) (2003) 1150–1158](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0255).
- [52] [M. Wang, F. Wang, J. Ma, M. Li, Z. Zhang, Y. Wang, X. Zhang, J. Xu, Chem.](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0260) [Commun. 50 (3) (2014) 292–294](http://refhub.elsevier.com/S0021-9797(17)31369-3/h0260).