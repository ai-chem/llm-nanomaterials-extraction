The image contains two graphs showing the normalized absorbance of different nanoparticle samples over time.

Graph 1 (Top):
This graph shows the normalized absorbance at 550 nm over a 20-minute period for various nanoparticle samples.

X-axis: Time (min), ranging from 0 to 20 minutes
Y-axis: Normalized absorbance (550 nm), ranging from 0 to approximately 0.3

The graph includes 8 different samples:
1. Control (highest absorbance)
2. 300μg CeO₂NPs (lowest absorbance)
3. 300μg AuNPs
4. 30μg CSNPs
5. 45μg CSNPs
6. 75μg CSNPs
7. 150μg CSNPs
8. 300μg CSNPs

All samples show an increase in absorbance over time, with the control sample reaching the highest absorbance of about 0.28 at 20 minutes. The 300μg CeO₂NPs sample shows the lowest absorbance, remaining close to 0 throughout the experiment. The other samples fall between these two extremes, with varying degrees of absorbance increase.

Graph 2 (Bottom):
This graph shows the normalized absorbance at 240 nm over a 20-minute period for different concentrations of CSNPs (Core-Shell Nanoparticles).

X-axis: Time (min), ranging from 0 to 20 minutes
Y-axis: Normalized absorbance (240 nm), ranging from -0.08 to 0.00

The graph includes 5 different samples:
1. Control
2. 50 μg CSNPs
3. 75 μg CSNPs
4. 100 μg CSNPs
5. 150 μg CSNPs

Unlike the first graph, this one shows a decrease in absorbance over time for all CSNP samples. The control sample remains relatively constant near 0 absorbance. The 150 μg CSNPs sample shows the most significant decrease, reaching about -0.07 absorbance at 20 minutes. The other CSNP samples show intermediate decreases in absorbance, with the magnitude of decrease correlating with the concentration of CSNPs.

Both graphs include error bars for each data point, indicating the variability or uncertainty in the measurements.

These graphs likely represent a study on the optical properties or interactions of different nanoparticles, particularly focusing on Core-Shell Nanoparticles (CSNPs) at different concentrations and wavelengths.