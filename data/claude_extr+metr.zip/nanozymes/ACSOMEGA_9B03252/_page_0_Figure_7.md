The image contains bibliographic and access information for a scientific article. The key elements are:

1. Citation information: 
   "Cite This: ACS Omega 2020, 5, 11883−11894"
   This indicates the article was published in the journal ACS Omega in 2020, volume 5, pages 11883-11894.

2. Access options:
   "Read Online" button is present, indicating the article is available for online viewing.

3. Article metadata:
   "ACCESS" label is displayed, suggesting this is likely an open access article.

4. Additional features:
   - "Metrics & More" icon, indicating availability of article-level metrics and additional information.
   - "Article Recommendations" icon, suggesting the platform offers related article suggestions.

This image appears to be a header or top section of an article page on a scientific journal's website, providing key information about the article's publication details and access options.