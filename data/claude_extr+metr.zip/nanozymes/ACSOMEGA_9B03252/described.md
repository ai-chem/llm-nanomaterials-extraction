<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

[http://pubs.acs.org/journal/acsodf](http://pubs.acs.org/journal/acsodf?ref=pdf) Article

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

# Intrinsic Enzyme-like Activities of Cerium Oxide Nanocomposite and Its Application for Extracellular H2O2 Detection Using an Electrochemical Microfluidic Device

[Negar Alizadeh,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Negar+Alizadeh"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [Abdollah Salimi,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Abdollah+Salimi"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf)[*](#page-9-0) [Tsun-Kong Sham,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Tsun-Kong+Sham"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [Paul Bazylewski,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Paul+Bazylewski"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [and Giovanni Fanchini](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Giovanni+Fanchini"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf)

<DESCRIPTION_FROM_IMAGE>The image contains bibliographic and access information for a scientific article. The key elements are:

1. Citation information: 
   "Cite This: ACS Omega 2020, 5, 11883−11894"
   This indicates the article was published in the journal ACS Omega in 2020, volume 5, pages 11883-11894.

2. Access options:
   "Read Online" button is present, indicating the article is available for online viewing.

3. Article metadata:
   "ACCESS" label is displayed, suggesting this is likely an open access article.

4. Additional features:
   - "Metrics & More" icon, indicating availability of article-level metrics and additional information.
   - "Article Recommendations" icon, suggesting the platform offers related article suggestions.

This image appears to be a header or top section of an article page on a scientific journal's website, providing key information about the article's publication details and access options.</DESCRIPTION_FROM_IMAGE>

ABSTRACT: Artificial enzyme mimics have gained considerable attention for use in sensing applications due to their high stability and outstanding catalytic activity. We show that cerium oxide nanosheets (NSs) exhibit triple-enzyme mimetic activity. The oxidase-, peroxidase-, and catalase-like activities of the proposed nanoparticles are demonstrated using both colorimetric and electron paramagnetic resonance (EPR) spectroscopy. On the basis of the excellent catalytic activity of cerium oxide NSs toward hydrogen peroxide, an electrochemical approach for the high-throughput detection of H2O2 in living cells was established. This report presents an analytical microfluidic chip integrated with a cerium oxide NS mimic enzyme for the fabrication of a simple, sensitive, and lowcost electrochemical sensor. Three Au microelectrodes were fabricated on a glass substrate using photolithography, and the working electrode was

functionalized using cerium oxide NSs. The operation of this biosensor is based on cerium oxide NSs and presents a high sensitivity over a wide detection range, between 100 nM and 20 mM, with a low detection limit of 20 nM and a high sensitivity threshold of 226.4 μA·cm−2 ·μM−1 . This microfluidic sensor shows a strong response to H2O2, suggesting potential applications in monitoring H2O2 directly secreted from living cells. This sensor chip provides a promising platform for applications in the field of diagnostics and sensing.

## 1. INTRODUCTION

Since the first exciting discovery of ferromagnetic nanoparticles[,1](#page-9-0) various efficient nanomaterial-based mimic enzymes (nanozymes[)2](#page-9-0) have been developed over the past few decades. Such nanomaterials can catalyze specific redox-like-type reactions and exhibit great activity for oxidase-like,[3,4](#page-9-0) peroxidase-like[,5](#page-9-0)−[7](#page-9-0) catalase-like[,8](#page-9-0),[9](#page-9-0) or superoxide dismutaselike (SOD) reactions.[10](#page-9-0),[11](#page-9-0) To date, there have been numerous works devoted to exploring nanomaterials' enzyme mimetics from carbon- and metal-based nanomaterials.[12](#page-9-0),[13](#page-9-0) Recently, metal nanomaterials have become an area of increasing interest because of unique electronic and a larger variety of enzyme-like characteristics.[14](#page-10-0),[15](#page-10-0) These nanozymes are widely used in sensing and diagnosis applications.[16](#page-10-0) For example, Wang et al. developed a direct electrochemical assay for kanamycin detection based on the peroxidase-like activity of gold nanoparticles.[17](#page-10-0) AuNPs could catalyze the reaction between H2O2 and reduced thionine to produce oxidized thionine. This reaction exhibited a distinct reduction peak on gold electrode in differential pulse voltammetry (DPV) and could be utilized to quantify the concentration of kanamycin. Furthermore, Wang and his colleagues fabricated FePt−Au ternary metallic nanoparticles with powerful enzymatic mimic for H2O2 sensing.[15](#page-10-0) Among nanozymes, multiactivity nanozymes with two or more catalytic activities have attracted significant attention.[18](#page-10-0),[19](#page-10-0) Some nanozymes such as Co3O4, [20](#page-10-0) Ni−Pd NPs,[21](#page-10-0) CoMo hybrids[,22](#page-10-0) and V6O13 [23](#page-10-0) have been reported with two or more catalytic activities. These kinds of nanozymes can have more effective applications in physiological and pathological processes.

Cerium oxide nanoparticles (nanoceria) have attracted enormous interest in recent years as nanocatalysts due to their unique physical and chemical properties. Nanoceria has been widely applied in various fields, such as catalysis, bioassays, and antioxidant therapy.[24](#page-10-0),[25](#page-10-0) This rare-earth oxide nanostructure shows high catalytic performance in various applications due to the presence of mixed valence states of Ce3+ and Ce4+, and the presence of oxygen vacancies. The key to this catalytic activity is that the redox couple can switch

Received: October 2, 2019 Accepted: March 23, 2020 Published: May 19, 2020

<DESCRIPTION_FROM_IMAGE>This image appears to be an advertisement or promotional material for a product called "ACS OMEGA". The image contains several elements that are not directly related to scientific chemistry content, but rather seem to be part of a marketing design. Given the instructions to respond with ABSTRACT_IMAGE for logos or non-scientific content, the appropriate response is:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo for ACS Publications, which is not directly related to conveying scientific or chemical information. The logo consists of stylized text and a graphical element, but does not contain any chemical structures, graphs, diagrams, or other scientific content that would require detailed interpretation in the context of chemistry research.</DESCRIPTION_FROM_IMAGE>

<span id="page-1-0"></span>Scheme 1. (A) Mimicking Three Different Enzymes Peroxidase, Catalase, and Oxidase by Individual Material Cerium Oxide, (B) Schematic Representation and Photograph of Lab-on-a-Chip Setup for the Electrocatalytic Reduction of H2O2

<DESCRIPTION_FROM_IMAGE>The image is divided into two main sections, A and B, describing the properties and applications of cerium oxide nanostructures (NSs).

Section A:
This section illustrates the catalytic properties of cerium oxide NSs. At the center is a representation of cerium oxide NSs. Surrounding it are four chemical reactions:

1. H2O2 decomposition to O2 (Catalase-like activity)
2. H2O2 decomposition to OH- (Peroxidase-like activity)
3. Oxidase-like activity, represented by the conversion of TMB (3,3',5,5'-tetramethylbenzidine) to its oxidized form TMB(ox)

These reactions demonstrate the multi-enzyme mimetic properties of cerium oxide NSs.

Section B:
This section depicts an experimental setup for studying the catalytic properties of cerium oxide NSs. It includes:

1. An image of laboratory equipment, likely a potentiostat or electrochemical workstation.
2. A microfluidic channel setup with three electrodes labeled RE (reference electrode), WE (working electrode), and CE (counter electrode).
3. A schematic showing PC 12 cells producing H2O2 through the action of ascorbic acid (AA).
4. A representation of cerium oxide NSs on a substrate.
5. A cyclic voltammogram showing the electrochemical behavior of the system:
   - X-axis: Potential (V) ranging from -0.8 to 0.7 V
   - Y-axis: Current (μA) ranging from -35 to 10 μA
   - Two curves are shown:
     a. "Without H2O2": A relatively flat curve near 0 μA
     b. "With H2O2": A curve showing significant cathodic current, peaking around -30 μA at -0.3 V

The voltammogram also labels two enzyme-like activities:
- Catalase-like activity: represented by the curve without H2O2
- Peroxidase-like activity: represented by the curve with H2O2

This setup demonstrates the use of cerium oxide NSs in a microfluidic electrochemical system to detect H2O2 produced by living cells, showcasing its potential applications in biosensing and catalysis.</DESCRIPTION_FROM_IMAGE>

between each state in a CeO2 ↔ CeO2−x + x/2O2 (Ce4+ ↔ Ce3+) recycle process[.26,27](#page-10-0) The catalytic activity of nanoceria originates from the surface oxygen; thus, the active oxygen content on the surface must be increased to improve catalytic activities. As a result, increasing the Ce3+/(Ce3+ + Ce4+) ratio (shorted as "Ce3+ ratio") enhances the surface oxygen defect in the structure, leading to improvement in catalytic properties[.28,29](#page-10-0)

It is worth noting that H2O2 has a considerable impact on food production, textile industry, paper bleaching, pharmaceutical research, and environment pollution.[30](#page-10-0),[31](#page-10-0) It is a byproduct of various enzymatic reactions including glucose oxidase, cholesterol oxidase, glutamate oxidase, urate oxidase, lactate oxidase, alcohol oxidase, lysine oxidase, oxalate oxidase, and horseradish peroxidase.[32](#page-10-0) In living organisms, H2O2 regulates diverse biological processes such as immune cell activation, vascular remodeling, apoptosis, and root growth. The presence of excess H2O2 in living organisms also causes severe diseases like cancer and Parkinson's disease[.33](#page-10-0),[34](#page-10-0) The determination of H2O2 in biological environments is of critical importance. Electrochemical methods have attracted great interest over competing H2O2 detection techniques such as chromatography,[35](#page-10-0) chemiluminescence,[36](#page-10-0) colorimetry,[37](#page-10-0) and fluorescence[,38](#page-10-0) due to their high sensitivity, fast response, low cost, and convenient operation.[39,40](#page-10-0)

The microfluidic lab-on-a-chip (LOC) technology is recognized as one of the most promising tools to develop novel diagnostic platforms.[41](#page-10-0) Microfluidic chips can be applied as point-of-care (POC) devices for clinical diagnostics because of their inherent small size, portability, low cost, easy operation, and low amount of biological sample required.[42,43](#page-10-0) These devices include a set of microfluidic channels to control fluid flow throughout the chip, in which various procedures such as reagent mixing, affinity-based binding, and signal transduction can be implemented side-by-side[.44](#page-10-0) Sensors can be integrated within microfluidic devices to enable continuous

<DESCRIPTION_FROM_IMAGE>The image presents a transmission electron microscopy (TEM) micrograph labeled "A" in the upper left corner. It depicts a nanostructured material, likely carbon-based, such as carbon nanotubes or graphene sheets. The structure appears as a network of interconnected, elongated dark features against a lighter background, suggesting a three-dimensional arrangement of the nanomaterial.

The material shows a complex, entangled morphology with various branching and intersecting structures. These structures appear to be thin and elongated, consistent with tubular or sheet-like nanostructures. The image reveals a high degree of porosity within the material, with visible spaces between the interconnected structures.

The scale bar in the lower right corner indicates a length of 50 nm, providing context for the size of the nanostructures observed. This scale suggests that the individual features in the image are on the order of tens of nanometers in width.

The overall appearance of the material suggests a high surface area to volume ratio, which is characteristic of many nanostructured materials used in applications such as catalysis, energy storage, or filtration.

The image does not contain any chemical structures that can be converted to SMILES format, nor does it present any graphs or diagrams requiring detailed interpretation of measured quantities or values.</DESCRIPTION_FROM_IMAGE>

Figure 1. (A) TEM image and (B) EDS spectra of cerium oxide NSs.

measurement of single or multiple analytes in small sample volumes[.45](#page-10-0)

In this work, we present a microfluidic electrochemical LOC for the real-time detection of H2O2 using a cerium oxide nanosheet (NS)-modified Au working electrode. Cerium oxide NSs were synthesized via a simple hydrothermal route, and they simultaneously displayed oxidase-, peroxidase-, and catalase enzyme-like activities ([Scheme 1](#page-1-0)). Cerium oxide NSs were integrated with a microfluidic platform for the effective detection of H2O2. This sensor is found to be highly selective and specific toward H2O2 with negligible interference from analytes such as glucose, dopamine, uric acid, glutathione, and ascorbic acid. Furthermore, cerium oxide NS-based LOC devices can find practical use in monitoring H2O2 inside living cells, which is indicative of their viability in real-world analysis applications.

### 2. RESULTS AND DISCUSSION

2.1. Structure Characterization of Prepared Cerium Oxide. The morphology of cerium oxide was investigated by transmission electron microscopy (TEM). Figure 1A shows the wrinkled nanosheet structure of the prepared cerium oxide, which shows a large surface area for the reaction with H2O2. The energy-dispersive spectrometry (EDS) analysis of cerium oxide NSs revealed their elemental composition and corroborated the presence of Ce, C, and O in these nanostructures (Figure 1B).

[Figure 2A](#page-3-0) shows the X-ray diffraction (XRD) patterns of cerium oxide NSs. The XRD peaks are located at angles (2θ) of 28.6, 32.84, 47.27, 55.83, 59.09, 69.02, 76.74, and 78.64°, corresponding to the (111), (200), (220), (311), (222), (400), (331), and (420) planes of CeO2 in the face-centered cubic phase (JCPDS data card no: 34-0394).[46](#page-10-0) Peaks at angles 2θ = 44.12 and 64.42° can be assigned to Ce2O(CO3)2·H2O.[47](#page-10-0) The formation of Ce2O(CO3)2·H2O is due to the reaction of the Ce3+ ions from cerium nitrate hexahydrate with the CO3 2− and OH− ions from the hydrolysis of urea and terephthalic acid[.48](#page-10-0) Ce2O(CO3)2·H2O improves the Ce3+/(Ce3+ + Ce4+) ratio in the structure and promotes the formation of oxygen vacancy. Significantly, oxygen vacancies enhance the redox ability and allow easier surface reaction, which is in favor of catalytic reaction[.29](#page-10-0) The thermal stability of cerium oxide NSs was

<DESCRIPTION_FROM_IMAGE>The image presents an Energy-Dispersive X-ray Spectroscopy (EDS) spectrum, labeled as "B" in the top left corner. This spectrum shows the elemental composition of a sample, with the x-axis representing energy (keV) ranging from 0 to 10.00 keV, and the y-axis representing intensity or counts, with a maximum value of 4000.

The spectrum displays several distinct peaks, each corresponding to a specific element:

1. Oxygen (O): A prominent peak labeled "O Kα" near the beginning of the spectrum.
2. Silicon (Si): A high-intensity peak labeled "Si Kα" at approximately 1.7 keV.
3. Cerium (Ce): Multiple peaks associated with cerium, including:
   - "Ce Lα" - The highest cerium peak at about 4.8 keV
   - "Ce Lβ" - A slightly lower peak adjacent to Ce Lα
   - "Ce Lγ1" - A smaller peak to the right of Ce Lβ
   - "Ce Lγ2" - A minor peak further to the right
   - "Ce Lγ11" - A very small peak at the highest energy among Ce L-series
   - "Ce M" - A small peak at lower energy, near the oxygen peak

4. Aluminum (Al): A small peak labeled "Al Kα" between the oxygen and silicon peaks.
5. Carbon (C): A very small peak labeled "C K" at the lowest energy end of the spectrum.

The spectrum indicates that the sample contains significant amounts of oxygen, silicon, and cerium, with minor presence of aluminum and carbon. This composition suggests the sample could be a cerium-containing silicate or oxide material, possibly with some aluminum incorporation.

The high intensity of the cerium peaks, particularly the L-series, indicates that cerium is a major constituent of the analyzed sample. The presence of both light (O, Si, Al) and heavy (Ce) elements suggests this could be a composite or doped material, potentially used in catalysis, optics, or other advanced materials applications where cerium compounds are commonly employed.</DESCRIPTION_FROM_IMAGE>

investigated through thermogravimetric analysis (TGA). As can be seen from [Figure 2](#page-3-0)B, weight loss occurs by the following three steps: (1) release of physically adsorbed water, with 7.9% weight loss from room temperature to 160 °C; (2) decomposition of cerium carbonate to form ceria, with 12.0% weight loss from 160 to 470 °C, which is representative of the surface Ce3+/(Ce3+ + Ce4+) ratio; and (3) minimum weight loss above 470 °C, which can be attributed to the removal of captured CO2. [49](#page-10-0)[Figure 2](#page-3-0)C shows the Fourier transform infrared (FTIR) spectra of urea, terephthalic acid, and cerium oxide NSs. Urea has characteristic vibrational peaks at 3348 and 3443 cm−1 (NH2 group stretching) and at 1680 cm−1 (−CO group stretching) (curve a)[.50](#page-10-0) Peaks from terephthalic acid, at 2542, 1682, and 1570−1424 cm−1 , are assigned to −COOH, −CO, and an aromatic ring of the terephthalic acid, respectively. Concerning the IR spectrum of terephthalic acid (curve b) peaks in the 1285−1000 cm−1 region are fingerprints of −C−OH, −CO, −C−CH, and −C−H bending modes, while the 700−800 cm−1 region contains the terephthalic acid aromatic ring bending mode.[51](#page-11-0) The IR spectrum of cerium oxide NSs (curve c) is different from its counterpart from reagents, in which most of the IR peaks are not present. Specifically, the broad IR absorption band 3422 cm−1 in the spectra of cerium oxide NSs is assigned to O−H stretching modes from residual water and Ce−OH, which is present in nanostructured cerium oxide because of its higher surface-to-volume ratio. Likewise, the same effect may be responsible for the absorption peak observed at 1019 cm−1 , which can be attributed to C−O−Ce and is also not present in bulk cerium oxide.

2.2. Triple-Enzyme Catalytic Activity of Cerium Oxide NSs. To investigate the triple-enzyme catalytic activity of cerium oxide NSs and their oxidase-, peroxidase-, and catalaselike activities, a series of experiments were carried out as indicated in the following subsections.

2.2.1. Peroxidase-like Catalytic Activity of Cerium Oxide NSs. The peroxidase-like catalytic activity of cerium oxide NSs was investigated by catalyzing the oxidation of 3,3′,5,5 tetramethylbenzidine (TMB) in the presence of H2O2. As shown by curve a in [Figure 3A](#page-4-0), as-synthesized cerium oxide NSs show strong optoelectronic absorption in the visible region between 395 and 420 nm. After the addition of cerium

<DESCRIPTION_FROM_IMAGE>The image contains three separate graphs labeled A, B, and C.

Graph A:
This is an X-ray diffraction (XRD) pattern. The x-axis represents 2θ (degree) ranging from 10 to 80 degrees. The y-axis shows intensity in arbitrary units (a.u.). Several peaks are visible and labeled with their corresponding 2θ values:
- A major peak at 2θ = 31°
- Other significant peaks at 2θ = 200°, 220°, 311°, 222°, 400°, 331°, and 420°
The pattern suggests a crystalline material with a specific crystal structure.

Graph B:
This is a thermogravimetric analysis (TGA) curve. The x-axis represents temperature (°C) ranging from 0 to 800°C. The y-axis shows weight percent (%) ranging from 75 to 100%. The graph depicts weight loss as temperature increases. Three distinct weight loss steps are labeled:
- First step: 7.92% weight loss
- Second step: 11.98% weight loss
- Third step: 1.14% weight loss
The total weight loss is approximately 21.04% over the temperature range.

Graph C:
This is an infrared (IR) spectroscopy graph. The x-axis represents wavenumber (cm⁻¹) ranging from 4000 to 500 cm⁻¹. The y-axis shows transmittance (%). The graph contains three separate spectra labeled a, b, and c.

Spectrum a (bottom):
- Strong, broad peak at 3348 cm⁻¹
- Sharp peak at 3443 cm⁻¹
- Strong peak at 1680 cm⁻¹

Spectrum b (middle):
- Peak at 2542 cm⁻¹
- Peaks at 1570 cm⁻¹ and 1424 cm⁻¹

Spectrum c (top):
- Strong, broad peak at 3422 cm⁻¹
- Strong peak at 1019 cm⁻¹

These spectra provide information about the functional groups present in the analyzed compounds.</DESCRIPTION_FROM_IMAGE>

Figure 2. (A) XRD patterns. (B) TGA analysis. (C) FTIR spectra of (a) urea, (b) terephthalic acid, and (c) cerium oxide NSs.

oxide NSs to an aqueous solution of TMB + H2O2, an additional strong adsorption peak at 652 nm is observed, and the color of the solution turned blue [(Figure 3A](#page-4-0), curve b). After adding H2SO4, the adsorption peak at 652 nm disappears with the appearance of a peak at 450 nm and the color of the solution changed from blue to yellow [(Figure 3](#page-4-0)A, curve c).

The oxidation reaction was catalyzed by peroxidase, but the catalytic activity of cerium oxide could be stopped by H2SO4, leading to the cation radical of the TMB molecule, which further lost another electron to form diamine[.52](#page-11-0) These changes could be expressed as follows

<DESCRIPTION_FROM_IMAGE>The image depicts a chemical reaction scheme showing the transformation of a compound through two steps. The scheme consists of three chemical structures, each representing a different state of the molecule, with arrows indicating the progression of the reaction.

1. Starting compound (TMB Transparent):
SMILES: CC1=C(N)C(C)=C(C2=C(C)C(=C(C)C(=C2C)N)C)C(=C1C)C

2. Intermediate compound (Cation Radical Blue):
SMILES: CC1=C([NH2+])C(C)=C(C2=C(C)C(=C(C)C(=C2C)N)C)C(=C1C)C

3. Final product (Diimine Yellow):
SMILES: CC1=C(N=C(C)C2=C(C)C(=C(C)C(=C2C)N)C)C(=C(C)C(=C1C)N)C

The reaction proceeds as follows:
1. TMB Transparent → Cation Radical Blue
   This step is labeled with "-e-" above the arrow, indicating an oxidation process through the loss of an electron.

2. Cation Radical Blue → Diimine Yellow
   This step is labeled with "H2SO4" above the arrow, suggesting that sulfuric acid is used as a reagent or catalyst in this transformation.

The names below each structure provide additional information:
1. TMB Transparent: This likely stands for tetramethylbenzidine in its reduced, colorless form.
2. Cation Radical Blue: Indicates the formation of a cation radical species with a blue color.
3. Diimine Yellow: Represents the final product, a diimine compound with a yellow color.

This reaction scheme illustrates the color changes associated with the oxidation of tetramethylbenzidine, which is commonly used in biochemical assays and as a chromogenic substrate in various analytical applications.</DESCRIPTION_FROM_IMAGE>

No color change was observed in the absence of cerium oxide NSs. This clearly shows that cerium oxide NSs showed peroxidase-like catalytic activity. Steady-state kinetic experiments were performed to further investigate the peroxidase-like catalytic property of cerium oxide NSs. As displayed in [Figure](#page-5-0) [4,](#page-5-0) the initial rate versus TMB and H2O2 concentrations both followed with typical Michaelis−Menten behaviors in a certain range of substrate concentration. The Michaelis−Menten constant (Km) and maximum initial velocity (Vmax) were calculated using the Lineweaver−Burk plot (inserted [Figure 4](#page-5-0)). It is known that the lower Km value reflects a higher affinity between enzymes and substrates.

In a possible mechanism of peroxidase activity, which we are here proposing, cerium oxide NSs catalyze the decomposition of H2O2 to produce • OH radicals that oxidize the peroxidase substrate represented by TMB. This process is consistent with the observed color change of the solution from blue to yellow[.53](#page-11-0) Such a catalytic activity of the proposed nanozyme was demonstrated by monitoring the presence of • OH radicals from this reaction via electron paramagnetic resonance (EPR) spectroscopy. EPR is sensitive to short-living free radicals if spin traps or spin probes that prevent their rapid spin quenching can be used.[54](#page-11-0) To identify hydroxyl radicals generated in the catalytic cerium oxide NSs system, EPR was performed by adding DMPO as a spin trap to the solution, and a parametric study was performed, as demonstrated in [Figure](#page-6-0) [5.](#page-6-0)

The EPR spectrum of DMPO−OH corresponds to line a in [Figure 5A](#page-6-0). The signal increases at decreasing pH, with increasing amounts of DMPO−• OH adducts being observed at lower pH when the reaction was performed in the presence of a constant amount of cerium oxide NSs. Conversely, no pH dependence of the EPR signal of DMPO was observed when the reaction was performed in the absence of the nanocomposite [(Figure 5A](#page-6-0), line a), which thus acts as a catalyst for the H2O2 decomposition. This model is in agreement with increasing enzyme activity at lower pH because more • OH radicals are produced under acidic conditions. These results confirmed the production of • OH radicals catalyzed by cerium oxide NSs. Furthermore, not only the concentration of generated • OH radicals but also the concentration of the cerium oxide NS catalyst is affected by the pH of the solution. The g-values were 2.00553, 2.00548, and 2.00557 at pH values of 11, 7, and 3, respectively, which are close to the values reported in previous studies[.55](#page-11-0) The EPR spectrum of DMPO− OH was contaminated by a triplet signal due to the nitrosyl radicals arising from the partial degradation of DMPO trap (black dots).[56](#page-11-0) In our measurement, the time between the spin labeling and the measurements was 5−10 min, so the additional hyperfine splitting could not attribute to the superoxide radicals (• O2 −) because it is known that the • O2 − adduct of DMPO (DMPO−OOH) is unstable (lifetime is 30− 90 s) and it spontaneously decays into the DMPO−hydroxyl adduct[.57,58](#page-11-0) Furthermore, the reaction rates of DMPO with • O2 − and • O2H are extremely smaller compared to that with OH radical. The rate constants of DMPO with • O2 − and • O2H are 2−170 and 6.6 × 103 M−1 ·s −1 , respectively, while that with • OH is reported to be 1.9−4.3 × 109 M−1 ·s −1 . [59](#page-11-0),[60](#page-11-0) Therefore, the detection of • O2− with DMPO is not facile. [Figure 5](#page-6-0)B shows that when the nanoparticle concentration is varied from 0 (line a) to 12 mg·mL−1 (line d), the catalytic activity also increases, consistent with an increase of the • OH signal up to 8 mg·mL−1 cerium oxide (line c) NP and a saturation of the

<DESCRIPTION_FROM_IMAGE>The image contains four separate graphs labeled A, B, C, and D, each presenting different data related to chemical analysis.

Graph A:
This graph shows UV-Vis absorption spectra for three different samples (a, b, c) over a wavelength range of 350-750 nm. The y-axis represents absorbance in arbitrary units (a.u.), ranging from 0.5 to 4.0. Sample 'a' (blue line) shows a peak around 375 nm and gradually decreases. Sample 'b' (pink line) has a similar initial peak but shows another broad peak around 650 nm. Sample 'c' (green line) has a sharp peak at 350 nm and rapidly decreases to the lowest absorbance among the three samples. An inset image shows three vials with different colored solutions corresponding to samples a, b, and c.

Graph B:
This graph also presents UV-Vis absorption spectra for three samples (a, b, c) but over a wavelength range of 400-800 nm. The y-axis shows absorbance (a.u.) from 0.2 to 1.2. All three samples show a peak around 620-640 nm, with sample 'c' (green line) having the highest absorbance, followed by 'b' (red line), and 'a' (blue line) with the lowest. An inset image shows three circular spots of different shades, likely corresponding to the three samples.

Graph C:
This graph plots dissolved oxygen concentration (mg/mL) against time (min) for four different samples (a, b, c, d) over 8 minutes. The y-axis ranges from 5 to 25 mg/mL. Sample 'a' (blue line) shows little change, remaining around 6 mg/mL. Samples 'b' (green line), 'c' (orange line), and 'd' (pink line) all show increases in dissolved oxygen over time, with 'd' reaching the highest concentration of about 23 mg/mL at 8 minutes.

Graph D:
This graph presents UV absorption spectra for two samples (a, b) over a wavelength range of 230-400 nm. The y-axis shows absorbance (a.u.) from 0 to 0.4. Both samples show a peak around 260 nm, with sample 'a' (red line) having a higher absorbance than 'b' (green line). The spectra for both samples converge at higher wavelengths.

These graphs collectively provide information about the optical properties and oxygen dissolution characteristics of different samples, likely related to a study involving nanoparticles or other chemical compounds.</DESCRIPTION_FROM_IMAGE>

Figure 3. (A) UV−vis spectra and photographs of (a) cerium oxide NSs solution, (b) cerium oxide NSs + TMB + H2O2, and (c) cerium oxide NSs + TMB + H2O2 + H2SO4 (concentration of enzyme: 2 mg·mL−1 , reaction time: 5 min). (B) Effect of O2 concentration on the direct oxidation of TMB by cerium oxide without H2O2 ((a) N2, (b) air, (c) O2). (C) Dissolved oxygen generation catalyzed by cerium oxide NSs at different concentrations (a) 0 mg·mL−1 , (b) 1 mg·mL−1 , (c) 2 mg·mL−1 , and (d) 4 mg·mL−1 . (D) UV−vis spectra of (a) NBT and (b) NBT + cerium oxide NSs + H2O2.

effect at higher concentrations. The variation of H2O2 concentration from 0% ([Figure 5](#page-6-0)C, line a) to 12% (line d) was also observed to improve the process effectiveness through the addition of more reagents, with an increase in the EPR signal intensity, indicating the generation of more DMPO−• OH(aq) adducts.

2.2.2. Oxidase-like Catalytic Activity of Cerium Oxide NSs. The prepared cerium oxide NSs could directly oxidize TMB, leading to blue color products even in the absence of H2O2 (Figure 3B). This indicates that cerium oxide NSs also exhibit oxidase-like catalytic activity. To further study the oxidation of the TMB chromogenic substrate by cerium oxide NSs, the effect of the oxidizing agent (dissolved oxygen) in the reaction system was investigated. Compared to bubbling an inert gas into the system of N2, the absorbance of oxidized TMB at 652 nm was significantly increased after saturation with O2. It is therefore concluded that increasing the concentration of oxygen as the electron acceptor in the oxidation of TMB can enhance the oxidase-like activity of cerium oxide NSs.

2.2.3. Catalase-like Catalytic Activity of Cerium Oxide NSs. To investigate the catalase-like activity of cerium oxide NSs, the concentration of dissolved oxygen in the system, consisting of cerium oxide NSs and H2O2, was recorded using a portable meter. The value of the dissolved oxygen concentration was monitored for 10 min as a function of cerium oxide NS concentration. As shown in Figure 3C, the concentration of dissolved oxygen increased proportionally to the concentration. This indicated that cerium oxide NSs can decompose H2O2 into O2 and provided strong evidence of the catalase-like activity. The production of O2 was also monitored by EPR by incorporating a spin probe (15N-PDT) in the system. The bimolecular combination of paramagnetic O2 and N-PDT results in shorter spin−spin relaxation times, broadening the EPR line widths with respect to the pristine EPR signal of the pure spin probe.[61](#page-11-0) As shown in [Figure 6](#page-6-0)A, where the pH increased to 11 in the presence of cerium oxide NSs and H2O2, the EPR signal line width increased as well, with a consistent signal intensity decrease to account for a constant N-PDT concentration. The EPR line width also broadens with

<DESCRIPTION_FROM_IMAGE>The image contains two graphs, labeled A and B, showing enzyme kinetics data.

Graph A:
- Main plot: Velocity (V) vs Concentration of TMB (mM)
- Y-axis: V (10^-7 M s^-1), ranging from 10 to 13
- X-axis: Concentration of TMB (mM), ranging from 0 to 4
- The plot shows a typical Michaelis-Menten kinetics curve, starting at about 10.7 and reaching a plateau around 12.7
- Kinetic parameters: Vmax = 13.31 10^-7 M s^-1, Km = 0.163 mM
- Inset plot: Lineweaver-Burk plot (double reciprocal plot)
  - Y-axis: 1/Velocity, ranging from 0.07 to 0.09
  - X-axis: 1/[TMB] (mM^-1), ranging from 0.3 to 0.7
  - Shows a linear relationship, typical for Lineweaver-Burk analysis

Graph B:
- Main plot: Velocity (V) vs Concentration of H2O2 (mM)
- Y-axis: V (10^-7 M s^-1), ranging from 0.4 to 10.4
- X-axis: Concentration of H2O2 (mM), ranging from 0 to 700
- The plot shows a typical Michaelis-Menten kinetics curve, starting at about 3 and reaching a plateau around 10.4
- Kinetic parameters: Vmax = 15.15 10^-7 M s^-1, Km = 198.34 mM
- Inset plot: Lineweaver-Burk plot (double reciprocal plot)
  - Y-axis: 1/Velocity, ranging from 0.05 to 0.35
  - X-axis: 1/[H2O2] (mM^-1), ranging from 0.002 to 0.022
  - Shows a linear relationship, typical for Lineweaver-Burk analysis

These graphs represent enzyme kinetics studies for two different substrates: TMB (3,3',5,5'-tetramethylbenzidine) and hydrogen peroxide (H2O2). The main plots show the relationship between reaction velocity and substrate concentration, while the insets provide Lineweaver-Burk plots for determining kinetic parameters. The data suggest that the enzyme has different affinities and maximum velocities for these two substrates, with a higher affinity (lower Km) for TMB compared to H2O2.</DESCRIPTION_FROM_IMAGE>

Figure 4. Steady-state kinetic analyses using the Michaelis−Menten model and Lineweaver−Burk model (insets) for cerium oxide NSs by (A) TMB as substrate and (B) H2O2 as substrate.

increasing cerium oxide NS concentration ([Figure 6](#page-6-0)B). This also indicates increased oxygen formation due to the stronger catalase-like activity of more concentrated cerium oxide NSs.

2.3. Electrocatalytic Activity of Cerium Oxide NSs. The electrocatalytic activity of cerium oxide NSs was tested by modifying the Au working electrode with cerium oxide NSs. A three-electrode microfluidic chip is used as the electrochemical cell for recording cyclic voltammograms (CV) and determining sensor performance. Cyclic voltammograms (CVs) were recorded for (a) bare Au electrode, (b) cerium oxide NSmodified Au electrode, (c) Au electrode + H2O2, and (d) cerium oxide NS-modified Au electrode + H2O2 in 0.1 M phosphate-buffered saline (PBS) (pH = 7.4) with a scan rate of 50 mV·s −1 ([Figure 7](#page-7-0)A). The bare Au electrode and cerium oxide NS-modified Au electrode did not show any voltammetric response (curves a and b), and upon addition of H2O2, a redox process was detected on the Au bare electrode, indicating reduction of H2O2 (curve c). However, a large enhancement in the H2O2 redox response was observed for the nanoparticle-modified Au electrode (curve d). The oxidation and reduction responses of the electrode-modified cerium oxide NSs when reacting with H2O2 clearly show the catalase and peroxidase activities of cerium oxide NSs. The cerium oxide/Au electrode therefore can act as a mimetic catalase, where it significantly electrocatalyzes the decomposition of hydrogen peroxide (H2O2) to water (H2O) and molecular oxygen (O2) and also acts as a mimetic peroxidase to generate OH• radicals via decomposition of H2O2. [30,](#page-10-0)[62](#page-11-0)

2.4. Investigation of the Effect of pH on Cerium Oxide/Au Electrode Response. To understand the effect of pH on the electrochemical properties of the cerium oxide/Au electrode in the presence of H2O2, electrocatalytic studies were performed at three different pH values: 5.0, 7.0, and 9.0 in the presence of H2O2 (10 mM) using a N2-purged PBS (0.1 M) with a scan rate of 50 mV·s −1 , and the results are shown in [Figure 7](#page-7-0)B. At pH = 5.0, both oxidation and reduction were observed; however, the cathodic peak current is higher than the anodic peak, indicating that the peroxidase activity is dominant in cerium oxide NSs at lower pH (curve a). By increasing the buffer solution pH, the cathodic peak current decreases while the anodic peak current is increased relative to curve a, showing dominant catalase activity at higher pH values (curves b and c). These results demonstrate the pH switchability of the catalytic properties of cerium oxide NSs: at acidic pH (pH < 7), the peroxidase catalytic activity is dominant, while at basic pH (pH > 7), the catalase activity is dominant.

2.5. Analytical Performance of Cerium Oxide NS-Modified Au Electrode for Detection of H2O2. [Figure 7](#page-7-0)C shows the CVs of cerium oxide NS-modified Au electrode in the presence of different concentrations of H2O2. As can be seen, with increasing H2O2 concentration, the reduction current increased, demonstrating the excellent catalytic activity of cerium oxide NSs toward the reduction of H2O2. Thereupon, the detection sensitivity of cerium oxide NSmodified electrodes to aqueous H2O2 was explored through a chronoamperometric study shown in [Figure 8.](#page-8-0) The response for the different amounts of H2O2 is shown by the I−t curves collected at −0.5 V in [Figure 8A](#page-8-0), which indicates that the reduction currents increase gradually with higher concentrations of H2O2. The calibration plot indicates good linearity for the reduction current versus H2O2 concentrations in the range from 100 to 20 mM [(Figure 8A](#page-8-0)). The linear regression equation generated for cerium oxide NS-modified electrodes was i (μA) = 1.03 logC (μM) + 1.72 μA with a correlation coefficient of R2 = 0.992 ([Figure 8](#page-8-0)B). The lowest concentration of H2O2 that could be estimated by this microfluidic electrochemical sensor was 20 nM (S/N = 3), and the sensitivity was calculated to be 226.4 μA·cm−2 ·μM−1 based on this result. Compared to previously reported H2O2 sensors based on other nanomaterials or enzymes, this detection method based on microfluidic device outperforms the sensitivity and detection limit of other sensors, as shown in [Table 1](#page-8-0). The stability of the microfluidic device was examined after 2 weeks, with the result showing that the current through the device with 1 mM H2O2 exhibited only a small deviation over time with a relative standard deviation (RSD) of 3.04%. Six repeated measurements of 1 mM H2O2 led to a relative standard deviation of 2.9%, further showing good reproducibility of the biosensing interface. The selectivity of cerium oxide/Au electrode for H2O2 detection in PBS was also studied by evaluation of the interference effect of coexisting

<DESCRIPTION_FROM_IMAGE>The image presents three panels (A, B, and C) of Electron Paramagnetic Resonance (EPR) spectra, each showing the intensity of the signal as a function of the applied magnetic field. Each panel contains multiple spectra labeled from 'a' to 'd'.

Panel A:
- X-axis: Magnetic Field (mT), ranging from 330 to 342 mT
- Y-axis: Intensity (arb. units)
- Four spectra (a-d) are shown, with increasing complexity from bottom to top
- Spectrum 'a' shows minimal features
- Spectrum 'b' displays small peaks
- Spectrum 'c' shows more pronounced peaks
- Spectrum 'd' exhibits the most complex pattern with multiple sharp peaks and broader features
- Black dots on spectrum 'd' indicate specific peak positions

Panel B:
- X-axis: Magnetic Field (mT), ranging from 323 to 329 mT
- Y-axis: Intensity (not labeled, but implied to be in arbitrary units)
- Four spectra (a-d) are presented
- Spectrum 'a' is nearly flat
- Spectra 'b', 'c', and 'd' show increasingly complex patterns with multiple peaks and troughs
- The patterns in 'b', 'c', and 'd' appear to be periodic, repeating approximately every 1 mT
- Black dots on spectrum 'd' mark specific features

Panel C:
- X-axis: Magnetic Field (mT), ranging from 323 to 329 mT (same as Panel B)
- Y-axis: Intensity (not labeled, but implied to be in arbitrary units)
- Four spectra (a-d) are shown
- Spectrum 'a' is nearly flat
- Spectra 'b', 'c', and 'd' display complex patterns similar to those in Panel B, but with some differences in relative peak intensities and shapes
- The patterns in 'b', 'c', and 'd' also appear periodic, repeating approximately every 1 mT
- Black dots on spectrum 'd' indicate specific features

Overall, these EPR spectra likely represent different experimental conditions or samples, showing the evolution of paramagnetic species or the effect of different treatments on the EPR signal. The increasing complexity from 'a' to 'd' in each panel suggests a progression in the formation or detection of paramagnetic centers.</DESCRIPTION_FROM_IMAGE>

Figure 5. Experimental EPR spectra recorded at room temperature after the reaction of cerium oxide NSs with H2O2 in the presence of DMPO spin trap. (The nitroxide degradation product of the spin trap is indicated by black dots.) EPR spectrum of the liquid phase separated from the (A) cerium oxide NSs at varying pH: (a) control (without cerium oxide NSs), (b) pH = 11, (c) pH = 7.0, and (d) pH = 3; (B) various cerium oxide NS concentrations: (a) 0 mg·mL−1 , (b) 4 mg·mL−1 , (c) 8 mg·mL−1 , and (d) 12 mg·mL−1 ; and (C) various H2O2 concentrations: (a) 0%, (b) 4%, (c) 8%, and (d) 12%.

compounds such as ascorbic acid (AA), dopamine (DA), uric acid (UA) glutathione (GSH), and glucose on the electrode response. As illustrated in [Figure 8](#page-8-0)C, there are negligible current responses when interfering molecules were used, confirming the good anti-interference ability of the biomimetic sensor for H2O2 detection.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled A and B, both showing Electron Paramagnetic Resonance (EPR) spectra.

Graph A:
This graph shows the effect of pH on the EPR spectrum. The x-axis represents the Magnetic Field in mT, ranging from 325.0 to 326.5 mT. The y-axis represents Intensity (arbitrary units). Four spectra are shown, corresponding to different pH conditions:
1. Control (black line)
2. pH = 3 (red line)
3. pH = 7 (green line)
4. pH = 11 (blue line)

The spectra for Control, pH 3, and pH 7 show similar patterns with a sharp positive peak followed by a sharp negative peak. The spectrum for pH 11 shows a significantly different pattern with a broader, less intense positive peak and a shallower negative peak.

Graph B:
This graph shows the effect of concentration on the EPR spectrum. The x-axis represents the Magnetic Field in mT, with each spectrum centered around 325-326 mT. The y-axis represents Intensity (arbitrary units). Four spectra are shown, corresponding to different concentrations:
1. Control (black line)
2. 2 mg (red line)
3. 4 mg (green line)
4. 6 mg (blue line)

Each spectrum shows a sharp positive peak followed by a sharp negative peak. The intensity of the peaks increases with increasing concentration, while the peak positions remain relatively constant.

Both graphs demonstrate how EPR spectra can be affected by different experimental conditions (pH and concentration), providing insights into the electronic structure and environment of paramagnetic species in the samples.</DESCRIPTION_FROM_IMAGE>

Figure 6. EPR spectra of 15N-PDT (A) in the presence of 2 mg of cerium oxide NSs and H2O2 (5%) at different pH values, and (B) in the presence of H2O2 (5%) and different concentration of cerium oxide NSs.

2.6. Real-Time Detection of H2O2 Released from Living Cells. To investigate the capability of the proposed system for real-time detection of H2O2, we chose the PC 12 cell as a model because it can release a trace amount of H2O2 under the stimulation of ascorbic acid (AA)[.63](#page-11-0) The as-prepared 106 cells were suspended in 500 μL of PBS (pH = 7.4) for further use. As shown in [Figure 8D](#page-8-0), in the presence of PC 12 cells, the cathodic current increases to a higher platform after the addition of 4 μM AA (curve c), which corresponds to about 0.1 μM H2O2 released from the living cells, confirming that the trace amounts of H2O2 released from a living cell can be detected rapidly by the cerium oxide NSs. However, no changes in current are observed in the absence of either cells (curve b) or AA (curve a) under the same conditions, indicating that H2O2 is released from cells under the stimulation of AA. These results suggest that the fabricated microfluidic device is highly sensitive and reliable for the detection of H2O2 in living cells. So, compared to the advantages such as high activity, low detection limit, wide concentration range, and applicability of the presented sensor for measuring H2O2 release from cells, the limitation of the purposed sensor is negligible.

<DESCRIPTION_FROM_IMAGE>The image contains three separate cyclic voltammograms labeled A, B, and C.

Graph A:
This cyclic voltammogram shows the relationship between current (μA) and potential (V) for four different curves labeled a, b, c, and d. The potential ranges from -0.8 V to 0.6 V, while the current ranges from -35 μA to 10 μA. Curves a and b show minimal current change across the potential range. Curve c exhibits a cathodic peak around -0.6 V and an anodic peak near 0 V. Curve d shows the largest current range, with a pronounced cathodic peak around -0.7 V and an anodic peak around 0.4 V.

Graph B:
This cyclic voltammogram illustrates the effect of pH on the current-potential relationship. The potential ranges from -1 V to 1.5 V, and the current ranges from -60 μA to 60 μA. Three curves are labeled a, b, and c, with arrows indicating increasing pH. As pH increases, the cathodic peak shifts towards more positive potentials, and the anodic peak becomes more pronounced at higher potentials (around 1.2-1.5 V).

Graph C:
This cyclic voltammogram demonstrates the effect of concentration on the current-potential relationship. The potential ranges from -0.5 V to 0 V, and the current ranges from -30 μA to 0 μA. Five curves are shown, corresponding to different concentrations: 0 mM, 0.01 mM, 0.1 mM, 1 mM, and 5 mM. As the concentration increases, the cathodic peak current becomes more negative, and the peak shifts slightly towards more negative potentials. The 0 mM curve shows minimal current change, while the 5 mM curve exhibits the largest current response.

These voltammograms provide information about the electrochemical behavior of a system under different conditions, including varying pH and analyte concentrations.</DESCRIPTION_FROM_IMAGE>

Figure 7. (A) Cyclic voltammograms of (a) bare Au electrode, (b) Au electrode/cerium oxide, (c) Au electrode + H2O2, and (d) Au electrode/cerium oxide + H2O2. (B) Cyclic voltammograms of Au electrode/cerium oxide + H2O2 at different pH values: (a) 5, (b) 7, and (c) 9. (C) Cyclic voltammograms of Au electrode/cerium oxide in the presence of varied H2O2 concentrations, recorded in N2-purged PBS (0.1 M) at a scan rate of 0.03 V·s −1 .

### 3. CONCLUSIONS

In summary, cerium oxide NSs were synthesized by a facile hydrothermal route and exhibited triple-enzyme mimetic activity: oxidase-, peroxidase-, and catalase-like activities. The enzyme mimic properties of cerium oxide NSs can be modulated by adjusting the pH. The peroxidase-like activity is predominant under acidic pH, while the catalase-like activity is prevalent under alkaline conditions. The underlying mechanisms of the catalytic processes involving cerium oxide NSs were investigated by means of EPR spectroscopy, which revealed that the peroxidase-like activity originates from the ability to produce hydroxyl (• OH) radicals. The catalase-like activity causes the decomposition of H2O2 to O2. The asprepared nanocomposite was used for the electrochemical detection of H2O2 using LOC microfluidic devices. The chronoamperometric technique was utilized for the sensitive detection of H2O2. The linear range of this method was found to be between 100 nM and 20 mM, with a detection limit of 20 nM. The methods we developed have decisive advantages in terms of wide linear range, low detection limit, high sensitivity, easiness of operation, and good practicability. The developed methods were applied to the detection of H2O2 in living cells, which may be competitive with existing methods because of their low cost, simplicity, and reproducibility. We believe that our microfluidic sensors, along with electrochemical detection, may contribute to the growth of biosensing technologies toward practical applications in bioanalysis, food safety, and environmental diagnostics.

### 4. EXPERIMENTAL SECTION

4.1. Materials and Instruments. Cerium nitrate hexahydrate Ce(NO3)3·6H2O, terephthalic acid C6H4(CO2H)2, urea (CO(NH2)2), H2O2, 3,3′,5,5 tetramethylbenzidine (TMB), glucose, dopamine, uric acid, glutathione, and ascorbic acid and all other reagents were purchased from Merck or Fluka. All chemicals and reagents were of analytical grade and directly used without further purification. Deionized water produced from a Milli-Q Plus system (Millipore) was used in all experiments.

Scanning electron microscopy (SEM) and transmission electron microscopy (TEM) images were obtained with a MIRA3 TESCAN HV: 20.0 kV instrument and a Philips EM 280 microscope, respectively. XRD patterns were recorded on a Bruker D8 Advance diffractometer equipped with a copper source and a general area detector diffraction system (GADDS). The FTIR and UV−vis spectra were recorded by a Vector-22 Bruker spectrophotometer and a SPECTROD 250-Analytik Jena spectrophotometer, respectively. Dissolved oxygen was monitored after the addition of H2O2 by a Handheld meter Oxi 330i/340i (WTW GmbH & Co. KG).

Electron paramagnetic resonance measurements were performed using a Jeol FA-200 EPR spectrometer operating in the X-band at 9.1 MHz and equipped with a cylindrical resonator. The hydroxyl radicals generated in the liquid phase were detected by applying the spin trapping technique. 5,5- Dimethyl-1-pyrroline N-oxide (DMPO) with a concentration of 20 mM was chosen as a suitable spin trap because of its high trapping ability and selectivity toward oxygen-centered radicals. In the spin trapping experiments, a predetermined amount of cerium oxide NSs was contacted with a mixture of 1 mL of H2O2/H2O and 10 μL of DMPO. The liquid sample (5 μL) was inserted into a quartz capillary tube with 1.0 mm inner diameter using a micropipette. The filled capillary was then sealed with parafilm and placed in a quartz glass EPR tube of 5 mm inner diameter (Wilmad LabGlass, 710-SQ-250M) and inserted in the microwave cavity, with all measurements recorded at room temperature unless otherwise stated.[56](#page-11-0)

<DESCRIPTION_FROM_IMAGE>The image contains four separate graphs labeled A, B, C, and D, each presenting different data related to electrochemical measurements and analyte detection.

Graph A: Current vs Time
This graph shows the change in current (μA) over time (s) for different concentrations of an analyte. The y-axis ranges from 0 to -12 μA, and the x-axis from 0 to 60 seconds. Multiple curves are presented, corresponding to concentrations ranging from 100 nM to 20 mM. The curves generally show a rapid initial decrease in current followed by stabilization.

Graph B: Calibration Curve
This is a calibration curve plotting Δi (μA) against Log[H2O2] (μM). The x-axis ranges from -2 to 5 log units, while the y-axis goes from 0 to 7 μA. Data points are shown with error bars, and a linear fit is applied. The equation of the line is y = 1.0353x + 1.7206, with an R² value of 0.9921, indicating a strong linear relationship.

Graph C: Selectivity Study
This bar graph compares the current response (μA) for different analytes. The y-axis ranges from 0 to 3.5 μA. The analytes tested are UA (uric acid), DA (dopamine), AA (ascorbic acid), GLU (glucose), GSH (glutathione), and H2O2 (hydrogen peroxide). H2O2 shows a significantly higher response (about 3.1 μA) compared to the other analytes (all below 0.5 μA).

Graph D: Interference Study
This graph shows current (μA) vs time (s) for three different conditions labeled a, b, and c. The y-axis ranges from 0 to -2.5 μA, and the x-axis from 0 to 60 seconds. All three curves show a rapid initial decrease in current followed by stabilization, with slight differences in their stable current values.

These graphs collectively demonstrate the performance of an electrochemical sensor, likely for the detection of hydrogen peroxide, showing its response characteristics, calibration, selectivity, and potential interference effects.</DESCRIPTION_FROM_IMAGE>

Figure 8. (A) Chronoamperometric responses of Au electrode/cerium oxide upon addition of different H2O2 concentrations. Applied potential: −0.5 V. (B) Logarithmic relationship between the concentrations of H2O2 (0.1, 0.5, 10, 100, 1000, 2000, and 20 000 μM). (C) Interference studies of cerium oxide-based lab-on-a-chip device on addition of 1 mM UA, DA, AA, GLU, GSH and 0.2 mM H2O2. (D) Chronoamperometric responses of Au electrode/cerium oxide for the reduction of H2O2 released from 106 PC 12 cells in 1 mL of 1 × PBS (pH = 7.4): (a) PC12 cells, (b) AA (4 μM), and (c) PC12 cells upon injection of 4 μM AA.

| Table 1. Comparison of the Performance of Various |  |  |
|---------------------------------------------------|--|--|
| Hydrogen Peroxide Sensors                         |  |  |

| electrode materials          | linear range (μM) | detection limit<br>(μM) | refs      |
|------------------------------|-------------------|-------------------------|-----------|
| MnO2 nanosheets              | up to 454         | 0.005                   | 63        |
| graphene/Pt<br>nanocomposite | 0.5−3475          | 0.2                     | 64        |
| Se/Pt nanocomposites         | 10−15 000         | 3.1                     | 65        |
| RGO−Au−PTBO                  | 5.0−25 362        | 0.2                     | 66        |
| rGO@CeO2-AgNPs               | 0.5−12 000        | 0.21                    | 67        |
| TiO2@Cu2O                    | 1−15 mM           | 0.15                    | 68        |
| Au/GS/HRP/CS                 | 5−5130            | 1.7                     | 69        |
| cerium oxide NSs             | 0.1−20 000        | 0.01                    | this work |

4.2. Synthesis of Cerium Oxide NSs. Cerium oxide NSs were prepared by a wet-chemical deposition precipitation method. Briefly, 0.25 g of Ce(NO3)3·6H2O was dissolved in 10 mL of distilled water. Subsequently, 0.02 g of urea was added to the solution under vigorous stirring. Then, 10 mL of terephthalic acid solution (60 μM) was added to the reaction solution. After stirring for 15 min, the precipitate product was transferred to a 40 mL Teflon-lined stainless steel autoclave and kept in an electric oven at 150 °C for 6 h. The autoclave was then taken out from the oven and left to cool to room temperature. The produced precipitate was collected via centrifugation, washed thoroughly with water and ethanol, and dried at 60 °C overnight.

4.3. Fabrication of Electrochemical Microfluidic Devices. All experiments were carried out in microfluidic chips made of polydimethylsiloxane (PDMS). The fabrication process can be broken down into three major steps: (1) fabrication of a three-electrode setup, (2) casting of PDMS, and (3) plasma bonding of PDMS over the prepared electrodes on the glass substrate. The electrochemical cell for detection comprised a set of three electrodes: a counter electrode (CE), a working electrode (WE), and a reference <span id="page-9-0"></span>electrode (RE). Gold (Au) was chosen as the material for electrodes, and the electrochemical device was fabricated using standard photolithography techniques. The modified electrode was fabricated by drop-casting 5 μL of aqueous cerium oxide NSs (1 mg·mL−1 ) solution on the cleaned Au working electrode. For fabrication of microfluidic channels, a mixture of polydimethylsiloxane (PDMS) prepolymer and curing agent (10:1) was poured onto the preetched silicon mold followed by curing at 80 °C for 12 h. Then, the cured PDMS was peeled off and placed on the clean bare glass substrate. The width and depth of the channel were both 200 μm, and the surface area of the working electrode was 0.2 mm2 . For better adhesion of PDMS channel to the glass, the sample was annealed at 80 °C for 2 h. Finally, it was treated with oxygen plasma before it was bonded to the patterned glass substrate. To ensure strong bonding between the PDMS channel and the glass substrate, the device was sandwiched between two plexiglass sheets. The width and depth of the channel were both 200 μm.

4.4. Electrochemical H2O2 Analysis by Microfluidic Electrochemical Devices. All electrochemical experiments were performed with a computer-controlled potentiostat, Autolab electrochemical analyzer model PGSTAT30 (Eco Chemie, Utrecht, the Netherlands) driven with GPES software (Eco Chemie) in conjunction with a personal computer for data storage and processing. A three Au electrode configuration was applied, in which the cerium oxide NS-modified Au electrode was used as the working electrode (WE) and placed into a microfluidic device. Peristaltic pumps (ISM834C) were connected to the inlet of the microfluidic device to injection of solution into the chip. The electrochemical sensing of H2O2 was carried out in 0.1 M PBS (pH = 7.4), and the PBS was degassed with N2 for 20 min before test. Cyclic voltammetric measurements for hydrogen peroxide were performed at a scanning rate of 50 mV·s−1 . Chronoamperometry was performed at a constant applied potential of −0.5 V, and the resulting chronoamperograms were subjected to baseline correction before further analysis.

4.5. Detection of H2O2 in Real Sample. PC 12 cells were cultured in Dulbecco's modified Eagle's medium (DMEM) solution containing 1% penicillin, 1% streptomycin, and 10% fetal bovine serum in a humidified atmosphere of 5% CO2 for 24 h at 37 °C in culture dishes. Then, the cells were removed from the Petri dish by trypsinization and washed three times with sterile buffer, followed by suspension in fresh DMEM. Upon the addition of AA (4 μM), the chronoamperometric current response flux of H2O2 in about 106 cells was recorded.

# ■ AUTHOR INFORMATION

#### Corresponding Author

Abdollah Salimi − Department of Chemistry and Research Center for Nanotechnology, University of Kurdistan, 66177- 15175 Sanandaj, Iran; Department of Chemistry, University of Western Ontario, N6A 5B7 London, Ontario, Canada; [orcid.org/0000-0003-1137-1854](http://orcid.org/0000-0003-1137-1854); Email: [absalimi@](mailto:absalimi@uok.ac.ir) [uok.ac.ir](mailto:absalimi@uok.ac.ir), [absalimi@yahoo.com](mailto:absalimi@yahoo.com)

#### Authors

- Negar Alizadeh − Department of Chemistry, University of Kurdistan, 66177-15175 Sanandaj, Iran
- Tsun-Kong Sham − Department of Chemistry, University of Western Ontario, N6A 5B7 London, Ontario, Canada; [orcid.org/0000-0003-1928-6697](http://orcid.org/0000-0003-1928-6697)

Paul Bazylewski − Department of Physics and Astronomy, University of Western Ontario, N6A 3K7 London, Canada Giovanni Fanchini − Department of Physics and Astronomy, University of Western Ontario, N6A 3K7 London, Canada; [orcid.org/0000-0002-2502-7475](http://orcid.org/0000-0002-2502-7475)

Complete contact information is available at: [https://pubs.acs.org/10.1021/acsomega.9b03252](https://pubs.acs.org/doi/10.1021/acsomega.9b03252?ref=pdf)

#### Notes

The authors declare no competing financial interest.

# ■ ACKNOWLEDGMENTS

The authors acknowledge financial support from the Research Office of University of Kurdistan (grant number 4.1261) and Iranian Nanotechnology Initiative Funds for research on microfluidic-based sensors.

# ■ REFERENCES

(1) Gao, L.; Zhuang, J.; Nie, L.; Zhang, J.; Zhang, Y.; Gu, N.; Wang, T.; Feng, J.; Yang, D.; Perrett, S.; Yan, X[. Intrinsic peroxidase-like](https://dx.doi.org/10.1038/nnano.2007.260) [activity of ferromagnetic nanoparticles.](https://dx.doi.org/10.1038/nnano.2007.260) Nat. Nanotechnol. 2007, 2, 577.

(2) Nakamura, E.; Isobe, H[. Functionalized fullerenes in water. The](https://dx.doi.org/10.1021/ar030027y) [first 10 years of their chemistry, biology, and nanoscience.](https://dx.doi.org/10.1021/ar030027y) Acc. Chem. Res. 2003, 36, 807−815.

(3) Xiong, Y.; Chen, S.; Ye, F.; Su, L.; Zhang, C.; Shen, S.; Zhao, S. [Synthesis of a mixed valence state Ce-MOF as an oxidase mimetic for](https://dx.doi.org/10.1039/C4CC10346G) [the colorimetric detection of biothiols.](https://dx.doi.org/10.1039/C4CC10346G) Chem. Commun. 2015, 51, 4635−4638.

(4) Asati, A.; Kaittanis, C.; Santra, S.; Perez, J. M. [pH-tunable](https://dx.doi.org/10.1021/ac102826k) [oxidase-like activity of cerium oxide nanoparticles achieving sensitive](https://dx.doi.org/10.1021/ac102826k) [fluorigenic detection of cancer biomarkers at neutral pH.](https://dx.doi.org/10.1021/ac102826k) Anal. Chem. 2011, 83, 2547−2553.

(5) Alizadeh, N.; Salimi, A.; Hallaj, R.; Fathi, F.; Soleimani, F. [CuO/](https://dx.doi.org/10.1016/j.msec.2019.02.048) WO3 [nanoparticles decorated graphene oxide nanosheets with](https://dx.doi.org/10.1016/j.msec.2019.02.048) [enhanced peroxidase-like activity for electrochemical cancer cell](https://dx.doi.org/10.1016/j.msec.2019.02.048) [detection and targeted therapeutics.](https://dx.doi.org/10.1016/j.msec.2019.02.048) Mater. Sci. Eng., C 2019, 99, 1374−1383.

(6) Ding, Y.; Yang, B.; Liu, H.; Liu, Z.; Zhang, X.; Zheng, X.; Liu, Q. [FePt-Au ternary metallic nanoparticles with the enhanced peroxidase](https://dx.doi.org/10.1016/j.snb.2017.12.115)[like activity for ultrafast colorimetric detection of H2O2.](https://dx.doi.org/10.1016/j.snb.2017.12.115) Sens. Actuators, B 2018, 259, 775−783.

(7) Jain, S.; Panigrahi, A.; Sarma, T. K[. Counter Anion-Directed](https://dx.doi.org/10.1021/acsomega.9b01201) [Growth of Iron Oxide Nanorods in a Polyol Medium with Efficient](https://dx.doi.org/10.1021/acsomega.9b01201) [Peroxidase-Mimicking Activity for Degradation of Dyes in Con](https://dx.doi.org/10.1021/acsomega.9b01201)[taminated Water.](https://dx.doi.org/10.1021/acsomega.9b01201) ACS Omega 2019, 4, 13153−13164.

(8) Liu, C. P.; Wu, T. H.; Liu, C. Y.; Chen, K. C.; Chen, Y. X.; Chen, G. S.; Lin, S. Y. Self-Supplying O2 [through the Catalase-Like Activity](https://dx.doi.org/10.1002/smll.201700278) [of Gold Nanoclusters for Photodynamic Therapy against Hypoxic](https://dx.doi.org/10.1002/smll.201700278) [Cancer Cells.](https://dx.doi.org/10.1002/smll.201700278) Small 2017, 13, No. 1700278.

(9) Yamada, M.; Yoshinari, N.; Kuwamura, N.; Saito, T.; Okada, S.; Maddala, S. P.; Harano, K.; Nakamura, E.; Yamagami, K.; Yamanaka, K.; et al[. Heterogeneous catalase-like activity of gold (I)](https://dx.doi.org/10.1039/C6SC04993A)−cobalt (III) [metallosupramolecular ionic crystals.](https://dx.doi.org/10.1039/C6SC04993A) Chem. Sci. 2017, 8, 2671−2676. (10) Mu, J.; Zhao, X.; Li, J.; Yang, E.-C.; Zhao, X.-J. [Novel](https://dx.doi.org/10.1039/C6TB01390B) [hierarchical NiO nanoflowers exhibiting intrinsic superoxide dis](https://dx.doi.org/10.1039/C6TB01390B)[mutase-like activity.](https://dx.doi.org/10.1039/C6TB01390B) J. Mater. Chem. B 2016, 4, 5217−5221.

(11) Singh, O.; Tyagi, N.; Olmstead, M. M.; Ghosh, K. [The design](https://dx.doi.org/10.1039/C7DT03278A) [of synthetic superoxide dismutase mimetics: seven-coordinate water](https://dx.doi.org/10.1039/C7DT03278A) [soluble manganese (II) and iron (II) complexes and their superoxide](https://dx.doi.org/10.1039/C7DT03278A) [dismutase-like activity studies.](https://dx.doi.org/10.1039/C7DT03278A) Dalton Trans. 2017, 46, 14186−14191.

(12) Lin, Y.; Ren, J.; Qu, X. [Catalytically active nanomaterials: a](https://dx.doi.org/10.1021/ar400250z) [promising candidate for artificial enzymes.](https://dx.doi.org/10.1021/ar400250z) Acc. Chem. Res. 2014, 47, 1097−1105.

(13) Wei, H.; Wang, E. [Nanomaterials with enzyme-like character](https://dx.doi.org/10.1039/c3cs35486e)[istics (nanozymes): next-generation artificial enzymes.](https://dx.doi.org/10.1039/c3cs35486e) Chem. Soc. Rev. 2013, 42, 6060−6093.

<span id="page-10-0"></span>(14) Wang, Q.; Zhang, X.; Huang, L.; Zhang, Z.; Dong, S. [One-pot](https://dx.doi.org/10.1021/acsami.6b16034) synthesis of Fe3O4 [nanoparticle loaded 3D porous graphene](https://dx.doi.org/10.1021/acsami.6b16034) [nanocomposites with enhanced nanozyme activity for glucose](https://dx.doi.org/10.1021/acsami.6b16034) [detection.](https://dx.doi.org/10.1021/acsami.6b16034) ACS Appl. Mater. Interfaces 2017, 9, 7465−7471.

(15) Zhao, J.; Dong, W.; Zhang, X.; Chai, H.; Huang, Y. [FeNPs@](https://dx.doi.org/10.1016/j.snb.2018.02.151) Co3O4 [hollow nanocages hybrids as effective peroxidase mimics for](https://dx.doi.org/10.1016/j.snb.2018.02.151) [glucose biosensing.](https://dx.doi.org/10.1016/j.snb.2018.02.151) Sens. Actuators, B 2018, 263, 575−584.

(16) Dong, W.; Zhuang, Y.; Li, S.; Zhang, X.; Chai, H.; Huang, Y. [High peroxidase-like activity of metallic cobalt nanoparticles](https://dx.doi.org/10.1016/j.snb.2017.09.013) encapsulated in metal−[organic frameworks derived carbon for](https://dx.doi.org/10.1016/j.snb.2017.09.013) [biosensing.](https://dx.doi.org/10.1016/j.snb.2017.09.013) Sens. Actuators, B 2018, 255, 2050−2057.

(17) Wang, C.; Liu, C.; Luo, J.; Tian, Y.; Zhou, N. [Direct](https://dx.doi.org/10.1016/j.aca.2016.07.013) [electrochemical detection of kanamycin based on peroxidase-like](https://dx.doi.org/10.1016/j.aca.2016.07.013) [activity of gold nanoparticles.](https://dx.doi.org/10.1016/j.aca.2016.07.013) Anal. Chim. Acta 2016, 936, 75−82.

(18) Dong, J.; Song, L.; Yin, J.-J.; He, W.; Wu, Y.; Gu, N.; Zhang, Y. Co3O4 [nanoparticles with multi-enzyme activities and their](https://dx.doi.org/10.1021/am405009f) [application in immunohistochemical assay.](https://dx.doi.org/10.1021/am405009f) ACS Appl. Mater. Interfaces 2014, 6, 1959−1970.

(19) Li, J.; Liu, W.; Wu, X.; Gao, X. [Mechanism of pH-switchable](https://dx.doi.org/10.1016/j.biomaterials.2015.01.012) [peroxidase and catalase-like activities of gold, silver, platinum and](https://dx.doi.org/10.1016/j.biomaterials.2015.01.012) [palladium.](https://dx.doi.org/10.1016/j.biomaterials.2015.01.012) Biomaterials 2015, 48, 37−44.

(20) Mu, J.; Wang, Y.; Zhao, M.; Zhang, L. [Intrinsic peroxidase-like](https://dx.doi.org/10.1039/c2cc17013b) [activity and catalase-like activity of Co3O4](https://dx.doi.org/10.1039/c2cc17013b) nanoparticles. Chem. Commun. 2012, 48, 2540−2542.

(21) Wang, Q.; Zhang, L.; Shang, C.; Zhang, Z.; Dong, S[. Triple](https://dx.doi.org/10.1039/C6CC00194G)[enzyme mimetic activity of nickel](https://dx.doi.org/10.1039/C6CC00194G)−palladium hollow nanoparticles [and their application in colorimetric biosensing of glucose.](https://dx.doi.org/10.1039/C6CC00194G) Chem. Commun. 2016, 52, 5410−5413.

(22) Ding, Y.; Wang, G.; Sun, F.; Lin, Y. [Heterogeneous](https://dx.doi.org/10.1021/acsami.8b10560) [Nanostructure Design Based on the Epitaxial Growth of Spongy](https://dx.doi.org/10.1021/acsami.8b10560) MoS x on 2D Co (OH) 2 [Nanoflakes for Triple-Enzyme Mimetic](https://dx.doi.org/10.1021/acsami.8b10560) [Activity: Experimental and Density Functional Theory Studies on the](https://dx.doi.org/10.1021/acsami.8b10560) [Dramatic Activation Mechanism.](https://dx.doi.org/10.1021/acsami.8b10560) ACS Appl. Mater. Interfaces 2018, 10, 32567−32578.

(23) Li, H.; Wang, T.; Wang, Y.; Wang, S.; Su, P.; Yang, Y. [Intrinsic](https://dx.doi.org/10.1021/acs.iecr.7b04821) [triple-enzyme mimetic activity of V6O13](https://dx.doi.org/10.1021/acs.iecr.7b04821) nanotextiles: mechanism [investigation and colorimetric and fluorescent detections.](https://dx.doi.org/10.1021/acs.iecr.7b04821) Ind. Eng. Chem. Res. 2018, 57, 2416−2425.

(24) Alizadeh, N.; Salimi, A.; Hallaj, R. [Mimicking peroxidase](https://dx.doi.org/10.1016/j.talanta.2018.06.034) activity of Co2 (OH) 2CO3-CeO2 [nanocomposite for smartphone](https://dx.doi.org/10.1016/j.talanta.2018.06.034) [based detection of tumor marker using paper-based microfluidic](https://dx.doi.org/10.1016/j.talanta.2018.06.034) [immunodevice.](https://dx.doi.org/10.1016/j.talanta.2018.06.034) Talanta 2018, 189, 100−110.

(25) Li, C.; Shi, X.; Shen, Q.; Guo, C.; Hou, Z.; Zhang, J[. Hot](https://dx.doi.org/10.1155/2018/4857461) [Topics and Challenges of Regenerative Nanoceria in Application of](https://dx.doi.org/10.1155/2018/4857461) [Antioxidant Therapy.](https://dx.doi.org/10.1155/2018/4857461) J. Nanomater. 2018, 2018, No. 4857461.

(26) Wu, J.; Wang, X.; Wang, Q.; Lou, Z.; Li, S.; Zhu, Y.; Qin, L.; Wei, H[. Nanomaterials with enzyme-like characteristics (nanozymes):](https://dx.doi.org/10.1039/C8CS00457A) [next-generation artificial enzymes (II).](https://dx.doi.org/10.1039/C8CS00457A) Chem. Soc. Rev. 2019, 48, 1004−1076.

(27) Alizadeh, N.; Salimi, A.; Hallaj, R. [Mimicking peroxidase-like](https://dx.doi.org/10.1016/j.snb.2019.01.068) activity of Co3O4-CeO2 [nanosheets integrated paper-based analytical](https://dx.doi.org/10.1016/j.snb.2019.01.068) [devices for detection of glucose with smartphone.](https://dx.doi.org/10.1016/j.snb.2019.01.068) Sens. Actuators, B 2019, 288, 44−52.

(28) Ding, H.; Yang, J.; Ma, S.; Yigit, N.; Xu, J.; Rupprechter, G.; Wang, J[. Large Dimensional CeO2 Nanoflakes by Microwave-Assisted](https://dx.doi.org/10.1002/cctc.201800784) [Synthesis: Lamellar Nano-Channels and Surface Oxygen Vacancies](https://dx.doi.org/10.1002/cctc.201800784) [Promote Catalytic Activity.](https://dx.doi.org/10.1002/cctc.201800784) ChemCatChem 2018, 10, 4100−4108.

(29) Huang, Y.; Long, B.; Tang, M.; Rui, Z.; Balogun, M.-S.; Tong, Y.; Ji, H[. Bifunctional catalytic material: An ultrastable and high](https://dx.doi.org/10.1016/j.apcatb.2015.08.047)[performance surface defect CeO2](https://dx.doi.org/10.1016/j.apcatb.2015.08.047) nanosheets for formaldehyde [thermal oxidation and photocatalytic oxidation.](https://dx.doi.org/10.1016/j.apcatb.2015.08.047) Appl. Catal., B 2016, 181, 779−787.

(30) Singh, S.; Singh, M.; Mitra, K.; Singh, R.; Gupta, S. K. S.; Tiwari, I.; Ray, B. [Electrochemical sensing of hydrogen peroxide using](https://dx.doi.org/10.1016/j.electacta.2017.12.006) [brominated graphene as mimetic catalase.](https://dx.doi.org/10.1016/j.electacta.2017.12.006) Electrochim. Acta 2017, 258, 1435−1444.

(31) Vilian, A. T. E.; Chen, S.-M.; Lou, B.-S. [A simple strategy for](https://dx.doi.org/10.1016/j.bios.2014.05.023) [the immobilization of catalase on multi-walled carbon nanotube/poly](https://dx.doi.org/10.1016/j.bios.2014.05.023) [(L-lysine) biocomposite for the detection of H2O2](https://dx.doi.org/10.1016/j.bios.2014.05.023) and iodate. Biosens. Bioelectron. 2014, 61, 639−647.

(32) Chen, S.; Yuan, R.; Chai, Y.; Hu, F. [Electrochemical sensing of](https://dx.doi.org/10.1007/s00604-012-0904-4) [hydrogen peroxide using metal nanoparticles: a review.](https://dx.doi.org/10.1007/s00604-012-0904-4) Microchim. Acta 2013, 180, 15−32.

(33) Chen, W.; Cai, S.; Ren, Q.-Q.; Wen, W.; Zhao, Y.-D[. Recent](https://dx.doi.org/10.1039/C1AN15738H) [advances in electrochemical sensing for hydrogen peroxide: a review.](https://dx.doi.org/10.1039/C1AN15738H) Analyst 2012, 137, 49−58.

(34) Watt, B. E.; Proudfoot, A. T.; Vale, J. A[. Hydrogen peroxide](https://dx.doi.org/10.2165/00139709-200423010-00006) [poisoning.](https://dx.doi.org/10.2165/00139709-200423010-00006) Toxicol. Rev. 2004, 23, 51−57.

(35) Hong, J.; Maguhn, J.; Freitag, D.; Kettrup, A[. Determination of](https://dx.doi.org/10.1007/s002160050847) H2O2 [and organic peroxides by high-performance liquid chromatog](https://dx.doi.org/10.1007/s002160050847)[raphy with post-column UV irradiation, derivatization and fluo](https://dx.doi.org/10.1007/s002160050847)[rescence detection.](https://dx.doi.org/10.1007/s002160050847) Fresenius' J. Anal. Chem. 1998, 361, 124−128.

(36) Lebiga, E.; Fernandez, R. E.; Beskok, A. [Confined](https://dx.doi.org/10.1039/C5AN00720H) [chemiluminescence detection of nanomolar levels of H](https://dx.doi.org/10.1039/C5AN00720H) 2 O 2 in a paper−[plastic disposable microfluidic device using a smartphone.](https://dx.doi.org/10.1039/C5AN00720H) Analyst 2015, 140, 5006−5011.

(37) Chen, S.; Hai, X.; Chen, X.-W.; Wang, J.-H. [In situ growth of](https://dx.doi.org/10.1021/ac501497d) [silver nanoparticles on graphene quantum dots for ultrasensitive](https://dx.doi.org/10.1021/ac501497d) [colorimetric detection of H2O2](https://dx.doi.org/10.1021/ac501497d) and glucose. Anal. Chem. 2014, 86, 6689−6694.

(38) Yuan, J.; Cen, Y.; Kong, X.-J.; Wu, S.; Liu, C.-L.; Yu, R.-Q.; Chu, X[. MnO2-nanosheet-modified upconversion nanosystem for](https://dx.doi.org/10.1021/acsami.5b02188) [sensitive turn-on fluorescence detection of H2O2](https://dx.doi.org/10.1021/acsami.5b02188) and glucose in [blood.](https://dx.doi.org/10.1021/acsami.5b02188) ACS Appl. Mater. Interfaces 2015, 7, 10548−10555.

(39) Teymourian, H.; Salimi, A.; Khezrian, S. Fe3O4 [magnetic](https://dx.doi.org/10.1016/j.bios.2013.04.034) [nanoparticles/reduced graphene oxide nanosheets as a novel electro](https://dx.doi.org/10.1016/j.bios.2013.04.034)[chemical and bioeletrochemical sensing platform.](https://dx.doi.org/10.1016/j.bios.2013.04.034) Biosens. Bioelectron. 2013, 49, 1−8.

(40) Salimi, A.; Hallaj, R.; Soltanian, S.; Mamkhezri, H. [Nanomolar](https://dx.doi.org/10.1016/j.aca.2007.05.010) [detection of hydrogen peroxide on glassy carbon electrode modified](https://dx.doi.org/10.1016/j.aca.2007.05.010) [with electrodeposited cobalt oxide nanoparticles.](https://dx.doi.org/10.1016/j.aca.2007.05.010) Anal. Chim. Acta 2007, 594, 24−31.

(41) Yamada, K.; Henares, T. G.; Suzuki, K.; Citterio, D. [Paper](https://dx.doi.org/10.1002/anie.201411508)[based inkjet-printed microfluidic analytical devices.](https://dx.doi.org/10.1002/anie.201411508) Angew. Chem. 2015, 54, 5294−5310.

(42) Alizadeh, N.; Ghasemi, F.; Salimi, A.; Hallaj, R.; Fathi, F.; Soleimani, F. [Polymer nanocomposite film for dual colorimetric and](https://dx.doi.org/10.1016/j.dyepig.2019.107875) [fluorescent ascorbic acid detection integrated single-cell bioimaging](https://dx.doi.org/10.1016/j.dyepig.2019.107875) [with droplet microfluidic platform.](https://dx.doi.org/10.1016/j.dyepig.2019.107875) Dyes Pigm. 2020, 173, No. 107875.

(43) Alizadeh, N.; Salimi, A. [Polymer dots as a novel probe for](https://dx.doi.org/10.1016/j.aca.2019.08.036) [fluorescence sensing of dopamine and imaging in single living cell](https://dx.doi.org/10.1016/j.aca.2019.08.036) [using droplet microfluidic platform.](https://dx.doi.org/10.1016/j.aca.2019.08.036) Anal. Chim. Acta 2019, 1091, 40− 49.

(44) Ben-Yoav, H.; Dykstra, P. H.; Bentley, W. E.; Ghodssi, R[. A](https://dx.doi.org/10.1016/j.bios.2014.09.069) [controlled microfluidic electrochemical lab-on-a-chip for label-free](https://dx.doi.org/10.1016/j.bios.2014.09.069) [diffusion-restricted DNA hybridization analysis.](https://dx.doi.org/10.1016/j.bios.2014.09.069) Biosens. Bioelectron. 2015, 64, 579−585.

(45) Riahi, R.; Shaegh, S. A. M.; Ghaderi, M.; Zhang, Y. S.; Shin, S. R.; Aleman, J.; Massa, S.; Kim, D.; Dokmeci, M. R.; Khademhosseini, A. [Automated microfluidic platform of bead-based electrochemical](https://dx.doi.org/10.1038/srep24598) [immunosensor integrated with bioreactor for continual monitoring of](https://dx.doi.org/10.1038/srep24598) [cell secreted biomarkers.](https://dx.doi.org/10.1038/srep24598) Sci. Rep. 2016, 6, No. 24598.

(46) Jampaiah, D.; Reddy, T. S.; Kandjani, A. E.; Selvakannan, P.; Sabri, Y. M.; Coyle, V. E.; Shukla, R.; Bhargava, S. K[. Fe-doped CeO2](https://dx.doi.org/10.1039/C6TB00422A) [nanorods for enhanced peroxidase-like activity and their application](https://dx.doi.org/10.1039/C6TB00422A) [towards glucose detection.](https://dx.doi.org/10.1039/C6TB00422A) J. Mater. Chem. B 2016, 4, 3874−3885.

(47) Cho, Y. J.; Jang, H.; Lee, K.-S.; Kim, D. R[. Direct growth of](https://dx.doi.org/10.1016/j.apsusc.2015.02.138) [cerium oxide nanorods on diverse substrates for superhydrophobicity](https://dx.doi.org/10.1016/j.apsusc.2015.02.138) [and corrosion resistance.](https://dx.doi.org/10.1016/j.apsusc.2015.02.138) Appl. Surf. Sci. 2015, 340, 96−101.

(48) Ikuma, Y.; Oosawa, H.; Shimada, E.; Kamiya, M. [Effect of](https://dx.doi.org/10.1016/S0167-2738(02)00538-6) [microwave radiation on the formation of Ce2O (CO3)](https://dx.doi.org/10.1016/S0167-2738(02)00538-6) 2· H2O in [aqueous solution.](https://dx.doi.org/10.1016/S0167-2738(02)00538-6) Solid State Ionics 2002, 151, 347−352.

(49) Heidari, F.; Irankhah, A. [Effect of surfactants and digestion time](https://dx.doi.org/10.1016/j.ceramint.2014.04.112) [on nano crystalline cerium oxide characteristics synthesized by](https://dx.doi.org/10.1016/j.ceramint.2014.04.112) [differential precipitation.](https://dx.doi.org/10.1016/j.ceramint.2014.04.112) Ceram. Int. 2014, 40, 12655−12660.

(50) Lin, Z.; Waller, G.; Liu, Y.; Liu, M.; Wong, C. P[. Facile](https://dx.doi.org/10.1002/aenm.201200038) [synthesis of nitrogen-doped graphene via pyrolysis of graphene oxide](https://dx.doi.org/10.1002/aenm.201200038) <span id="page-11-0"></span>[and urea, and its electrocatalytic activity toward the oxygen-reduction](https://dx.doi.org/10.1002/aenm.201200038) [reaction.](https://dx.doi.org/10.1002/aenm.201200038) Adv. Energy Mater. 2012, 2, 884−888.

(51) Varaprasad, K.; Pariguana, M.; Raghavendra, G. M.; Jayaramudu, T.; Sadiku, E. R. [Development of biodegradable](https://dx.doi.org/10.1016/j.msec.2016.08.053) [metaloxide/polymer nanocomposite films based on poly-](https://dx.doi.org/10.1016/j.msec.2016.08.053)ε-caprolac[tone and terephthalic acid.](https://dx.doi.org/10.1016/j.msec.2016.08.053) Mater. Sci. Eng., C 2017, 70, 85−93.

(52) Cui, L.; Wu, J.; Li, J.; Ju, H[. Electrochemical sensor for lead](https://dx.doi.org/10.1021/acs.analchem.5b03287) [cation sensitized with a DNA functionalized porphyrinic metal](https://dx.doi.org/10.1021/acs.analchem.5b03287)− [organic framework.](https://dx.doi.org/10.1021/acs.analchem.5b03287) Anal. Chem. 2015, 87, 10635−10641.

(53) Su, L.; Qin, W.; Zhang, H.; Rahman, Z. U.; Ren, C.; Ma, S.; Chen, X[. The peroxidase/catalase-like activities of MFe2O4](https://dx.doi.org/10.1016/j.bios.2014.07.048) (M = Mg, [Ni, Cu) MNPs and their application in colorimetric biosensing of](https://dx.doi.org/10.1016/j.bios.2014.07.048) [glucose.](https://dx.doi.org/10.1016/j.bios.2014.07.048) Biosens. Bioelectron. 2015, 63, 384−391.

(54) Iravani, S.; Soofi, G. J. Measurement of Oxidative Stress Using ESR Spectroscopy. In Electron Spin Resonance Spectroscopy in Medicine; Springer, 2019; pp 73−81.

(55) Kurake, N.; Tanaka, H.; Ishikawa, K.; Takeda, K.; Hashizume, H.; Nakamura, K.; Kajiyama, H.; Kondo, T.; Kikkawa, F.; Mizuno, M.; Hori, M. Effects of • OH and • [NO radicals in the aqueous phase on](https://dx.doi.org/10.1088/1361-6463/aa5f1d) H2O2 [and generated in plasma-activated medium.](https://dx.doi.org/10.1088/1361-6463/aa5f1d) J. Phys. D: Appl. Phys. 2017, 50, No. 155202.

(56) Sobanska, K.; Pietrzyk, P.; Sojka, Z[. Generation of reactive](https://dx.doi.org/10.1021/acscatal.7b00189) ́ [oxygen species via electroprotic interaction of H2O2](https://dx.doi.org/10.1021/acscatal.7b00189) with ZrO2 gel: [ionic sponge effect and pH-switchable peroxidase-and catalase-like](https://dx.doi.org/10.1021/acscatal.7b00189) [activity.](https://dx.doi.org/10.1021/acscatal.7b00189) ACS Catal. 2017, 7, 2935−2947.

(57) Finkelstein, E.; Rosen, G. M.; Rauckman, E. J. [Spin trapping of](https://dx.doi.org/10.1016/0003-9861(80)90323-9) [superoxide and hydroxyl radical: Practical aspects.](https://dx.doi.org/10.1016/0003-9861(80)90323-9) Arch. Biochem. Biophys. 1980, 200, 1−16.

(58) Buxton, G. V.; Greenstock, C. L.; Helman, W. P.; Ross, A. B. [Critical review of rate constants for reactions of hydrated electrons,](https://dx.doi.org/10.1063/1.555805) [hydrogen atoms and hydroxyl radicals (](https://dx.doi.org/10.1063/1.555805)• OH/• O−) in aqueous [solution.](https://dx.doi.org/10.1063/1.555805) J. Phys. Chem. Ref. Data 1988, 17, 513−886.

(59) Buettner, G. R.; Oberley, L. W[. Considerations in the spin](https://dx.doi.org/10.1016/0006-291X(78)90398-4) [trapping of superoxide and hydroxyl radical in aqueous systems using](https://dx.doi.org/10.1016/0006-291X(78)90398-4) [5,5-dimethyl-1-pyrroline-1-oxide.](https://dx.doi.org/10.1016/0006-291X(78)90398-4) Biochem. Biophys. Res. Commun. 1978, 83, 69−74.

(60) Hawkins, C. L.; Davies, M. J. [Detection and characterization of](https://dx.doi.org/10.1016/j.bbagen.2013.03.034) [radicals in biological materials using EPR methodology.](https://dx.doi.org/10.1016/j.bbagen.2013.03.034) Biochim. Biophys. Acta, Gen. Subj. 2014, 1840, 708−721.

(61) Wen, T.; He, W.; Chong, Y.; Liu, Y.; Yin, J.-J.; Wu, X[. Exploring](https://dx.doi.org/10.1039/C5CP04046A) [environment-dependent effects of Pd nanostructures on reactive](https://dx.doi.org/10.1039/C5CP04046A) [oxygen species (ROS) using electron spin resonance (ESR)](https://dx.doi.org/10.1039/C5CP04046A) [technique: implications for biomedical applications.](https://dx.doi.org/10.1039/C5CP04046A) Phys. Chem. Chem. Phys. 2015, 17, 24937−24943.

(62) Alizadeh, N.; Salimi, A.; Hallaj, R.; Fathi, F.; Soleimani, F. [Ni](https://dx.doi.org/10.1186/s12951-018-0421-7)hemin metal−[organic framework with highly efficient peroxidase](https://dx.doi.org/10.1186/s12951-018-0421-7) [catalytic activity: toward colorimetric cancer cell detection and](https://dx.doi.org/10.1186/s12951-018-0421-7) [targeted therapeutics.](https://dx.doi.org/10.1186/s12951-018-0421-7) J. Nanobiotechnol. 2018, 16, No. 93.

(63) Shu, Y.; Xu, J.; Chen, J.; Xu, Q.; Xiao, X.; Jin, D.; Pang, H.; Hu, X[. Ultrasensitive electrochemical detection of H2O2](https://dx.doi.org/10.1016/j.snb.2017.05.124) in living cells [based on ultrathin MnO2](https://dx.doi.org/10.1016/j.snb.2017.05.124) nanosheets. Sens. Actuators, B 2017, 252, 72−78.

(64) Zhang, Y.; Bai, X.; Wang, X.; Shiu, K.-K.; Zhu, Y.; Jiang, H. Highly sensitive graphene−[Pt nanocomposites amperometric bio](https://dx.doi.org/10.1021/ac5009699)[sensor and its application in living cell H2O2](https://dx.doi.org/10.1021/ac5009699) detection. Anal. Chem. 2014, 86, 9459−9465.

(65) Li, Y.; Zhang, J.-J.; Xuan, J.; Jiang, L.-P.; Zhu, J.-J. [Fabrication of](https://dx.doi.org/10.1016/j.elecom.2010.03.031) [a novel nonenzymatic hydrogen peroxide sensor based on Se/Pt](https://dx.doi.org/10.1016/j.elecom.2010.03.031) [nanocomposites.](https://dx.doi.org/10.1016/j.elecom.2010.03.031) Electrochem. Commun. 2010, 12, 777−780.

(66) Chang, H.; Wang, X.; Shiu, K.-K.; Zhu, Y.; Wang, J.; Li, Q.; Chen, B.; Jiang, H[. Layer-by-layer assembly of graphene, Au and poly](https://dx.doi.org/10.1016/j.bios.2012.10.001) [(toluidine blue O) films sensor for evaluation of oxidative stress of](https://dx.doi.org/10.1016/j.bios.2012.10.001) [tumor cells elicited by hydrogen peroxide.](https://dx.doi.org/10.1016/j.bios.2012.10.001) Biosens. Bioelectron. 2013, 41, 789−794.

(67) Yao, Z.; Yang, X.; Wu, F.; Wu, W.; Wu, F[. Synthesis of](https://dx.doi.org/10.1007/s00604-016-1924-2) [differently sized silver nanoparticles on a screen-printed electrode](https://dx.doi.org/10.1007/s00604-016-1924-2) [sensitized with a nanocomposites consisting of reduced graphene](https://dx.doi.org/10.1007/s00604-016-1924-2) [oxide and cerium (IV) oxide for nonenzymatic sensing of hydrogen](https://dx.doi.org/10.1007/s00604-016-1924-2) [peroxide.](https://dx.doi.org/10.1007/s00604-016-1924-2) Microchim. Acta 2016, 183, 2799−2806.

(68) Li, Z.; Xin, Y.; Zhang, Z[. New photocathodic analysis platform](https://dx.doi.org/10.1021/acs.analchem.5b02644) [with quasi-core/shell-structured TiO2@ Cu2O for sensitive detection](https://dx.doi.org/10.1021/acs.analchem.5b02644) of H2O2 [release from living cells.](https://dx.doi.org/10.1021/acs.analchem.5b02644) Anal. Chem. 2015, 87, 10491− 10497.

(69) Zhou, K.; Zhu, Y.; Yang, X.; Luo, J.; Li, C.; Luan, S[. A novel](https://dx.doi.org/10.1016/j.electacta.2010.01.035) [hydrogen peroxide biosensor based on Au](https://dx.doi.org/10.1016/j.electacta.2010.01.035)−graphene−HRP−chitosan [biocomposites.](https://dx.doi.org/10.1016/j.electacta.2010.01.035) Electrochim. Acta 2010, 55, 3055−3060.