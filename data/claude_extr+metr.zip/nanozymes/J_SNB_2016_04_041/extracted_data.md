[
  {
    "formula": "NOT_DETECTED",
    "activity": "NOT_DETECTED",
    "syngony": "NOT_DETECTED",
    "length": "NOT_DETECTED",
    "width": "NOT_DETECTED",
    "depth": "NOT_DETECTED",
    "surface": "NOT_DETECTED",
    "km_value": "NOT_DETECTED",
    "km_unit": "NOT_DETECTED",
    "vmax_value": "NOT_DETECTED",
    "vmax_unit": "NOT_DETECTED",
    "reaction_type": "TMB + H2O2",
    "c_min": "NOT_DETECTED",
    "c_max": "NOT_DETECTED",
    "c_const": "NOT_DETECTED",
    "c_const_unit": "NOT_DETECTED",
    "ccat_value": "NOT_DETECTED",
    "ccat_unit": "NOT_DETECTED",
    "ph": "NOT_DETECTED",
    "temperature": "NOT_DETECTED"
  }
]