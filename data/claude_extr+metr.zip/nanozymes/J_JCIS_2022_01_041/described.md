#### [Journal of Colloid and Interface Science 613 (2022) 384–395](https://doi.org/10.1016/j.jcis.2022.01.041)

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or emblem, likely for the academic publishing company Elsevier. While it contains some scientific and historical imagery, it does not convey specific chemical or scientific information relevant to interpreting research data or results. Therefore, I've classified it as an abstract image per the instructions.</DESCRIPTION_FROM_IMAGE>

Contents lists available at [ScienceDirect](http://www.sciencedirect.com/science/journal/00219797)

# Journal of Colloid and Interface Science

journal homepage: [www.elsevier.com/locate/jcis](http://www.elsevier.com/locate/jcis)

# Colorimetric assay for the detection of dopamine using bismuth ferrite oxide (Bi2Fe4O9) nanoparticles as an efficient peroxidase-mimic nanozyme

<DESCRIPTION_FROM_IMAGE>The image depicts a circular logo or emblem design. The main element is a stylized bookmark or ribbon shape in red, positioned in the center of a blue circular background. The bookmark shape appears to be folded or creased, creating a three-dimensional effect. The overall design is simple and minimalist, using only two colors (red and blue) on a white background. The circular emblem is enclosed within a thin gray border. This type of image is commonly used as a brand logo or icon for applications, websites, or organizations related to reading, bookmarking, or information management. However, as this logo does not convey specific scientific or chemical information, the appropriate response is:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

Mehri Razavi a,b , Alexandre Barras b , Madjid Ifires b,c , Abir Swaidan b , Maryam Khoshkam d , Sabine Szunerits b , Mohsen Kompany-Zareh a,e , Rabah Boukherroub b,⇑

aDepartment of Chemistry, Institute for Advanced Studies in Basic Sciences, Zanjan 45137-66731, Iran

bUniv. Lille, CNRS, Centrale Lille, Univ. Polytechnique Hauts-de-France, UMR 8520 - IEMN, Lille F-59000, France

c Research Center of Semi-conductor Technology for Energy, CRTSE - 02, Bd. Dr. Frantz FANON, B.P. 140 Algiers-7, Merveilles 16038, Algeria

dDepartment of Chemistry, Faculty of Science, Mohaghegh Ardabili University, 56199-11367, Ardabil, Iran

eDepartment of Chemistry, Dalhousie University, 6274 Coburg Road, P.O. Box 15000, Halifax, NS B3H 4R2, Canada

# highlights

- Bi2Fe4O9 nanozyme as a simple and low-cost colorimetric sensor was developed for easy dopamine detection.
- The sensor achieved good performance with a linear range from 0.15 to 50 lM and a detection limit of 51 nM.
- The nanozyme was reused up to 4 cycles without a significant decrease in its performance.

# article info

Article history: Received 21 October 2021 Revised 3 January 2022 Accepted 6 January 2022 Available online 10 January 2022

Keywords: Bi2Fe4O9 nanozyme 3,30 ,5,50 -tetramethylbenzidine (TMB) Peroxidase-like activity Dopamine Colorimetric assay

# graphical abstract

<DESCRIPTION_FROM_IMAGE>The image presents a comprehensive overview of a scientific study related to dopamine sensing using Bi2Fe4O9 nanoparticles. Here's a detailed description of the components:

1. Chemical structures:
   - Bi(NO3)3·5H2O (SMILES: [Bi](=[O])(=[O])(=[O]).[N+](=O)([O-])[O-].[N+](=O)([O-])[O-].[N+](=O)([O-])[O-].O.O.O.O.O)
   - Fe(NO3)3·9H2O (SMILES: [Fe](=[O])(=[O])(=[O]).[N+](=O)([O-])[O-].[N+](=O)([O-])[O-].[N+](=O)([O-])[O-].O.O.O.O.O.O.O.O.O)
   - Bi2Fe4O9 (final product)
   - H2O2 (SMILES: OO)
   - TMB (3,3',5,5'-Tetramethylbenzidine, SMILES: Cc1cc(C)c(-c2cc(C)c(N)c(C)c2)c(N)c1)
   - Dopamine (SMILES: C(CCN)c1ccc(O)c(O)c1)

2. Synthesis process:
   - Precursors: Bi(NO3)3·5H2O and Fe(NO3)3·9H2O
   - Intermediate steps: mixing, heating (500°C for 3 hours)
   - Final product: Bi2Fe4O9 nanoparticles (orange powder)

3. Sensing mechanism:
   - Interaction between Bi2Fe4O9, H2O2, TMB, and dopamine
   - Colorimetric change observed (blue color formation)

4. 3D graph:
   - X-axis: Wavelength (nm), range approximately 300-800 nm
   - Y-axis: Time (s), range 0-600 seconds
   - Z-axis: Absorbance (a.u.)
   - The graph shows a peak around 650-700 nm, increasing in intensity over time

5. Additional elements:
   - Image of scientific equipment (possibly a spectrophotometer)
   - Representation of naked eye detection
   - Visual color gradient from colorless to deep blue

This image illustrates the synthesis of Bi2Fe4O9 nanoparticles and their application in dopamine sensing through a colorimetric method, likely involving the oxidation of TMB in the presence of H2O2 and dopamine, catalyzed by the Bi2Fe4O9 nanoparticles.</DESCRIPTION_FROM_IMAGE>

# abstract

This work describes the preparation of ternary bismuth ferrite oxide nanoparticles (Bi2Fe4O9 NPs) with an enzyme mimetic activity for dopamine (DA) qualitative and quantitative detection. Bi2Fe4O9 NPs were prepared using a facile, low cost, and one-pot hydrothermal treatment. The chemical composition, morphology, and optical properties of Bi2Fe4O9 nanozyme were characterized using different techniques such as Fourier-transform infrared spectroscopy (FTIR), X-ray diffraction pattern (XRD), X-ray photoelectron spectroscopy (XPS), thermo-gravimetric analysis (TGA), dynamic light scattering (DLS), field-emission scanning electron microscopy (FESEM) imaging, FESEM-energy dispersive X-ray spectroscopy (EDS), UV–vis absorption, and fluorescence emission spectroscopy. Bi2Fe4O9 NPs were utilized to catalyze the oxidation of a typical chromogenic peroxidase substrate, 3,30 ,5,50 -tetramethylbenzidine (TMB), to form the blue-colored oxidized product (oxTMB), in the presence of hydrogen peroxide (H2O2). All reactions occurred in acetate buffer solution (pH 3.5) to generate hydroxyl radicals ( OH) and the kinetics were followed by UV–vis absorbance at 654 nm. The steady-state kinetic parameters were obtained from the Michaelis-Menten equation and exhibited a good catalytic efficiency of Bi2Fe4O9 NPs as enzyme mimetics. Michaelis–Menten constant (Km) values were estimated as 0.07 and 0.73 mM for TMB and H2O2, respectively. The presented method is efficient, rapid, cost-effective, and sensitive for the colorimetric detection of dopamine with a linear range (LR) from 0.15 to 50 lM and a detection limit (LOD) of

⇑ Corresponding author at: Univ. Lille, CNRS, Centrale Lille, Univ. Polytechnique Hauts-de-France, UMR 8520 - IEMN, Lille F-59000, France. E-mail address: [rabah.boukherroub@univ-lille.fr](mailto:rabah.boukherroub@univ-lille.fr) (R. Boukherroub).

51 nM. The proposed colorimetric sensor was successfully applied for the detection of different concentrations of dopamine in spiked fetal bovine serum (FBS) and horse serum (HS) samples. It is anticipated that Bi2Fe4O9 nanozyme holds great potential in biomedical analysis and diagnostic applications of dopamine-related diseases.

2022 Elsevier Inc. All rights reserved.

#### 1. Introduction

Dopamine (DA), 4-(2-aminoethyl)benzene-1,2-diol), is a biogenic monoamine and one of the quite important catecholamine neurotransmitters (NT), which plays significant key roles in the mammalian central nervous such as memory, learning, cognition, emotions, renal, hormonal, and cardiovascular systems [\[1–3\].](#page-9-0) The abnormal level of dopamine concentration in the human body can lead to serious neurological syndromes and various diseases like Alzheimer, Parkinson, Huntington, senile dementia, and Schizophrenia [\[4–7\].](#page-9-0)

Therefore, the measurement of the dopamine level in biological fluids with high accuracy and sensitivity is an extremely important factor for early diagnosis of diseases and development of therapeutic approaches [\[3,8\]](#page-9-0). Various analytical strategies have been developed to detect the DA level, including high-performance liquid chromatography (HPLC) [\[9\],](#page-9-0) capillary electrophoresis (CE) [\[10,11\],](#page-10-0) field-effect transistor (FET)-based biosensor [\[12\],](#page-10-0) fluorometry [\[13,14\],](#page-10-0) random lasers (RL) with incoherent feedback [\[15\],](#page-10-0) electrochemiluminescence (ECL) [\[16\],](#page-10-0) and electrochemical methods [\[17,18\].](#page-10-0) However, all these methods have several constraints; they often require complex and advanced pre-treatment processes, long analysis times, high-costs, sophisticated instruments, and trained personnel [\[4,8\].](#page-9-0) In this regard, many studies have been focused on elucidating the colorimetric assays for dopamine identification, because of their intrinsic advantages of simple assay design, time-saving, high efficiency, and most importantly, easy visual detection [\[3,4,7\].](#page-9-0)

Traditionally, natural enzymes as biological catalysts have been applied in colorimetric analysis systems. A common example is the horseradish peroxidase enzyme (HRP). To keep up with the more efficient performance of natural enzymes, they must be applied under relatively mild conditions. Natural enzymes feature high substrate-specificity and efficiency. However, they are limited by some inherent drawbacks such as the high-cost of preparation and purification, easy denaturation, the extreme sensitivity of catalytic activity towards environmental changes such as pH or temperature, difficulties in recovery, limited storage, and availability [\[19,20\].](#page-10-0) As a potential alternative, an emerging group of nanomaterials has recently been considered. The choice of enzymemimics based on nanomaterials rather than natural enzymes has well-confirmed the rational decision to detect dopamine and conquer these limitations. The significant properties of nanozymes include a high surface-to-volume ratio, low-cost, simple preparation, tunable activity, high stability, long-term storage, and easy preparation. As evidenced by the mentioned advantages, nanozymes have been exploited to further evaluate their analytical performance in bio-nanotechnology [\[21–23\].](#page-10-0)

Yan and colleagues were the first to point out Fe3O4 NPs as an enzyme-mimic for TMB substrate [\[24\].](#page-10-0) In recent years, ferritebased enzyme-like nanomaterials have generated tremendous attention [\[25–27\],](#page-10-0) because of their potential for various applications such as gas sensors [\[28\],](#page-10-0) catalyst for ammonia oxidation [\[29\],](#page-10-0) photocatalysts for hydrophobic and organic pollutants degradation [\[26,30\],](#page-10-0) removal of heavy metal ions [\[31\],](#page-10-0) memory devices [\[32\],](#page-10-0) data storage [\[33\],](#page-10-0) and spintronic devices [\[34\].](#page-10-0) Lu and colleagues successfully synthesized and applied CuFe2O4/Cu9S8/polypyrrole (PPy) ternary nanotubes as a suitable colorimetric platform for easy detection of dopamine and H2O2 molecules [\[35\]](#page-10-0). Chen et al. reported that Fe/NC-800 exhibited an enhanced catalytic activity for dopamine sensing [\[36\].](#page-10-0) Liu and co-workers reported that ZnO/ZnFe2O4/graphene foam (ZZFO/GF) is an excellent colorimetric-catalyst to distinguish hydroquinone (HQ) molecules with the assistance of H2O2 molecule [\[37\].](#page-10-0) Su and co-workers demonstrated the use of the spinel ZnFe2O4 NP-decorated ZnO nanofiber as an effective colorimetric platform with a peroxidase-like activity for glucose detection in urine samples [\[38\]](#page-10-0). Hou et al. fabricated Fe3O4@C@MnO2 composite as a tripleenzyme mimetic to catalyze TMB oxidation reaction and was successfully applied for dopamine detection [39].

In this investigation, we report, for the first time, the application of irregular sheet-like Bi2Fe4O9 nanoparticles as one of the Febased nanozymes for the colorimetric detection of nanomolar concentration of dopamine in aqueous media. Fe active sites (Fe2+/ Fe3+) and the d-orbitals of Fe3+ in Bi2Fe4O9 NPs operate in a Fenton-like reaction to improve the catalytic oxidization of 3,30 ,5,50 -tetramethylbenzidine (TMB), a chromogenic substrate, in presence of H2O2 in acetic acid medium (pH = 3.5) to yield a deep-blue product (oxTMB). The simultaneous existence of large irregular-sheets and Fe, as a transition-metal ion, located at FeO6 (octahedral) and FeO4 (tetrahedral) in the unit cell of Bi2Fe4O9 nanozyme, were useful factors to reduce H2O2 to OH radical and increase the oxidation of TMB molecules. In presence of dopamine (DA), as efficient OH radical scavenger, the colorimetric signal of the Bi2Fe4O9/H2O2/TMB/DA was significantly lower than that of Bi2Fe4O9/H2O2/TMB system, and the deep-blue color of the oxTMB was changed to fade-blue color. On the basis of this quenching behavior, the catalytic activity of Bi2Fe4O9 nanozyme was exploited to design a selective and sensitive colorimetric sensor for dopamine concentration determination in fetal bovine serum (FBS) and horse serum (HS) samples. The results of the study showed that Bi2Fe4O9 NPs could be developed as a promising group of nanozyme materials for dopamine diagnostic purposes and biomedical applications.

#### 2. Experimental

# 2.1. Synthesis of Bi2Fe4O9 nanoparticles

As shown in Scheme S1, Bi2Fe4O9 NPs were prepared using the hydrothermal method, according to a previous procedure with a slight modification [\[27\]](#page-10-0). First, Bi(NO3)35H2O (4.85 g) and Fe (NO3)39H2O (4.04 g) powders were dissolved in 13 mL of deionized water (DIW) and 2 mL of nitric acid (HNO3 65%) at room temperature (RT) to form solution A. Throughout the process, the above solution was kept under vigorous magnetic stirring for 30 min. Then, 75 mL of potassium hydroxide (KOH, 8 M) as a mineralizer was slowly dropped into solution A to adjust the pH to 8–9 with rapid stirring. It is worth noticing that a red-brown suspension of a bismuth-ferrite was formed at room temperature. In hydrothermal processing, the uniform suspension was transferred into a Teflon-lined autoclave and heated at 200 C for 24 h. Then, the autoclave was cooled to room temperature and the formed precipitate was collected by centrifugation at 5,000 rpm for 5 min and washed at least three times with deionized water and ethanol (95%) to remove residual ions. Furthermore, the produced Bi2Fe4O9 powder was dried in an oven at 60 C overnight for later use. Ultimately, the produced Bi2Fe4O9 NPs were yellow-orange color at room temperature.

### 2.2. Peroxidase-like activity of Bi2Fe4O9 nanoparticles

In a typical assay, different concentrations of Bi2Fe4O9 (0–30 mg/ mL) were added to 225 mL of TMB (0.3 mM dissolved in ethanol), 225 mL of H2O2 (5 mM) in acetate buffer (pH 3.5, 0.1 M) and the final volume of solution was adjusted to 1.5 mL. The mixture was incubated for 25 min at 45 C. All chemical reagents were exactly prepared before every experiment. UV–vis spectrometry (500 to 800 nm) was used to investigate the absorbance variation at 654 nm due to oxidation of TMB substrate.

### 2.3. Steady-state kinetics for the determination Km and Vmax

The catalytic efficiency and the rate of enzyme reactions of Bi2- Fe4O9 NPs can be determined by the Michaelis–Menten equation. To assess the kinetics parameters, the utilization of different substrate concentrations (TMB or H2O2) is an essential factor. Under the optimized conditions, kinetic experiments were determined by adding various concentrations of TMB chromogenic substrate (0.01–0.3 mM) at a fixed concentration of H2O2 (5 mM) in the first set of experiments. For the second set of kinetic experiments, the H2O2 concentration was varied from 0.1 to 5.0 mM while the concentration of TMB substrate was kept constant (0.3 mM). All experiments were carried out in the acetic acidic buffer (pH 3.5, 0.1 M) and the total volume of the mixture solutions was equal to 1.5 mL. UV–vis absorbance was recorded within the 500–800 nm range and the obtained Vmax and Km values were compared with the kinetic parameters of other nanozymes.

### 2.4. Colorimetric assay for the detection of dopamine

To accurately investigate the efficacy of Bi2Fe4O9 NPs (120 lL, 8 mg/mL) to detect dopamine, first, a solution of a fixed concentration of TMB (225 lL, 0.3 mM) and H2O2 (525 lL, 5 mM) in acetate buffer solution (pH = 3.5, 0.1 M) was prepared. Afterward, various dopamine concentrations (0–150 lM) were added to the above solution; the total volume was 1.5 mL. The entire reaction mixture was quickly shacked then incubated at 45 C for 25 min. The course of the reaction was monitored using UV–vis spectrophotometry (500–800 nm). At the end of incubation, UV–vis absorbance values were recorded at 654 nm and the obtained maximum absorbance was used to generate the calibration curve and also to determine the limit of detection of dopamine.

# 2.5. Selectivity and reproducibility of Bi2Fe4O9 nanoparticles

To evaluate the selectivity of the designed colorimetric assay, various amino acids and small molecules such as alanine (Ala), cysteine (Cys), arginine (Arg), lysine (Lys), glutathione (GSH), uric acid (UA), ascorbic acid (AA), lactose (Lac), glucose (Glu), fructose (Fru), and different ions (K+ , Na+ , Mg2+, and Ca2+) were separately added to the mixture solution of TMB (0.3 mM), H2O2 (5 mM), and Bi2Fe4- O9 NPs (8 mg/mL) in acetate buffer (pH 3.5, 0.1 M). The concentration of applied interfering components was two times the concentration of dopamine (100 mM). All the above solutions were incubated for 25 min at 45 C, and their UV–vis spectra were measured in the 500–800 nm range. The characteristic reproducibility of the synthesized Bi2Fe4O9 nanozyme was examined for four catalytic cycles of TMB oxidation under the optimized experimental conditions (Bi2Fe4O9 (8 mg/mL), TMB (0.3 mM), H2O2 (5 mM), acetate buffer (pH 3.5, 0.1 M), T = 45 C, and incubation time = 25 min).

#### 2.6. Procedure for dopamine detection in real samples

For dopamine analysis in real samples, 1 mL of pure fetal bovine serum (FBS) and horse serum (HS) samples were diluted in phosphate buffer saline (PBS, pH 7.4) and then Bi2Fe4O9 nanozyme (8 mg/mL), H2O2 (5 mM), and TMB (0.3 mM) were added. The total volume of the solution was maintained at 1.5 mL using acetate buffer (pH 3.5, 0.1 M). Afterward, different concentrations of dopamine (1, 5, and 10 mM) were introduced into the above mixture solution and incubated for 25 min at 45 C. To detect the presence of dopamine in the FBS 1 (Sigma-Aldrich), FBS 2 (Fisher Scientific), and HS (Fisher Scientific) samples, the corresponding changes in the absorbance spectra were monitored by UV–vis spectroscopy (500–800 nm). All experiments were performed in triplicates.

#### 2.7. Detection of hydroxyl radicals ( OH) generation in the presence of Bi2Fe4O9

In a typical assay, 0.2 mM of terephthalic acid (TA) was dissolved in ethanol. Eight mixtures were prepared as following: (a) H2O2 (5 mM) + Bi2Fe4O9 NPs (8 mg/mL), (b) H2O2 (5 mM) + Bi2Fe4O9 NPs (8 mg/mL) + dopamine (50 mM), (c) Bi2Fe4O9 NPs (8 mg/mL), (d) Bi2Fe4O9 NPs (8 mg/mL) + dopamine (50 mM), (e) H2O2 (5 mM), (f) H2O2 (5 mM) + dopamine (50 mM), (g) only TA (15 mL), and (h) TA (15 mL) + dopamine (50 mM) in acetate buffer (pH 3.5), and all solutions were incubated for 25 min at 45 C. The total volume of eight tubes was filled to 1.5 mL. The change of fluorescence emission spectra (kex = 315 nm) was recorded in the 400– 550 nm range by utilizing a Safas Xenius XC fluorescence spectrophotometer.

Moreover, to examine the presence of OH radicals as one of the members of reactive oxygen species (ROS), tert-butyl alcohol (TBA) was used as a quencher. Bi2Fe4O9 NPs (8 mg/mL), TMB (0.3 mM), H2O2 (5 mM), acetate buffer (pH 3.5, 0.1 M), TBA (0.5 mM) were incubated at 45 C for 25 min (total volume of the solution was 1.5 mL). All absorption spectra of the solutions with or without TBA molecules were recorded at 564 nm.

#### 3. Results and discussion

### 3.1. Characterization of Bi2Fe4O9 nanoparticles

As observed in [Fig. 1](#page-3-0), the morphological and chemical composition of the as-prepared Bi2Fe4O9 nanozyme were characterized by field emission scanning electron microscopy (FESEM) imaging and energy-dispersive X-ray (EDX) spectroscopy. The low and high magnification FESEM micrographs showed that Bi2Fe4O9 consist of an irregularly sheet-like morphology [(Fig. 1](#page-3-0)A-C).

The accumulation of initial bismuth and ferrite salts causes the random collision of Bi-Fe-O elements, which leads to an increase of the irregular sheet growth. The irregular particle shapes of Bi2Fe4- O9 were formed by considering the different growth rates in various directions. Taken together, the results of elemental distribution mapping and EDX analysis [(Fig. 1](#page-3-0)D) clearly illustrate the presence of Bi, Fe, and O elements, which is in full agreement with the chemical composition of Bi2Fe4O9 NPs. The atomic percentages of Bi, Fe, and O elements in the Bi2Fe4O9 sample were equal to 15.77%, 21.15%, and 63.08%, respectively. It can be noticed that there is a deviation from the stoichiometric composition due to iron deficiency. As revealed in [Fig. 1](#page-3-0)E-G, the elemental mapping of Bi (green), Fe (white), and O (red) has intelligibly confirmed the

<DESCRIPTION_FROM_IMAGE>This image is a composite of several microscopy and analytical results, labeled A through I. I'll describe each component in detail:

A, B, C: These are scanning electron microscopy (SEM) images of a material at different magnifications. 
A: Scale bar 2 μm, showing aggregated particles with irregular shapes.
B: Scale bar 1.0 μm, revealing a more detailed view of the layered, flake-like structures.
C: Scale bar 100 nm, providing the highest magnification view of the particle morphology.

D: Energy-dispersive X-ray spectroscopy (EDX) spectrum and elemental analysis.
- Spectrum shows peaks for O, Fe, and Bi.
- Table of elemental composition:
  O K: 18.40 Weight%, 63.08 Atomic%
  Fe L: 21.54 Weight%, 21.15 Atomic%
  Bi M: 60.07 Weight%, 15.77 Atomic%

E, F, G: Elemental mapping images
E: Bi distribution
F: Fe distribution
G: O distribution
These maps show the spatial distribution of each element in the sample.

H: Particle size distribution histogram
- X-axis: Size (d, nm), ranging from 0 to 1500 nm
- Y-axis: Intensity (%), ranging from 0 to 20%
- The distribution appears to be centered around 400-500 nm, with the highest intensity around 18-20%.

I: Zeta potential measurement graph
- X-axis: Zeta Potential (mV), ranging from -100 to 100 mV
- Y-axis: Total counts, ranging from 0 to 250000
- The graph shows a sharp peak centered slightly below 0 mV, indicating a negative zeta potential for the particles.

This comprehensive analysis suggests the material is a composite of bismuth, iron, and oxygen, likely a bismuth ferrite nanostructure. The particles have irregular, flake-like morphology with sizes primarily in the 400-500 nm range and a slightly negative surface charge in solution.</DESCRIPTION_FROM_IMAGE>

Fig. 1. FESEM images at low and high magnifications (A-C), EDX spectrum (D), elemental mappings for Bi (E), Fe (F), and O (G), DLS size distribution (H), and zeta potential (I) of the as-prepared Bi2Fe4O9 NPs.

uniform distribution of mentioned elements on the surface of Bi2- Fe4O9 enzyme-mimicking nanomaterial [\[27,31\].](#page-10-0)

The hydrodynamic diameter and surface charge of the synthesized Bi2Fe4O9 NPs were measured by utilizing the dynamic light scattering (DLS) and zeta potential techniques, respectively (Fig. 1H and I). The average hydrodynamic diameter (dhydr) of Bi2- Fe4O9 NPs was 396 nm (3 measurements). In addition, the average surface charge of Bi2Fe4O9 was found to be 31.62 mV. Based on these results, Bi2Fe4O9 NPs with a negative surface charge are expected to interact electrostatically with the positively charged chromogenic substrate (TMB) and efficiently catalyze the oxidation of TMB. The positive surface charge of TMB was brought by the presence of two amine groups [\[40–42\].](#page-10-0)

Fig. S1 depicts the FTIR spectrum of the Bi2Fe4O9 NPs (700– 4000 cm1 ), which indicates the presence of diverse functional groups on the surface of the NPs. The spectrum comprises broad and weak absorption bands at 3441 and 1636 cm1 related to hydroxyl groups stretching and bending vibrations from water molecules or intermolecular hydrogen bonds, respectively. The strong absorption peak at 1384 cm1 belongs to the residual NO3 – group incorporated during the preparation of Bi2Fe4O9 sample. Besides, bismuth ferrite is an isostructural compound and contains tetrahedral FeO4, octahedral FeO6, and octahedral BiO6 units. The vibration band at 808 cm1 is assigned to Fe-O stretching vibrations of FeO4 and FeO6, and also Bi-O in the BiO6 octahedral pairs [\[31,43,44\]](#page-10-0).

The results of the thermogravimetric analysis (TGA) and derivative thermogravimetric (DTG) of Bi2Fe4O9 NPs in the 30–980 C temperature range are shown in Fig. S2. TGA analysis of Bi2Fe4O9 NPs demonstrates four clear steps of weight loss: (I) 50 C, (II) 150 C, (III) 220 C, (IV) 657 C corresponding to the mass reduction of 0.79%, 0.79%, 0.47% and 5.49%, respectively. The first step belongs to water and residual organic solvent evaporation, and the second step of the significant mass loss was probably due to the decomposition of the ternary metal oxide structure of BFO [\[45\]](#page-10-0). By increasing the temperature (978.5 C), the TGA curve of Bi2Fe4O9 features an approximate loss of 8.2% of its total mass and 91.8% of the residual mass was left at the end of heating.

X-ray photoelectron spectrometry (XPS) was utilized to examine the elemental composition and the oxidation states of the asprepared Bi2Fe4O9 NPs ([Fig. 2](#page-4-0)A-D). The XPS survey spectrum of Bi2- Fe4O9 NPs revealed the presence of Bi 4f, Bi 4d, Bi 4p, C 1s, Fe 2p, and O 1s peaks [(Fig. 2](#page-4-0)A). In the survey spectrum of Bi2Fe4O9 NPs [(Fig. 2](#page-4-0)A), the narrow peak of C 1s observed at 285 eV is most likely

<DESCRIPTION_FROM_IMAGE>This image contains four X-ray photoelectron spectroscopy (XPS) spectra labeled A, B, C, and D. Each spectrum shows the intensity of photoelectrons as a function of binding energy.

A. Survey spectrum:
This spectrum covers a binding energy range from approximately 100 to 800 eV. It shows several peaks corresponding to different elements:
- Bi 4f7/2 and Bi 4f5/2: Two intense peaks at lower binding energies
- C 1s: A small peak around 285 eV
- O 1s: A prominent peak around 530 eV
- Bi 4d: Two peaks in the 440-460 eV range
- Bi 4p3/2: A broad peak around 600 eV
- Fe 2p: Two peaks at higher binding energies (700-725 eV)

B. O 1s spectrum:
This high-resolution spectrum focuses on the oxygen 1s region (528-536 eV). It shows a deconvolution of the O 1s peak into four components:
- O1: The most intense peak at the lowest binding energy
- O2, O3, and O4: Three less intense peaks at progressively higher binding energies

C. Fe 2p spectrum:
This spectrum shows the iron 2p region (705-740 eV). It is deconvoluted into several components:
- Fe 2p3/2 and Fe 2p1/2: Two main peaks
- Fe2+ and Fe3+: Peaks indicating different oxidation states of iron
- Sat. I and Sat. II: Two satellite peaks at higher binding energies

D. Bi 4f spectrum:
This spectrum focuses on the bismuth 4f region (156-168 eV). It shows:
- Bi 4f7/2 and Bi 4f5/2: Two intense peaks with the 4f7/2 peak at a lower binding energy

These spectra provide information about the elemental composition and chemical states of a sample containing bismuth, iron, oxygen, and carbon. The presence of multiple oxidation states for iron and the detailed analysis of the oxygen spectrum suggest a complex oxide material, possibly a bismuth iron oxide compound.</DESCRIPTION_FROM_IMAGE>

Fig. 2. (A) XPS survey spectrum, and high-resolution XPS spectra of (B) O 1s, (C) Fe 2p, and (D) Bi 4f regions of Bi2Fe4O9 NPs.

due to surface contamination. On the basis of the XPS results, the atomic percentages of Bi, Fe, and O elements in Bi2Fe4O9 NPs were 13.72, 17.62, and 68.66 at.%, respectively. The results reflect Fe deficiency, in accordance with EDX analysis, even though there was no evidence for the existence of another crystalline phase (see XRD analysis below).

The O 1s wide scan spectrum (Fig. 2B) can be fitted with four Gaussian curves at around 528.8 eV (O1), 530.3 eV (O2), 531.4 eV (O3), and 532.9 eV (O4), which are respectively ascribed to lattice MOM bonds, surface lattice oxygen, the presence of oxygen vacancies, and absorbed H2O or surface carbonate [\[27,46,47\].](#page-10-0) As shown in Fig. 2C, the wide scan of Fe 2p XPS profile can be fitted with two components at binding energies of 710.1 and 723.6 eV, that are respectively assigned to Fe 2p3/2 and Fe 2p1/2. These binding energies data confirmed the occurrence of two oxidation states (+2 and +3) in the BFO oxide. The high-resolution spectrum of Fe 2p3/2 can be deconvoluted into two Gaussian peaks at 711.4 and 725.4 eV which belong to the Fe3+ valence state in the Bi2Fe4O9. The two peaks at 709.4 and 723.1 eV can be attributed to Fe 2p1/2 that correlate with the existence of Fe2+ ions in Fe-O bands. Furthermore, the two satellite peaks located at 717.9 eV (Sat. I) and 732.2 eV (Sat. II) both belong to Fe3+ species in the Bi2Fe4O9 NPs [\[27,47–49\].](#page-10-0) The Bi 4f XPS plot (Fig. 2D) can be deconvoluted into two distinct peaks ascribed to Bi 4f7/2 peak at 158.2 eV and Bi 4f5/2 peak at 164.1 eV. The spin–orbit splitting of Bi 4f (5.90 eV) corresponds to bismuth ion in the +3-valence state in the synthesized Bi2Fe4O9 NPs [\[26,27,50\].](#page-10-0)

The phase purity and crystallinity of the as-prepared Bi2Fe4O9 NPs were analyzed by X-ray diffraction (XRD) patterns (Fig. S3). The characteristic diffraction peaks located at 2h angles of 14.78, 20.88, 22.40, 23.88, 24.90, 25.72, 26.88, 28.06, 28.94, 29.72, 30.80, 33.58, 35.52, 36.62, 37.54, 39.20, 44.18, 45.40, 46.82, 48.82, 49.50, 50.68, 52.04, 54.36, 55.30, 56.54, 58.8, 61.56, 64.68, and 67.22 can be perfectly indexed to the orthorhombic Bi2Fe4O9 structure with (001), (0 2 0), (2 00), (12 0), (21 0), (021), (2 01), (121), (211), (0 02), (22 0), (13 0), (31 0), (022), (20 2), (212), (140), (132), (141), (24 0), (411), (42 0), (123), (142), (40 2), (332), (431), (00 4), (342), and (53 0) planes, respectively ((JCPDS File No. 00–025-0090). The crystalline planes with d-spacing values related to the above crystal planes of Bi2Fe4O9 sample were determined to be 5.99, 4.25, 3.97, 3.72, 3.57, 3.46, 3.32, 3.18, 3.09, 3.00, 2.90, 2.67, 2.52, 2.45, 2.39, 2.30, 2.05, 2.00, 1.93, 1.86, 1.83, 1.80, 1.75, 1.68, 1.65, 1.63, 1.57, 1.51, 1.44, and 1.39 Å, respectively. The sharp diffraction peaks in the XRD pattern obviously indicate that Bi2Fe4O9 has a well-crystallized structure without the existence of other impurities [\[44,51–53\]](#page-10-0)

### 3.2. Peroxidase-like activity of Bi2Fe4O9 nanoparticles

In this catalytic process, the enzyme-mimetic activity of Bi2Fe4- O9 NPs was examined for the oxidation of TMB, as electron-donor species, to oxTMB in the presence of H2O2 as electron-acceptor species. The decomposition of H2O2 molecules was catalyzed by Fe species on the surface of Bi2Fe4O9 nanozyme. Ferrite ions in Bi2- Fe4O9 nanozyme are located at FeO6 octahedral and FeO4 tetrahedral in the unit cell. Fe is a useful transition metal ion in Fenton reactions to reduce H2O2 to OH radicals. Different oxidation forms of Fe cations like Fe3+/Fe2+ and the d-orbitals of Fe3+ were consecutively produced and used in the suggested Fenton-reaction cycle. Besides the Fe active-sites, the large irregular sheet area of Bi2Fe4- O9 created more reactive sites and enhanced the peroxidase-like activity of Bi2Fe4O9 nanozyme. To mimic the Fenton-like reaction, Fe ions and the produced OH radicals played a key role in oxidizing TMB molecules to the blue-coloured form of TMB semiquinone dimer [\[43,44,47,54–58\].](#page-10-0)

TMB oxidation in presence of Bi2Fe4O9 nanozyme is believed to occur through a Fenton-like reaction, as summarized in Eq. 1–4 (Scheme 1). In a weakly acidic medium, Bi2Fe4O9 nanozyme successfully decomposes H2O2 molecules to hydroxyl radical ( OH), as an effective intermediate molecule (Eq. 3) to carry out the oxidation of TMB molecules in H2O2/TMB/Bi2Fe4O9 system (Eq. 4) at room temperature. The oxidized TMB substrate can be visualized by monitoring the maximum absorbance peak at 654 nm.

Under the reaction conditions, the meaningful effect of the absence and presence of Bi2Fe4O9 nanozyme catalyst and H2O2 molecule on the catalytic oxidation of TMB substrate was investigated and the variation of UV–vis spectra are displayed in [Fig. 3](#page-5-0)( i-iii). Insert in [Fig. 3](#page-5-0) indicated the recorded photographs of the oxTMB color-change system. The experimental systems consisting of only H2O2 or Bi2Fe4O9 had no obvious effect on the oxidation reaction of TMB and the absorbance signal of the solutions was close to the background [(Fig. 3](#page-5-0)i). Meanwhile, the addition of Bi2- Fe4O9 to TMB only slightly increased the TMB oxidation [(Fig. 3](#page-5-0)ii). After the introduction of both Bi2Fe4O9 and H2O2 solutions into the fresh TMB reagent, the peroxidase-like activity Bi2Fe4O9 improved and considerably decomposed H2O2 molecules to OH as active intermediates for oxidation of TMB [(Fig. 3](#page-5-0)iii). In an acidic medium (pH 3.5), the occurrence of the oxidation reaction was

<DESCRIPTION_FROM_IMAGE>The image depicts a series of chemical reactions and structures related to the oxidation of TMB (3,3',5,5'-tetramethylbenzidine). Here's a detailed description:

1. Three Fenton-like reactions are shown:
   1) Fe³⁺ + H₂O₂ → Fe²⁺ + HO₂• + H⁺
   2) HO₂• + H₂O₂ → HO• + O₂ + H₂O
   3) Fe²⁺ + H₂O₂ → Fe³⁺ + HO• + OH⁻

2. The fourth reaction shows the oxidation of TMB:
   4) TMB (Colorless) → oxTMB (Blue)
   This reaction occurs at pH 3.5 and is catalyzed by HO• (hydroxyl radical) produced in the previous reactions.

3. Chemical structures:
   - TMB (Colorless):
     SMILES: Nc1cc(C)c(-c2cc(C)c(N)cc2C)cc1C
   
   - oxTMB (Blue):
     SMILES: [NH3+]c1cc(C)c(-c2cc(C)c([NH3+])cc2C)cc1C

The image illustrates the transition from colorless TMB to blue oxTMB, emphasizing the role of hydroxyl radicals (HO•) in this oxidation process. The Fenton-like reactions (1-3) demonstrate the generation of these reactive oxygen species, which then participate in the oxidation of TMB (reaction 4).</DESCRIPTION_FROM_IMAGE>

Scheme 1. Schematic illustration of the plausible mechanism of TMB oxidation by H2O2 in the presence of Bi2Fe4O9 NPs.

<DESCRIPTION_FROM_IMAGE>This image presents a bar graph and accompanying vial images illustrating the absorbance measurements at 654 nm for different chemical reactions involving hydrogen peroxide (H2O2), 3,3',5,5'-tetramethylbenzidine (TMB), and bismuth iron oxide nanoparticles (Bi2Fe4O9 NPs).

The graph shows three distinct conditions:

i. H2O2 + TMB: This condition shows the lowest absorbance, with a value of approximately 0.13.

ii. Bi2Fe4O9 NPs + TMB: This condition shows a slightly higher absorbance than the first, with a value of about 0.19.

iii. Bi2Fe4O9 NPs + H2O2 + TMB: This condition demonstrates the highest absorbance, with a value of approximately 1.62.

Each bar in the graph has error bars, indicating the standard deviation of the measurements.

Above the graph, three vial images are shown, presumably corresponding to the three conditions in the same order. The vials display a gradual increase in color intensity from left to right, correlating with the increasing absorbance values in the graph.

The x-axis labels the different reaction conditions, while the y-axis shows the absorbance values at 654 nm, ranging from 0 to 1.8.

This experiment likely demonstrates the catalytic activity of Bi2Fe4O9 NPs in the presence of H2O2, using TMB as a chromogenic substrate. The significant increase in absorbance for condition iii suggests a synergistic effect between the nanoparticles and hydrogen peroxide in oxidizing TMB, resulting in a more intense color change.</DESCRIPTION_FROM_IMAGE>

Fig. 3. Relative UV–vis absorption spectra changes of different solutions containing acetate buffer (pH 3.5, 0.1 M) and reaction components recorded after 25 min incubation at T = 45 C. Typical photographs of the oxidized TMB (oxTMB) [from left to right: (i) H2O2 + TMB without Bi2Fe4O9 NPs (colorless), (ii) TMB + Bi2Fe4O9 without H2O2 (slightly blue), and (iii) TMB + H2O2 + Bi2Fe4O9 NPs (blue)]. Reaction condition: Bi2Fe4O9 NPs (8 mg/mL), TMB (0.3 mM), H2O2 (5 mM), T = 45 C (For each solution, n = 3).

confirmed by the naked eyes through the color change from the colorless mixtures of H2O2/TMB and Bi2Fe4O9/TMB to the deepblue color of H2O2/TMB/Bi2Fe4O9, and also the produced ox-TMB recorded a remarkable absorbance at around 654 nm (Fig. 3). All of the results demonstrated that the presence of both Bi2Fe4O9, as intrinsic peroxidase-like activity catalyst, and H2O2, as inherent oxidant, was responsible for the remarkable increase of the oxidation rate of TMB substrate.

#### 3.3. Experimental condition optimization

In order to have a better insight into the reaction performance, the enzyme-like catalytic reaction was performed under different experimental conditions by varying TMB, H2O2, and Bi2Fe4O9 concentrations, pH, temperature, and the incubation time of the reaction [\[24,59\]](#page-10-0). The effects of the different concentrations of Bi2Fe4O9 NPs (1–30 mg/mL), TMB (0–0.7 mM), and H2O2 (0–8 mM), pH (pH = 1–12), incubation time (5–50 min), and temperature (15– 60 C) was investigated and clearly depicted in (Fig. S4A-F). Optimizing the concentrations of Bi2Fe4O9, TMB, and H2O2 molecules were manifested by the maximum value of absorbance at 654 nm. As depicted in (Fig. S4A-C), the optimum absorbance was recorded using 8 mg/mL, 0.3 mM, and 5 mM of Bi2Fe4O9, TMB, and H2O2 respectively. In this study, the optimum concentrations were utilized to carry out the following experiments. The result in (Fig. S4D) demonstrated that pH values higher than 3.5 may cause the decomposition of H2O2 substrate into H2O and O2 molecules. Consequently, the rate of the formation of OH radicals was decreased, and the distinct blue color-change was obtained only in an acidic condition. Therefore, the pH value of 3.5 was selected as the optimum pH that illustrated the blue-dark color solution with the highest absorbance at 654 nm. Another effective factor was the reaction temperature. In each case, the influence of the temperature on the peroxidase activity of mimic-catalyst was investigated in a slightly acidic buffer (pH 3.5, 0.1 M). The catalytic activity of the Bi2Fe4O9 sharply increased when the temperature was raised from 10 to 45 C, and then decreased at temperatures higher than 45 C. Therefore, the subsequent experiments were performed at the optimal temperature of 45 C (Fig. S4E). Moreover, incubation time plays an important role in the decomposition of H2O2 and the accomplishment of the oxidation reaction for which the selected optimal-time corresponds to 25 min (Fig. S4F). As expected, the mimic-catalytic activity of Bi2Fe4O9 depends on the concentration, pH, temperature, and reactiontime, similar to other nanozymes reported in the literature. According to the optimized values, it can be expected that Bi2Fe4- O9 nanozyme as a metal oxide-type mimic catalyst can be applied for sensitive and accurate detection of dopamine.

## 3.4. Kinetic study of Bi2Fe4O9 NPs and the determination of Michaelis-Menten constants

To explore the steady-state kinetic of Bi2Fe4O9 as a peroxidase mimic nanozyme, various concentrations of H2O2 and TMB as two different substrates were used to determine the initial rate of H2O2 and TMB in acetate buffer (pH 3.5, 0.1 M) at 45 C. In order to accurately calculate the initial velocity rate, the Beer-Lambert Law was applied (Eq. (5)).

$$\mathcal{V} = \frac{\Delta \mathcal{C}}{\Delta \mathbf{t}} = \frac{\frac{\Delta \mathcal{C}}{\Delta \mathcal{C}}}{\Delta \mathbf{t}} \tag{5}$$

where A, b, e, t and V represent respectively the absorbance at 654 nm, the optical path length (1 cm), the molar absorptivity coefficient of oxTMB (39000 M1 .cm1 ), the time (min), and the reaction rate. In the time span of 0–30 min, Fig S5 (A, B) depicts the relationship between the recorded UV–vis absorption spectra at 654 nm with the constant concentration of one substrate (TMB or H2O2) and varying the concentration of the other substrate in the reaction mixture. UV–vis absorption was dramatically increased and then reached a steady-state level for both TMB (under the constant concentration of H2O2) and H2O2 (under the constant concentration of TMB) substrates. And at this investigation time, the Michaelis-Menten kinetic model fitted well the variation of the absorption process.

To determine the kinetic parameters, the Michaelis-Menten model is one of the earliest descriptions and the best-known models to comprehensively investigate the value of nanozyme kinetics activity. Michaelis-Menten kinetics of Bi2Fe4O9 peroxidase-mimic catalyst was determined by keeping constant the concentration of TMB or H2O2 as a targeted substrate and varying the concentration of the other molecule in a time-scan mode, simultaneously. Kinetic parameters (Km and Vmax) were calculated using the Lineweaver–Burk plots of the double reciprocal of the Michaelis-Menten Eq. (6):

$$\frac{1}{\mathcal{V}} = \frac{1}{[\mathcal{S}]} \times \frac{\mathsf{K}_{\mathsf{m}}}{\mathsf{V}_{\max}} + \frac{1}{\mathsf{V}_{\max}} \tag{6}$$

where [S], m, Vmax, and Km refer to the substrate concentration, the initial reaction rate, the maximum reaction rate, and Michaelis-Menten constant, respectively [\[6,22,60\]](#page-9-0). The steady-state kinetic measurements were conducted for both TMB and H2O2 as enzyme substrates [(Fig. 4](#page-6-0)A-B). Under the optimized conditions, the Michaelis-Menten curves were generated for TMB at different concentrations of TMB (0.01–0.3 mM) and a fixed concentration of H2O2 (5 mM), [Fig. 4](#page-6-0)A, and also for H2O2 at various concentrations of H2O2 (0.1–5 mM) and a constant concentration of TMB (0.3 mM), [Fig. 4](#page-6-0)B. According to the obtained results, the Michaelis-Menten constant (Km) and maximum reaction rate (Vmax) for H2O2/TMB/Bi2Fe4O9 system were calculated and drawn via fitting the data into the Lineweaver Burk double reciprocal plots [(Fig. 4](#page-6-0)A and B insets).

[Table 1](#page-6-0) summarizes the obtained enzyme kinetic parameters (Km and Vmax) in comparison to the horseradish peroxidase (HRP) enzyme and other nanomaterials reported in the literature. For

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled A and B, each showing enzyme kinetics data.

Graph A:
Main plot: Shows the relationship between the reaction velocity (V) and the concentration of TMB ([TMB]). The x-axis represents [TMB] in mM, ranging from 0 to 0.3 mM. The y-axis represents V in 10^-8 M.s^-1, ranging from -0.2 to 1.8. The data points follow a typical Michaelis-Menten kinetics curve, with the reaction rate increasing rapidly at low substrate concentrations and then leveling off at higher concentrations.

Inset plot: Shows the Lineweaver-Burk plot (double reciprocal plot) of the same data. The x-axis represents [TMB]^-1 in mM^-1, ranging from 0 to 35 mM^-1. The y-axis represents V^-1 in (10^8 M^-1.s), ranging from 0.2 to 2.0. The linear regression equation is y = 0.0332x + 0.4756, with an R^2 value of 0.972.

Graph B:
Main plot: Shows the relationship between the reaction velocity (V) and the concentration of H2O2 ([H2O2]). The x-axis represents [H2O2] in mM, ranging from 0 to 5 mM. The y-axis represents V in 10^-8 M.s^-1, ranging from 0 to 1.4. The data points follow a similar Michaelis-Menten kinetics curve as in Graph A.

Inset plot: Shows the Lineweaver-Burk plot of the H2O2 data. The x-axis represents [H2O2]^-1 in mM^-1, ranging from 0 to 10 mM^-1. The y-axis represents V^-1 in (10^8 M^-1.s), ranging from 0 to 7. The linear regression equation is y = 0.4522x + 0.6755, with an R^2 value of 0.968.

Both graphs include error bars on the data points, indicating experimental uncertainty. The main plots demonstrate the saturation kinetics typical of enzyme-catalyzed reactions, while the inset plots provide linearized representations used for determining kinetic parameters such as Km and Vmax.</DESCRIPTION_FROM_IMAGE>

Fig. 4. Steady-state kinetic experiments of Bi2Fe4O9 NPs at (A) different concentrations of TMB (0.01–0.3 mM) and fixed concentration of H2O2 (5 mM) substrates, and (B) varying concentrations of H2O2 (0.1–5 mM) and constant concentration of TMB (0.3 mM) substrates. Insets: the linear calibration curves for the determination of TMB and H2O2. Reaction conditions: Bi2Fe4O9 NPs (8 mg/mL), acetate buffer (pH 3.5, 0.1 M), T = 45 C, and incubation time = 25 min. UV–vis measurements were repeated three times.

#### Table 1

Comparison of the steady-state kinetic parameters (Michaelis-Menten constant (Km) and maximum velocity (Vm) of H2O2 and TMB substrates with previously reported materials).

| Catalysts               | Substrates | Km (mM) | Vm<br>(10-8 M.s1<br>) | Ref.      |
|-------------------------|------------|---------|-----------------------|-----------|
| HRP                     | H2O2       | 3.70    | 8.71                  | [24]      |
| HRP                     | TMB        | 0.43    | 10.00                 | [24]      |
| CuFe2O4/Cu9S8/PPy       | H2O2       | 23.83   | 9.82                  | [47]      |
| CuFe2O4/Cu9S8/PPy       | TMB        | 0.13    | 6.97                  | [47]      |
| Co3O4 gilly-flower like | H2O2       | 245.00  | 28.50                 | [61]      |
| Co3O4 gilly-flower like | TMB        | 0.12    | 33.20                 | [61]      |
| MoS2/PPy                | H2O2       | 12.80   | 15.10                 | [62]      |
| MoS2/PPy                | TMB        | 0.41    | 47.40                 | [62]      |
| Bi2Fe4O9                | H2O2       | 0.73    | 1.56                  | This work |
| Bi2Fe4O9                | TMB        | 0.07    | 2.17                  | This work |
|                         |            |         |                       |           |

TMB and H2O2 substrates in H2O2/TMB/Bi2Fe4O9 system, the obtained constant Km and Vmax parameters were equal to 0.07 and 0.73 mM, and 2.17 and 1.56 (10-8) M.s1 , respectively. In this context, the Michaelis-Menten constant (Km) is an effective parameter to emphasize the affinity between the Bi2Fe4O9 as an enzymelike catalyst with peroxidase substrate (TMB or H2O2). The lower value of Km of Bi2Fe4O9 in comparison to natural HRP and other nanozyme catalysts refer to its stronger affinity towards both TMB and H2O2 substrates. Besides, the lower Km value of Bi2Fe4O9 NPs for H2O2 means that the higher catalytic response of Bi2Fe4O9 NPs was obtained using a small concentration of H2O2 substrate. This means that the decomposition of H2O2 into OH radical can be accelerated to oxidase TMB molecules. According to the obtained Km and Vmax constants, Bi2Fe4O9 features a good affinity towards TMB and H2O2 for peroxidase-mimic activity.

### 3.5. Colorimetric sensing of dopamine in the presence of Bi2Fe4O9 nanozyme

In order to demonstrate the acceptable enzyme-mimetic property of Bi2Fe4O9 nanozyme, the optimized H2O2/TMB/Bi2Fe4O9 system was applied as an indirect platform to sense dopamine. As displayed in [Fig. 5](#page-7-0)A-B, the presence of dopamine molecule with an effective inhibiting role, prevents the formation oxTMB under optimum conditions. A point of fact during the increase of dopamine concentration is the gradual vanishing of the dark-blue color and the decreased number of oxTMB molecules [(Fig. 5](#page-7-0)C). Therefore, the presence of dopamine effectively prohibited the production of oxTMB molecules. The color changes of TMB solutions were easily observable by naked eyes and the variation of the UV–vis spectra was recorded at 654 nm. This phenomenon clearly indicated the competition between dopamine and TMB molecules to capture OH generated in the catalytic decomposition of H2O2 molecules. The notable decrease of accessible OH radicals may be the result of phenolic ring oxidation in dopamine molecules [\[1,60\].](#page-9-0) Generally, dopamine oxidation was accelerated using Bi2Fe4O9 nanozyme to produce dopamine o-quinone (DOQ). The defined system outlines a simple colorimetric platform for dopamine sensing that is based on the oxidation of dopamine by utilizing H2O2 molecules in presence of Bi2Fe4O9 nanozyme and TMB substrate.

An elevation of dopamine concentration from 0 to 150 mM led to a decrease in absorbance intensity of oxTMB at 654 nm. The color tonality faded from deep-blue to colorless, indicating a decrease in the oxidation rate of TMB oxidation and enhanced formation of dopamine o-quinone molecule [(Fig. 5](#page-7-0)C). A good linear range of added dopamine (from 0.15 to 50 mM) to TMB/H2O2/Bi2Fe4O9 system was obtained by applying the equation A= 0.024 [dopamine (lM)] + 1.663 (R2 = 0.9979). In addition, the limit of detection (LOD) was determined to be 51 nM at S/N = 3, where S and N represent the signal and noise, respectively.

[Table 2](#page-7-0) lists the analytical merits of the developed Bi2Fe4O9 nanozyme sensor compared to different nanoparticles using various approaches such as electrochemistry [\[17,18\],](#page-10-0) electrochemiluminescence [\[16\],](#page-10-0) fluorescence spectroscopy [\[13\],](#page-10-0) and colorimetric assays [\[3,23\].](#page-9-0) The value of the LOD of our colorimetric-method by using Bi2Fe4O9 nanozyme is lower than previously reported ones. The above results indicate that this designed colorimetric sensor as a simple, facile, and reproducible assay has a high sensitivity to detect dopamine molecules.

### 3.6. Selectivity of Bi2Fe4O9 nanozyme-sensor toward dopamine detection

Under the optimized conditions, the selectivity of the proposed Bi2Fe4O9 nanozyme was investigated in the presence of different molecules such as alanine (Ala), cysteine (Cys), arginine (Arg), lysine (Lys), glutathione (GSH), uric acid (UA), ascorbic acid (AA), lactose (Lac), glucose (Glu), fructose (Fru), K+ , Na+ , Mg2+, and Ca2+, with the concentration two times higher (100 mM) than the optimized concentration of dopamine. The reduction of UV–vis absorbance intensity in H2O2/TMB/Bi2Fe4O9/interfering system was compared to control condition [(Fig. 6](#page-7-0)). The excellent inhibition

<DESCRIPTION_FROM_IMAGE>This image contains three panels labeled A, B, and C, each presenting different aspects of a chemical analysis.

Panel A: 
This is a 3D surface plot showing the relationship between absorbance (Abs), wavelength, and concentration. The x-axis represents wavelength (nm) ranging from approximately 500 to 800 nm. The y-axis shows concentration (μM) from 0 to 150 μM. The z-axis displays absorbance (Abs) in arbitrary units (a.u.) from 0 to 2. The surface plot shows a peak in absorbance at around 650-700 nm wavelength, with the highest absorbance occurring at lower concentrations.

Panel B:
This panel shows a 2D plot of absorbance at 654 nm versus DA (presumably dopamine) concentration. The x-axis represents DA concentration (μM) from 0 to 160 μM, while the y-axis shows absorbance from 0 to 1.8. The plot demonstrates a non-linear relationship, with absorbance decreasing as DA concentration increases. The curve appears to follow an exponential decay pattern.

Inset in Panel B:
A smaller graph within Panel B shows a linear relationship between absorbance and DA concentration. The x-axis represents DA concentration (μM) from 0 to 50 μM, and the y-axis shows absorbance from 0 to 1.8. The plot includes a linear regression line with an R² value of 0.9979, indicating a strong linear correlation in this concentration range.

Panel C:
This panel appears to show a schematic or stylized representation of a chemical or biological process. Without more context, it's difficult to interpret the specific meaning of this image. It shows a fan-like or semicircular arrangement of elements transitioning from light to dark shades, with an arrow-like shape in the center pointing upwards.

Overall, this image set appears to be analyzing the spectroscopic properties of dopamine (DA) at various concentrations, demonstrating how its absorbance changes with both wavelength and concentration.</DESCRIPTION_FROM_IMAGE>

Fig. 5. UV–vis absorption spectra (A) and absorbance at 654 nm (B) of TMB solutions in presence of Bi2Fe4O9 nanozyme and various DA concentrations (0– 150 mM). Inset: The linear calibration curve in the lower concentration range of DA (R2 = 0.9979). Photographs of the color-changes during TMB oxidation in presence of different dopamine concentrations (C) (from left to right arrow: increasing the concentration of dopamine). Reaction conditions: Bi2Fe4O9 NPs (8 mg/mL), TMB (0.3 mM), H2O2 (5 mM), acetate buffer (pH 3.5, 0.1 M), T = 45 C, and incubation time = 25 min. The measurements were performed in triplicates.

role of dopamine in comparison to other molecules (at higher concentration) indicates that ox-TMB product could not easily be generated in the dopamine-containing system.

Dopamine is a strong free radical scavenger and has a potent hydrogen-donating activity. As presented in Fig. 6, the excellent inhibition role of dopamine in comparison to the applied interference molecules is obviously reflected from its higher tendency to capture hydroxyl radicals ( OH) in the acidic medium and prohibit the oxidation of TMB molecules. The higher quenching ability of dopamine is related to its specific chemical structure. Dopamine features several H atoms on its aromatic ring responsible for increasing the electron density, mobility, and also the propensity to capture OH radicals. During the reaction with the reactive oxygen species (ROS) like OH radical, dopamine is able to produce

#### Table 2

Comparison of different analytical methods for quantitative analysis of dopamine.

<DESCRIPTION_FROM_IMAGE>This image presents a bar graph showing the absorbance values at 654 nm for various substances or conditions. The y-axis represents the absorbance, ranging from 0 to 1.8, while the x-axis lists different compounds or ions.

The graph includes error bars for each measurement, indicating the precision of the data. The substances tested, from left to right, are:

1. Blank
2. Dopamine
3. Alanine
4. Cysteine
5. Arginine
6. Lysine
7. Glutathione
8. Uric acid
9. Ascorbic acid
10. Lactose
11. Glucose
12. Fructose
13. K+ (Potassium ion)
14. Na+ (Sodium ion)
15. Mg2+ (Magnesium ion)
16. Ca2+ (Calcium ion)

The absorbance values for most substances are between 1.4 and 1.8, with a few exceptions:

1. Dopamine shows a significantly lower absorbance of approximately 0.4.
2. Ascorbic acid has a lower absorbance of about 1.2.

The highest absorbance is observed for glucose, at around 1.7, while the lowest (excluding dopamine) is for ascorbic acid.

This graph likely represents a selectivity or interference study for a spectrophotometric method, possibly related to the detection or quantification of one of these compounds. The similar absorbance values for most substances suggest that the method may not be highly selective, with dopamine and ascorbic acid showing distinct responses.</DESCRIPTION_FROM_IMAGE>

Fig. 6. Absorption at 654 nm of oxTMB in the presence of different interfering molecules at a concentration of 100 mM (2 times higher than the concentration of DA); Reaction conditions: Bi2Fe4O9 NPs (8 mg/mL), H2O2 (5 mM), TMB (0.3 mM), acetate buffer (0.1 M, pH 3.5), T = 45 C, and incubation time = 25 min. The measurements were performed in triplicates.

several derivatives (Scheme S2 B-D). As indicated in Scheme S2, three initial-hydroxylated products of dopamine are generated during the reaction with OH radical, namely 2 hydroxydopamine (2-OHDA), 5-hydroxydopamine (5-OHDA), and 6-hydroxydopamine (6-OHDA). All three ring-monohydroxylated dopamine molecules as reactive species could inhibit the oxidation of TMB molecules to oxTMB [\[1\].](#page-9-0) Another effective factor of dopamine for inhibiting TMB oxidation is associated with the presence of its ethyl-amine group. The amine group in the side chain of the dopamine phenolic ring, as a suitable electron-donor group, helps to accelerate electron transfer to enhance the interaction among H atoms on aromatic rings of dopamine with OH radicals. This result means that dopamine has higher quenching ability of OH radicals compared to ascorbic acid and uric acid [\[5,66\]](#page-9-0). This oxidation process indicated that the designed colorimetric probe owns a good selectivity and could play an important role in the low detection of dopamine in aqueous media.

### 3.7. Reproducibility of Bi2Fe4O9 nanoparticles

To investigate the nanozyme efficiency, a fresh sample of Bi2- Fe4O9 NPs (8 mg/mL), TMB (0.3 mM), and H2O2 (5 mM) in acetate

| Method           | Sensor                  | Linear range (lM) | LOD1 (mM) | Ref.      |
|------------------|-------------------------|-------------------|-----------|-----------|
| Electrochemistry | rGO/TiO2                | 2–60              | 0.60      | [17]      |
| Electrochemistry | CAuNE                   | 1–100             | 5.83      | [18]      |
| ECL2             | CdSeTe/ZnS QDs          | 3.75–450          | 0.10      | [16]      |
| Fluorescence     | BSA-CuNCs               | 0.50–50           | 0.28      | [13]      |
| Colorimetric     | LaCoO3                  | 0.50–20           | 0.19      | [3]       |
| Colorimetric     | Co3O4@NiO               | 1–1000            | 1.21      | [60]      |
| Colorimetric     | CuS/rGO                 | 2–100             | 0.48      | [63]      |
| Colorimetric     | Ag NPs                  | 3.20–20           | 1.20      | [64]      |
| Colorimetric     | CuFe2O4/Cu9S8/PPy h-CuS | 20–2              | 1.00      | [35]      |
| Colorimetric     | NCs                     | 2–150             | 1.67      | [65]      |
| Colorimetric     | NiCo2S4-rGO             | 0.50–100          | 0.42      | [23]      |
| Colorimetric     | Bi2Fe4O                 | 0.15–50           | 0.05      | This work |

1 Limit of detection (LOD)

2 Electrochemiluminescence (ECL)

<span id="page-8-0"></span>buffer (pH 3.5, 0.1 M) at 45 C was slightly shaken for 25 min. The final volume of the solution was 1.5 mL. For the repeated cycle purpose, H2O2/TMB/Bi2Fe4O9 reaction mixture was centrifuged at 10,000 rpm for 7 min and rinsed with deionized water at 25 C and then the precipitate was added to H2O2/TMB solution under the obtained optimal conditions. The relative activity versus response cycle is depicted in Fig. S6. The catalytic stability of Bi2- Fe4O9 after every catalytic cycle, compared with the original activity, was slightly reduced. After the fourth independent cycle, the primary absorbance intensity of the fresh mixture was decreased from 100% to 93%. The result proved that Bi2Fe4O9 NPs exhibit a good enzyme-like catalytic activity, stability, and reproducibility.

### 3.8. Detection of dopamine in real samples

To evaluate the practical applicability of the proposed Bi2Fe4O9 NPs as an efficient enzyme-like catalyst, we examined dopamine determination in fetal bovine serum (FBS), and horse serum (HS) samples. It should be noted that FBS and HS samples before adding the reagents were diluted 1000 times with buffer phosphate saline (PBS 1x, pH 7.4). Using the optimized conditions (Bi2Fe4O9 NPs (8 mg/mL), H2O2 (5 mM), TMB (0.3 mM), pH = 3.5, incubation time = 25 min, and T = 45 C), different concentrations of dopamine

Table 3

Sensing of DA in fetal bovine serum (FBS 1 and 2), and horse serum (HS) samples (n = 3).

(1, 5, and 10 lM) were spiked into diluted FBS 1 (Sigma-Aldrich), FBS 2 (Fisher Scientific), and HS (Fisher Scientific) solutions.

Moreover, the recovery values and the content of dopamine in real samples were calculated using the obtained calibration curve in [Fig. 5](#page-7-0) and the recorded UV–vis absorption spectra at 654 nm for every real sample (FBS 1, FBS 2, and HS). The result of percentage recovery ([dopamine]found/ [dopamine]added 100) and relative standard deviation (RSD %) are listed in Table 3. The relative recoveries of dopamine concentration in FBS (1 and 2) and HS samples were respectively in the ranges of 96.18–118.12% and 97.61– 104.92%. It should be noted that to reduce the stochastic error effect, UV–vis absorbance values were recorded three-times for each experimental condition. The results revealed that this colorimetric method, as a feasible and reliable approach, can be applied to determine dopamine in different real samples.

#### 3.9. The investigation of the mimic-enzyme catalytic mechanism to produce hydroxyl radicals ( OH)

To confirm the peroxidase-like mechanism of Bi2Fe4O9 NPs, terephthalic acid (TA) molecule was selected as a fluorescence probe. As indicated in Fig. 7, TA can react with OH radicals to yield 2-hydroxyterephthalic acid (2-HTA) molecule, displaying an

| Samples | DA added (mM) | DA founded (mM) | Recovery (%) | RSD (%) |
|---------|---------------|-----------------|--------------|---------|
|         | 1.00          | 1.02            | 101.78       | 0.39    |
| FBS 1   | 5.00          | 5.35            | 106.95       | 0.64    |
|         | 10.00         | 9.62            | 96.18        | 1.76    |
|         |               |                 |              |         |
| FBS 2   | 1.00          | 1.16            | 116.22       | 1.66    |
|         | 5.00          | 5.40            | 108.02       | 0.39    |
|         | 10.00         | 11.81           | 118.12       | 3.81    |
| HS      | 1.00          | 0.97            | 97.61        | 1.42    |
|         | 5.00          | 5.10            | 102.04       | 0.80    |
|         | 10.00         | 10.49           | 104.92       | 3.27    |
|         |               |                 |              |         |

<DESCRIPTION_FROM_IMAGE>This image contains four panels labeled A, B, C, and D, each depicting different aspects of chemical reactions and spectroscopic data.

Panel A: This panel shows a chemical reaction scheme. The reactant, terephthalic acid (TA), is labeled as "Non-Fluorescent". It reacts with a hydroxyl radical (•OH) to form 2-hydroxyterephthalic acid (2-HTA), which is labeled as "Fluorescent". The reaction is represented by an arrow, and the product is surrounded by a star-like shape, indicating its fluorescent property.

SMILES for TA: O=C(O)c1ccc(C(=O)O)cc1
SMILES for 2-HTA: O=C(O)c1ccc(C(=O)O)c(O)c1

Panel B: This panel presents a graph showing the fluorescence emission spectra of various reaction mixtures. The x-axis represents the wavelength in nanometers (nm) from 400 to 550 nm. The y-axis shows the fluorescence intensity in arbitrary units (% EMI) from 0 to 50. Eight different reaction conditions are plotted:

(a) TA + H2O2 + Bi2Fe4O9 NPs
(b) TA + H2O2 + Bi2Fe4O9 NPs + DA
(c) TA + Bi2Fe4O9 NPs
(d) TA + Bi2Fe4O9 NPs + DA
(e) TA + H2O2
(f) TA + H2O2 + DA
(g) TA
(h) HTA + DA

The spectra show varying intensities, with condition (a) having the highest peak intensity around 425-450 nm.

Panel C: This panel illustrates another reaction scheme involving 3,3',5,5'-tetramethylbenzidine (TMB) and tert-butyl alcohol (TBA). TMB is oxidized to ox-TMB, represented by a color change from white to blue. The reaction with TBA is shown to be inhibited, indicated by a red "no" symbol.

SMILES for TMB: Cc1cc(C)c(Nc2ccc(C)c(N)c2C)cc1N
SMILES for ox-TMB: Cc1cc(C)c(N=c2ccc(C)c(=N)c2C)cc1=N

Panel D: This panel shows an absorption spectrum graph. The x-axis represents wavelength from 500 to 800 nm, and the y-axis shows absorbance from 0 to 1.8. Two spectra are plotted:

I (control): Shows a peak around 650-660 nm with a maximum absorbance of about 1.7.
II (tert-butyl alcohol system): Shows a lower peak at the same wavelength with a maximum absorbance of about 0.5.

This graph demonstrates the effect of tert-butyl alcohol on the absorption spectrum of the reaction mixture, likely corresponding to the oxidation of TMB shown in Panel C.</DESCRIPTION_FROM_IMAGE>

Fig. 7. (A) The possible mechanism of reaction of terephthalic acid (TA) with hydroxyl radicals. (B) Fluorescence spectra using TA as a fluorescent probe (kex = 315 nm), Reaction experimental conditions: (a) H2O2 (5 mM) + Bi2Fe4O9 NPs (8 mg/mL), (b) H2O2 (5 mM) + Bi2Fe4O9 NPs (8 mg/mL) + dopamine (50 mM), (c) Bi2Fe4O9 NPs (8 mg/mL), (d) Bi2Fe4O9 NPs (8 mg/mL) + dopamine (50 mM), (e) H2O2 (5 mM), (f) H2O2 (5 mM) + dopamine (50 mM), (g) only TA (0.2 mM), and (h) TA (0.2 mM) + dopamine (50 mM) in acetate buffer (pH 3.5, 0.1 M) and all solutions were incubated for 25 min at 45 C. (C) The proposed mechanism of effect of tert-butyl alcohol (TBA) on the peroxidase-mimic catalytic activity of Bi2Fe4O9 NPs. (D) UV–vis spectra using TBA as an electron scavenger, Reaction experimental conditions: Bi2Fe4O9 NPs (8 mg/mL), TMB (0.3 mM), H2O2 (5 mM), acetate buffer (pH 3.5, 0.1 M), TBA (0.5 mM), T = 45 C, and incubation time = 25 min.

<span id="page-9-0"></span>intense fluorescence signal [6,67–69]. The general oxidation reaction of the TA molecule is depicted in the following [Fig. 7](#page-8-0)A. All the solutions [(Fig. 7](#page-8-0)B) were prepared in acetate buffer (pH 3.5, 0.1 M) and the total volume was 1.5 mL. As presented in [Fig. 7](#page-8-0)B (g, e, and c), terephthalic acid (TA) did not show an obvious emission peak in the absence of H2O2, the presence of H2O2 alone, and Bi2Fe4O9 NPs alone. It could be clearly seen, in [Fig. 7](#page-8-0)B (a), that the introduction of Bi2Fe4O9 nanozyme to TA/H2O2 mixture led to the appearance of fluorescence emission with a maximum peak at around 435 nm under optimum experimental conditions, which is a strong indication that TA was converted into 2-HTA molecules. The fluorescence curves indicated that the formation of 2-HTA molecules was highly related to the presence of both H2O2 substrate and Bi2Fe4O9 nanozyme in the reaction mixture (H2O2/Bi2- Fe4O9/TA). In the presence of dopamine, the fluorescence intensity of obtained 2-HTA was dramatically decreased, which proved the competitive role of dopamine compared to TA for grasping the hydroxide radicals [(Fig. 7](#page-8-0)B (b), orange curve). The fluorescence intensity related to 2-HTA molecules in each of the eight solutions was recorded at 435 nm. The transformation of TA into fluorescent (2-HTA) molecules was accelerated in the presence of Bi2Fe4O9 nanozyme through the decomposition of H2O2 molecules into hydroxyl radicals ( OH).

In addition, to confirm the role of OH radicals in the reaction mechanism, tert-butanol alcohol (TBA) was used as OH radical scavenger molecule (rate constant = 6.2 108 dm3 mol1 s1 ). The presence of TBA obviously prevented the oxidation of TMB molecules and simultaneously produced (. (CH3)3O) radicals [7,70]. As mentioned above, TBA can directly quench reactive oxygen species (ROS) as hydroxyl radicals [(Fig. 7](#page-8-0)C-D). The comparison of the UV–vis absorption spectra of the H2O2/TMB/Bi2Fe4O9 [(Fig. 7](#page-8-0)D, blue curve) and H2O2/TMB/Bi2Fe4O9/TBA [(Fig. 7](#page-8-0)D, pink curve) systems illustrated an obvious absorption peak in the UV– vis range whose intensity was significantly decreased in the presence of TBA. These phenomena prove that the hydroxyl radicals play an important role in the oxidation of TMB substrate and the charge transfer between Fe (II) to Fe (III) ions in the Fenton-like cycle of Bi2Fe4O9 nanozyme.

#### 4. Conclusion

In summary, dopamine (DA) as a neurotransmitter plays a number of key roles in humans and animals. Therefore, the control and monitoring of the amount of dopamine is necessary to prevent disease conditions. In this work, we report, for the first time, a new colorimetric sensor using Bi2Fe4O9 nanoparticles with peroxidase-mimic catalytic activity. The Bi2Fe4O9 NPs were prepared by a hydrothermal method that is a facile and low-cost approach. Bi2Fe4O9 enzyme mimic features high water-solubility and good stability. On the basis of the outstanding catalytic activity of Bi2Fe4O9 in the presence of TMB and H2O2, a colorimetric sensing platform was developed and exhibited an accurate, highly sensitive, and selective detection of dopamine at a nanomolar level. This colorimetric probe achieved a detection limit and linear concentration range of 51 nM and 0.15–50 lM for dopamine, respectively. The developed sensor outperforms the already reported nanozymes in literature [3,35,63–65]. Under optimized experimental conditions, Michaelis-Menten kinetics analysis of the oxidation state of TMB substrate, in H2O2/TMB/Bi2Fe4O9 system, achieved Vmax and Km values of 2.17 10-8 M.s1 and 0.07 mM, respectively. To gain a better understanding of the reaction mechanism, we examined the effect of hydroxyl ( OH) radicals as important reactive oxygen species to oxidase dopamine molecules in the H2O2/ TMB/Bi2Fe4O9/DA colorimetric-system using terephthalic acid (TA) and tert-butyl alcohol (TBA) probes. This spectroscopic method for evaluation of OH radicals is a simple, inexpensive, and reliable approach. In addition, the potential application of Bi2- Fe4O9 as a peroxidase-mimic catalyst to accurately detect dopamine concentration in fetal bovine serum (FBS) and horse serum (HS) samples was demonstrated. Taken together the results of the present study highlight the potential application of nanostructured bismuth ferrite (Bi2Fe4O9) in the diagnosis of dopaminerelated diseases. Future work will introduce the investigation of dopamine in real samples by using lateral-flow test strips coupled with smartphones. These studies will open new perspectives for early detection and treatment of different types of drug addiction and neurological related diseases.

#### CRediT authorship contribution statement

Mehri Razavi: Investigation, Methodology, Validation, Visualization, Formal analysis, Writing – original draft. Alexandre Barras: Investigation, Methodology. Madjid Ifires: Resources. Abir Swaidan Resource: . Maryam Khoshkam: Investigation. Sabine Szunerits: Investigation. Mohsen Kompany-Zareh: Writing – review & editing. Rabah Boukherroub: Supervision, Conceptualization, Writing – review & editing, Funding acquisition, Project administration.

#### Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

#### Acknowledgements

The authors wish to thank the Centre National de la Recherche Scientifique (CNRS), the University of Lille, the region Hauts-de-France, the CPER ''Photonics for Society", and the Institute for Advanced Studies in Basic Sciences (IASBS) in Iran for supporting this study.

#### Appendix A. Supplementary material

Supplementary data to this article can be found online at [https://doi.org/10.1016/j.jcis.2022.01.041.](https://doi.org/10.1016/j.jcis.2022.01.041)

#### References

- [1] [A. Slivka, G. Cohen, Hydroxyl radical attack on dopamine, J. Biol. Chem. 260](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0005) [(29) (1985) 15466–15472](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0005).
- [2] [J. Liu, L. Yuan, X. Dong, Recent advances in analytical techniques for the](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0010) [determination of dopamine, Int. J. Chem. Stud. 3 (2015) 39–45](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0010).
- [3] [K. Wang, J. Song, X. Duan, J. Mu, Y. Wang, Perovskite LaCoO3](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0015) [nanoparticles as](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0015) [enzyme mimetics: their catalytic properties, mechanism and application in](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0015) [dopamine biosensing, New J. Chem. 41 (2017) 8554–8560](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0015).
- [4] [P.A. Rasheed, J.-S. Lee, Recent advances in optical detection of dopamine using](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0020) [nanomaterials, Microchim. Acta 184 (5) (2017) 1239–1266](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0020).
- [5] [G.-C. Yen, C.-L. Hsieh, Antioxidant effects of dopamine and related compounds,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0025) [Biosci. Biotechnol. Biochem. 61 (10) (1997) 1646–1649](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0025).
- [6] [M.N. Ivanova, E.D. Grayfer, E.E. Plotnikova, L.S. Kibis, G. Darabdhara, P.K.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0030) [Boruah, M.R. Das, V.E. Fedorov, Pt-decorated boron nitride nanosheets as](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0030) [artificial nanozyme for detection of dopamine, ACS Appl. Mater. Interfaces 11](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0030) [(25) (2019) 22102–22112.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0030)
- [7] [A. Swaidan, A. Barras, A. Addad, J.-F. Tahon, J. Toufaily, T. Hamieh, S. Szunerits,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0035) [R. Boukherroub, Colorimetric sensing of dopamine in beef meat using copper](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0035) [sulfide encapsulated within bovine serum albumin functionalized with copper](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0035) [phosphate (CuS-BSA-Cu3(PO4)2) nanoparticles, J. Colloid Interface Sci. 582](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0035) [(2021) 732–740.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0035)
- [8] [S. Rostami, A. Mehdinia, A. Jabbari, Intrinsic peroxidase-like activity of](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0040) [graphene nanoribbons for label-free colorimetric detection of dopamine,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0040) [Mater. Sci. Eng. C 114 (2020) 111034–111044](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0040).
- [9] [G.E. De Benedetto, D. Fico, A. Pennetta, C. Malitesta, G. Nicolardi, D.D.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0045) [Lofrumento, F. De Nuccio, V. La Pesa, A rapid and simple method for the](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0045) [determination of 3, 4-dihydroxyphenylacetic acid, norepinephrine, dopamine,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0045)

<span id="page-10-0"></span>[and serotonin in mouse brain homogenate by HPLC with fluorimetric](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0045) [detection, J. Pharm. Biomed. Anal. 98 (2014) 266–270](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0045).

- [10] H. Fang, M.L. Pajski, A.E. Ross, B.J. Venton, Quantitation of dopamine, serotonin and adenosine content in a tissue punch from a brain slice using capillary electrophoresis with fast-scan cyclic voltammetry detection, Anal. Methods 5 (11) (2013) 2704, <https://doi.org/10.1039/c3ay40222c>.
- [11] [Y. Dong, H. Chen, Y. Chen, Y. Hui, X. Chen, Z. Hu, Separation and determination](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0055) [of epinephrine and dopamine in traditional Chinese medicines by micellar](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0055) [electrokinetic capillary chromatography with laser induced fluorescence](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0055) [detection, J. Sep. Sci. 29 (13) (2006) 2049–2055](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0055).
- [12] [S.J. Park, S.H. Lee, H. Yang, C.S. Park, C.-S. Lee, O.S. Kwon, T.H. Park, J. Jang,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0060) [Human dopamine receptor-conjugated multidimensional conducting polymer](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0060) [nanofiber membrane for dopamine detection, ACS Appl. Mater. Interfaces 8](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0060) [(42) (2016) 28897–28903.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0060)
- [13] [Z. Miao, W. Hou, M. Liu, Y. Zhang, S. Yao, BSA capped bi-functional fluorescent](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0065) [Cu nanoclusters as pH sensor and selective detection of dopamine, New J.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0065) [Chem. 42 (2) (2018) 1446–1456](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0065).
- [14] [B. Xu, Y. Su, L.i. Li, R. Liu, Y.i. Lv, Thiol-functionalized single-layered MoS2](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0070) [nanosheet as a photoluminescence sensing platform via charge transfer for](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0070) [dopamine detection, Sens.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0070) Actuators B 246 (2017) 380–388.
- [15] W.Z. Wan Ismail, G. Liu, K. Zhang, E.M. Goldys, J.M. Dawes, Dopamine sensing and measurement using threshold and spectral measurements in random lasers, Opt. Express 24 (2) (2016) A85, [https://doi.org/10.1364/OE.24.000A85.](https://doi.org/10.1364/OE.24.000A85)
- [16] [A.J. Stewart, J. Hendry, L. Dennany, Whole blood electrochemiluminescent](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0080) [detection of dopamine, Anal. Chem. 87 (23) (2015) 11847–11853](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0080).
- [17] [G.T.S. How, A. Pandikumar, H.N. Ming, L.H. Ngee, Highly exposed 001 facets of](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0085) [titanium dioxide modified with reduced graphene oxide for dopamine sensing,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0085) [Sci. Rep. 4 (2014) 1–8](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0085).
- [18] [D.-S. Kim, E.-S. Kang, S. Baek, S.-S. Choo, Y.-H. Chung, D. Lee, J. Min, T.-H. Kim,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0090) [Electrochemical detection of dopamine using periodic cylindrical gold](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0090) [nanoelectrode arrays, Sci. Rep. 8 (2018) 1–10](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0090).
- [19] [H. Wei, E. Wang, Nanomaterials with enzyme-like characteristics](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0095) [(nanozymes): next-generation artificial enzymes, Chem. Soc. Rev. 42 (2013)](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0095) [6060–6093.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0095)
- [20] [Y. Lin, J. Ren, X. Qu, Catalytically active nanomaterials: a promising candidate](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0100) [for artificial enzymes, Acc. Chem. Res. 47 (2014) 1097–1105](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0100).
- [21] [N. Chaibakhsh, Z. Moradi-Shoeili, Enzyme mimetic activities of spinel](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0105) [substituted nanoferrites (MFe2O4): A review of synthesis, mechanism and](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0105) [potential applications, Mater. Sci. Eng. C 99 (2019) 1424–1447](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0105).
- [22] [A. Swaidan, A. Addad, J.-F. Tahon, A. Barras, J. Toufaily, T. Hamieh, S. Szunerits,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0110) [R. Boukherroub, Ultrasmall CuS-BSA-Cu3(PO4)2](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0110) [nanozyme for highly efficient](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0110) [colorimetric sensing of H2O2](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0110) [and glucose in contact lens care solutions and](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0110) [human serum, Anal. Chim. Acta 1109 (2020) 78–89](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0110).
- [23] [Y. Wang, L. Yang, Y. Liu, Q. Zhao, F. Ding, P. Zou, H. Rao, X. Wang, Colorimetric](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0115) [determination of dopamine by exploiting the enhanced oxidase mimicking](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0115) [activity of hierarchical NiCo2S4-rGO composites, Microchim. Acta 185 (2018)](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0115) [1–9.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0115)
- [24] [L. Gao, J. Zhuang, L. Nie, J. Zhang, Y.u. Zhang, N. Gu, T. Wang, J. Feng, D. Yang, S.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0120) [Perrett, X. Yan, Intrinsic peroxidase-like activity of ferromagnetic](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0120) [nanoparticles, Nat. Nanotechnol. 2 (9) (2007) 577–583.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0120)
- [25] [R. Awasthi, B. Das, Effect of temperature on physical properties of Bi2Fe4O9](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0125) [polycrystalline materials, J. Aust. Ceram. Soc. 56 (2020) 243–250.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0125)
- [26] [Z.-T. Hu, S.K. Lua, X. Yan, T.-T. Lim, Nanostructured hexahedron of bismuth](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0130) [ferrite clusters: delicate synthesis processes and an efficient multiplex catalyst](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0130) [for organic pollutant degradation, RSC Adv. 5 (2015) 86891–86900.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0130)
- [27] [B. Li, C. Lai, G. Zeng, L. Qin, H. Yi, D. Huang, C. Zhou, X. Liu, M. Cheng, P. Xu, C.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0135) [Zhang, F. Huang, S. Liu, Facile hydrothermal synthesis of Z-scheme Bi2Fe4O9/](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0135) [Bi2WO6](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0135) [heterojunction photocatalyst with enhanced visible light](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0135) [photocatalytic activity, ACS Appl. Mater. Interfaces 10 (22) (2018) 18824–](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0135) [18836](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0135).
- [28] [A. Poghossian, H. Abovian, P. Avakian, S. Mkrtchian, V. Haroutunian, Bismuth](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0140) [ferrites: New materials for semiconductor gas sensors, Sens.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0140) Actuators B 4 [(1991) 545–549.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0140)
- [29] [N. Zakharchenko, Catalytic properties of the Fe2O3–Bi2O3](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0145) [system in ammonia](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0145) [oxidation to nitrogen oxides, Kinet. Catal. 43 (2002) 95–98.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0145)
- [30] [Z.-T. Hu, J. Liu, X. Yan, W.-D. Oh, T.-T. Lim, Low-temperature synthesis of](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0150) [graphene/ Bi2Fe4O9](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0150) [composite for synergistic adsorption-photocatalytic](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0150) [degradation of hydrophobic pollutant under solar irradiation, Chem. Eng. J.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0150) [262 (2015) 1022–1032](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0150).
- [31] [M. Kong, H. Song, F. Li, D. Dai, H. Gao, Facile synthesis of Bi2Fe4O9](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0155) [nanoplate](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0155) [and its application as a novel adsorbent for Cu (II) removal, J. Environ. Chem.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0155) [Eng. 5 (2017) 69–78.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0155)
- [32] [A. Roy, R. Gupta, A. Garg, Multiferroic memories, Adv. Condens. Matter Phys.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0160) [2012 (2012) 1–12](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0160).
- [33] [J.F. Scott, Multiferroic memories, Nat. Mater. 6 (4) (2007) 256–257](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0165).
- [34] [J.-T. Han, Y.-H. Huang, X.-J. Wu, C.-L. Wu, W. Wei, B. Peng, W. Huang, J.B.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0170) [Goodenough, Tunable synthesis of bismuth ferrites with various](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0170) [morphologies, Adv. Mater. 18 (16) (2006) 2145–2148.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0170)
- [35] [Z. Yang, F. Ma, Y. Zhu, S. Chen, C.e. Wang, X. Lu, A facile synthesis of CuFe2O4/](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0175) [Cu9S8/PPy ternary nanotubes as peroxidase mimics for the sensitive](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0175) [colorimetric detection of H2O2](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0175) [and dopamine, Dalton Trans. 46 (34) (2017)](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0175) [11171–11179](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0175).
- [36] [Q. Chen, C. Liang, X. Zhang, Y. Huang, High oxidase-mimic activity of Fe](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0180) [nanoparticles embedded in an N-rich porous carbon and their application for](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0180) [sensing of dopamine, Talanta 182 (2018) 476–483](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0180).

- [37] [X. Wang, M. Zhao, Y. Song, Q. Liu, Y. Zhang, Y. Zhuang, S. Chen, Synthesis of](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0185) [ZnFe2O4/ZnO heterostructures decorated three-dimensional graphene foam as](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0185) [peroxidase mimetics for colorimetric assay of hydroquinone, Sens.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0185) Actuators B [283 (2019) 130–137.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0185)
- [38] [Y. Xing, M. Chen, Y. Zhao, J. Xu, X. Hou, Triple-enzyme mimetic activity of](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0190) [Fe3O4@ C@MnO2](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0190) [composites derived from metal–organic frameworks and](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0190) [their application to colorimetric biosensing of dopamine, Microchim. Acta 189](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0190) [(2022) 1–10](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0190).
- [40] [J. Yu, D. Ma, L. Mei, Q. Gao, W. Yin, X. Zhang, L. Yan, Z. Gu, X. Ma, Y. Zhao,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0195) [Peroxidase-like activity of MoS2](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0195) [nanoflakes with different modifications and](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0195) [their application for H2O2](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0195) [and glucose detection,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0195) J. Mater. Chem. B 6 (3) (2018) [487–498](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0195).
- [41] [F. Yu, Y. Huang, A.J. Cole, V.C. Yang, The artificial peroxidase activity of](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0200) [magnetic iron oxide nanoparticles and its application to glucose detection,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0200) [Biomaterials 30 (27) (2009) 4716–4722.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0200)
- [42] [P.D. Liyanage, P. Weerathunge, M. Singh, V. Bansal, R. Ramanathan, L-Cysteine](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0205) [as an Irreversible Inhibitor of the Peroxidase-Mimic Catalytic Activity of 2-](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0205) [Dimensional Ni-Based Nanozymes, Nanomaterials 11 (2021) 1285–1298.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0205)
- [43] [F. Ma, H. Zhao, Optical, Magnetic, Ferroelectric Properties and Photocatalytic](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0210) [Activity of Bi2Fe4O9](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0210) [Nanoparticles through a Hydrothermal Assisted Sol-Gel](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0210) [Method, Russ. J. Phys. Chem. A 93 (2019) 2079–2086.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0210)
- [44] [J. Zhao, T. Liu, Y. Xu, Y. He, W. Chen, Synthesis and characterization of](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0215) [Bi2Fe4O9powders, Mater. Chem. Phys. 128 (3) (2011) 388–391](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0215).
- [45] [Z.-T. Hu, S.K. Lua, T.-T. Lim, Cuboid-like Bi2Fe4O9/Ag with graphene-wrapping](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0220) [tribrid composite with superior capability for environmental](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0220) [decontamination: nanoscaled material design and visible-light-driven](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0220) [multifunctional catalyst, ACS Sustain. Chem. Eng. 3 (2015) 2726–2736.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0220)
- [46] [Y. Wang, M. Daboczi, C.A. Mesa, S.R. Ratnasingham, J.-S. Kim, J.R. Durrant, S.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0225) [Dunn, H. Yan, J. Briscoe, Bi2Fe4O9](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0225) [thin films as novel visible-light-active](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0225) [photoanodes for solar water splitting, J. Mater. Chem. A 7 (16) (2019) 9537–](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0225) [9541](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0225).
- [47] [H. Yang, J. Dai, L. Wang, Y. Lin, F. Wang, P. Kang, A novel approach to prepare](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0230) [Bi2Fe4O9](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0230) [flower-like spheres with enhanced photocatalytic performance, Sci.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0230) [Rep. 7 (2017) 1–11](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0230).
- [48] [M.O. Amin, B. D'Cruz, M. Madkour, E. Al-Hetlani, Magnetic nanocomposite](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0235)[based SELDI probe for extraction and detection of drugs, amino acids and fatty](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0235) [acids, Microchim. Acta 186 (2019) 1–10](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0235).
- [49] [L. Li, P. Ma, S. Hussain, L. Jia, D. Lin, X. Yin, Y. Lin, Z. Cheng, L. Wang, FeS2/carbon](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0240) [hybrids on carbon cloth: a highly efficient and stable counter electrode for](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0240) [dye-sensitized solar cells,, Sustain. Energy Fuels 3 (2019) 1749–1756](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0240).
- [50] [B. Hu, J.-F. Wang, J.i. Zhang, Z.-B. Gu, S.-T. Zhang, Synthesis, structures and](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0245) [properties of single phase BiFeO3](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0245) [and Bi2Fe4O9](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0245) [powders by hydrothermal](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0245) [method, J. Mater. Sci.: Mater. Electron. 26 (9) (2015) 6887–6891](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0245).
- [51] [Y. Du, Z. Cheng, S. Dou, X. Wang, Tunable morphology and magnetic properties](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0250) [of Bi2Fe4O9 nanocrystal synthesized by hydrothermal method, J. Nanosci.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0250) [Nanotechnol. 11 (2011) 2691–2695.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0250)
- [52] T.-J. Park, G.C. Papaefthymiou, A.R. Moodenbaugh, Y. Mao, S.S. Wong, Synthesis and characterization of submicron single-crystalline Bi2Fe4O9 cubes, J. Mater. Chem. 15 (21) (2005) 2099, [https://doi.org/10.1039/b501552a.](https://doi.org/10.1039/b501552a)
- [53] [X. Wang, M. Zhang, P. Tian, W.S. Chin, C.M. Zhang, A facile approach to pure](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0260)[phase Bi2Fe4O9](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0260) [nanoparticles sensitive to visible light, Appl. Surf. Sci. 321](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0260) [(2014) 144–149](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0260).
- [54] [P. Salgado, V. Melin, D. Contreras, Y. Moreno, H.D. Mansilla, Fenton reaction](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0265) [driven by iron ligands, J. Chil. Chem. Soc. 58 (2013) 2096–2101.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0265)
- [55] [C. von Sonntag, Advanced oxidation processes: mechanistic aspects, Water Sci.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0270) [Technol. 58 (5) (2008) 1015–1021.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0270)
- [56] [E.S.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0275) [Henle,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0275) [Y.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0275) [Luo,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0275) [S.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0275) [Linn,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0275) [Fe2+,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0275) [Fe3+, and oxygen react with DNA-derived](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0275) [radicals formed during iron-mediated Fenton reactions, Biochemistry 35 (37)](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0275) [(1996) 12212–12219.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0275)
- [57] M. Zhao, J. Huang, Y.u. Zhou, X. Pan, H. He, Z. Ye, X. Pan, Controlled synthesis of spinel ZnFe2O4 decorated ZnO heterostructures as peroxidase mimetics for enhanced colorimetric biosensing, Chem. Commun. 49 (69) (2013) 7656, [https://doi.org/10.1039/c3cc43154a.](https://doi.org/10.1039/c3cc43154a)
- [58] [M. Pooladi, I. Sharifi, M. Behzadipour, A review of the structure, magnetic and](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0285) [electrical properties of bismuth ferrite (Bi2Fe4O9), Ceram. Int. 46 (11) (2020)](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0285) [18453–18463](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0285).
- [59] [Y. Liu, C. Wang, N. Cai, S. Long, F. Yu, Negatively charged gold nanoparticles as](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0290) [an intrinsic peroxidase mimic and their applications in the oxidation of](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0290) [dopamine, J. Mater. Sci. 49 (20) (2014) 7143–7150.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0290)
- [60] [Y. Zhu, Z. Yang, M. Chi, M. Li, C.e. Wang, X. Lu, Synthesis of hierarchical Co3O4@](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0295) [NiO core-shell nanotubes with a synergistic catalytic activity for peroxidase](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0295) [mimicking and colorimetric detection of dopamine, Talanta 181 (2018) 431–](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0295) [439](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0295).
- [61] [J. Yin, H. Cao, Y. Lu, Self-assembly into magnetic Co3O4](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0300) [complex](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0300) [nanostructures as peroxidase, J. Mater. Chem. 22 (2) (2012) 527–534.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0300)
- [62] [J. Lei, X. Lu, G. Nie, Z. Jiang, C. Wang, One-Pot Synthesis of Algae-Like MoS2/PPy](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0305) [Nanocomposite: A Synergistic Catalyst with Superior Peroxidase-Like Catalytic](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0305) [Activity for H2O2](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0305) [Detection, Part. Part. Syst. Charact. 32 (2015) 886–892](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0305).
- [63] [S. Dutta, C. Ray, S. Mallick, S. Sarkar, R. Sahoo, Y. Negishi, T. Pal, A gel-based](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0310) [approach to design hierarchical CuS decorated reduced graphene oxide](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0310) [nanosheets for enhanced peroxidase-like activity leading to colorimetric](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0310) [detection of dopamine, J. Phys. Chem. C 119 (41) (2015) 23790–23800.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0310)
- [64] M. Reza Hormozi Nezhad, J. Tashkhourian, J. Khodaveisi, M. Reza Khoshi, Simultaneous colorimetric determination of dopamine and ascorbic acid based on the surface plasmon resonance band of colloidal silver nanoparticles using

<span id="page-11-0"></span>artificial neural networks, Anal. Methods 2 (9) (2010) 1263, [https://doi.org/](https://doi.org/10.1039/c0ay00302f) [10.1039/c0ay00302f](https://doi.org/10.1039/c0ay00302f).

- [65] [J. Zhu, X. Peng, W. Nie, Y. Wang, J. Gao, W. Wen, J.N. Selvaraj, X. Zhang, S. Wang,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0320) [Hollow copper sulfide nanocubes as multifunctional nanozymes for](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0320) [colorimetric detection of dopamine and electrochemical detection of](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0320) [glucose, Biosens. Bioelectron. 141 (2019) 111450–111466](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0320).
- [66] [H.W. Richter, W.H. Waddell, Mechanism of the oxidation of dopamine by the](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0325) [hydroxyl radical in aqueous solution, J. Am. Chem. Soc. 105 (16) (1983) 5434–](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0325) [5440.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0325)
- [67] [J.C. Barreto, G.S. Smith, N.H.P. Strobel, P.A. McQuillin, T.A. Miller, Terephthalic](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0330) [acid: a dosimeter for the detection of hydroxyl radicals in vitro, Life Sci. 56 (4)](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0330) [(1994) PL89–PL96.](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0330)
- [68] [Z. Xiang, Y.i. Wang, P. Ju, D. Zhang, Optical determination of hydrogen peroxide](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0335) [by exploiting the peroxidase-like activity of AgVO3](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0335) [nanobelts, Microchim. Acta](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0335) [183 (1) (2016) 457–463](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0335).
- [69] [X. Lai, Y. Han, J. Zhang, J. Zhang, W. Lin, Z. Liu, L. Wang, Peroxidase-Like](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0340) [Platinum Clusters Synthesized by Ganoderma lucidum Polysaccharide for](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0340) [Sensitively Colorimetric Detection of Dopamine, Molecules 26 (2021) 2738–](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0340) [2751](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0340).
- [70] [M. Alam, B. Rao, E. Janata, OH reactions with aliphatic alcohols: evaluation of](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0345) [kinetics by direct optical absorption measurement. A pulse radiolysis study,](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0345) [Radiat. Phys. Chem. 67 (2003) 723–728](http://refhub.elsevier.com/S0021-9797(22)00043-1/h0345).