The image contains two graphs labeled A and B, each showing enzyme kinetics data.

Graph A:
Main plot: Shows the relationship between the reaction velocity (V) and the concentration of TMB ([TMB]). The x-axis represents [TMB] in mM, ranging from 0 to 0.3 mM. The y-axis represents V in 10^-8 M.s^-1, ranging from -0.2 to 1.8. The data points follow a typical Michaelis-Menten kinetics curve, with the reaction rate increasing rapidly at low substrate concentrations and then leveling off at higher concentrations.

Inset plot: Shows the Lineweaver-Burk plot (double reciprocal plot) of the same data. The x-axis represents [TMB]^-1 in mM^-1, ranging from 0 to 35 mM^-1. The y-axis represents V^-1 in (10^8 M^-1.s), ranging from 0.2 to 2.0. The linear regression equation is y = 0.0332x + 0.4756, with an R^2 value of 0.972.

Graph B:
Main plot: Shows the relationship between the reaction velocity (V) and the concentration of H2O2 ([H2O2]). The x-axis represents [H2O2] in mM, ranging from 0 to 5 mM. The y-axis represents V in 10^-8 M.s^-1, ranging from 0 to 1.4. The data points follow a similar Michaelis-Menten kinetics curve as in Graph A.

Inset plot: Shows the Lineweaver-Burk plot of the H2O2 data. The x-axis represents [H2O2]^-1 in mM^-1, ranging from 0 to 10 mM^-1. The y-axis represents V^-1 in (10^8 M^-1.s), ranging from 0 to 7. The linear regression equation is y = 0.4522x + 0.6755, with an R^2 value of 0.968.

Both graphs include error bars on the data points, indicating experimental uncertainty. The main plots demonstrate the saturation kinetics typical of enzyme-catalyzed reactions, while the inset plots provide linearized representations used for determining kinetic parameters such as Km and Vmax.