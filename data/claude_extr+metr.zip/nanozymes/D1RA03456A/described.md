# RSC Advances

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

**[View Article Online](https://doi.org/10.1039/d1ra03456a) [View Journal](https://pubs.rsc.org/en/journals/journal/RA) [| View Issue](https://pubs.rsc.org/en/journals/journal/RA?issueid=RA011039)**

#### PAPER

Cite this: RSC Adv., 2021, 11, 24065

## Sweetsop-like a-Fe2O3@CoNi catalyst with superior peroxidase-like activity for sensitive and selective detection of hydroquinone†

Min Feng,a Sha[ohu](http://orcid.org/0000-0002-0943-824X)a Wen,a Xiaofang Chen,a Die Deng,a Xiupei Yang *a and Run Zhang *b

Hydroquinone (HQ) is poorly degradable in the ecological environment and is highly toxic to human health even at a low concentration. The colorimetric method has the advantages of low cost and fast analysis, which provides the possibility for simple and rapid detection of HQ. In this work, a new colorimetric method has been developed for HQ detection based on a peroxidase-like catalyst, a-Fe2O3@CoNi. This sweetsop-like a-Fe2O3@CoNi catalyst enables H2O2 to produce hydroxyl (cOH), leading to the oxidization of colorless 3,30 ,5,50 -tetramethylbenzidine (TMB) to blue oxTMB. In the presence of HQ, the blue oxTMB is reduced to colorless, which allows for colorimetric detection of HQ in water samples. This method has been validated by detecting HQ in water samples with high selectivity, rapid response, broad detection range (0.50 to 30 mM), and low detection limit (0.16 mM).

Received 3rd May 2021 Accepted 26th June 2021 DOI: 10.1039/d1ra03456a

rsc.li/rsc-advances

### Introduction

Hydroquinone (1,4-dihydroxybenzene, HQ) is a phenolic compound widely used as an industrial reagent in cosmetics, dyes, plastics, textiles, rubber, medicine and other industries.1–3 During its industrial uses, the unavoidable contamination of the environment, especially water pollution, has threatened aquatic life.4 This compound is highly toxic to human health even at low concentrations and can cause damage to the skin, mouth, and respiratory system by inhalation.5–7 HQ is difficult to degrade in the ecological environment, and the accumulation of HQ caused by water discharge has always been a major environmental issue. HQ has been listed as a priority pollutant for aquatic environment monitoring by the US Environmental Protection Agency (EPA) and the European Union (EU).8 Therefore, HQ detection in water samples is essential for environmental regulation and human health. Currently, several methods have been developed for its detection, including electrochemiluminescence (ECL),9,10 high-performance liquid chromatography (HPLC),11,12 uorometric method,13–15 gas chromatography-mass spectrometry (CG-MS),16 chemiluminescence (CL),17–19 etc. However, HQ detection by these methods can only be achieved in well-equipped laboratories with the assistance of professional lab technicians, which makes them not suitable for quick and efficient determination of HQ in samples. In recent years, due to the convenience of the naked-eye colorimetric detection method, it is possible to easily and quickly visually inspect samples without any advanced equipment, which has gained considerable attention.20–22

Natural enzymes have high substrate specicity and activity and are widely used in medicine, chemical industry, food processing, agriculture, detection, and other elds.23–25 However, the application of natural enzymes is fundamentally limited by their intrinsic drawbacks.26,27 Unlike natural enzymes, articial nanozymes have obvious advantages such as high stability, low cost, and easy scale up.28,29 Therefore, articial nanozyme can be an ideal candidate for various enzymatic reactions.30,31 Since the report of Fe3O4 nanoparticles' peroxidase activity in 2007, the preparation and application of nanozymes have aroused great interest among researchers.32 In the past 20 years, a number of nanomaterials have been developed and used as articial enzymes.33 These nanomaterials mainly include metal/metal oxide nanoparticles (NPs),34 metal–organic frameworks (MOFs),35 carbon nanomaterials,36 etc. Iron oxide nanoparticles are one of the most typical nanoenzymes. They are widely used in biomedicine, biosensing and other elds due to their unique nanometer properties, stability and enzyme-like activity.37 As an emerging class of articial nanozymes, nanomaterials with peroxidase mimetic activity have also been widely used in the development of sensors for the detection of aqueous contaminants.38,39 Nevertheless, it remains interests to develop articial nanozymes for rapid and effective colorimetric sensing of organic substrates, such as HQ, because the selection of

a College of Chemistry and Chemical Engineering, Chemical Synthesis and Pollution Control Key Laboratory of Sichuan Province, China West Normal University, Nanchong 637000, China. E-mail: xiupeiyang@163.com

b Australian Institute for Bioengineering and Nanotechnology, The University of Queensland, Brisbane, Queensland 4072, Australia. E-mail: r.zhang@uq.edu.au

<sup>†</sup> Electronic supplementary information (ESI) available. See DOI: 10.1039/d1ra03456a

appropriate catalysts for oxidizing organic substrates to have colour changes is full of challenges.40

In this work, we report the development of a new peroxidaselike catalyst, a-Fe2O3@CoNi, and its application for colorimetric detection of HQ in water samples. The sweetsop-like a-Fe2- O3@CoNi was prepared by the one-pot hydrothermal method. The as-synthesized a-Fe2O3@CoNi showed high peroxidase activity, stability and was successfully applied to the colorimetric detection of HQ through catalytic oxidation with 3,30 ,5,50 -tetramethylbenzidine (TMB). The experimental results demonstrated that a-Fe2O3@CoNi could catalyze H2O2 to produce cOH which oxidized colorless TMB into blue oxTMB. The blue oxTMB be further reduced to TMB in the presence of HQ. Then a sensor for the colorimetric detection of HQ in water samples has been developed with a-Fe2O3@CoNi, H2O2 and TMB.

### Experimental

#### Materials

Iron nitrate nonahydrate (Fe(NO3)3\$9H2O), Cobalt nitrate hexahydrate (Co(NO3)2\$6H2O), Ethylenediaminetetraacetic acid tetrasodium salt hydrate (Na4EDTA\$xH2O), 3,30 ,5,50 -tetramethylbenzidine (TMB), hydroquinone (HQ), catechol, resorcinol, phenol, o-nitrophenol, p-nitrophenol, glucose and other nitrate salts including (Ca2+, Cu2+, Zn2+, Mg2+, Co2+, Mn2+, Cd2+, Fe3+, Cl-, SO4 2-, NO3 -) were purchased from Aladdin in China. Methanol, hydrogen peroxide (H2O2, 30%), Acetic acid (C2H4O2), sodium acetate anhydrous (NaAc), nickel nitrate hexahydrate (Ni(NO3)2\$6H2O) were received from Chengdu Kelong Chemical Reagents Co. Ltd in China. The tap water and the river were collected from the laboratory and Jialing River of Nanchong, respectively.

#### Instrumentation

Transmission electron microscope (TEM) and mapping detected with an acceleration voltage of 200 kV on JEM-1200EX (JEOL, Tokyo, Japan). The scanning electron microscopy (SEM) and energy dispersive X-ray mappings (EDS) were performed on Hitachi S4800 (Hitachi Limited, Japan). X-ray photoelectron spectra (XPS) were obtained on a Thermo ESCALAB 250XI (Thermo Fisher Scientic, U.S.A.). The X-ray diffractometer (XRD) was measured using a Rigaku D/MAX-2550 (Rigaku, Japan) with Cu Ka radiation. The infrared spectra were acquired from a Nicolet 6700 Fourier transform infrared (FTIR) spectrometer (Thermo Electron Corporation, USA) with a passed KBr pellet at room temperature. All absorption spectra were detected by a Shimadzu UV-2550 UV-vis absorption spectrophotometer (Kyoto, Japan). Electron spin resonance (ESR) spectra were recorded using Bruker MS-5000 ESR spectrometer (Bruker, Germany).

#### Preparation of a-Fe2O3@CoNi

Sweetsop-like a-Fe2O3@CoNi were prepared by previous one-pot hydrothermal method reported with some minor modications.41 Briey, a certain amount of EDTA was dissolved in

12 mL ultrapure water to form solution A. A certain amount of Fe(NO3)3\$9H2O, Co(NO3)2\$6H2O, Ni(NO3)2\$6H2O was dissolved in 8 mL ultrapure water to form a uniform mixture solution B. To solution A, solution B was slowly introduced under vigorously stirring. The resulting mixture was allowed to proceed for 10 minutes followed by the addition of 10 mL methanol. The aqueous solution obtained above was transferred to a Teonlined container and enclosed into a 100 mL stainless steel autoclave followed by heating at 180 C for 12 h. Aer heating, the solution was cooled to room temperature and the solid sample was collected and dried under a vacuum aer washing with ultrapure water. The product has a spherical shape with small particles on the surface, and its morphology is remarkably similar to that of sweetsop, so it was named as sweetsop-like a-Fe2O3@CoNi. Sweetsop is composed of many round or oval mature carpels connected together, and its aggregate berries are spherical or heart-shaped cones. Other single-metal composites (Co, Ni counterparts) were all fabricated through the same hydrothermal method as sweetsop-like a-Fe2O3@CoNi without adding the certain metal ions into solution B. **[View Article Online](https://doi.org/10.1039/d1ra03456a)**

#### Peroxidase-like activity measurements and kinetic studies

The peroxidase-like catalytic activities of a-Fe2O3@CoNi nanozymes were investigated by the oxidation of TMB substrate in the presence of H2O2. All reactions were carried out in acetate buffer (0.20 M, pH ¼ 6.0), and the absorbance at 652 nm was monitored using a UV-vis absorption spectrophotometer. The reactions were optimized under different a-Fe2O3@CoNi concentrations, TMB dosages, H2O2 dosages, reaction time, temperatures, type of buffer solution, buffer concentration and pH values. Use standard reaction conditions for steady-state kinetic determination, change the concentration of H2O2 (6.0– 165.0 mM) at a xed concentration of TMB (0.35 mM), and vice versa, change the concentration of TMB (0.25–2.5 mM) at a xed concentration of H2O2 (130 mM). The Lineweaver–Burk plots is executed by the double reciprocal of the Michaelis–Menten equation to calculate the Michaelis constant (Km) and the Maximum response speed (Vmax).

#### Procedure for visual colorimetric determination of hydroquinone

Three milliliter of NaAc-HAc buffer (pH ¼ 6.0), TMB (0.35 mM), H2O2 (30%, 40 mL), a-Fe2O3@CoNi (3 mg mL-1 , 30 mL) and the different concentrations of hydroquinone solution were added to a 4 mL spectrophotometer cell. The mixture was further incubated at 20 C for 14 min followed by monitoring the formation of an oxidation product of TMB at 652 nm using UVvis spectrophotometry. In order to investigate the selectivity of this colorimetric assay, hydroquinone was replaced by other materials, and the same experimental operations were also conducted. Subsequently, the content of hydroquinone water samples was evaluated according to the same steps described above, of which the samples of hydroquinone were prepared by spiking different concentrations of hydroquinone in real water samples.

### Results and discussion

### Preparation and characterization of a-Fe2O3@CoNi nanoparticles

Sweetsop-like a-Fe2O3@CoNi was prepared by the hydrothermal method, and the experimental conditions were optimized with temperatures, reaction times as well as the dosages of nitrate and EDTA (Fig. S1†). Fig. 1 shows the typical SEM image, TEM image, and element mapping images of sweetsop-like a-Fe2- O3@CoNi. It clearly shows that a-Fe2O3@CoNi displays a uniformly spherical shape with a size of about 700 nm. The surface is covered by nanoparticles, like sweetsop (Fig. 1A) and conrmed by the TEM image (Fig. 1B). As shown in Fig. 1C–F, Fe, Co, Ni, and O are homogenously dispersed in nanomaterials, which is consistent with EDS results (Fig. S2†). The marked diffraction peaks of crystalline a-Fe2O3@CoNi (Fig. 2A) are in good agreement with the well-established data (JCPDS 33- 664). Sweetsop-like a-Fe2O3@CoNi, commercial Fe2O3 and EDTA were characterized using Fourier transform infrared (FT-IR) spectroscopy shown in Fig. S3.† It is proved that there are abundant hydrophilic groups on the surface of a-Fe2O3@CoNi, such as O–H (3400 cm-1 ) and C]O (1600 cm-1 ), which endow them with excellent water dispersibility. The IR peak at 586 cm-1 , can be attributed to the characteristic stretching vibration of the Fe–O bond.42 In addition, the absorption bands at 1340 cm-1 identied the presence of C–N bonds from EDTA. To further conrm the chemical composition and surface state of a-Fe2O3@CoNi, XPS spectra were used to analyze the surface elemental composition (Fig. 2C–F). The full-range XPS spectrum further conrmed that the elemental components of a-Fe2- O3@CoNi are Fe, Co, Ni, O, and C (Fig. 2C). In the highresolution spectrum of Fe 2p (Fig. 2D), the two peaks located at 710.5 eV and 724.6 eV correspond to Fe 2p3/2 and Fe 2p1/2 respectively, and the energy difference is 14.1 eV, which corresponds to Fe3+ in a-Fe2O3@CoNi. As exhibited in Fig. 2E, two characteristic peaks at 781.0 and 796.9 eV are observed in the Co 2p spectrum, which link to 2p3/2 and 2p1/2 doublet of Co2+ and Co3+, respectively. Meanwhile, the Ni2+ was conrmed by the Ni

<DESCRIPTION_FROM_IMAGE>This image is a composite of six microscopy images labeled A through F, showing nanoparticles and their elemental composition:

A: Scanning electron microscopy (SEM) image showing three spherical nanoparticles. Scale bar indicates 500 nm.

B: Transmission electron microscopy (TEM) image of a single larger nanoparticle with a rough, irregular surface. Scale bar indicates 500 nm.

C-F: Elemental mapping images corresponding to the nanoparticle in image B, showing the distribution of different elements:

C: Iron (Fe) distribution
D: Cobalt (Co) distribution
E: Nickel (Ni) distribution
F: Oxygen (O) distribution

The elemental mapping images suggest that the nanoparticle is composed of iron, cobalt, nickel, and oxygen, indicating it may be a mixed metal oxide nanoparticle. The distribution of elements appears relatively uniform throughout the particle, with some variations in intensity.

This set of images provides information on the morphology, size, and elemental composition of the nanoparticles, which is crucial for understanding their properties and potential applications in chemistry and materials science.</DESCRIPTION_FROM_IMAGE>

Fig. 1 The SEM (A), HRTEM (B) and element mapping images (C–F) of sweetsop-like a-Fe2O3@CoNi.

<DESCRIPTION_FROM_IMAGE>The image contains six graphs labeled A through F, presenting various characterization data for α-Fe2O3@CoNi nanoparticles. I will describe each graph in detail:

A. X-ray diffraction (XRD) pattern of α-Fe2O3@CoNi:
- Shows multiple sharp peaks characteristic of a crystalline material
- Major peaks are labeled with Miller indices: (012), (104), (110), (113), (024), (116), (018), (214), (300), (1010), (220)
- Pattern matches JCPDS 33-664 standard for α-Fe2O3

B. Electron Paramagnetic Resonance (EPR) spectra:
- Two spectra shown: H2O2+α-Fe2O3@CoNi+DMPO (red) and H2O2+DMPO (blue)
- Red spectrum shows multiple sharp peaks, indicating the presence of paramagnetic species
- Blue spectrum is relatively flat, serving as a control

C. X-ray Photoelectron Spectroscopy (XPS) survey spectrum:
- Shows peaks for Ni 2p, Fe 2p, Co 2p, O 1s, N 1s, and C 1s
- Indicates the presence of all expected elements in the nanoparticles

D. High-resolution XPS spectrum of Fe 2p region:
- Two main peaks: Fe 2p3/2 and Fe 2p1/2
- Complex peak shape with satellite features, typical for Fe(III) in iron oxide

E. High-resolution XPS spectrum of Co 2p region:
- Two main peaks: Co 2p3/2 and Co 2p1/2
- Satellite features present, indicating Co(II) oxidation state

F. High-resolution XPS spectrum of Ni 2p region:
- Complex peak shape with main peaks and satellite features
- Consistent with Ni(II) oxidation state

These graphs collectively provide evidence for the successful synthesis of α-Fe2O3@CoNi nanoparticles, confirming their crystalline structure, elemental composition, and oxidation states of the constituent elements.</DESCRIPTION_FROM_IMAGE>

Fig. 2 (A) XRD pattern of a-Fe2O3@CoNi. (B) ESR spectra demonstrating cOH generation by H2O2 and a-Fe2O3@CoNi + H2O2. XPS survey spectra of sweetsop-like a-Fe2O3@CoNi (C). Fe 2p, Co 2p and Ni 2p XPS spectra of a-Fe2O3@CoNi, respectively (D–F).

2p3/2 (852.3 eV) and Ni 2p1/2 (876 eV) peaks in a-Fe2O3@CoNi (Fig. 2F).43 It further guaranteed that the Co and Ni on the surface of a-Fe2O3 were successfully immobilized.

#### Peroxidase-mimetic activity of a-Fe2O3@CoNi

The peroxidase-like activities of the four nanomaterials: commercial Fe2O3, a-Fe2O3@Co, a-Fe2O3@Ni, and a-Fe2O3@- CoNi were studied by UV-vis absorption spectrum. Aer incubating a-Fe2O3@CoNi with TMB in a buffer solution containing H2O2 for 14 min, intense absorption bands centered at 652 nm (Fig. S4†) were observed and they were from the oxidation of TMB to oxTMB.44,45 The changes in solution from colorless to blue suggests the formation of oxTMB. In contrast, negligible changes of absorption spectra were observed aer reacting of TMB with commercial Fe2O3, a-Fe2O3@Co and a-Fe2O3@Ni. The UV-vis data indicates that a-Fe2O3@CoNi has high catalytic activity for oxidation of TMB. At the same time, Fe2O3@Ni has a certain enzymatic activity, and the addition of Co adjusts the electronic structure to a certain extent, increases the electron transfer rate, and further improves its catalytic activity. The synergistic effect of Co, Ni, and a-Fe2O3 may be responsible for such high catalytic activity.

We then investigated the catalytic oxidation ability of a-Fe2O3@CoNi on the peroxidase substrate TMB to evaluate whether they can be applied as peroxidase mimics. As displayed in Fig. 3, TMB was oxidized to form a blue solution in the presence of H2O2 and a-Fe2O3@CoNi (inset in Fig. 3). A typical

<DESCRIPTION_FROM_IMAGE>This image contains multiple graphs and an inset image, providing detailed information about chemical reactions and kinetics. I'll describe each component in detail:

1. Main Graph (left side):
This is an absorption spectrum graph showing absorbance (Abs) on the y-axis (ranging from 0 to 3.0 a.u.) versus wavelength on the x-axis (from 300 to 800 nm). It displays four different spectra:

- TMB+H2O2+α-Fe2O3@CoNi (blue line): Shows two major peaks, one at around 370 nm (absorbance ~1.8) and another at about 650 nm (absorbance ~1.1).
- TMB+H2O2 (green line): Flat line near zero absorbance across all wavelengths.
- TMB+α-Fe2O3@CoNi (red line): High absorbance at 300 nm, rapidly decreasing to near zero by 400 nm.
- H2O2+α-Fe2O3@CoNi (black line): Flat line near zero absorbance across all wavelengths.

2. Inset Image (top right of main graph):
Shows four vials labeled a, b, c, and d. Vial 'a' appears to contain a colored solution, while b, c, and d appear clear or white.

3. Graph A (top right):
Title: A
X-axis: CH2O2 (mM), ranging from 0 to 160
Y-axis: v (10^-8 M s^-1), ranging from 0 to 80
Shows a curve that increases rapidly initially, then levels off, suggesting saturation kinetics.

4. Graph B (top right):
Title: B
X-axis: 1/CH2O2 (mM^-1), ranging from 0 to 0.16
Y-axis: 1/v (10^8 M^-1 s), ranging from 0 to 8
Shows a linear relationship, indicative of a Lineweaver-Burk plot.

5. Graph C (bottom left):
Title: C
X-axis: CTMB (mM), ranging from 0 to 2.5
Y-axis: v (10^-8 M s^-1), ranging from 0 to 80
Shows a curve similar to Graph A, suggesting saturation kinetics for TMB.

6. Graph D (bottom right):
Title: D
X-axis: 1/CTMB (mM^-1), ranging from 0 to 20
Y-axis: 1/v (10^8 M^-1 s), ranging from 0 to 6.0
Shows a linear relationship, another Lineweaver-Burk plot.

These graphs collectively provide information about the kinetics of a reaction involving TMB (likely 3,3',5,5'-Tetramethylbenzidine), H2O2, and α-Fe2O3@CoNi (likely a nanocomposite catalyst). The main graph shows spectral changes, while the other graphs provide kinetic data for both H2O2 and TMB as substrates.</DESCRIPTION_FROM_IMAGE>

Fig. 3 Typical absorption spectra of the different solutions. (a) TMB + H2O2+a-Fe2O3@CoNi, (b) TMB + H2O2, (c) TMB + a-Fe2O3@CoNi, (d) H2O2 + a-Fe2O3@CoNi. Inset is the corresponding colorimetric photographs.

absorption peak of oxTMB centered at 652 nm (cuvette A in Fig. 3) was observed. Changes in UV-vis absorption spectra and solution color were not noticed for other groups, indicating that both H2O2 and a-Fe2O3@CoNi are required for TMB oxidation. Similar to horseradish peroxidase (HRP), a-Fe2O3@CoNi greatly enhanced the reaction of TMB with H2O2, indicating that the a-Fe2O3@CoNi can be considered as an efficient peroxidase mimic.

Effects of pH and temperature on a-Fe2O3@CoNi-mediated catalytic oxidation were investigated and the results are shown in Fig. S5.† Obviously, the catalytic activity of Fe2O3@- CoNi is dependent on pH and temperature. a-Fe2O3@CoNi exhibits high catalytic activity at 20 C and at pH 6 while others reported at 40–45 C and at pH 4.5. Other experimental conditions on the catalytic oxidation of TMB in the a-Fe2O3@CoNi/ H2O2 system were studied as well including the buffer solution (Fig. S6A and B†), the amount of a-Fe2O3@C6oNi (Fig. S6C†), the dosage of TMB (Fig. S6D†), and H2O2 (Fig. S6E†). The results suggested that the optimal conditions for catalytic oxidation of TMB were HAc-NaAc buffer (3 mL, pH 6), a-Fe2O3@CoNi (30 mL, 3 mg mL-1 ), TMB (70 mL, 15 mM), and H2O2 (40 mL, 30%).

### Steady-state kinetics for a-Fe2O3@CoNi

In order to study the peroxidase-like activity of a-Fe2O3@CoNi, the apparent steady-state kinetic parameters of TMB oxidation were determined by changing the concentrations of H2O2 and TMB (Fig. 4), which is a similar strategy commonly used by HRP enzymes. Within the appropriate concentration range of H2O2 (Fig. 4A and B) and TMB (Fig. 4C and D), a typical Michaelis– Mentenlike curve was achieved. Based on the function of double-reciprocal Lineweaver–Burk plots (1/V ¼ Km/Vmax 1/[C] + 1/Vmax, where Vmax is maximum response speed and Km is an indicator of enzyme affinity toward its substrate. A lower Km indicates the stronger affinity between enzymes and substrates),46 Michaelis–Menten constant (Km) was 0.23, 0.42 mM for TMB and H2O2, respectively, and maximum initial

<DESCRIPTION_FROM_IMAGE>The image contains four separate graphs labeled A, B, C, and D, each representing different relationships in a chemical reaction study.

Graph A:
X-axis: Concentration of H2O2 (mM), ranging from 0 to 160 mM
Y-axis: Reaction rate v (10^-8 M s^-1), ranging from 0 to 80
The graph shows a non-linear relationship, with the reaction rate increasing rapidly at lower H2O2 concentrations and then leveling off at higher concentrations, suggesting saturation kinetics.

Graph B:
X-axis: Reciprocal of H2O2 concentration (1/[H2O2], mM^-1), ranging from 0 to 0.16
Y-axis: Reciprocal of reaction rate (1/v, 10^8 M^-1 s), ranging from 0 to 8
This graph shows a linear relationship, indicating a double reciprocal (Lineweaver-Burk) plot of the data from Graph A.

Graph C:
X-axis: Concentration of TMB (mM), ranging from 0 to 2.5 mM
Y-axis: Reaction rate v (10^-8 M s^-1), ranging from 0 to 80
Similar to Graph A, this shows a non-linear relationship with saturation kinetics for TMB concentration.

Graph D:
X-axis: Reciprocal of TMB concentration (1/[TMB], mM^-1), ranging from 0 to 20
Y-axis: Reciprocal of reaction rate (1/v, 10^8 M^-1 s), ranging from 0 to 6
This is a linear double reciprocal plot of the data from Graph C.

These graphs collectively represent enzyme kinetics studies, likely for a peroxidase enzyme using H2O2 as a substrate and TMB (3,3',5,5'-Tetramethylbenzidine) as a chromogenic electron donor. The Lineweaver-Burk plots (B and D) can be used to determine kinetic parameters such as Km and Vmax for both H2O2 and TMB in this enzymatic reaction.</DESCRIPTION_FROM_IMAGE>

Fig. 4 Steady-state kinetic assay and catalytic mechanism of the reaction catalyzed by a-Fe2O3@CoNi. (A): TMB concentration was at 0.35 mM. (C): H2O2 concentration was at 130 mM. (B and D) Doublereciprocal Lineweaver–Burk plots of catalytic activity of a-Fe2O3@- CoNi with the same concentration of one substrate (TMB or H2O2) and the other varied.

velocity (Vmax) was 13.5 10-8 and 9.3 10-8 M s-1 for TMB and H2O2, respectively (Table S1†). As can be seen from the table, a-Fe2O3@CoNi possesses smaller Km and higher Vmax than other nanozymes, indicating its outstanding peroxidaselike activity.

#### Selective and sensitive colorimetric detection of HQ

Fig. 5A and B show the time-dependent scanning kinetic curve and UV-Vis spectra of the a-Fe2O3@CoNi in TMB/H2O2 system at different HQ dosages. The absorbance at 652 nm decreased signicantly with the increasing HQ concentration, indicating that HQ successfully inhibited the oxidation of TMB. As shown in Fig. 5C, UV-vis absorption of the solution containing TMB,

<DESCRIPTION_FROM_IMAGE>This image contains four separate graphs labeled A, B, C, and D, each presenting different aspects of a chemical analysis:

Graph A: Time-dependent absorbance measurements
- X-axis: Time (s), ranging from 0 to 300 seconds
- Y-axis: Absorbance (a.u.), ranging from 0 to 0.8
- Three curves representing different concentrations: 30 μM, 15 μM, and 0 μM
- Shows increasing absorbance over time, with higher concentrations exhibiting steeper slopes

Graph B: Wavelength-dependent absorbance spectra
- X-axis: Wavelength (nm), ranging from approximately 575 to 725 nm
- Y-axis: Absorbance (a.u.), ranging from 0 to 1.00
- Three curves representing different concentrations: 0 μM, 15 μM, and 30 μM
- Displays absorption peaks around 650-675 nm, with higher concentrations showing higher peak absorbance

Graph C: Concentration-dependent absorbance spectra
- X-axis: Wavelength (nm), ranging from approximately 575 to 725 nm
- Y-axis: Absorbance (a.u.), ranging from 0 to 1.00
- Multiple curves representing concentrations from 0.5 μM to 30 μM
- Shows increasing peak absorbance with increasing concentration, maintaining the same peak wavelength

Graph D: Concentration vs. Absorbance calibration curve
- X-axis: Concentration (μM), ranging from 0 to 30 μM
- Y-axis: Absorbance (a.u.), ranging from 0.2 to 1.0
- Data points with error bars and a linear fit
- Equation of the linear fit: Abs(λmax) = 0.021C + 0.853
- R² value: 0.996, indicating a strong linear correlation

This set of graphs provides a comprehensive analysis of the absorbance characteristics of a chemical species, including its time-dependent behavior, spectral properties, concentration-dependent effects, and quantitative relationship between concentration and absorbance.</DESCRIPTION_FROM_IMAGE>

Fig. 5 The Time-dynamics scanning spectrum (A) and the absorption spectra (B) of TMB + H2O2+ a-Fe2O3@CoNi system with different concentrations of HQ. (C)The absorption spectra of oxTMB with different HQ concentrations. (D)The linear calibration plot for HQ.

H2O2, and a-Fe2O3@CoNi were gradually reduced upon the addition of HQ. A good linear relationship (R2 ¼ 0.996) was obtained when plotting the absorbance at 652 nm against the HQ concentration range of 0.50–30 mM. The detection limit 0.16 mM (0.018 mg L-1 ) is lower than the U.S. Environment Protection Agency estimated wastewater discharge limit of 0.5 mg L-1 . Compared with other methods (Table S2†), our approach has a higher sensitivity for HQ detection. The selective response of the proposed method for HQ detection over other ions and molecules was evaluated in the aqueous solutions containing TMB, H2O2 and a-Fe2O3@CoNi, 20-fold of potential interference species, including Fe3+, Cd2+, Ca2+, Mn2+, Mg2+, Cu2+, Co2+, Zn2+, Cl-, SO4 2-, NO3 -, glucose, catechol, resorcinol, phenol, onitrophenol, p-nitrophenol, and glycine. Changes of the UV-vis absorbance ((A0 - A)/A0) were determined aer 1 min incubation and presented in Fig. 6. As shown in Fig. 6, no signicant changes in (A0 - A)/A0 were observed upon the addition of ions and molecules except HQ. Catechol has a similar structure to hydroquinone, which might interfere the HQ detection (Fig. S7†). The interference from catechol may be minimized by using activated alumina as it has been reported that activated alumina can adsorb catechol. The optimum amount of alumina used was explored to not interfere with the detection of HQ while adsorbing catechol and the results are shown in Fig. S8.† **[View Article Online](https://doi.org/10.1039/d1ra03456a)**

#### Further understanding of the detection mechanism

According to previous reports, the catalytic mechanism of nanozymes can be divided into two categories: one is the transfer of electrons between the substrate and H2O2, and the other is the active substance in the catalytic system.38,47 In order to study the catalytic mechanism, isopropanol (IPA) was added to the solution containing TMB, H2O2, and a-Fe2O3@CoNi. As a hydroxyl radical scavenger, IPA was oen used to detect hydroxyl radicals in the oxidation process.48 As shown in Fig. S9,† the absorption at 652 nm is signicantly reduced aer adding IPA (10 mM), which proves the generation of hydroxyl

<DESCRIPTION_FROM_IMAGE>The image contains two main components: a bar graph and an inset photograph.

Bar Graph:
The graph shows the relative absorbance (|A0-A|/A0) for 19 different samples, labeled 'a' through 's' on the x-axis. The y-axis ranges from 0 to 1.0. Sample 'a' shows the highest absorbance, with a value very close to 1.0. All other samples (b through s) show significantly lower absorbance values, mostly below 0.1. There is a slight increase in absorbance for the last few samples (p, q, r, s), with 's' showing the second highest value, though still much lower than 'a'. Error bars are visible on each bar, indicating the precision of the measurements.

Inset Photograph:
The inset shows a circular arrangement of 19 small vials or tubes containing liquid. The liquids appear to vary in intensity, with the leftmost vial (labeled 'a') being the most intense, and the intensity gradually decreasing clockwise around the circle to 's'. This arrangement corresponds to the samples in the bar graph.

A red arrow is superimposed on the photograph, pointing from 'a' to 's', indicating the direction of the sample sequence.

Interpretation:
This image likely represents a colorimetric assay or spectrophotometric analysis of 19 different samples. Sample 'a' shows the strongest response or highest concentration of the analyte, while the other samples show much lower responses. The circular arrangement of vials provides a visual representation of the quantitative data shown in the bar graph, allowing for quick qualitative assessment of the samples' relative intensities.</DESCRIPTION_FROM_IMAGE>

Fig. 6 Effect of several metal ions and molecules on the chromogenic system and corresponding photograph (inset). From a to s are hydroquinone, glycine, resorcinol catechol, phenol, o-nitrophenol, pnitrophenol, glucose, Zn2+, Co2+, Cu2+, Mg2+, Mn2+, Cl-, SO4 2-, NO3 -, Ca2+, Cd2+, Fe3+, respectively.

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a chemical reaction or process involving several compounds and intermediates. The background suggests an aqueous environment, indicated by water droplets.

The main components and their relationships are as follows:

1. TMB (3,3',5,5'-Tetramethylbenzidine): Represented on the left side. SMILES: Cc1cc(C)c(Nc2ccc(N)c(C)c2C)cc1C

2. oxTMB (oxidized TMB): Shown adjacent to TMB. This is the oxidized form of TMB.

3. α-Fe2O3@CoNi: Depicted in the center as a cluster of spheres, representing iron oxide nanoparticles doped or coated with cobalt and nickel.

4. H2O2 (Hydrogen peroxide): Shown above the central cluster. SMILES: OO

5. •OH (Hydroxyl radical): Depicted to the right of H2O2. SMILES: [OH]

6. HQ (Hydroquinone): Shown on the right side. SMILES: Oc1ccc(O)cc1

7. PBQ (p-Benzoquinone): Depicted below HQ. SMILES: O=C1C=CC(=O)C=C1

The arrows in the diagram suggest the following process:
1. TMB is oxidized to oxTMB.
2. The α-Fe2O3@CoNi nanoparticles interact with H2O2 to produce •OH radicals.
3. The •OH radicals then interact with HQ, converting it to PBQ.

This schematic likely represents a catalytic process where the α-Fe2O3@CoNi nanoparticles act as a catalyst for the decomposition of H2O2, generating hydroxyl radicals. These radicals then oxidize hydroquinone to p-benzoquinone. The TMB oxidation may be a parallel process or an indicator reaction.</DESCRIPTION_FROM_IMAGE>

Fig. 7 Colorimetric sensing mechanism of HQ.

Table 1 Analytical results of the HQ determination in spiked samples

| Sample             | Added (mM) Found (mM) |                   |        | Recovery (%) RSD (%, n ¼ 5) |
|--------------------|-----------------------|-------------------|--------|-----------------------------|
| Tap water          | 2.50                  | 2.57  0.08        | 102.8% | 1.75                        |
|                    | 7.50                  | 6.85  0.06        | 91.3%  | 1.75                        |
|                    | 22.50                 | 21.07  0.02 93.6% |        | 4.60                        |
| Jialing water 2.50 |                       | 2.53  0.09        | 101.2% | 4.94                        |
|                    | 7.50                  | 7.27  0.03        | 96.9%  | 3.63                        |
|                    | 22.50                 | 22.44  0.01 99.7% |        | 4.47                        |

radicals (cOH). At the same time, electron spin resonance (ESR) spectroscopy is used to explore the reaction mechanism and the active free radicals generated during the reaction. As shown in Fig. 2B, a characteristic signal peak of DMPO-HOc with an intensity of 1 : 2 : 2 : 1 was generated aer the addition of a-Fe2O3@CoNi, indicating that a-Fe2O3@CoNi can catalyze H2O2 to produce cOH.49 Based on the experimental results and previous reports, the mechanism of the peroxide-like activity of a-Fe2O3@CoNi was proposed and illustrated in Fig. 7. H2O2 is rst adsorbed on the surface of a-Fe2O3@CoNi, and then a-Fe2O3@CoNi promotes the decomposition of H2O2 to produce cOH, which can further oxidize TMB and produce blue substances. The addition of HQ reduces oxTMB to TMB, which is oxidized to p-benzoquinone.

#### Determination of HQ in real samples

To validate the feasibility of the proposed method for HQ colorimetric detection in tap water and river water, HQ was spiked into them, and the concentration of HQ was measured thereaer. As shown in Table 1, the recoveries of HQ in spiked samples were in the range of 91.3–102.8%, with RSDs <5%. Such results demonstrated that the proposed method has good accuracy and precision for HQ detection in spiked water samples.

### Conclusions

Sweetsop-like a-Fe2O3@CoNi prepared by hydrothermal method was characterized by SEM, TEM, XRD, and XPS. An

efficient and convenient HQ quantitative detection method was developed based on the peroxidase-like activity of a-Fe2O3@- CoNi. This developed colorimetric method for HQ detection exhibited high sensitivity (detection limit 0.16 mM) and selectivity and was validated via spiked water samples. **[View Article Online](https://doi.org/10.1039/d1ra03456a)**

## Conflicts of interest

There are no conicts to declare.

### Acknowledgements

This work was nancially supported by the National Natural Science Foundation of China (21777130, 41807210), the Natural Science Foundation of Sichuan Province of China (2019YJ0522, 2018JY0184), the Meritocracy Research Funds of China West Normal University (463132) and the Fundamental Research Funds of China West Normal University (416390).

### Notes and references

- 1 R. Li, Z. Li, G. Wang and Z. Gu, Sens. Actuators, B, 2018, 276, 404–412.
- 2 J. Ahmed, M. M. Rahman, I. A. Siddiquey, A. M. Asiri and M. A. Hasnat, Sens. Actuators, B, 2018, 256, 383–392.
- 3 Y. Wee, S. Park, Y. H. Kwon, Y. Ju, K. M. Yeon and J. Kim, Biosens. Bioelectron., 2019, 132, 279–285.
- 4 H. Wang, Q. Hu, Y. Meng, Z. Jin, Z. Fang, Q. Fu, W. Gao, L. Xu, Y. Song and F. Lu, J. Hazard. Mater., 2018, 353, 151– 157.
- 5 H. Wang, R. Li and Z. Li, Electrochim. Acta, 2017, 255, 323– 334.
- 6 Y. Liu, Q. Wang, S. Guo, P. Jia, Y. Shui, S. Yao, C. Huang, M. Zhang and L. Wang, Sens. Actuators, B, 2018, 275, 415– 421.
- 7 C. Lou, T. Jing, J. Zhou, J. Tian, Y. Zheng, C. Wang, Z. Zhao, J. Lin, H. Liu, C. Zhao and Z. Guo, Int. J. Biol. Macromol., 2020, 149, 1130–1138.
- 8 D. Balram, K. Y. Lian and N. Sebastian, Ultrason. Sonochem., 2019, 58, 104650–104673.
- 9 D. L. Huang, J. Wang, F. Cheng, A. Ali, H. S. Guo, X. Ying, L. P. Si and H. Y. Liu, Microchim. Acta, 2019, 186, 381–392.
- 10 R. Huang, D. Liao, S. Chen, J. Yu and X. Jiang, Sens. Actuators, B, 2020, 320, 128386–128395.
- 11 D. Cheaib, N. El Darra, H. N. Rajha, I. El-Ghazzawi, Y. Mouneimne, A. Jammoul, R. G. Maroun and N. Louka, Antioxidants, 2018, 7, 174–186.
- 12 Q. Zhou, M. Lei, Y. Wu, X. Zhou, H. Wang, Y. Sun, X. Sheng and Y. Tong, Chemosphere, 2020, 238, 124621–124627.
- 13 Y. Wang, Q. Yue, L. Tao, C. Zhang and C. Z. Li, Microchim. Acta, 2018, 185, 550–559.
- 14 X. Wang, Z. Cheng, Y. Zhou, S. K. Tammina and Y. Yang, Microchim. Acta, 2020, 187, 350–358.
- 15 Y. Liu, Y. Cao, T. Bu, X. Sun, T. Zhe, C. Huang, S. Yao and L. Wang, Microchim. Acta, 2019, 186, 399–407.
- 16 Q. Ye, F. Yan, D. Kong, J. Zhang, X. Zhou, J. Xu and L. Chen, Sens. Actuators, B, 2017, 250, 712–720.

- 17 Y. Chao, X. Zhang, L. Liu, L. Tian, M. Pei and W. Cao, Microchim. Acta, 2014, 182, 943–948.
- 18 S. Xu, J. Li, X. Li, M. Su, Z. Shi, Y. Zeng and S. Ni, Microchim. Acta, 2015, 183, 667–673.
- 19 Z. Y. Lin, Y. C. Kuo, C. J. Chang, Y. S. Lin, T. C. Chiu and C. C. Hu, RSC Adv., 2018, 8, 19381–19388.
- 20 H. Yang, M. Xiao, W. Lai, Y. Wan, L. Li and H. Pei, Anal. Chem., 2020, 92, 4990–4995.
- 21 Z. Gao, G. G. Liu, H. Ye, R. Rauschendorfer, D. Tang and X. Xia, Anal. Chem., 2017, 89, 3622–3629.
- 22 L. Zhi, X. Zeng, H. Wang, J. Hai, X. Yang, B. Wang and Y. Zhu, Anal. Chem., 2017, 89, 7649–7658.
- 23 N. Luo, Z. Yang, F. Tang, D. Wang, M. Feng, X. Liao and X. Yang, ACS Appl. Nano Mater., 2019, 2, 3951–3959.
- 24 L. Zhang, X. Hai, C. Xia, X. W. Chen and J. H. Wang, Sens. Actuators, B, 2017, 248, 374–384.
- 25 X. Li, J. Li, J. Zhu, S. Hao, G. Fang, J. Liu and S. Wang, Chem. Commun., 2019, 55, 13458–13461.
- 26 F. Tian, J. Zhou, B. Jiao and Y. He, Nanoscale, 2019, 11, 9547– 9555.
- 27 X. Wang, L. Qin, M. Lin, H. Xing and H. Wei, Anal. Chem., 2019, 91, 10648–10656.
- 28 Y. Liu, H. Jin, W. Zou and R. Guo, RSC Adv., 2020, 10, 28819– 28826.
- 29 X. Wang, L. Qin, M. Zhou, Z. Lou and H. Wei, Anal. Chem., 2018, 90, 11696–11702.
- 30 M. Liang, Y. Wang, K. Ma, S. Yu, Y. Chen, Z. Deng, Y. Liu and F. Wang, Small, 2020, 16, 2002348–2002357.
- 31 M. Liang and X. Yan, Acc. Chem. Res., 2019, 52, 2190–2200.
- 32 L. Gao, J. Zhuang, L. Nie, J. Zhang, Y. Zhang, N. Gu, T. Wang, J. Feng, D. Yang, S. Perrett and X. Yan, Nat. Nanotechnol., 2007, 2, 577–583.
- 33 B. Liu and J. Liu, Nano Res., 2017, 10, 1125–1148.
- 34 X. Shen, W. Liu, X. Gao, Z. Lu, X. Wu and X. Gao, J. Am. Chem. Soc., 2015, 137, 15882–15891.
- 35 C. Huang, J. Dong, W. Sun, Z. Xue, J. Ma, L. Zheng, C. Liu, X. Li, K. Zhou, X. Qiao, Q. Song, W. Ma, L. Zhang, Z. Lin and T. Wang, Nat. Commun., 2019, 10, 2779–2789.
- 36 X. Qu, H. Sun, Y. Zhou and J. Ren, Angew. Chem., Int. Ed., 2018, 57, 9224–9237.
- 37 L. Gao, K. Fan and X. Yan, Theranostics, 2017, 7, 3207–3227.
- 38 S. Zhang, D. Zhang, X. Zhang, D. Shang, Z. Xue, D. Shan and X. Lu, Anal. Chem., 2017, 89, 3538–3544.
- 39 L. Zhi, W. Zuo, F. Chen and B. Wang, ACS Sustainable Chem. Eng., 2016, 4, 3398–3408.
- 40 X. Wang, M. Zhao, Y. Song, Q. Liu, Y. Zhang, Y. Zhuang and S. Chen, Sens. Actuators, B, 2019, 283, 130–137.
- 41 Q. Zhang, N. M. Bedford, J. Pan, X. Lu and R. Amal, Adv. Energy Mater., 2019, 9, 1901312–1901325.
- 42 O. F. Odio, L. Lartundo-Rojas, P. Santiago-Jacinto, R. Mart´ınez and E. Reguera, J. Phys. Chem. C, 2014, 118, 2776–2791.
- 43 L. Yang, D. Wang, Y. Lv and D. Cao, Carbon, 2019, 144, 8–14.
- 44 M. K. Masud, S. Yadav, M. N. Islam, N. T. Nguyen, C. Salomon, R. Kline, H. R. Alamri, Z. A. Alothman, Y. Yamauchi, M. S. A. Hossain and M. J. A. Shiddiky, Anal. Chem., 2017, 89, 11005–11013.

- 45 D. Yi, Z. Wei, W. Zheng, Y. Pan, Y. Long and H. Zheng, Sens. Actuators, B, 2020, 323, 128691–128697.
- 46 M. Ivanova, E. Grayfer, E. Plotnikova, L. Kibis, G. Darabdhara, P. Boruah, M. Das and V. Fedorov, ACS Appl. Mater. Interfaces, 2019, 22102–22112.
- 47 J. Liang, H. Li, J. Wang, H. Yu and Y. He, Anal. Chem., 2020, 92, 6548–6554.
- 48 L. Jiao, J. Wu, H. Zhong, Y. Zhang, W. Xu, Y. Wu, Y. Chen, H. Yan, Q. Zhang, W. Gu, L. Gu, S. P. Beckman, L. Huang and C. Zhu, ACS Catal., 2020, 10, 6422–6429. **[View Article Online](https://doi.org/10.1039/d1ra03456a)**
  - 49 X. Huang, F. Xia and Z. Nan, ACS Appl. Mater. Interfaces, 2020, 12, 46539–46548.