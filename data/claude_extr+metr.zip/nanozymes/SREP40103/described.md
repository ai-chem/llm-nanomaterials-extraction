## **OPEN**

received: 18 October 2016 accepted: 30 November 2016 Published: 04 January 2017

# **AuPt Alloy Nanostructures with Tunable Composition and Enzymelike Activities for Colorimetric Detection of Bisulfide**

**Weiwei He1, Xiangna Han1, Huimin Jia1, JunhuiCai1, Yunlong Zhou2,3 & Zhi Zheng1**

**Tuning the enzyme-like activity and studying the interaction between biologically relevant species and nano-enzymes may facilitate the applications of nanostructures in mimicking natural enzymes. In this work, AuPt alloy nanoparticles (NPs) with varying compositions were prepared through a facile method by co-reduction of Au3+ and Pt2+ in aqueous solutions. The composition could be tuned easily by adjusting the molar ratios of added Pt2+ to Au3+. It was found that both peroxidase-like and oxidase-like activity of AuPt alloy NPs were highly dependent on the alloy compositions, which thus suggesting an effective way to tailor their catalytic properties. By investigating the inhibitory effects of HS− on the enzyme-like activity of AuPt alloy NPs and natural enzyme, we have developed a method for colorimetric detection of HS− and evaluation of the inhibiting effects of inhibitors on natural and artificial enzymes. In addition, the responsive ability of this method was influenced largely by the composition: AuPt alloy NPs show much lower limit of detection for HS− than Pt NPs while Pt NPs show wider linear range than AuPt alloy NPs. This study suggests the facile way not only for synthesis of alloy nanostructures, but also for tuning their catalytic activities and for use in bioanalysis.**

Nanostructured artificial enzymes, an emerging class of enzyme mimics, have received enormous interest due to their robust and efficient activities and potential applications ranging from biosensing and food processes to environmental protection and beyond[1,](#page-8-0)[2](#page-8-1). Compared with natural enzymes, nanostructured artificial enzymes have several advantages, such as easy synthesis, facile storage and high catalytic stability against stringent conditions. Until now, a variety of nanomaterials, including metal oxide[s3–5,](#page-8-2) metal sulfide[s6](#page-8-3)[,7](#page-8-4), noble metal[s8–11,](#page-8-5) carbo[n12](#page-8-6)[,13,](#page-8-7) and their combined nanostructures[14,](#page-8-8)[15](#page-8-9) have been explored to exhibit enzyme-like activities. Because of the quantum size and surface effect, nanoparticles generally exhibit superior catalytic activity and intrinsic ability to generate or scavenge reactive oxygen species[16–18.](#page-8-10) These properties are likely responsible for the mechanism by which the NPs mimic the catalytic activity of natural enzymes.

Metal NPs based enzyme mimetics have attracted particular attentions because of their defined mechanism, well-developed synthesis techniques, easy modification of surface and good bio-compatibility[19–21](#page-8-11). Several metal nanomaterials (e.g., Pt, Au, Pd, Ir) have been discovered for their intrinsic enzyme-like activities[8–11.](#page-8-5) Among them, Pt family NPs recently have been found to exhibit multiple enzyme-like activities similarly to peroxidase, polyphenol oxidase, ferroxidase, catalase and SOD[9](#page-8-12),[22–24](#page-8-13). Bimetallic or multi-metallic nanostructures having unique properties dependent on structures and compositions can provide more versatile ways to optimize the enzyme-like activities than monometallic one[s25–28.](#page-9-0) Zhang and coworkers have prepared Au@PtPd multi-component core/shell nanorods exhibiting tunable oxidase-like activity that was used for sensitive detection of Fe2+ ions[26.](#page-9-1) Wang's group has reported that PtCo bimetallic nanoparticles not only can be facilitated for magnetic separation, but also showed significantly improved oxidase-like activity for cancer-cell detectio[n27.](#page-9-2) FeCo NPs were also found the much higher enzyme-mimic activity than other NPs-based peroxidase mimetics due to the synergistic effects[28](#page-9-3). The active and tunable enzyme-like activity may make bimetallic NPs potential

1 Key Laboratory of Micro-Nano Materials for Energy Storage and Conversion of Henan Province, College of Advanced Materials and Energy, Institute of Surface Micro and Nano Materials, Xuchang University, Henan 461000, P.R. China. 2Wenzhou Institute of biomaterials and engineering, CNITECH, CAS, Zhejiang 325001, P.R. China. 3Institute of biomaterials and engineering, Wenzhou Medical University, Zhejiang 325001, P.R. China. Correspondence and requests for materials should be addressed to W.H. (email: [heweiweixcu@gmail.com](mailto:heweiweixcu@gmail.com)) or Y.Z. (email: [zhouyl@wibe.ac.cn](mailto:zhouyl@wibe.ac.cn))

valuable in bio-detections. In light of these findings and the unique properties of bimetallic NPs, a number of potential applications still remain to be explored that exploit the enzyme-mimicking functions of alloy NPs. For example, AuPt bimetallic nanostructures have exhibited intrinsic multiple enzyme-like activities, but most of these works involved AuPt bimetallic nanostructures rather than AuPt alloy nanoparticles[9](#page-8-12)[,22](#page-8-13)[,24](#page-8-14)[,29–31.](#page-9-4) The study on AuPt alloy nanoparticles for tailoring their chemical compositions to fine tune the oxidase and peroxidase-like activity and sensing capability for biodetection are limited. This knowledge will facilitate our understanding in depth the activity and applications of nanoenzymes.

In this study, we will take AuPt alloy NPs as an example to investigate their oxidase-like and peroxidase-like activities, and study the interaction with enzyme inhibitors for colorimetric detection. Especially, we will investigate systematically the effects of alloy compositions on both the enzyme-like activity and the sensing performance to enzyme inhibitors. We have developed a very simple yet effective way to prepare AuPt alloy nanostructures having porous structure and tunable composition. The oxidase-like and peroxidase-like activity of AuPt alloy NPs were found correlate closely with the compositions of Au and Pt. Furthermore, bisulfide (HS−) was selected as model to study its interactive behavior with enzymes or nanoenzymes because HS− is an important gasotransmitter along with nitric oxide and carbon monoxide for biological signaling[32.](#page-9-5) HS− can inhibit effectively the peroxidase and oxidase like activity of AuPt bimetallic NPs. This inhibiting effect was same to the effect on nature enzyme horseradish peroxidase (HRP). The inhibitory degree was dependent on the concentration of HS−. Based on this finding, a facile method for colorimetric detection of HS− was proposed with high sensitivity. The alloy of Au with Pt shows a large effect on the linear range and limit of detection for HS−.

#### **Results and Discussion**

AuPt alloy NPs were prepared by the co-reduction of AuCl4 − and PtCl4 2− with ascorbic acid in water. [Figure 1](#page-2-0)  shows typical TEM images and the electron diffraction pattern of Au0.5Pt0.5 alloy nanostructures with an Au/Pt molar ratio of 1/1. The as-prepared AuPt alloy NPs have a spherical dendritic shape and a porous structure. They are well dispersed in solution. The average diameter of the Au0.5Pt0.5 alloy NPs was calculated from 50 random particles to be 23.6± 2.3 nm. The HRTEM further indicates the dendritic structure of the Au0.5Pt0.5 alloy NPs and the well-defined lattice planes ([Fig. 1b)](#page-2-0). The calculated lattice spacing of the (111) facet is 0.231 nm, which falls between the values for pure Au (0.235nm) and Pt (0.228nm). This intermediate lattice spacing indicates the formation of an AuPt alloy structure. In the single particle, the orientation of the [111] plane differs in different part of the particle, indicating that the formation of the AuPt alloy may go through the attachment mechanism from smaller nanodots. The ED pattern shows that the diffraction spots are superimposed on the rings, which is consistent with the polycrystalline structure of single AuPt particle. The elemental distribution of Pt and Au in the nanoparticle was measured by STEM-EDX mapping of a single particle [(Fig. 1d and e](#page-2-0)). The line profiles of Au and Pt in the selected particle show that Pt and Au are homogeneously mixed in the nanoparticle which further supports the formation of an AuPt alloy structure.

By changing the molar ratio of added Au3+/Pt2+, the morphology and the alloy compositions of AuPt nanoparticles can be controlled. [Figure 2](#page-3-0) shows that the shape of AuPt alloy NPs is highly dependent on the Au/Pt molar ratio. Pure Au NPs have irregular shapes with a solid structure and a smooth surface [(Fig. 2a](#page-3-0)). The addition of Pt induces the formation of spherical NPs with a scraggly structure at a low Pt/Au ratio (0.33). Increasing the Pt/Au ratios from 0.33 to 6 produces a more condensed and porous structure, and obviously increases the particle size of AuPt alloy NPs. The particle sizes of particles with different Pt/Au ratios were calculated (see Supplementary Fig. S1). It was found that a higher Pt content produced larger particles, e.g. the diameter changed from 20nm when the Pt/Au ratio was 1/3 to 40nm when the Pt/Au ratio was 6/1. The presence of both Au and Pt in the particle also gave a larger particle size distribution (see Supplementary Fig. S1). AuPt alloy NPs with an Au/ Pt ratio of 1/1 and 1/3 showed a narrower size distribution compared to other cases. These results indicated that the porous morphologies and particle size of AuPt alloy NPs can be subtly controlled by adjusting the Au/Pt ratio. Why such a simple method can produce uniform AuPt alloy NPs with dendritic structures? The reasons may be due to that the high bond dissociation energies and the large lattice mismatch (3.8%) between Au and Pt tend to favor the island growth mod[e33](#page-9-6). In addition, the residual ascorbic acid and oxidized product, e.g. dehydroascorbic acid, may play a protective role in regulating the growth since no additional surfactant was added during the AuPt formation process[34.](#page-9-7)

Apart from the morphology, varying the amount of added Pt2+/Au3+ also greatly influenced the alloy content in AuPt alloy NPs. The elemental Au and Pt content in prepared AuPt alloy NPs were measured by energy dispersive X-ray analysis ([Fig. 3)](#page-3-1). The measured Pt content linearly increased and the Au content linear decreased with the increasing addition of Pt2+ from 0 to 100%. The two linear relationships have a slope near 1.0 or −1.0 which indicates a complete reduction of Au3+ and Pt2+ to form the AuPt alloy NPs. The linear relationship also reflects that the alloy composition can be tuned by changing the amount of Pt2+/Au3+ that is added.

The formation of AuPt alloy NPs was also verified from UV-Vis absorption spectroscopy (see Supplementary Fig. S2). The pure Au NPs show a typical absorption band at 520 nm due to their surface plasmonic resonance property. The formation of bimetallic NPs as Pt is added leads to a less evident absorption band which disappeared gradually on higher Pt loading. The disappearance of this band indicates the formation of an alloy structure. The XRD patterns further confirmed the formation of AuPt alloy ([Fig. 4)](#page-4-0). The diffraction peaks from the Au, the Pt and the AuPt NPs with various Au/Pt ratios indicates that all of the samples have a face center cubic phase. The 2θ degree of diffraction peaks (111) and (200) from the AuPt NPs fall between the corresponding 2θ degree in the Au and Pt NPs. These phases are gradually shifted upon increasing the Au/ Pt ratio which indicates the change of alloy degree. The d-value of plane (111) was calculated from the XRD pattern by the Debye-Scherrer equation:

<DESCRIPTION_FROM_IMAGE>This image is a composite of five different microscopy and analytical techniques used to characterize nanoparticles, likely gold nanoparticles. I'll describe each panel in detail:

a) Transmission Electron Microscopy (TEM) image showing a network of nanoparticles. The particles appear as dark spots against a lighter background, forming chain-like structures. The scale bar indicates 100 nm.

b) High-Resolution TEM (HRTEM) image of a single nanoparticle. The lattice fringes are visible, indicating crystallinity. Two measurements are shown: 0.231 nm and 0.204 nm, which likely correspond to specific crystal plane spacings in the nanoparticle. The scale bar indicates 5 nm.

c) Selected Area Electron Diffraction (SAED) pattern. This shows concentric rings of bright spots, typical of polycrystalline materials. Three rings are labeled: (111), (200), and (220), which correspond to Miller indices of face-centered cubic (FCC) crystal structures, common in gold nanoparticles. The scale bar indicates 2 1/nm.

d) Dark-field Scanning Transmission Electron Microscopy (STEM) image. This shows the nanoparticles as bright spots against a dark background, highlighting their arrangement. A scale bar of 50 nm is provided.

e) A graph showing elemental line profiles, likely from Energy Dispersive X-ray Spectroscopy (EDS) or Electron Energy Loss Spectroscopy (EELS). The x-axis represents Position (nm) from 0 to 50 nm, and the y-axis shows Counts from 0 to 150. Two overlapping profiles are shown: Pt-L (red) and Au-M (green). These likely represent platinum and gold signals, suggesting the nanoparticles may be composed of both elements or have a core-shell structure.

This comprehensive characterization provides information about the nanoparticles' size, shape, crystal structure, and elemental composition, which are crucial for understanding their properties and potential applications in catalysis or other fields of nanotechnology.</DESCRIPTION_FROM_IMAGE>

<span id="page-2-0"></span>**Figure 1.** A typical (**a**) low-magnification TEM and (**b**) HRTEM image of AuPt nanostructures with an Au/Pt ratio of 1:1, (**c**) an ED pattern of a single particle in b, (**d**) a STEM HAADF image and (**e**) the STEM-EDX crosssection composition line profiles of the particle marked in (**d**).

#### D / = *Kλ β* cos *θ*

where K is the Scherrer constant, *λ* is the X-ray wavelength, *β* is the line broadening at half the maximum intensity (FWHM), and *θ* is the Bragg angle. The d-values of the AuPt NPs at various Au/Pt ratios all fell between the Au (111) of 0.235nm and the Pt (111) of 0.224nm. They show a quasi-linear relationship with the calculated Pt/ (Au+Pt) ratio. Therefore, the degree of alloying and the crystal structures of the AuPt NPs are closely correlated to the Au/Pt ratio of added salts.

Au and Pt nanoparticles have achieved activities similar to those of enzymes in some reactions. For example, small Pt or Au NPs (e.g. <5nm) have been shown to mimic multiple enzymes (i.e. peroxidase, oxidase, catalase and SOD) for a variety of applications[8](#page-8-5),[9.](#page-8-12) It would be interesting, then, if varying the alloy composition of the AuPt alloy nanostructures could tune the enzyme-like activities of these catalysts. For proof of this concept, the AuPt alloy NPs with varied composition were subjected to reaction conditions typical for peroxidase and oxidase enzymes and the activities of the NPs were compared. 3,3,5,5-Tetramethylbenzidine (TMB) is a chromophoric substrate commonly used in nano-peroxidase mimetic studies and was chosen as a substrate to be oxidized in this studies. Pt NPs and AuPt NPs with various Au/Pt ratios can quickly catalyze the oxidation of TMB to produce a typical blue color either in the presence or absence of hydrogen peroxide ([Fig. 5a,](#page-5-0) color changes in H2O2 not shown). Control reactions in the absence of AuPt alloy NPs were performed and showed negligible color changes over the same time period, implying that the AuPt alloy NPs, similar to natural oxidase and peroxidase, are responsible for the oxidation of TMB. While previous reports have shown that Au NPs have peroxidase-like activit[y8](#page-8-5) , the Au NPs herein do not mimic peroxidases or oxidases. This may be due to the larger particle size of Au NPs formed in this work (>30nm). [Figure 5a–c](#page-5-0) show the activities of the AuPt alloy NPs used in this reaction. It was found that the catalytic activities of the AuPt alloy NPs increased with an increasing Pt/Au ratio. The reaction

<DESCRIPTION_FROM_IMAGE>This image presents a series of six transmission electron microscopy (TEM) micrographs labeled from (a) to (f), showing the evolution of nanoparticle morphology. The scale bar in image (a) and (f) indicates 20 nm.

(a) Smooth, spherical nanoparticles with diameters ranging from approximately 20-30 nm. The particles appear solid and uniform in density.

(b) Slightly rougher nanoparticles with a more irregular shape, still roughly spherical but with some surface texturing. The particles are similar in size to those in (a).

(c) Nanoparticles with a distinct core-shell structure. The core appears denser, while the shell shows a fuzzy, less dense appearance. The overall particle size is similar to (b).

(d) Further development of the core-shell structure, with the shell becoming more prominent and appearing more porous or branched. The overall particle size has increased slightly.

(e) Larger nanoparticles with a very prominent and well-developed porous or branched shell structure. The core is still visible but occupies a smaller proportion of the total particle volume.

(f) The largest nanoparticles in the series, with a highly developed, porous/branched outer structure. The core is barely distinguishable, and the overall particle morphology resembles a dendritic or flower-like structure.

This series of images likely represents a time-course or reaction progression showing the transformation of solid nanoparticles into more complex, hierarchical structures. The evolution suggests a process of surface etching or growth that results in the formation of a porous outer layer while maintaining a core structure. This type of morphological evolution is often seen in the synthesis of catalytic nanoparticles or in the preparation of high surface area materials for applications such as energy storage or chemical sensing.</DESCRIPTION_FROM_IMAGE>

<span id="page-3-0"></span>**Figure 2.** TEM images of (**a**) pure Au nanoparticles, AuPt bimetallic nanostructures with an Au/Pt molar ratio of (**b**) 3/1, (**c**) 1/1, (**d**) 1/3, (**e**) 1/6, and (**f**) Pt nanoparticles prepared under the same conditions. All the scale bars are 20nm.

<DESCRIPTION_FROM_IMAGE>This image presents a graph showing the relationship between the calculated platinum (Pt) content and the measured platinum and gold (Au) content in AuPt nanoparticles (NPs) as determined by Energy-Dispersive X-ray spectroscopy (EDX).

The x-axis represents the "Calculated Pt content (%) of AuPt NPs", ranging from 0% to 100%.

The y-axis shows the "Measured Pt (Au) content by EDX (%)", also ranging from 0% to 100%.

Two data series are plotted:

1. Au content (represented by black half-filled circles): This shows a decreasing trend as the calculated Pt content increases. The Au content starts at nearly 100% when the calculated Pt content is 0%, and decreases linearly to about 0% when the calculated Pt content reaches 100%.

2. Pt content (represented by red filled circles): This shows an increasing trend as the calculated Pt content increases. The Pt content starts at about 0% when the calculated Pt content is 0%, and increases linearly to about 100% when the calculated Pt content reaches 100%.

The two trend lines intersect at approximately 50% calculated Pt content, where both the measured Au and Pt contents are around 50%.

This graph demonstrates a clear inverse relationship between the Au and Pt content in the AuPt nanoparticles. As the calculated Pt content increases, the measured Pt content increases proportionally, while the measured Au content decreases proportionally. This suggests a consistent composition control in the synthesis of these bimetallic nanoparticles, with the EDX measurements closely matching the calculated (intended) compositions.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image presents a graph titled "Figure 3. The measured Pt or Au content in AuPt nanostructures by EDX analysis as a function of the calculated Pt content (%) in AuPt nanostructures."

This graph shows the relationship between the calculated and measured content of platinum (Pt) and gold (Au) in AuPt nanostructures, as determined by Energy-Dispersive X-ray (EDX) analysis.

The graph contains two data series:

1. Measured Pt content (represented by black squares)
2. Measured Au content (represented by white circles)

X-axis: Calculated Pt content (%) in AuPt nanostructures
Range: 0% to 100%

Y-axis: Measured Pt or Au content (%) by EDX analysis
Range: 0% to 100%

The graph shows a clear trend for both Pt and Au:

1. Pt content: As the calculated Pt content increases from 0% to 100%, the measured Pt content also increases linearly from about 0% to 100%. The data points form a nearly straight line with a positive slope, indicating a strong positive correlation between calculated and measured Pt content.

2. Au content: Conversely, as the calculated Pt content increases from 0% to 100%, the measured Au content decreases linearly from about 100% to 0%. The data points form a nearly straight line with a negative slope, showing a strong negative correlation between calculated Pt content and measured Au content.

The two trend lines intersect at approximately 50% calculated Pt content, where both measured Pt and Au contents are around 50%.

This graph demonstrates that the EDX analysis results closely match the calculated composition of the AuPt nanostructures across the entire range of Pt:Au ratios. This suggests that the synthesis method used to create these nanostructures produces compositions that are very close to the intended ratios.

The close agreement between calculated and measured values indicates high accuracy in both the nanostructure synthesis process and the EDX analysis technique.</DESCRIPTION_FROM_IMAGE>

rates of TMB oxidation both in the absence and in the presence of hydrogen peroxide were calculated and are shown in [Fig. 5d](#page-5-0). The linear relationship between the reaction rates and the AuPt alloy composition confirms that the rates increase with increasing Pt/Au ratio. It is important to note that the oxidation rate of TMB in 0.67 mM H2O2 is twice as fast as when the reaction is run in water. These results indicate that the alloy composition can affect the peroxidase-like and oxidase-like activities of AuPt NPs in the oxidation of TMB.

The apparent kinetic parameters of the AuPt nanostructures as oxidase mimetics for TMB oxidation in the absence of H2O2 were determined. Typical double-reciprocal plots of 1/ν vs. 1/[S] were constructed and fitted to the Michaelis-Menten equation to calculate the Michaelis constant (*Km*) and the maximal reaction velocity (*Vmax*) for the oxidation of TMB (see Supplementary Fig. S3). The values of both *Km* and *Vmax* were found to be highly dependent on the Pt content in the AuPt alloys. A higher Pt content led to an increase of *Km* and *Vmax*. In other words, the AuPt alloy NPs having a higher Au content gave lower *Km* and *Vmax* values. In natural enzymes, *Km* is an

<DESCRIPTION_FROM_IMAGE>The image consists of two graphs labeled a) and b).

Graph a) is an X-ray diffraction (XRD) pattern showing the relative intensity of diffraction peaks for various gold-platinum nanoparticle compositions. The x-axis represents the 2 Theta degree ranging from 30 to 70 degrees. The y-axis shows the relative intensity in arbitrary units (a.u.) from 0 to 4000.

The graph displays XRD patterns for:
1. Au (PDF 1-1172) reference
2. Au NPs
3. Au0.75Pt0.25
4. Au0.5Pt0.5
5. Au0.4Pt0.6
6. Au0.25Pt0.75
7. Au0.15Pt0.85
8. Au0.09Pt0.91
9. Pt NPs
10. Pt (PDF 1-1194) reference

The main peaks are labeled (111), (200), and (220), corresponding to the crystal planes of the face-centered cubic (FCC) structure. As the platinum content increases, the peaks shift towards higher 2 Theta values, indicating a change in lattice parameters.

Graph b) shows the relationship between the d-value of the (111) plane and the Pt content in AuPt nanoparticles. The x-axis represents the Pt content (%) of AuPt NPs, ranging from 0 to 100%. The y-axis shows the d-value of (111) plane in Angstroms (Å), ranging from 2.24 to 2.36 Å.

The graph displays a linear trend (red line) with experimental data points (black hexagons). As the Pt content increases, the d-value of the (111) plane decreases linearly, indicating a contraction of the crystal lattice. This is consistent with Vegard's law for solid solutions.

The linear relationship suggests a uniform distribution of Au and Pt atoms in the nanoparticles across the entire composition range. The d-value decreases from about 2.35 Å for pure Au to about 2.24 Å for pure Pt.</DESCRIPTION_FROM_IMAGE>

<span id="page-4-0"></span>**Figure 4.** (**a**) XRD patterns of prepared Au NPs, Pt NPs and AuPt alloy nanostructures with varying compositions, (**b**) the plot of d-value variation of the (111) plane versus the Pt content in the AuPt nanostructures.

indicator of the affinity between the enzyme and the substrate where a lower *Km* value indicates a higher affinity and catalytic activity. In the case of the nanostructure enzyme mimetics, the *Km* value is often used to compare the enzyme-like performance of the nanostructures[4–6.](#page-8-15) It was found that the AuPt alloy NPs oxidase mimetics with a lower *Km* value were accompanied by lower reaction rates in the oxidation of TMB, indicating the higher affinity of AuPt alloy NPs with substrate than that of Pt NPs. Generally, the specific affinity between substrate and inorganic nanoparticles is much weaker than between substrates and natural enzyme[s35.](#page-9-8) This work indicates that the use of *K*m should be critically cautious to consider for evaluating the enzyme-like capabilities of inorganic nanostructures.

Ascorbic acid (AA) is an essential nutrient and a well-known antioxidant that protects other important biological structures against oxidative damage by many oxidants. Although AA is slowly oxidized by oxygen, the oxidation can be accelerated by the addition of ascorbic acid oxidase (AAO). The intermediate ascorbyl radical is an indicator in this oxidation. In our previous work, we found that Au@Pt core-shell nanostructures behave similarly to AAO and can accelerate the oxidation of AA and reduce their antioxidant ability[24](#page-8-14). The AuPt alloy NPs also showed the intrinsic ability to quickly oxidize AA ([Fig. 6)](#page-5-1). The oxidation of AA to ascorbyl radical is accompanied by a decrease in the characteristic absorption of AA near 260nm. UV-Vis spectroscopy was used to measure this absorption band in order to study the reaction kinetics of the oxidation of AA [(Fig. 6](#page-5-1) insets). AA alone or AA in the presence of Au NPs reacted slowly by dissolved oxygen during the reaction period. However, the oxidation of AA was significantly accelerated upon the addition of Pt NPs and AuPt NPs with various compositions. A clear composition-dependence on catalytic oxidation of AA was observed. A higher Pt/Au ratio in the alloy NPs resulted in a faster AA oxidation. The oxidation rates of AA using different catalysts were calculated [(Fig. 6b](#page-5-1)). The catalytic activities on AA oxidation were linearly proportional to the Pt content in the AuPt alloy NPs. Our experimental results are in remarkable agreement with previous calculations by Wu and coworker[s36](#page-9-9). The mechanisms of the oxidase-like activity of noble metals and their alloys have been studied by using density functional theory calculations. The alloy of Au with Pt decreases the oxidase-like reactivity of Pt due to higher activation energy barriers and positive reaction energies resulted from the addition of high Au content. Our experimental results suggest an effective way to tailor the AAO-like activity of Pt NPs and to diminish the antioxidant potential of AA by changing the elemental composition of the AuPt alloy NPs.

<DESCRIPTION_FROM_IMAGE>The image contains four panels labeled a, b, c, and d, each presenting different aspects of a chemical experiment involving the oxidation of TMB (3,3',5,5'-tetramethylbenzidine) and its interaction with various gold-platinum nanoparticles.

Panel a:
1. Chemical reaction: TMB oxidation
   SMILES for TMB: CC1=CC(=C(C=C1N)C2=CC(=C(C=C2N)C)C)C
   SMILES for Oxidized TMB: CC1=CC(=C(C=C1N)C2=CC(=C(C=C2N)C)C)C

2. Visual representation of the reaction in solution:
   Six vials showing color change from colorless (TMB) to various shades of blue (oxidized TMB) in the presence of different Au-Pt nanoparticle compositions.

Panel b:
Graph showing absorbance at 650 nm vs. reaction time (0-16 min) for different Au-Pt nanoparticle compositions:
- Au: Negligible absorbance increase
- Au0.75Pt0.25: Slight absorbance increase
- Au0.5Pt0.5: Moderate absorbance increase
- Au0.4Pt0.6: Higher absorbance increase
- Au0.25Pt0.75: Significant absorbance increase
- Au0.15Pt0.85: High absorbance increase
- Pt: Highest absorbance increase
- Control: Negligible absorbance increase

Panel c:
Similar graph to panel b, but with extended y-axis range (up to 1.4 a.u.) and slightly different curve shapes, indicating a different experimental condition or replicate.

Panel d:
Graph showing the reaction rate of TMB oxidation vs. Pt/Au ratio (0-6):
- Two datasets: H2O (black) and H2O2 (red)
- Both datasets show a linear increase in reaction rate with increasing Pt/Au ratio
- H2O2 dataset shows a steeper slope (S=0.02) compared to H2O (S=0.01)
- Maximum reaction rate achieved at Pt/Au ratio of 6 for both conditions

This image demonstrates the catalytic activity of Au-Pt nanoparticles in TMB oxidation, with increasing Pt content generally leading to higher reaction rates and absorbance values. The presence of H2O2 enhances the catalytic effect compared to H2O alone.</DESCRIPTION_FROM_IMAGE>

<span id="page-5-0"></span>**Figure 5.** (**a**) Color evolution of TMB oxidation in the absence of hydrogen peroxide catalyzed by different NPs. The absorbance change at 650nm as a function of reaction time during the TMB oxidation catalyzed by different catalysts in the absence (**b**) and in the presence (**c**) of hydrogen peroxide, (**d**) the reaction rate of TMB oxidation in water and in hydrogen peroxide is dependent on the Au/Pt ratio of the AuPt nanoalloy.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled a) and b), presenting data related to the catalytic activity of AuPt nanoparticles (NPs) with varying compositions.

a) This graph shows the absorbance (in arbitrary units, a.u.) versus reaction time (in minutes) for different catalysts:
- Control
- Au
- Au0.75Pt0.25
- Au0.5Pt0.5
- Au0.4Pt0.6
- Au0.25Pt0.75
- Au0.15Pt0.85
- Pt

The graph demonstrates the catalytic activity of these materials over a 20-minute reaction period. The control and pure Au samples show little to no change in absorbance over time. As the Pt content increases in the AuPt NPs, the rate of decrease in absorbance becomes more pronounced, with pure Pt showing the steepest decline.

b) This graph presents the catalytic activity on AA oxidation (min^-1) as a function of Pt content in AuPt NPs. The x-axis ranges from 0 to 1, representing the Pt content, while the y-axis shows the catalytic activity from 0 to 0.06 min^-1. The data points follow a non-linear trend, with catalytic activity increasing as Pt content increases, showing a sharp rise at higher Pt contents.

Two inset graphs are included in b):
1. Top-left inset: Shows absorbance spectra (wavelength range 200-300 nm) with multiple overlapping curves, likely representing different reaction times or Pt contents.
2. Bottom-right inset: Displays a single absorbance spectrum (wavelength range 200-300 nm) with a prominent peak around 260 nm.

These insets likely represent UV-Vis spectra related to the AA (ascorbic acid) oxidation reaction being catalyzed by the AuPt NPs.

The graphs collectively demonstrate the effect of Pt content in AuPt nanoparticles on their catalytic activity for AA oxidation, with higher Pt content generally resulting in improved catalytic performance.</DESCRIPTION_FROM_IMAGE>

<span id="page-5-1"></span>**Figure 6. The effect of alloy composition on the catalytic activity of AuPt NPs toward ascorbic acid oxidation.** (**a**) The normalized absorbance at 257nm as a function of reaction time after the addition of Au NPs, Pt NPs and AuPt alloy NPs with various compositions. (**b**) The dependence of AA oxidation rates on Pt content in the AuPt NPs. Insets in (**b**) show the evolutions of the absorption spectra of AA over time for Au NPs and for Au0.15Pt0.85 alloy NPs.

<DESCRIPTION_FROM_IMAGE>The image presents a graph showing the relationship between the concentration of HS- (hydrosulfide ion) and the reaction rate for three different catalysts: HRP (Horseradish Peroxidase), Pt NPs (Platinum Nanoparticles), and Au0.4Pt0.6 NPs (Gold-Platinum Nanoparticles with a 0.4:0.6 ratio).

The x-axis represents the concentration of HS- in μM (micromolar), ranging from 0 to 35 μM. The y-axis shows the reaction rate in min^-1, ranging from 0 to 0.12 min^-1.

Three curves are plotted, each representing a different catalyst:
1. HRP (black circles): Shows the highest reaction rates, starting at about 0.12 min^-1 at 0 μM HS- and decreasing to about 0.03 min^-1 at 20 μM HS-.
2. Pt NPs (red circles): Exhibits intermediate reaction rates, starting at about 0.09 min^-1 at 0 μM HS- and decreasing to about 0.02 min^-1 at 20 μM HS-.
3. Au0.4Pt0.6 NPs (blue circles): Shows the lowest reaction rates, starting at about 0.015 min^-1 at 0 μM HS- and quickly decreasing to near 0 min^-1 at higher HS- concentrations.

All three curves demonstrate a negative correlation between HS- concentration and reaction rate, with the rate decreasing as HS- concentration increases. The effect is most pronounced for HRP and least for Au0.4Pt0.6 NPs.

The graph is accompanied by an inset image showing four vials containing solutions of decreasing intensity from left to right. The caption indicates "HS increased" from left to right, suggesting that the color change is related to increasing HS- concentration.

This graph illustrates the inhibitory effect of HS- on the catalytic activity of these three systems, with HRP being the most resistant to inhibition and Au0.4Pt0.6 NPs being the most susceptible.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image presents a complex graph illustrating the concentration-dependent effect of HS- (hydrosulfide ion) on inhibiting the activities of the enzyme HRP (likely Horseradish Peroxidase) and nanoparticles of Pt (Platinum) or Au0.4Pt0.6 alloy.

The main graph shows:
- X-axis: Concentration of HS- (μM)
- Y-axis: Relative activity (%)
- Three distinct curves representing:
  1. HRP enzyme
  2. Pt nanoparticles
  3. Au0.4Pt0.6 alloy nanoparticles

The curves demonstrate a decrease in relative activity as the concentration of HS- increases, indicating an inhibitory effect.

Key observations:
1. The HRP enzyme shows the steepest decline in activity, reaching near-zero activity at the highest HS- concentrations.
2. Pt nanoparticles show a more gradual decline in activity compared to HRP.
3. Au0.4Pt0.6 alloy nanoparticles exhibit the least decline in activity, maintaining higher relative activity even at higher HS- concentrations.

Insets: The figure mentions insets showing photographs of TMB (3,3',5,5'-Tetramethylbenzidine) oxidation catalyzed by AuPt NPs (Gold-Platinum nanoparticles) as the concentration of HS- increases. These insets likely demonstrate a visual color change corresponding to the degree of TMB oxidation at different HS- concentrations.

This graph provides insights into the differential sensitivity of these catalytic systems (enzyme and nanoparticles) to HS- inhibition, with potential implications for their use in various applications or as sensors for HS- concentration.</DESCRIPTION_FROM_IMAGE>

From [Figs 5](#page-5-0) and [6,](#page-5-1) it was found the same composition dependence of catalytic activities of AuPt alloy NPs in different catalytic reactions: a higher gold percentage in AuPt alloy NPs leads to more reduction of catalytic activities. This tendency was well consistent with previous reports on AgPt and PdPt alloy nanoparticles[26,](#page-9-1)[37.](#page-9-10) It was recognized that electronic structure of metal NPs plays crucial role in influencing their catalytic activity. Take Pt based bimetallic alloy as example, it has been established that alloying Pt with the 3d-transition metals can tune the d-band center position and consequently change their catalytic performance[38.](#page-9-11) Herein, we proposed that the alloying Pt with Au may change the electronic structure of Pt and the electronic property was influenced largely by the Au content in alloy, which in turn affected the catalytic performance. This hypothesis may require further information for the the electronic structure change of AuPt alloy with varying composition by theoretical calculation.

Hydrogen sulfide has been identified as an important biological molecule with diverse functions in gaseous signaling and pathophysiologica[l39](#page-9-12). In addition, H2S can also interact with biochemical molecules or species, such as cytochrome C oxidase, NO and reactive oxygen specie[s40](#page-9-13)[,41](#page-9-14), consequently affect their bioactivities. Because H2S is a weak acid, about 80% of H2S exists as monoanionic HS− under physiological conditions. HS– is highly reactive anion, as it is more reality oxidized than H2S. It is of biological importance to be able to detect HS− and to understand the interactions this molecule has with other biological structures. In this work, we found that HS− ions could significantly inhibit the peroxidase-like and oxidase-like activities of AuPt NPs, similarly to the effect on the activity of enzyme horseradish peroxidase (HRP). This, in turn, provided an efficient way to colorimetrically detect HS− ions. Compared to the control experiment without HS− ions ([Fig. 7)](#page-6-0), the addition of HS− inhibits the color evolution of TMB oxidation catalyzed by HRP, Pt NPs or AuPt NPs either in the presence or absence of hydrogen peroxide. The UV-Vis spectral evolution of TMB oxidation over time in the absence of SH− and in the presence of SH− is shown in Supplementary Fig. S4. The oxidation rates of TMB catalyzed by NPs and HRP in the absence and presence of HS− were calculated. The inhibitory degree dependent on the concentration of HS− was found for either natural enzyme HRP or nanoenzyme mimetic Pt and AuPt NPs ([Fig. 7)](#page-6-0). They showed the same trend: a higher concentration of disulfide leads to a greater reduction in TMB oxidation rate. In addition, they may have the similar inhibitory mechanisms. HS− can chemically bind with the metal ions of active site in HRP while HS− may poison the active surface of the Pt or the AuPt NPs by metal-sulfur bond, which consequently results in a reduction of catalytic activity. It is important to note that the alloy with Au is required for good detection of HS−. For example, the AuPt NPs show a 4 times lower limit of detection for HS− than pure Pt NPs. A concentration of 0.83μM SH− could almost completely inhibit the AuPt NPs used to catalyze the oxidation of TMB while a concentration of 3.3μM SH− was needed to inhibit the oxidation of TMB with Pt NPs. In contrast, the Pt NPs (3.3 μM to 33 μM) showed a wider linear range for detection of hydrosulfide than that of AuPt NPs at Au/ Pt of 2/3 (0.83 μM to 10 μM). By using the enzyme-like activity of AuPt NPs, we demonstrated that it is feasible to not only fabricate a colorimetrical method for detection of HS−, but also change the sensing performance to HS− by altering the alloy compositions.

We further tested the selectivity of proposed method for detection of bisulfide. Several metal ions (Fe2+, Cu2+, Co2+, Zn2+ and Mg2+), sulfide ions (S2−), cysteine, GSH, glycine, AA, GSSG, glucose and uric acid, they are often-considered species in biological system, were selected to investigate their interference on the detection of bisulfide. The concentrations of all the interference substances were 20μM, 4 times as high as HS− and S2− (5μM). The result was displayed in [Fig. 8.](#page-7-0) Metal ions (Fe2+, Cu2+, Co2+, Zn2+ and Mg2+), AA, glucose, GSSG, uric acid and glycine showed negligible effects on inhibiting the oxidase-like activity of Au0.4Pt0.6 alloy NPs. In contrast, sulfide ions, ionized product of HS−, can inhibit significantly the catalytic activity as same as bisulfide, while cysteine and GSH cause considerable reduction of catalytic activity. These results indicated that the method was sensitive to HS− and S2−, but the chemical species with thiol-group may cause some interference.

For testing the feasibility of the method in practical samples, the determination of bisulfide in spiked human blood serum was performed. The serum samples were spiked with desirable amounts of bisulfide, and their inhibitory effect on the oxidase-like activities of Pt NPs and Au0.4Pt0.6 alloy NPs were evaluated (see Supplementary Fig. S5). Compared with the control in water, the un-spiked serum reduced slightly the catalytic activity for both Pt NPs

<DESCRIPTION_FROM_IMAGE>This image presents a bar graph showing reaction activity measurements for various chemical species and compounds. The y-axis represents reaction activity in units of min^-1, ranging from 0 to 0.03. The x-axis lists different chemical species and compounds.

The graph displays the following data points, from left to right:

1. Control: approximately 0.027 min^-1
2. Fe²⁺: approximately 0.025 min^-1
3. Co²⁺: approximately 0.027 min^-1
4. Cu²⁺: approximately 0.026 min^-1
5. Zn²⁺: approximately 0.027 min^-1
6. Mg²⁺: approximately 0.027 min^-1
7. AA (likely Ascorbic Acid): approximately 0.025 min^-1
8. HS⁻: approximately 0.001 min^-1
9. S²⁻: approximately 0.001 min^-1
10. glucose: approximately 0.026 min^-1
11. cysteine: approximately 0.01 min^-1
12. GSH (likely Glutathione): approximately 0.024 min^-1
13. uric acid: approximately 0.028 min^-1
14. sorbate: approximately 0.026 min^-1

Each bar has an error bar indicating the uncertainty of the measurement.

Key observations:
1. Most species show reaction activities between 0.024 and 0.028 min^-1.
2. HS⁻ and S²⁻ show significantly lower reaction activities, both around 0.001 min^-1.
3. Cysteine shows a moderately lower reaction activity of about 0.01 min^-1.
4. Uric acid shows the highest reaction activity, slightly above the control.

This graph likely compares the effects of various chemical species on a specific reaction, possibly investigating potential inhibitors or catalysts.</DESCRIPTION_FROM_IMAGE>

<span id="page-7-0"></span>**Figure 8. Selectivity for detection of bisulfide by employing the oxidase-like activity of Au0.4Pt0.6 alloy nanoparticles.** The error bars represent the standard deviation of 3 measurements.

and AuPt alloy NPs. The spiked serum samples with different concentrations of bisulfide (1–3 μM) exhibited distinct behavior for inhibiting the oxidase-like activity of Pt and AuPt alloy NPs. A linear and sensitive response was observed for AuPt alloy NPs while HS− less than 3 μM cause unobvious inhibition for Pt NPs, indicating the higher detection capability of AuPt alloy NPs than Pt NPs. As we calculated above, the alloying Pt with Au gradually changed the electronic structure and decreased the Km, the lower Km of AuPt alloy NPs than pure Pt NPs indicated the higher affinity which may result in lower limit of detection. These results indicated this method based on the oxidase-like activity of AuPt alloy NPs can be applied to bisulfide (sulfide) detection in real sample. Furthermore, it was expected that the inhibitors of natural antioxidants for nanomaterial mimics can mirror natural enzymes. This may provide a facile route to investigate the interaction between inhibitors and natural enzymes. Many other inhibitors are being investigated for their inhibitory activity and mechanism by using NPs enzyme mimics.

### **Conclusions**

AuPt alloy nanostructures with tunable compositions were synthesized through a facile method in aqueous solution by adjusting the molar ratio of added Pt2+ to Au3+. This method may be a cost-effective and environmentally-friendly way to prepare other binary or multicomponent metal nanostructures. AuPt alloy nanoparticles were verified to exhibit intrinsic peroxidase-like and oxidase-like activities that were highly dependent on the alloy compositions of AuPt NPs. This provides an effective way to tailor the enzyme-like properties of nanoparticles. By studying the inhibiting effect of bisulfide on the catalytic activities of enzyme HRP and AuPt NPs, we developed a platform that can be used for colorimetrical detection of bisulfide and sulfide to evaluate the inhibiting effect of inhibitors on natural enzymes and nanoenzymes. This method exhibits high sensitivity and selectivity to bisulfide (and its ionized product, sulfide) against selected metal ions and non-thiol containing biologically relevant molecules, yet biothiols may result in considerable interference. In addition, the sensing performance for HS− can be tailored by changing the compositions of AuPt. Since many biological and chemical inhibitors can reduce the activity of natural enzymes, our results will also facilitate the investigation of biochemical interactions between enzymes and their inhibitors.

#### **Methods**

**Chemicals.** Chlorauric acid (HAuCl4∙3H2O), potassium tetrachloroplatinate (II) (K2PtCl4), cetyltrimethylammonium bromide (CTAB), hydrogen peroxide, L-ascorbic acid (AA), 3,3′,5,5′-tetramethylbenzidine (TMB), cysteine, L-glutathione reduced (GSH), L-glutathione oxidized (GSSG), horseradish peroxidase and sodium hydrosulfide (NaHS) were purchased from Alfa Aesar. FeSO4∙6H2O, Co(NO3)2∙6H2O, ZnSO4, CuSO4, Mg2SO4, Na2S∙9H2O, glucose, uric acid and glycine were obtained from Sinopharm Chemical Reagent Co., Ltd. Milli-Q water (18MΩ cm) was used in the preparation of all solutions.

**Synthesis of Au, Pt and AuPt nanostructures.** AuPt nanostructures were prepared by mixing desirable volumes of 17mM AuCl4 − and 24mM PtCl4 2− in 2mL H2O (according to the calculated Au/Pt molar ratio in the bimetallic alloy from 3/1, 1/1, 1/1.5, 1/3, 1/6 to 1/10). A 40μl 0.1M AA solution (ratio of AA/(Au3+ +Pt2+)=10) was added into the homogenous solution and was shaken vigorously. The solution was placed in a 30 °C water bath for 2 hours. The color became dark brown which suggested the formation of AuPt bimetallic NPs. Then, 0.1 mL 0.1M CTAB was added into above solutions. The same procedure was used to prepare pure Au and Pt nanoparticles except without the addition of either PtCl4 2− or AuCl4 −. The samples were purified by centrifugation at 12000 rounds per min for 10 min and the precipitation was re-dispersed in water. We named here the AuxPt1-x alloy NPs as Au0.75Pt0.25, Au0.5Pt0.5, Au0.4Pt0.6, Au0.25Pt0.75, Au0.15Pt0.85 and Au0.09Pt0.91 alloy NPs, respectively, according to the added Au/Pt ratio.

**Characterization.** UV-visible absorption spectra were obtained using a UV-VIS-NIR Spectrometer (Varian Cary 5000) and a matched quartz cuvette with a path length of 1 cm. The crystal structures of the AuPt alloy nanoparticles were characterized by X-ray diffraction (XRD, Bruker D8 Advance diffractometer) using monochromatized Cu Kα radiation (λ = 1.5418Å). Transmission electron microscopy (TEM) images were captured on a Tecnai G2 F20 U-TWIN electron microscope with an accelerating voltage of 200 kV. High-resolution TEM (HRTEM), selected-area electron diffraction and energy dispersive X-ray spectrometry were performed using the same microscope. Elemental composition and element distribution was identified by the spectrum-imaging method using a dedicated STEM and energy dispersive X-ray spectroscopy under a high-angle annular dark field (HAADF) mode. TEM analysis samples were prepared by adding a droplet of colloidal solution onto a standard holey carbon-coated copper grid and allowing it to air dry.

**Peroxidase-like and oxidase-like activities measurements.** The reaction kinetics for the catalytic oxidation of TMB or AA were studied by recording absorption spectra at 2min intervals in the scanning kinetics mode. Unless otherwise noted, reactions were performed at room temperature, with a fixed amount of AuPt nanoparticles, and with different concentrations of TMB or AA. For the catalytic oxidation of TMB in the presence of hydrogen peroxide, 20μL of 20mM TMB solution and 20μL of 0.1M H2O2 were added to 3mL of H2O. To this solution, a suspension of 25 μL AuPt NPs (with different Au/Pt ratio) or Au or Pt NPs was added to initiate the oxidation of TMB. The reaction was also performed in the absence of hydrogen peroxide. Similarly, the catalytic oxidation of AA was initiated by adding 25μl AuPt NPs into a 3mL 0.1mM aqueous solution of AA. The apparent kinetic parameters for the oxidation of TMB were calculated using the Michaelis-Menten equation υ = Vmax× [S]/ (Km + [S]), where υ is the initial velocity, Vmax is the maximal reaction velocity, [S] is the concentration of substrate and Km is the Michaelis constant.

The inhibitory effect of bisulfide on the enzyme-like activity of AuPt NPs and enzyme HRP was evaluated by addition of 1.3 μg ml−1 AuPt NPs or 1.0 μg/mL HRP to a mixture containing 20 μL 20 mM TMB, 20 μl 0.1M H2O2 and bisulfide at different concentrations in 3ml H2O, and then the reaction process was monitored at 2min intervals. The inhibiting effects of interference substances (Fe2+, Cu2+, Co2+, Zn2+, Mg2+, AA, glucose, GSSG, uric acid, glycine, cysteine and GSH) on the oxidase-like activity of AuPt alloy NPs were studied using the same experimental procedure except for their concentrations were fixed at 20μM. To test the feasibility of the method in practical application, the human blood serum was obtained from hospital (Xinhua Hospital of Xuchang) and used as received. The blood serum samples were spiked with 1, 2 and 3 μM bisulfide, respectively. Then the spiked and unspiked serum samples were measured for their inhibitory effect on the enzyme-like activity of NPs by the procedure described above.

#### **References**

- <span id="page-8-0"></span>1. He, W. W., Wamer, W. G., Xia, Q., Yin, J.-J. & Fu, P. P. Enzyme-Like Activity of Nanomaterials. *J. Environ. Sci. Health. C* **32,** 186–211 (2014).
- <span id="page-8-1"></span>2. Wei, H. & Wang, E. Nanomaterials with enzyme-like characteristics (nanozymes): next-generation artificial enzymes. *Chem. Soc. Rev.* **42,** 6060–6093 (2013).
- <span id="page-8-2"></span>3. Dong, J. *et al.* Co3O4 Nanoparticles with Multi-Enzyme Activities and Their Application in Immunohistochemical Assay. *ACS Appl. Mater. Interfaces* 6, 1959–1970 (2014).
- <span id="page-8-15"></span>4. Asati, A. *et al.* Oxidase-like Activity of Polymer-coated Cerium Oxide Nanoparticles. *Angew. Chem. Int. Ed.* **48,** 2308 –2312 (2009).
- <span id="page-8-3"></span>5. André, R. *et al.* V2O5 Nanowires with an Intrinsic Peroxidase-Like Activity. *Adv. Funct. Mater.* **21,** 501–509 (2011). 6. He, W. W. *et al.* Understanding the formation of CuS concave superstructures with peroxidase-like activity. *Nanoscale* **4,** 3501–3506 (2012).
- <span id="page-8-4"></span>7. Dutta, A. K. *et al.* Synthesis of FeS and FeSe Nanoparticles from a Single Source Precursor: A Study of Their Photocatalytic Activity, Peroxidase-Like Behavior, and Electrochemical Sensing of H2O2. *ACS Appl. Mater. Interfaces* **4,** 1919–1927 (2012).
- <span id="page-8-5"></span>8. Jv, Y., Li, B. & Cao, R. Positively-charged gold nanoparticles as peroxidiase mimic and their application in hydrogen peroxide and glucose detection. *Chem. Commun.* **46,** 8017–8019 (2010).
- <span id="page-8-12"></span>9. He, W. W. *et al.* Au@Pt nanostructures as oxidase and peroxidase for use in immunoassays. *Biomaterials* **32,** 1139–1147 (2011).
- 10. He, W. W. *et al.* Design of AgM Bimetallic Alloy Nanostructures (M= Au, Pd, Pt) with Tunable Morphology and Peroxidase-Like Activity. *Chem. Mater.* **22,** 2988–2944 (2010).
- 11. Xia, X. *et al.* Pd–Ir Core–Shell Nanocubes: A Type of Highly Efficient and Versatile Peroxidase Mimic. *ACS Nano* **9,** 9994–10004 (2015).
- <span id="page-8-6"></span>12. Yin, J. *et al.* The scavenging of reactive oxygen species and the potential for cell protection by functionalized fullerene materials. *Biomaterials* **30,** 611–621 (2009).
- <span id="page-8-7"></span>13. Song, Y. *et al.* Graphene oxide: intrinsic peroxidase catalytic activity and its application to glucose detection. *Adv. Mater.* **22,** 2206–2210 (2010).
- <span id="page-8-8"></span>14. Li, S. *et al.* Wang, Strong coupled palladium nanoparticles decorated on magnetic graphene nanosheets as enhanced peroxidase mimetics for colorimetric detection of H2O2. *Dyes and Pigments* **125,** 64–71 (2016).
- <span id="page-8-9"></span>15. Sun, H. *et al.* Synthesis of Fe3O4-Au Nanocomposites with Enhanced Peroxidase-Like Activity. *Eur. J. Inorg. Chem.* 109–114 (2013).
- <span id="page-8-10"></span>16. Wen, T. *et al.* Exploring environment-dependent effects of Pd nanostructures on reactive oxygen species (ROS) using electron spin resonance (ESR) technique: implications for biomedical applications. *Phys. Chem. Chem. Phys.* **17,** 24937–24943 (2015).
- 17. Liu, Y. *et al.* pH Dependent Catalytic Activities of Platinum Nanoparticles with Respect to the Decomposition of Hydrogen Peroxide and Scavenging of Superoxide and Singlet Oxygen. *Nanoscale* **6,** 11904–11910 (2014).
- 18. He, W. W. *et al.* Intrinsic catalytic activity of Au nanoparticles with respect to hydrogen peroxide decomposition and superoxide scavenging. *Biomaterials* **34,** 765–773 (2013).
- <span id="page-8-11"></span>19. Wang, L. *et al.* Rapid synthesis of biocompatible gold nanoflowers with tailored surface textures with the assistance of amino acid molecules. *RSC Advances* **2,** 4608–4611 (2012).
- 20. Tang, J. *et al.* Au@Pt nanostructures: a novel photothermal conversion agent for cancer therapy. *Nanoscale* **6,** 3670 (2014).
- 21. Tao, Y., Li, M., Ren, J. & Qu, X. Metal nanoclusters: novel probes for diagnostic and therapeutic applications. *Chem. Soc. Rev*. **44,** 8636 (2015).
- <span id="page-8-13"></span>22. Liu, J. *et al.* Ferroxidase-like activity of Au nanorod/Pt nanodot structures and implications for cellular oxidative stress. *Nano Res*. **8,** 4024–4037 (2015).
- 23. Liu, Y. *et al.* Platinum Nanoparticles: Efficient and Stable Catechol Oxidase Mimetics. *ACS Appl. Mater. Interfaces* 7, 19709–19717 (2015).
- <span id="page-8-14"></span>24. Zhou, Y. T. *et al.* Enzyme-mimetic Effects of Gold@platinum Nanorods on the Antioxidant Activity of Ascorbic Acid. *Nanoscale* **5,** 1583–1591 (2013).

- <span id="page-9-4"></span><span id="page-9-3"></span><span id="page-9-2"></span><span id="page-9-1"></span><span id="page-9-0"></span>25. Wang, D., Peng, Q. & Li, Y. Nanocrystalline Intermetallics and Alloys. *Nano Res*. **3,** 574–580 (2010).
- <span id="page-9-7"></span><span id="page-9-6"></span><span id="page-9-5"></span>26. Hu, X. *et al.* Au@PtAg core/shell nanorods: tailoring enzyme-like activities via alloying. *RSC Adv*. **3,** 6095–6105 (2013).
  - 27. Cai, S. *et al.* PtCo bimetallic nanoparticles with high oxidase-like catalytic activity and their applications for magnetic-enhanced colorimetric biosensing. *J. Mater. Chem. B* **4,** 1869 (2016).
  - 28. Chen, Y. *et al.* Fe–Co bimetallic alloy nanoparticles as a highly active peroxidase mimetic and its application in biosensing. *Chem. Commun.* **49,** 5013 (2013).
  - 29. Wu, Q. *et al.* Ultralow Pt-loading bimetallic nanoflowers: fabrication and sensing applications. *Nanotechnology* **24,** 025501 (2013).
  - 30. Tseng, C., Chang, H.-Y., Chang, J.-Y. & Huang, C.-C. Detection of mercury ions based on mercury-induced switching of enzymelike activity of platinum/gold nanoparticles. *Nanoscale* **4,** 6823 (2012).
  - 31. Li, X.-R., Xu, M., Chen, H. & Xu, J. Bimetallic Au@Pt@Au core–shell nanoparticles on graphene oxide nanosheets for highperformance H2O2 bi-directional sensing. *J. Mater. Chem. B* **3,** 4355–4362 (2015).
  - 32. Pavlik, J. W. *et al.* Hydrosulfide (HS−) Coordination in Iron Porphyrinates. *Inorg. Chem*. **49(3),** 1017–1026 (2010).
  - 33. Fan, F. R. *et al.* Epitaxial Growth of Heterogeneous Metal Nanocrystals: From Gold Nano-octahedra to Palladium and Silver Nanocubes. *J. Am. Chem. Soc.* **130,** 6949–6951 (2008).
  - 34. Xiong, J., Wang, Y., Xue, Q. & Wu, X. Synthesis of highly stable dispersions of nanosized copper particles using L-ascorbic acid. *Green Chem.* **13,** 900 (2011).
  - 35. Hou, S., Hu, X., Wen, T., Liu, W. & Wu, X. Core–Shell Noble Metal Nanostructures Templated by Gold Nanorods. *Adv. Mater.* **25,** 3857–3862 (2013).
  - 36. Shen, X. *et al.* Mechanisms of Oxidase and Superoxide Dismutation-like Activities of Gold, Silver, Platinum, and Palladium, and Their Alloys: A General Way to the Activation of Molecular Oxygen. *J. Am. Chem. Soc.* **137,** 15882−15891 (2015).
  - 37. Zhang, K. *et al.* Formation of PdPt Alloy Nanodots on Gold Nanorods: Tuning Oxidase-like Activities via Composition. *Langmuir* **27,** 2796–2803 (2011).
  - 38. Stamenkovic, V. R. *et al.* Trends in electrocatalysis on extended and nanoscale Pt-bimetallic alloy surfaces. *Nat. Mater.* **6,** 241–247 (2007).
  - 39. Kolluru, G. K., Shen, X., Bir, S. C. & Kevil, C. G. Hydrogen Sulfide Chemical Biology: Pathophysiological roles and detection. *Nitric Oxide* **35,** 5–20 (2013).
  - 40. Keilin, D. Cytochrome and respiratory enzymes. *Proc. R. Soc. London B* **104,** 206–252 (1921).
  - 41. Tyagi, N. *et al.* H2S protects against methionine-induced oxidative stress in brain endothelial cells. *Antioxid. Redox Signal.* **11,** 25–33 (2009).

#### <span id="page-9-14"></span><span id="page-9-13"></span><span id="page-9-12"></span><span id="page-9-11"></span><span id="page-9-10"></span><span id="page-9-9"></span><span id="page-9-8"></span>**Acknowledgements**

This work was supported by the National Natural Science Foundation of China (Grant No. 21303153) the Program for Science & Technology Innovation Talents in Universities of Henan Province (14HASTIT008), Plan for Scientific Innovation Talent of Henan Province (2017JQ0014) and the Project for Basic and Advanced Technique Research of Henan Province (162300410047).

#### **Author Contributions**

W.H. designed the experiment. W.H. and Y.Z. wrote the paper. X.H. conducted the synthesis, enzyme-like activity measurements of AuPt bimetallic nanostructures. Y.Z. and H.J. contributed to characterization of AuPt nanostructures. X.H. and J.C. conducted the detection of bisulfide. W. H. and X. H. analyzed the results. Z.Z. prepared the figures. All authors reviewed the manuscript.

#### **Additional Information**

**Supplementary information** accompanies this paper at<http://www.nature.com/srep>

**Competing financial interests:** The authors declare no competing financial interests.

**How to cite this article**: He, W. *et al.* AuPt Alloy Nanostructures with Tunable Composition and Enzyme-like Activities for Colorimetric Detection of Bisulfide. *Sci. Rep.* **7**, 40103; doi: 10.1038/srep40103 (2017).

**Publisher's note:** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

This work is licensed under a Creative Commons Attribution 4.0 International License. The images or other third party material in this article are included in the article's Creative Commons license, unless indicated otherwise in the credit line; if the material is not included under the Creative Commons license, users will need to obtain permission from the license holder to reproduce the material. To view a copy of this license, visit<http://creativecommons.org/licenses/by/4.0/>

© The Author(s) 2017