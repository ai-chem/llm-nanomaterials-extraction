<DESCRIPTION_FROM_IMAGE>This image appears to be a logo for a scientific publication or organization related to nanomaterials. The logo consists of two main elements:

1. A graphical representation of a nanomaterial structure:
   The structure depicted is likely a fullerene or similar nanoscale carbon structure. It shows a spherical arrangement of atoms or molecules, which is characteristic of certain nanomaterials like buckyballs (C60) or other fullerene structures.

2. Text element:
   The word "nanomaterials" is written in lowercase letters next to the graphical element.

This logo is likely used to represent a scientific journal, conference, or organization focused on nanomaterials research and applications. The combination of the molecular structure graphic and the text "nanomaterials" effectively communicates the subject matter and scale of the field being represented.

While this image does contain a simplified representation of a nanomaterial structure, it does not provide detailed scientific information, chemical structures to be converted to SMILES format, or graphs/diagrams to be interpreted. Therefore, this image serves more as a branding or identification element rather than conveying specific scientific data.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image depicts the logo of MDPI (Multidisciplinary Digital Publishing Institute), a prominent open-access academic publisher. The logo consists of a stylized representation of a house or building outline, with the letters "MDPI" inside. This logo does not convey specific scientific or chemical information relevant to the context of applied chemistry or scientific research. Therefore, the appropriate response for this image is:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

# *Article* **Pt Nanoparticles with High Oxidase-Like Activity and Reusability for Detection of Ascorbic Acid**

**Qin Cheng 1,2, Yong Yang 1,*, Yusi Peng 1 and Meng Liu 1**

- 1 Shanghai Institute of Ceramics, Chinese Academy of Sciences, Shanghai 200050, China; cq18817206957@163.com (Q.C.); pengyusi@student.sic.ac.cn (Y.P.); liumeng1@shanghaitech.edu.cn (M.L.)
- 2 Institute of Nanochemistry and Nanobiology, School of Environmental and Chemical Engineering, Shanghai University, Shanghai 200444, China
- ***** Correspondence: yangyong@mail.sic.ac.cn; Tel.: +86-21-69906065; Fax: +86-21-69906025.

Received: 21 April 2020; Accepted: 22 May 2020; Published: 26 May 2020

**Abstract:** Noble metal nanoenzymes such as Pt, Au, Pd, etc. exhibit magnificent activity. However, due to the scarce reserves and expensive prices of precious metals, it is essential to investigate their enzyme-like activity and explore the possibility of their reuse. In this work, the oxidase-like activity and reusability of several Pt nanoparticles with different morphologies were detected. We compared the Pt nanoparticles (NPs) with a size of about 30 nm self-assembled by 5 nm Pt nanoparticles and Pt nanoparticles (Pt-0 HCl) with a diameter of about 5 nm, and found that their Michaelis−Menten constants (Km) were close and their initial performance similar, but the Pt NPs had better reusability. This was probably attributed to the stacked structure of Pt NPs, which was conducive to the substance transport and sufficient contact. At the same time, it was found that the size, dispersion, and organic substances adsorbed on the surface of Pt nanoparticles would have a significant impact on their reusability. A colorimetric detection method was designed using the oxidase-like activity of Pt NPs to detect ascorbic acid in triplicate. The limits of detection were 131 ± 15, 144 ± 14, and 152 ± 9 nM, with little difference. This research not only showed that the morphology of the catalyst could be changed and its catalytic performance could be controlled by a simple liquid phase synthesis method, but also that it had great significance for the reuse of Pt nanoenzymes in the field of bioanalysis.

**Keywords:** Pt nanoparticles; oxidase-like activity; reusability; colorimetric method; ascorbic acid

# **1. Introduction**

Ascorbic acid (AA), as an antioxidant, plays an important role in many biochemical and physiological processes, such as the formation of neurotransmitters, ion absorption, amino acid metabolism, and so on [1,2]. It also can prevent and treat scurvy, colds, cardiovascular diseases, allergies, and cancer [3–6]. However, the human body cannot synthesize ascorbic acid through its own metabolism and must ingest it from the outside [1,7,8]. In addition, ascorbic acid is widely present in vegetables, fruits, and medicines [9,10]. Therefore, developing a simple, efficient, and sensitive detection method is very important for these fields. Thus far, mainstream methods for detecting AA have been reported including the electrochemical method, liquid chromatography, fluorescence method, titration, and chemiluminescence technology [11–13]. However, these methods all have the disadvantages of complicated and expensive operations. Due to having the advantages of visibility, simple operation, and low cost, the technology of colorimetric detection of small biomolecules, such as ascorbic acid, has become more and more mature and has attracted wide attention [14–17].

In recent years, with the rapid development of nanotechnology, lots of nanomaterials have been found with enzyme-like activities (such as Pt, Au, Fe3O4, CeO2, Co3O4, etc.) [18–23]. Compared to natural enzymes, nanoenzymes have the advantages of simple synthesis, low cost, good stability, etc. [22,24]. At present, the synthesis of nanoenzymes with high catalytic activity and investigations into

their mechanisms of action are topical. Pt nanomaterials (Pt NPs) have a variety of catalytic properties and are widely used in energy, medicine, chemical, and environmental fields [22,25]. As a kind of nanoenzyme, Pt nanoparticles have the advantages of high activity, great biocompatibility, and broad application prospects [26]. In addition, Pt NPs have been reported to have various enzyme-like activities like oxidase, peroxidase, SOD, polyphenol oxidase, and catalase [22,23]. However, Pt is an expensive precious metal [25,27]. Therefore, it is essential that the Pt NPs are recycled after use in order to conserve supplies. At present, the research of Pt-related nano-enzymes have focused on improving the catalytic activity, while few attempts have been taken to study its reusability. In this work, we found that Pt NPs, as synthesized, were reusable and could catalyze 3, 3, 5, 5′-tetramethylbenzidine (TMB) oxidation multiple times in a row. Based on this, we explored a series of Pt NPs and found that their reusable properties and affinities to the substrate were strongly related to their morphology and surface state. In addition, the method for colorimetric detection of AA was established to detect AA in triplicate, and the limits of detection were 131 ± 15, 144 ± 14, and 152 ± 9 nM, which had broad application prospects. These investigations not only extend our understanding of the properties of Pt NPs, but also provide a significant basis for the development and design of nanoenzymes.

#### **2. Experimental**

## *2.1. Chemicals*

Chloroplatinic acid hexahydrate (H2PtCl6·6H2O) was purchased from Sigma-Aldrich. In addition, polyvinylpyrrolidone (PVP), 3, 3, 5, 5′-tetramethylbenzidine (TMB), and ethylene glycol (C2H6O2) were obtained from Alfa Aesar. Ascorbic acid, acetic acid-sodium acetate buffer solution (0.2 M, pH 4.0), and n-hexane were purchased from Aladdin, China. The water used was deionized water (18 MΩ cm).

## *2.2. Characterization*

The absorbance spectra of oxidase reactions were measured by ultraviolet-visible spectrophotometry (Lamda950), and the morphology of Pt nanoparticles (Pt NPs) was tested by transmission electron microscopy (TEM, Tecnai G2 F20).

#### *2.3. Synthesis of Pt Nanoparticles*

In a 50 mL three-necked flask, 2.5 mL of ethylene glycol (EG) was refluxed at 180 °C for 5 min with an oil bath, after which 0.34 mL of HCl (37 wt%) was added. Then, 0.94 mL of H2PtCl6·6H2O (0.0625 M) solution and 4 mL of PVP (0.0375 M) were added into the above solution for 10 times within 5 min. During the whole reaction, the reactants were continuously stirred and mixed uniformly. After 20 min, the three-necked flask was taken out, naturally cooled to room temperature. The sample was collected and washed by centrifugation with water and ethanol. Finally, the samples were dried in an oven at 60 °C. By changing the concentration of HCl (37 wt%) into 0 wt%, 3.7 wt%, and 9.25 wt%, we prepared Pt-0 HCl (0 wt%), Pt-3.7 HCl (3.7 wt%), and Pt-9.25 HCl (9.25 wt%), respectively. In addition, changing the concentration of PVP solution (0.00375 M) into 0.075 M, we prepared Pt-2PVP (0.075 M).

#### *2.4. Kinetic Assay of Oxidase-Like Pt Nanoparticles*

First, 60 μL Pt nanoparticles (0.75 mg mL–1, dispersant was deionized water) and 140 μL of TMB were added into 2.8 mL of acetic acid-acetate buffer solution (0.2 M, pH 4.0) at 35 °C. The kinetic measurements were performed in a time course mode, and a spectrophotometer was used to measure the absorbance spectra in the first 3 min of the reaction system at 652 nm every 15 s. Lineweaver– Burk graphs were used to calculate Michaelis–Menten constants: *1/v = Km/Vmax(1/{S} + 1/Km).*

## *2.5. The Oxidase-Like Activity of Pt Nanoparticles*

First, 40 uL TMB (5 mM) and 60 uL Pt nanoparticles (0.75 mg mL–1, dispersant was deionized water) were added into acetic acid-sodium acetate buffer solution (0.2 M, pH 4.0, 2.9 mL), and the solution was incubated at 35 °C with water bath for 10 min. UV-visible absorption spectra were used to monitor the reaction at 652 nm.

## *2.6. The Reusability of Pt Nanoparticles*

First, 40 uL TMB (5 mM) and 60 uL Pt NP solution (0.75 mg mL–1, dispersant was deionized water) were added into 2.8 mL acetic acid-sodium acetate buffer solution (0.2 M, pH 4.0), and the mixture was incubated at 35 °C for 10 min. Then, 50 uL AA solution (1.5 μM) were added into it and mixed uniformly. Their UV-visible absorption spectra were measured at 652 nm. After that, the mixture was re-incubated for 10 min and tested by an ultraviolet-visible spectrophotometer. The above process was repeated many times.

#### *2.7. Detection of Ascorbic Acid (AA)*

First, 40 uL TMB (5 mM) and 60 uL Pt NP solution (0.75 mg mL–1) were added into 2.8 mL acetic acid-sodium acetate buffer solution (0.2 M, pH 4.0). Then, the mixture was incubated at 35 °C for 10 min, followed by adding 50 uL AA solution. Their UV-visible absorption spectra were measured at 652 nm. Without centrifuging the catalyst, the solution after being tested was re-incubated at 35 °C, changes in ox-TMB concentration in the solution were monitored by the UV-visible spectrophotometer until the oxidation of the solution was comparable to the previous test, and the absorbance spectra was re-measured at 652 nm. This process was repeated multiple times.

#### **3. Results and Discussion**

#### *3.1. Characterization of Pt Nanoparticles (Pt NPs)*

As shown in Figure 1a, the prepared Pt NPs were about 30 nm and formed by these so-called "building blocks" with a size of 5 nm [28]. The size distributions of Pt NPs were analyzed based on counting more than 60 nanoparticles. As displayed in Figure 1b, the size of Pt NPs was relatively uniform in principle and concentrated around 28–32 nm. In addition, EDS analysis showed that the particles consisted of pure Pt (Figure 1c). From the analysis of high-resolution (HR)-TEM images, the lattice spacing of the Pt NPs was 0.196 nm and consistent with the (100) crystal plane of Pt nanoparticles, which was also consistent with literature reports and proved that nanoparticles with a stacked structure had been synthesized [28,29]. Pt nanoparticles with different morphologies were synthesized by changing the reaction conditions in order to evaluate the oxidase-like activities of the Pt NPs, as shown in Figure 2. By changing the HCl concentration during the preparation process, Pt-0 HCl of about 5 nm, Pt-3.7 HCl of about 9 nm, and Pt-9.25 HCl of about 16 nm formed by the accumulation of 7–8 nm Pt nanoparticles were prepared (Figure 2a–c). At the same time, the Pt-2 PVP was prepared by changing the PVP concentration, and it was found that Pt-2 PVP and Pt NPs were similar in morphology (Figure 2d). Their size distribution diagrams and EDS elemental analysis are shown in Figures S1 and S2, respectively.

<DESCRIPTION_FROM_IMAGE>This image is a composite of four separate panels labeled (a), (b), (c), and (d), each providing different analytical information about nanoparticles.

(a) Transmission Electron Microscopy (TEM) image: Shows clusters of nanoparticles. The particles appear to be aggregated into flower-like structures. The scale bar indicates 20 nm.

(b) Particle size distribution histogram: Displays the frequency of particle sizes ranging from 25 to 36 nm. The distribution appears to be roughly normal, with a peak around 31-32 nm. The y-axis shows frequency in percentage, ranging from 0 to 20%. A fitted normal distribution curve is overlaid on the histogram.

(c) Energy Dispersive X-ray (EDX) spectrum: Shows peaks corresponding to Platinum (Pt) and Copper (Cu). The x-axis represents energy in eV, ranging from 0 to 12000 eV. The y-axis shows counts. Prominent peaks are observed for Pt around 2000 eV and 9000 eV, and for Cu around 8000 eV.

(d) High-Resolution TEM (HRTEM) image: Reveals the lattice structure of a nanoparticle. The image shows a lattice spacing of 0.196 nm, corresponding to the (100) plane. The scale bar indicates 5 nm.

This composite image provides comprehensive characterization of the nanoparticles, including their morphology, size distribution, elemental composition, and crystal structure.</DESCRIPTION_FROM_IMAGE>

**Figure 1.** (**a**) TEM image of Pt nanoparticles (NPs), (**b**) size distributions of Pt NPs, (**c**) EDS elemental analysis of Pt NPs, and (**d**) HR-TEM image of Pt NPs.

<DESCRIPTION_FROM_IMAGE>The image presents four transmission electron microscopy (TEM) micrographs labeled (a), (b), (c), and (d), each showing nanoparticles of different morphologies and sizes. All four main images have a scale bar of 20 nm, while the inset images in the upper right corner of each micrograph have a scale bar of 10 nm.

(a) This micrograph shows a collection of small, spherical nanoparticles forming chain-like structures. The particles appear to be relatively uniform in size and are well-dispersed. The inset image provides a higher magnification view of a single nanoparticle, revealing its crystalline structure.

(b) This image depicts slightly larger nanoparticles compared to (a). The particles are still mostly spherical but show some variation in size and shape. They appear to be more closely packed than in (a). The inset image shows a higher magnification view of a single, larger nanoparticle.

(c) This micrograph reveals nanoparticles that are significantly larger and more irregular in shape compared to (a) and (b). The particles appear to be aggregating or fusing together, forming larger clusters. The inset image shows a higher magnification view of a cluster of these irregular nanoparticles.

(d) This image shows nanoparticles with a flower-like or star-shaped morphology. These particles are larger than those in (a) and (b) and have a more complex structure than the previous samples. The particles appear to be composed of multiple smaller units fused together. The inset image provides a closer view of one of these flower-like nanostructures.

The progression from (a) to (d) suggests a series of nanoparticle samples with increasing size and structural complexity, possibly representing different stages of nanoparticle growth or different synthesis conditions.</DESCRIPTION_FROM_IMAGE>

**Figure 2.** TEM images of Pt nanoparticles obtained by adding HCl and polyvinylpyrrolidone (PVP) with different concentrations: (**a**) Pt-0 HCl (without HCl), (**b**) Pt-3.7 HCl (3.7 wt% HCl), (**c**) Pt-9.25 HCl (9.25 wt% HCl), and (**d**) Pt-2 PVP (0.075 M PVP), Inset: TEM images of single Pt nanoparticle.

#### *3.2. Evaluation of the Oxidase-Like Catalytic Performances of Pt NPs*

Using TMB as substrates, the oxidase-like activity of Pt nanoparticles was evaluated by testing the absorbance curve of the reaction system without adding H2O2. As shown in Figure 3a, Pt nanoparticles catalyzed the oxidation of TMB to ox-TMB, and the reaction system generated a typical blue product and had a typical absorption peak at 652 nm. However, no characteristic peaks after testing were observed in the system containing only TMB, indicating that Pt nanoparticles had good catalytic activity. In addition, no characteristic peak of Pt nanoparticle suspension appeared at 550– 750 nm, demonstrating that it had no significant effect on subsequent reactions. At the same time, the catalytic activities of Pt nanoparticles with different morphologies were compared, as shown in Figure 3b. After 10 min of reaction, the catalytic activities of Pt-0 HCl, Pt-9.25 HCl, and Pt NPs were slightly better than those of Pt-3.7 HCl and Pt-2 PVP. At the same time, in the characterization at this stage, the performance difference between Pt-0 HCl and Pt NPs could not be distinguished. In general, all of them had brilliant activity.

<DESCRIPTION_FROM_IMAGE>The image consists of two parts, labeled (a) and (b).

(a) This part shows a graph of Absorbance (a.u.) vs Wavelength (nm). The graph contains three lines:
1. A black line labeled "TMB" which remains close to zero absorbance across all wavelengths.
2. A red line labeled "Pt NPs" which also remains close to zero absorbance across all wavelengths.
3. A blue line labeled "TMB+Pt NPs" which shows a broad peak centered around 650 nm, reaching a maximum absorbance of about 0.6 a.u.

The wavelength range shown is from 550 nm to 750 nm.

An inset image shows three vials containing solutions: TMB (colorless), Pt NPs (colorless), and TMB+Pt NPs (blue).

(b) This part shows a bar graph of Absorbance at 652 nm (a.u.) for five different conditions labeled a through e. The values are approximately:
a: 0.90 ± 0.03
b: 0.75 ± 0.02
c: 0.88 ± 0.02
d: 0.92 ± 0.02
e: 0.73 ± 0.03

The y-axis ranges from 0 to 1.0 a.u.

This graph appears to be showing the absorbance at a specific wavelength (652 nm) for different experimental conditions, possibly related to the interaction between TMB (likely 3,3',5,5'-Tetramethylbenzidine) and platinum nanoparticles (Pt NPs).</DESCRIPTION_FROM_IMAGE>

**Figure 3.** (**a**) UV-visible absorption spectra of different systems: 3, 3, 5, 5′-tetramethylbenzidine (TMB), Pt NPs, TMB + Pt NPs (reaction time: 5 min); (**b**) absorbance of the reaction systems at 652 nm with addition of different Pt nanoparticles (a: Pt-0 HCl, b: Pt-3.7 HCl, c: Pt-9.25 HCl, d: Pt NPs, e: Pt-2 PVP).

## *3.3. Optimization of Different Experimental Conditions*

Similar to other nanoenzymes, the properties of Pt nanomaterials are closely related to the reaction conditions [30]. The effects of pH, temperature, and reaction time on the reaction system were studied. The catalytic activity was low at 20 °C; as the temperature increased, the catalytic performance of the nanoparticles improved, reaching a maximum at 35 °C, and maintaining more than 70% of the highest activity in the range of 30–40 °C (Figure 4a), demonstrating the potential for use at room temperature. The pH also had a great impact on nanoenzyme performance, as shown in Figure 4b, where the performance was best at pH 4.0. The pH value above and below 4.0 both affected its oxidase-like activity, which is similar to natural enzymes [30,31]. Further research found that the absorbance of the ox-TMB solution increased with time, and the reaction rate gradually decreased after 8 min of reaction (Figure 4c). Therefore, in order to reduce the interference of environmental factors and the convenience of experiments, the following experiments used the following reaction conditions: Pt nanoparticle concentration 15 μg/mL, reaction temperature 35° C, reaction pH 4.0, reaction time 10 min.

<DESCRIPTION_FROM_IMAGE>The image contains three graphs labeled (a), (b), and (c), each showing different relationships related to absorbance measurements at 652 nm.

Graph (a) depicts the relationship between temperature (°C) and absorbance (a.u.). The x-axis ranges from 20°C to 45°C, while the y-axis shows absorbance values from 0.4 to 0.9 a.u. The graph shows an initial increase in absorbance as temperature rises, reaching a peak at around 35°C with an absorbance of approximately 0.82 a.u. After this peak, the absorbance decreases as the temperature continues to increase.

Graph (b) illustrates the effect of pH on absorbance (a.u.). The x-axis represents pH values from 3 to 7, and the y-axis shows absorbance values from 0.0 to 1.0 a.u. The graph demonstrates a sharp increase in absorbance from pH 3 to 4, reaching a maximum of about 0.8 a.u. at pH 4. After this peak, there is a steady decrease in absorbance as pH increases further.

Graph (c) shows the change in absorbance (a.u.) over time (min). The x-axis ranges from 0 to 12 minutes, while the y-axis displays absorbance values from 0.4 to 1.0 a.u. The graph exhibits a rapid initial increase in absorbance during the first 4 minutes, followed by a more gradual increase that appears to be approaching a plateau towards the end of the 12-minute period.

All three graphs use error bars to indicate the precision of the measurements. The absorbance measurements in all graphs are specifically noted to be at 652 nm.

These graphs likely represent experimental data related to the optimization of reaction conditions or the characterization of a chemical system, showing how temperature, pH, and time affect the absorbance of a particular substance or reaction mixture at 652 nm.</DESCRIPTION_FROM_IMAGE>

**Figure 4.** Effects of different conditions on the oxidase-like activity of Pt NPs: (**a**) Temperature, (**b**) pH, (**c**) time.

In order to quantify the catalytic performance of the prepared Pt nanomaterials, the time course mode was used in this experiment to determine the reaction initial velocity and explore the kinetic parameters. By fixing other parameters and changing the TMB concentration, the absorbance change of the reaction solution at 652 nm three minutes before the reaction was tracked to calculate the concentration of the oxidized product by the Lambert−Beer law, and a kinetic curve was established. As shown in Figure 5a, the obtained curve satisfied the typical Michaelis–Menten equation, and the Lineweaver–Burk double inverse curve (inset Figure 5a) was obtained. The calculated maximum reaction rate was 330 nM S−1, and the Michaelis−Menten constant (Km) was 0.102 mM. Compared to the Km of many nanoenzymes that have been reported, the Km obtained was smaller (Table S1), indicating that the affinity of PtNPs with TMB was great (a smaller Km indicates a higher affinity with the substrate [32,33]). Compared to the different nanoparticles prepared, as shown in Figure 5b, it was found that the Km of Pt NPs was slightly smaller than those of other nanoparticles. At the same time, the Km of Pt NPs was close to those of Pt-0 HCl and Pt-9.25 HCl, and the Km of Pt-3.7 HCl and Pt-2 PVP was slightly larger. This may be due to the large number of PVPs on the surface of Pt-2 PVP, which caused a large number of active sites to be occupied [34]. However, in general, the Km of these nanoparticles was not very different, which was consistent with previous tests.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (a) and (b), both related to TMB (3,3',5,5'-Tetramethylbenzidine) concentration.

Graph (a):
This graph shows the relationship between TMB concentration (mM) on the x-axis and V (mV s^-1) on the y-axis. The main plot shows a non-linear relationship with data points and a fitted curve. The curve appears to be approaching a plateau at higher TMB concentrations. The y-axis ranges from 50 to 350 mV s^-1, while the x-axis goes from 0 to 1 mM TMB.

An inset graph is present in the lower right corner of graph (a). This inset shows a linear relationship between 1/[TMB] (mM^-1) on the x-axis and 1/V (s mV^-1) on the y-axis. This appears to be a Lineweaver-Burk plot, which is commonly used in enzyme kinetics.

Graph (b):
This graph shows a linear relationship between 1/[TMB] (mM^-1) on the x-axis and 1/V (mV^-1 s) on the y-axis for different catalysts or conditions. The x-axis ranges from 0 to 40 mM^-1, while the y-axis goes from 0 to 0.030 mV^-1 s.

Five different datasets are plotted, each with a different symbol and color:
1. Pt-3.7 HCl (black squares)
2. Pt-9.25 HCl (red circles)
3. Pt-2PVP (blue triangles)
4. Pt-0 HCl (pink inverted triangles)
5. Pt NPs (green diamonds)

Each dataset shows a linear trend with different slopes and y-intercepts, indicating varying kinetic parameters for the different catalysts or conditions.

These graphs likely represent a kinetic study of TMB oxidation using different platinum-based catalysts, possibly in the context of developing or optimizing a colorimetric assay or sensor.</DESCRIPTION_FROM_IMAGE>

**Figure 5.** (**a**) Michaelis–Menten curve of Pt NPs with TMB, Inset: Lineweaver–Burk plots of Pt NPs with TMB; (**b**) Lineweaver–Burk plots of different Pt nanoparticles.

#### *3.5. Reusable Performance of Pt NPs*

In order to further investigate the oxidase-like activity of Pt NPs, a cyclic experiment was designed (achieved by continuous redox TMB with AA and Pt NPs). As shown in Figure 6a, the reusability of Pt NPs for catalyzing the redox reactions was up to six cycles. We found that the performance of the second cycle redox reaction was similar to that of the first one, and the performance decreased about 10% at the third cycle redox reaction. After five cycles, its performance was greatly restored after the Pt NPs being centrifuged and washed with ethanol. The slight decrease in activity may be mainly caused by the loss of Pt NPs during the washing process. At the same time, Pt nanoparticles with different morphologies were compared to evaluate the reusability of Pt NPs. Figure 6b showed that except Pt NPs, the performance of other Pt nanoparticles was greatly reduced as the second cycle. In addition, Sections 3.2 and 3.4 in this paper showed that the Km of various Pt nanoparticles prepared and the amount of ox-TMB produced after a full reaction in ten minutes were very close, but their reusability was quite different. Comparing Figure 1 and Figure 2a, Pt NPs were formed by 5 nm Pt nanoparticles, and Pt nanoparticles (Pt-0 HCl) were about 5 nm simply (Figure S1a). Their catalytic performance was similar in the first cycle, and in the second cycle, their performance started to differ significantly. It is reported that the size of nanoparticles is an important factor to determine their enzyme-like activity [35,36]. Therefore, Pt-0 HCl exhibited a great oxidaselike activity in the first cycle. The Pt NPs, which were formed by the accumulation of 5 nm Pt nanoparticles, have similar activity to Pt-0 HCl during the first cycle, which may be due to the relatively reduced exposed active sites due to their stacked structure. In the second cycle, the difference in catalytic activities between Pt NPs and Pt-0 HCl became larger (Figure 6b). The main reason was probably that the stacked structure of Pt NPs was conducive to the substance transport and sufficient contact, so the performance was more stable [28,34]. Similarly, as shown in Figure 2b and Figure S1b, the prepared Pt nanoparticles (Pt-3.7HCl) increased to 9 nm with poor dispersibility, and no "building blocks" existed, which had a slightly lower performance in the first cycle, and significantly lower performance in subsequent cycles, than Pt NPs and Pt-0 HCl (Figure 6b). In addition, compared to Pt-0 HCl, Pt-3.7 HCl had more defects, but its larger nanoparticles and worse dispersion led to degradation in the catalytic activity (Figure 2b, Figure S1b, Figure 6b). Unlike Pt-0 HCl and Pt-3.7 HCl, so-called "building blocks" existed in Pt-9.25 HCl—approximately 16 nm nanoparticles were formed by small nanoparticles with the size of 7–8 nm, and not unexpectedly, the reusability performance of Pt-9.25 HCl was better than that of Pt-3.7 HCl (Figure 2c, Figure S1c, Figure 6b). However, the reusability performance of Pt nanoparticles with the same morphology was not necessarily the same. As shown in Figure 2d and Figure S1d, the Pt nanoparticles (Pt-2 PVP) had similar morphology and good dispersibility as Pt NPs. However, its reusability performance was lower than that of Pt NPs (Figure 6b). It may be due to the excessive PVP (as surface covering agent) added during the preparation process, so too many active sites were occupied (Figure S3 showed that the surface of Pt NPs was covered with an amount of PVP).

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (a) and (b), both showing data related to absorbance at 652 nm over multiple cycles.

Graph (a):
This is a bar graph showing absorbance at 652 nm (in arbitrary units, a.u.) over 6 cycles. The y-axis ranges from 0 to 1.0 a.u. The bars show a general decreasing trend from cycle 1 to 5, with cycle 6 showing an increase. The values are approximately:
Cycle 1: 0.93
Cycle 2: 0.91
Cycle 3: 0.78
Cycle 4: 0.64
Cycle 5: 0.33
Cycle 6: 0.74

There is a note "Washed by ethanol" with an arrow pointing to the bar for cycle 5, indicating this cycle involved an ethanol wash step.

Graph (b):
This is a line graph showing absorbance at 652 nm (in a.u.) over 5 cycles. The y-axis again ranges from 0 to 1.0 a.u. Five different conditions are plotted:

1. Pt-0 HCl: Shows a gradual decrease from about 0.9 to 0.2 over 5 cycles.
2. Pt-3.7 HCl: Starts around 0.8, decreases to about 0.4 by cycle 3, then levels off.
3. Pt-9.25 HCl: Similar trend to Pt-3.7 HCl but slightly higher values.
4. Pt NPs: Starts highest at about 0.95, decreases steadily to about 0.3 by cycle 5.
5. Pt-2 PVP: Starts lowest at about 0.7, drops sharply to about 0.2 by cycle 3, then levels off.

These graphs appear to be comparing the stability or reusability of different platinum-based materials, possibly catalysts, over multiple use cycles. Graph (a) focuses on the effect of ethanol washing, while graph (b) compares different platinum preparations, including nanoparticles (NPs) and those treated with different concentrations of HCl or stabilized with PVP (polyvinylpyrrolidone).</DESCRIPTION_FROM_IMAGE>

**Figure 6.** Reusability of (**a**) Pt NPs and (**b**) Pt nanoparticles with different morphologies for catalytically oxidizing TMB.

## *3.6. Detection of Ascorbic Acid (AA)*

Without centrifuging the catalyst, the solution after being tested was re-incubated at 35 °C, and detection of the change in the concentration of ox-TMB in the reaction solution was carried out by an ultraviolet-visible spectrophotometer. After the solution was oxidized to a certain degree, the AA solution was added and tested immediately to determine the detection limit of the AA content of the colorimetric method. After three testing times, the linear calibration plots were obtained by analysis (Figure 7). It is found that the limits of detection (LOD) obtained were close, which were 131 ± 15, 144 ± 14, and 152 ± 9 nM, indicating that the detection accuracy had no significant change in at least three circles, which confirmed that Pt NPs had great reusability. In addition, the linear range of the three reactions was obtained. As shown in Figure 6, the linear range of the three reactions all falls approximately between 1 and 20 μM. At the same time, the selectivity of Pt NPs was tested, as shown in Figure S4, and it was found that the common ions had little effect on the test, indicating that the method have potential applications in general water quality testing and other fields.

<DESCRIPTION_FROM_IMAGE>The image contains three graphs labeled (a), (b), and (c), each showing the relationship between AA (presumably Ascorbic Acid) concentration (μM) on the x-axis and ΔA (likely change in absorbance) on the y-axis. Each graph also includes a Limit of Detection (LOD) value.

Graph (a):
- X-axis: AA concentration from 0 to 25 μM
- Y-axis: ΔA from 0 to 0.6
- LOD = 131 nM
- Linear trend line with data points showing a positive correlation
- Data points at approximately (0, 0), (5, 0.1), (10, 0.15), (15, 0.25), (20, 0.4), and (25, 0.5)

Graph (b):
- X-axis: AA concentration from 0 to 20 μM
- Y-axis: ΔA from 0 to 0.4
- LOD = 144 nM
- Linear trend line with data points showing a positive correlation
- Data points at approximately (0, 0), (5, 0.1), (10, 0.15), (15, 0.3), and (20, 0.4)
- Error bars visible on the last data point

Graph (c):
- X-axis: AA concentration from 0 to 20 μM
- Y-axis: ΔA from 0 to 0.5
- LOD = 152 nM
- Linear trend line with data points showing a positive correlation
- Data points at approximately (0, 0), (5, 0.1), (10, 0.15), (15, 0.3), and (20, 0.43)
- Error bars visible on several data points, most notably the last one

All three graphs demonstrate a linear relationship between AA concentration and ΔA, with slight variations in slope and LOD values. The data suggests that as AA concentration increases, there is a proportional increase in the measured change in absorbance (ΔA).</DESCRIPTION_FROM_IMAGE>

**Figure 7.** Linear calibration plot for three consecutive detections of ascorbic acid (AA): (**a**) the first time, (**b**) the second time, and (**c**) the third time.

#### **4. Conclusions**

In summary, a variety of Pt nanoparticles with different morphologies were prepared by changing the reaction conditions. Compared to Pt-0 HCl, Pt-3.7 HCl, Pt-9.25 HCl, Pt NPs, and Pt-2 PVP, it was found that the prepared Pt NPs had good intrinsic oxidase-like activity and reusability. The characteristic was mainly due to the so-called "building blocks" of Pt NPs—this structure allowed it to have a large specific surface area, and may be beneficial to material transfer [28]. In addition, by repeatedly detecting AA three times, we found that the limit of detection obtained did not change significantly. This study demonstrates the potential for reuse of Pt NPs, and provides an important direction for subsequent research.

**Supplementary Materials:** The following are available online at www.mdpi.com/2079-4991/10/6/1015/s1. Figure S1 Size distributions of (a) Pt-0 HCl, (b) Pt-3.7 HCl, (c) Pt-9.25 HCl and (d) Pt-2 PVP. Figure S2 EDS elemental analysis of (a) Pt-0 HCl, (b) Pt-3.7 HCl, (c) Pt-9.25 HCl and (d) Pt-2 PVP. Figure S3 FTIR spectra of Pt NPs. Figure S4 Interference of different interfering substances in the AA detection, all interfering substances were at a concentration of 25 μM. Table S1 Comparative table of steady-state kinetic parameter for Pt NPs and other materials.

**Author Contributions:** Conceptualisation, Q.C. and Y.Y.; investigation Q.C.; writing—original draft preparation, Q.C.; writing—review and editing, Q.C., Y.Y., Y.P. and M.L.; supervision, Y.Y. All authors have read and agreed to the published version of the manuscript.

**Funding:** This research was funded by the National Key Research and Development Project grant number [No. 2017YFB0310600], and Shanghai international science and Technology Cooperation Fund grant number [No. 17520711700 and No.18520744200].

**Acknowledgment:** The authors sincerely acknowledge the finical support of the National Key Research and Development Project (No. 2017YFB0310600), and Shanghai International Science and Technology Cooperation Fund (No. 17520711700 and No.18520744200).

**Conflicts of interest:** The authors declare no competing financial interest*.* 

# **References**

- 1. Collie, J.T.B.; Greaves, R.F.; Jones, O.A.H.; Eastwood, G.; Bellomo, R. Vitamin C measurement in critical illness: Challenges, methodologies and quality improvements. *Clin. Chem. Lab. Med.* **2020**, *58*, 460–470, doi:10.1515/cclm-2019-0912.
- 2. Righi, N.C.; Schuch, F.B.; De Nardi, A.T.; Pippi, C.M.; de Almeida Righi, G.; Puntel, G.O.; da Silva, A.M.V.; Signori, L.U. Effects of vitamin C on oxidative stress, inflammation, muscle soreness, and strength following acute exercise: Meta-analyses of randomized clinical trials. *Eur. J. Nutr.* **2020**, doi:10.1007/s00394- 020-02215-2.
- 3. Yang, W.; Li, J.; Wang, M.; Sun, X.; Liu, Y.; Yang, J.; Ng, D.H.L. A colorimetric strategy for ascorbic acid sensing based on the peroxidase-like activity of core-shell Fe3O4/CoFe-LDH hybrid. *Colloids Surf. B Biointerfaces* **2020**, *188*, 110742–110742, doi:10.1016/j.colsurfb.2019.110742.
- 4. Shu, X.; Chen, Y.; Yuan, C.; Wang, Y. Ag+-3,3 ',5,5 '-tetramethylbenzidine as a probe for colorimetric detection of ascorbic acid in beverages. *New J. Chem.* 2020, 44, doi:10.1039/c9nj05879f.
- 5. Chen, M.; Lu, R.; Yu, A. Water-soluble graphitic carbon nitride as an oxidase-like mimic for calorimetric detection of ascorbic acid. *Mater. Lett.* **2020**, *263*, doi:10.1016/j.matlet.2019.127253.
- 6. Arayachukiat, S.; Kongtes, C.; Barthel, A.; Vummaleti, S.V.C.; Poater, A.; Wannakao, S.; Cavallo, L.; D'Elia, V. Ascorbic acid as a bifunctional hydrogen bond donor for the synthesis of cyclic carbonates from CO2 under ambient conditions. *ACS Sustain. Chem. Eng.* **2017**, *5*, 6392–6397, doi:10.1021/acssuschemeng.7b01650.
- 7. Mishra, S.; Chishti, B.; Fouad, H.; Seo, H.K.; Ansari, Z.A. Nanostructured cerium-oxide-based screen printed electrode for electrochemical detection of melamine via ascorbic acid. *Sci. Adv. Mater.* **2020**, *12*, 220– 227, doi:10.1166/sam.2020.3700.
- 8. Alizadeh, N.; Ghasemi, F.; Salimi, A.; Hallaj, R.; Fathi, F.; Soleimani, F. Polymer nanocomposite film for dual colorimetric and fluorescent ascorbic acid detection integrated single-cell bioimaging with droplet microfluidic platform. *Dye. Pigment.* **2020**, *173*, doi:10.1016/j.dyepig.2019.107875.
- 9. Hwang, E.T.; Tatavarty, R.; Chung, J.; Gu, M.B. New functional amorphous calcium phosphate nanocomposites by enzyme-assisted biomineralization. *ACS Appl. Mater. Interfaces* **2013**, *5*, 532–537, doi:10.1021/am302580p.
- 10. Li, J.; Kuang, D.; Feng, Y.; Zhang, F.; Xu, Z.; Liu, M. A Novel Electrochemical method for sensitive detection of melamine in infant formula and milk using ascorbic acid as recognition element. *Bull. Korean Chem. Soc.*  **2012**, *33*, 2499–2507, doi:10.5012/bkcs.2012.33.8.2499.
- 11. Malashikhina, N.; Pavlov, V. DNA-decorated nanoparticles as nanosensors for rapid detection of ascorbic acid. *Biosens. Bioelectron.* **2012**, *33*, 241–246, doi:10.1016/j.bios.2012.01.011.
- 12. Singh, V.; Mondal, P.C.; Lakshmanan, J.Y.; Zharnikov, M.; Gupta, T. "Turn on" electron-transfer-based selective detection of ascorbic acid via copper complexes immobilized on glass. *Analyst* **2012**, *137*, 3216– 3219, doi:10.1039/c2an16197d.
- 13. Gokmen, V.; Kahraman, N.; Demir, N.; Acar, J. Enzymatically validated liquid chromatographic method for the determination of ascorbic and dehydroascorbic acids in fruit and vegetables. *J. Chromatogr. A* **2000**, *881*, 309–316, doi:10.1016/s0021-9673(00)00080-7.
- 14. Guan, H.; Han, B.; Gong, D.; Song, Y.; Liu, B.; Zhang, N. Colorimetric sensing for ascorbic acid based on peroxidase-like of GoldMag nanocomposites. *Spectrochim. Acta Part A-Mol. Biomol. Spectrosc.* **2019**, *222*, doi:10.1016/j.saa.2019.117277.
- 15. Jia, M.; Sha, J.; Li, Z.; Wang, W.; Zhang, H. High affinity truncated aptamers for ultra-sensitive colorimetric detection of bisphenol A with label-free aptasensor. *Food Chem.* **2020**, *317*, 126459–126459, doi:10.1016/j.foodchem.2020.126459.
- 16. Pastore, A.; Badocco, D.; Pastore, P. Influence of surfactant chain length, counterion and OrMoSil precursors on reversibility and working interval of pH colorimetric sensors. *Talanta* **2020**, *212*, 120739– 120739, doi:10.1016/j.talanta.2020.120739.
- 17. Huang, L.; Sun, D.-W.; Pu, H.; Wei, Q. Development of nanozymes for food quality and safety detection: Principles and recent applications. *Compr. Rev. Food Sci. Food Saf.* **2019**, *18*, 1496–1513, doi:10.1111/1541- 4337.12485.
- 18. Liu, Y.; Wu, H.; Chong, Y.; Wamer, W.G.; Xia, Q.; Cai, L.; Nie, Z.; Fu, P.P.; Yin, J.-J. Platinum nanoparticles: Efficient and stable catechol oxidase mimetics. *ACS Appl. Mater. Interfaces* **2015**, *7*, 19709–19717, doi:10.1021/acsami.5b05180.

- 19. Yu, C.-J.; Chen, T.-H.; Jiang, J.-Y.; Tseng, W.-L. Lysozyme-directed synthesis of platinum nanoclusters as a mimic oxidase. *Nanoscale* **2014**, *6*, 9618–9624, doi:10.1039/c3nr06896j.
- 20. Zhang, X.; He, S.; Chen, Z.; Huang, Y. CoFe2O4 Nanoparticles as oxidase mimic-mediated chemiluminescence of aqueous luminol for sulfite in white wines. *J. Agric. Food Chem.* **2013**, *61*, 840–847, doi:10.1021/jf3041269.
- 21. Liu, J.B.; Jiang, X.M.; Wang, L.M.; Hu, Z.J.; Wen, T.; Liu, W.Q.; Yin, J.J.; Chen, C.Y.; Wu, X.C. Ferroxidaselike activity of Au nanorod/Pt nanodot structures and implications for cellular oxidative stress. *Nano Res.*  **2015**, *8*, 4024–4037, doi:10.1007/s12274-015-0904-x.
- 22. Huang, Y.; Ren, J.; Qu, X. Nanozymes: Classification, catalytic mechanisms, activity regulation, and applications. *Chem. Rev.* **2019**, *119*, 4357–4412, doi:10.1021/acs.chemrev.8b00672.
- 23. Qin, W.; Su, L.; Yang, C.; Ma, Y.; Zhang, H.; Chen, X. Colorimetric detection of sulfite in foods by a TMB-O2-Co3O4 nanoparticles detection system. *J. Agric. Food Chem.* **2014**, *62*, 5827–5834, doi:10.1021/jf500950p.
- 24. Shen, X.; Liu, W.; Gao, X.; Lu, Z.; Wu, X.; Gao, X. Mechanisms of oxidase and superoxide dismutation-like activities of gold, silver, platinum, and palladium, and their alloys: A general way to the activation of molecular oxygen. *J. Am. Chem. Soc.* **2015**, *137*, 15882–15891, doi:10.1021/jacs.5b10346.
- 25. Wang, X.; Han, Q.; Cai, S.; Wang, T.; Qi, C.; Yang, R.; Wang, C. Excellent peroxidase mimicking property of CuO/Pt nanocomposites and their application as an ascorbic acid sensor. *Analyst* **2017**, *142*, 2500–2506, doi:10.1039/c7an00589j.
- 26. Chen, W.; Li, S.; Wang, J.; Sun, K.; Si, Y. Metal and metal-oxide nanozymes: Bioenzymatic characteristics, catalytic mechanism, and eco-environmental applications. *Nanoscale* **2019**, *11*, 15783–15793, doi:10.1039/c9nr04771a.
- 27. Zhang, K.; Hu, X.; Liu, J.; Yin, J.-J.; Hou, S.; Wen, T.; He, W.; Ji, Y.; Guo, Y.; Wang, Q.; et al. Formation of PdPt alloy nanodots on gold nanorods: Tuning oxidase-like activities via composition. *Langmuir* **2011**, *27*, 2796–2803, doi:10.1021/la104566e.
- 28. Cao, Y.; Yang, Y.; Shan, Y.; Fu, C.; Nguyen Vet, L.; Huang, Z.; Guo, X.; Nogami, M. Large-scale templatefree synthesis of ordered mesoporous platinum nanocubes and their electrocatalytic properties. *Nanoscale* **2015**, *7*, 19461–19467, doi:10.1039/c5nr05772h.
- 29. Nogami, M.; Koike, R.; Jalem, R.; Kawamura, G.; Yang, Y.; Sasaki, Y. Synthesis of porous single-crystalline platinum nanocubes composed of nanoparticles. *J. Phys. Chem. Lett.* **2010**, *1*, 568–571, doi:10.1021/jz900342q.
- 30. Dong, H.; Fan, Y.; Zhang, W.; Gu, N.; Zhang, Y. Catalytic mechanisms of nanozymes and their applications in biomedicine. *Bioconjugate Chem.* **2019**, *30*, 1273–1296, doi:10.1021/acs.bioconjchem.9b00171.
- 31. Yadav, P.K.; Singh, V.K.; Chandra, S.; Bano, D.; Kumar, V.; Talat, M.; Hasan, S.H. Green synthesis of fluorescent carbon quantum dots from azadirachta indica leaves and their peroxidase-mimetic activity for the detection of H2O2 and ascorbic acid in common fresh fruits. *ACS Biomater. Sci. Eng.* **2019**, *5*, 623–632, doi:10.1021/acsbiomaterials.8b01528.
- 32. Lian, Q.; Liu, H.; Zheng, X.; Li, X.; Zhang, F.; Gao, J. Enhanced peroxidase-like activity of CuO/Pt nanoflowers for colorimetric and ultrasensitive Hg2+ detection in water sample. *Appl. Surf. Sci.* **2019**, *483*, 551–561, doi:10.1016/j.apsusc.2019.03.337.
- 33. Li, W.; Chen, B.; Zhang, H.; Sun, Y.; Wang, J.; Zhang, J.; Fu, Y. BSA-stabilized Pt nanozyme for peroxidase mimetics and its application on colorimetric detection of mercury(II) ions. *Biosens. Bioelectron.* **2015**, *66*, 251– 258, doi:10.1016/j.bios.2014.11.032.
- 34. Cao, Y.; Yang, Y.; Shan, Y.; Huang, Z. One-pot and facile fabrication of hierarchical branched Pt–Cu nanoparticles as excellent electrocatalysts for direct methanol fuel cells. *ACS Appl. Mater. Interfaces* **2016**, *8*, 5998–6003, doi:10.1021/acsami.5b11364.
- 35. Luo, W.; Zhu, C.; Su, S.; Li, D.; He, Y.; Huang, Q.; Fan, C. Self-catalyzed, self-limiting growth of glucose oxidase-mimicking gold nanoparticles. *ACS Nano* **2010**, *4*, 7451–7458, doi:10.1021/nn102592h.
- 36. Gao, L.; Zhuang, J.; Nie, L.; Zhang, J.; Zhang, Y.; Gu, N.; Wang, T.; Feng, J.; Yang, D.; Perrett, S.; et al. Intrinsic peroxidase-like activity of ferromagnetic nanoparticles. *Nat. Nanotechnol.* **2007**, *2*, 577–583, doi:10.1038/nnano.2007.260.

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

© 2020 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license (http://creativecommons.org/licenses/by/4.0/).