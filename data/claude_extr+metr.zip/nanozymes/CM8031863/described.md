# **Synthesis, Magnetic Characterization, and Sensing Applications of Novel Dextran-Coated Iron Oxide Nanorods**

Sudip Nath,† Charalambos Kaittanis,†,‡ Vasanth Ramachandran,§ Naresh S. Dalal,§ and J. Manuel Perez*,†,‡,|

*Nanoscience Technology Center, Burnett School of Biomedical Sciences, College of Medicine, and Department of Chemistry, Uni*V*ersity of Central Florida, Orlando, Florida 32826, and Department of Chemistry and Biochemistry, Florida State Uni*V*ersity, Tallahassee, Fl 32306*

*Recei*V*ed No*V*ember 24, 2008. Re*V*ised Manuscript Recei*V*ed January 31, 2009*

Monodisperse, water-soluble dextran-coated iron oxide (Fe3O4) nanorods were synthesized using a facile and scalable approach. Our room temperature method involves the mixing of an acidic solution of iron salts with a basic solution of ammonium hydroxide to facilitate initial formation of iron oxide crystals. The stability, crystallinity, and shape of these nanorods depends on the time of addition of the dextran, as well as the degree of purity of the polymer. The as-synthesized nanorods exhibit unique magnetic properties, including superparamagnetic behavior and high spin-spin water relaxivity (R2). Additionally, they possess enhanced peroxidase-like activity when compared to those reported in the literature for spherical iron oxide nanoparticles. Thus, this high yield synthetic method for polymer-coated iron oxide nanorods will expedite their use in applications from magnetic sensors, devices, and nanocomposites with magnetic and catalytic properties.

## **Introduction**

Iron oxide-based magnetic nanoparticles have been widely used in a variety of biomedical applications such as magnetic separation,1 magnetic resonance imaging,2 hyperthermia,3,4 magnetically guided drug delivery,5,6 tissue repair,3 and molecular diagnostics.7-9 For most applications, a polymeric coating is needed to improve the nanoparticles' aqueous stability, biocompatibility, and conjugation properties. For instance, dextran-coated iron oxide nanoparticles have been successfully used as magnetic resonance imaging (MRI) contrast agents because of their strong ability to dephase water protons in surrounding tissue, which results in a decrease in the MRI signal.10 In addition, the dextran coating can be cross-linked and functionalized with amino groups to facilitate the conjugation of targeting ligands for MRI and

- † Nanoscience Technology Center, University of Central Florida.
- ‡ College of Medicine, University of Central Florida.
- § Florida State University.
- |Department of Chemistry, University of Central Florida.
- (1) Wang, D. H., J.; Rosenzweig, N.; Rosenzweig, Z. *Nano Lett.* **2004**, *4*, 409–413.
- (2) Baghi, M.; Mack, M. G.; Hambek, M.; Rieger, J.; Vogl, T.; Gstoettner, W.; Knecht, R. *Anticancer Res.* **2005**, *25* (5), 3665–70.
- (3) Gupta, A. K.; Gupta, M. *Biomaterials* **2005**, *26* (18), 3995–4021.
- (4) Ito, A.; Kuga, Y.; Honda, H.; Kikkawa, H.; Horiuchi, A.; Watanabe,
- Y.; Kobayashi, T. *Cancer Lett.* **2004**, *212* (2), 167–75. (5) Kohler, N.; Sun, C.; Wang, J.; Zhang, M. *Langmuir* **2005**, *21* (19),
- 8858–64. (6) Gupta, A. K.; Curtis, A. S. *J. Mater. Sci. Mater. Med.* **2004**, *15* (4),
- 493–6.
- (7) Perez, J. M.; Josephson, L.; O'Loughlin, T.; Hogemann, D.; Weissleder, R. *Nat. Biotechnol.* **2002**, *20* (8), 816–20.
- (8) Perez, J. M.; O'Loughin, T.; Simeone, F. J.; Weissleder, R.; Josephson, L. *J. Am. Chem. Soc.* **2002**, *124* (12), 2856–7.
- (9) Perez, J. M.; Simeone, F. J.; Saeki, Y.; Josephson, L.; Weissleder, R. *J. Am. Chem. Soc.* **2003**, *125* (34), 10192–3.
- (10) Perez, J. M.; Josephson, L.; Weissleder, R. *Chembiochem* **2004**, *5* (3), 261–4.

in vitro diagnostics applications.11 Current synthetic procedures for dextran-coated iron oxide nanoparticles involve the formation of the iron oxide core in the presence of dextran, as stabilizer and capping agent.12 Under these in situ conditions, the nature, quality, and amount of the polymer modulate the nucleation, growth, and size of the newly formed iron oxide nanocrystal. A common characteristic of most reported in situ dextran-coated iron oxide nanoparticles synthetic procedures is the formation of nanoparticles with a spherical iron oxide core.

Research efforts have been geared toward the production of small, uniform and highly dispersed spherical nanocrystals. Only recently, the importance of the nanoparticles' shape has been recognized, in particular one-dimensional (1D) structures such as nanorods and nanotubes, because they exhibit unique properties that are different from their corresponding zero dimensional counterparts (0D or spherical nanocrystals). Particularly in the case of iron oxide, 1D nanorods have been found to exhibit interesting magnetic properties because of their shape anisotropy, such as higher blocking temperatures and larger magnetization coercivity, compared to their 0D counterparts.13-16 However, their wide application in biomedical research has been hampered by difficult procedures, use of toxic reagents,17 and poor yields. For instance, current methods for iron oxide

- (12) Thorek, D. L.; Chen, A. K.; Czupryna, J.; Tsourkas, A. *Ann. Biomed. Eng.* **2006**, *34* (1), 23–38.
- (13) Peng, X.; Manna, L.; Yang, W.; Wickham, J.; Scher, E.; Kadavanich, A.; Alivisatos, A. P. *Nature* **2000**, *404* (6773), 59–61.
- (14) Hu, J.; Li, L.; Yang, W.; Manna, L.; Wang, L.; Alivisatos, A. P. *Science* **2001**, *292* (5524), 2060–3.
- (15) Puntes, V. F.; Krishnan, K. M.; Alivisatos, A. P. *Science* **2001**, *291* (5511), 2115–7.
- (16) Melosh, N. A.; Boukai, A.; Diana, F.; Gerardot, B.; Badolato, A.; Petroff, P. M.; Heath, J. R. *Science* **2003**, *300* (5616), 112–5.

<sup>*</sup> Corresponding author. E-mail: jmperez@mail.ucf.edu

<sup>(11)</sup> Josephson, L.; Tung, C. H.; Moore, A.; Weissleder, R. *Bioconjugate Chem.* **1999**, *10* (2), 186–91.

nanorods involve hydrothermal,18,19 sol-gel,20 and high-temperature procedures,17,21 among others. Therefore, water-based synthetic procedures for iron oxide nanorods that are simple, economical, low temperature, and high yield are in high demand. In particular, synthetic methods that yield water-soluble and stable polymer-coated nanorods would be ideal for studies geared toward the development of magnetic biosensors and magnetic devices.

Here we report a facile, high-yield, room-temperature, and water-based synthetic protocol that yields disperse dextrancoated iron oxide nanorods (DIONrods). Our synthetic procedure differs from those previously reported methods for dextrancoated iron oxide nanoparticles in that the dextran is not present during the initial nucleation process. Instead, the dextran is added at a later stage. This "stepwise" process, as opposed to the in situ process, allows the formation of stable, disperse, and highly crystalline iron oxide nanorods that exhibit supermagnetic behavior and improved high water relaxivity. First, we used these nanorods as magnetic nanosensors for the sensitive and fast detection of a particular bacterium in milk, achieving a detection limit of 6 cfu (colony forming units) in just 5 min. Next, the peroxidase-like activity of the as-synthesized rods was also evaluated, demonstrating that our DIONrods possess enhanced peroxidase activity as compared to their spherical counterparts. Finally, studies using dextrans with various degrees of purity revealed that rod formation is favored when a highly pure polymer is used.

## **Materials and Methods**

**Materials.** Iron salts, FeCl2 · 4H2O, and FeCl3 · 6H2O were purchased from Sigma. Dextran (10 kDa) was received from Amersham Biosciences and Sigma. Sulfo-*N*-hydroxysuccinimide-LC-Biotin, disuccinimidyl suberate (DSS) and *N* -Succinimidyl 3-(2-pyridyldithio)-propionate (SPDP) were purchased from Pierce. The peroxidase-sensitive dye 3,3′,5,5′-tetramethylbenzidine (TMB), protein G, and concanavalin A were received from Sigma. The anti-MAP antibody and MAP bacteria were kindly supplied by Dr Saleh Naser from the Microbiology and Molecular Biology Department, University of Central Florida.

**Synthesis of Iron Oxide Nanoparticles.** An acidic solution of iron salts containing 0.203 g of FeCl2 · 4H2O and 0.488 g of FeCl3 · 6H2O in HCl solution (88.7 *µ*L of 12 N HCl in 2 mL of water) was mixed with ammonium hydroxide solution (830 *µ*L of NH4OH in 15 mL of DI water) under stirring conditions using a digital vortex meter. The reaction mixture turned black instantaneously and after a few seconds (*θ*) of stirring, a solution of dextran (5 g in 10 mL of DI water) was added to yield dextran-coated iron oxide nanoparticles. The resultant solution continued to be stirred for 1 h and was then centrifuged at 13 000 rpm for 30 min to get rid of large particles. The supernatant was collected, washed several times with distilled water, and concentrated through an Amicon 8200 cell (Millipore ultrafiltration membrane YM - 30 k). This results in dextran-coated iron oxide nanorods (DIONrods). To prepare aminated nanoparticles, 3 mg (i.e., 3 mL of solution containing ∼1 mg of iron/mL) of DIONrod suspension in water was treated with 5 mL of 0.5 M NaOH and 200 *µ*L of epicholohydrin. The mixture was stirred vigorously at room temperature for 8 h. Afterward, 850 *µ*L of 30% ammonia was added and stirred for 12 h to complete the amination procedure. The free epichlorohydrin was removed by washing the solution repeatedly with distilled water using Amicon cell. The resulting aminated DIONrods are highly stable in water and phosphate buffer saline for months.

**Characterization.** The particles were characterized using HR-TEM (FEI TECNAI F30), XPS (Physical Electronics 5400 ESCA) and XRD (Rigaku D/MAX XRD) techniques. T2 was measured using a Bruker Minispec mq20 NMR analyzer operating at 0.47 T at 37 °C. A Quantum Design SQUID magnetic property measurement system (MPMS XL) was used to perform all the magnetic measurements on the Fe3O4 nanoparticles. Zero-field-cooled (ZFC) and field-cooled (FC) measurements of dc magnetic susceptibility were done using a 200 G field, by varying the temperature from 1.8 to 250 K. In the ZFC process, the sample was first cooled under zero external magnetic field, followed by the application of *H* ) 200 G, whereas in the FC process, the sample was cooled in the presence of magnetic field *H* ) 200 G, before sweeping the temperature. Hysteresis loops were measured at temperatures 5, 100, and 200 K with the magnetic field varying from -2 to 2 T. Zero field ac magnetic susceptibility as a function of temperature was measured at frequencies ranging from 0.01 Hz to 1 kHz, using a drive field of 5 G. The amount of iron present per ml of solution was determined using acid digestion method. The quantification of amines present on the surface of the aminated DIONrods was done as described.11

**Synthesis of MAP Nanosensors and Detection of MAP Bacteria in Milk.** The aminated DIONrods were centrifuged at 13 000 rpm and the pellet was redispersed in DMSO. The nanorods suspension in DMSO (650 *µ*L, 0.1 mg Fe/mL) was then incubated with 6.89 mg of disuccinimidyl suberate (DSS) for 12 h at room temperature. The reaction mixture was then centrifuged and the pellet was washed and redispersed in PBS. Finally, the modified nanorods were incubated with protein G (1 mg/ml) and kept for 12 h at 4 °C. The excess protein G was removed by magnetic separation using a MACS magnetic column and the amount of protein G was assessed by protein assay as described. 9,22

The resulting protein G-conjugated nanorods (protein G DIONrods) were treated with anti-MAP-antibody (10 *µ*L) and incubated overnight in order to facilitate a stable protein G-anti-MAPantibody association. The average number of antibodies conjugated per nanoparticle was assessed as previously described. 9,11,22 The resulting anti-MAP DIONrods (200 *µ*L) were used as magnetic nanosensors to detect MAP bacteria in milk (20 *µ*L) and the changes in T2 were monitored using a 0.47T magnetic relaxometer (MiniSpec, Bruker) to detect the bacteria present in the sample.

**Kinetic Assay of DIONrods Peroxidase Activity.** The peroxidase activity of the iron oxide nanoparticles was evaluated via steady-state kinetic assays at room temperature. Specifically, serial dilutions of TMB were prepared in citrate buffer (pH 4), and 100 *µ*L aliquots were dispensed in a 96-well plate. Subsequently, aliquots of either the corresponding DIONrod preparations, having equal iron concentrations (2 *µ*g per mL), were added to the wells. After addition of 25 *µ*L of H2O2 (30%), each well's absorbance was recorded at 652 nm, using a Synergy HT microtiter plate reader (Biotek).The kinetic parameters were determined via the Michaelis-Menten equation: *´ı* ) *V*max [S]/(*K*m + [S]), where *´ı* is the initial rate of reaction, *V*max is the maximum rate of reaction, [S] is the substrate's concentration, and *K*m is the Michaelis constant.

<sup>(17)</sup> Park, S. J.; Kim, S.; Lee, S.; Khim, Z. G.; Char, K.; Hyeon, T. *J. Am. Chem. Soc.* **2000**, *122* (35), 8581–8582.

<sup>(18)</sup> Wang, J. P., Z. M.; Huang, Y. J.; Chen, C. W. *J. Cryst. Growth* **2004**, *263*, 616–619.

<sup>(19)</sup> Zhao, Y. M.; Li, Y. H.; Ma, R. Z.; Roe, M. J.; McCartney, D. G.; Zhu, Y. Q. *Small* **2006**, *2* (3), 422–427.

<sup>(20)</sup> Corr, S. A.; Gun'ko, Y. K.; Douvalis, A. P.; Venkatesan, M.; Gunning, R. D.; Nellist, P. D. *J. Phys. Chem. C* **2008**, *112* (4), 1008–1018.

<sup>(21)</sup> Wen, X.; Wang, S.; Ding, Y.; Wang, Z. L.; Yang, S. *J. Phys. Chem. B* **2005**, *109* (1), 215–20.

<sup>(22)</sup> Kaittanis, C.; Naser, S. A.; Perez, J. M. *Nano Lett.* **2007**, *7* (2), 380– 3.

**Table 1. Effect of the Time of Addition of Dextran (***θ***) on the R2 Relaxivity of the DIONrods**

| time of addition of dextran (θ) | R2 (mM-1 s-1<br>) |
|---------------------------------|-------------------|
| before adding ammonia           | <1                |
| 1 s                             | 50 ( 2            |
| 10 s                            | 150 ( 7           |
| 30 s                            | 300 ( 5           |
| 60 s                            | 300 ( 9           |
|                                 |                   |

## **Results and Discussions**

In our first set of experiments, we optimized the synthetic protocol, including the order of addition (in situ vs stepwise), and the time of addition of the dextran polymer. Our waterbased synthetic protocol involves an acid-base reaction between an acidic solution of iron salts and a basic solution of ammonium hydroxide. Upon mixing, the resulting solution becomes alkaline (pH 9.0), facilitating the formation of iron oxide nanocrystals. This initial formation of nanocrystals can occur either in the presence (in situ) or absence (stepwise) of dextran. Because most synthetic procedures that afford stable and monodisperse nanoparticles use an in situ approach, we opted to follow this approach first. In these experiments, a mixture of iron salts (FeCl3 · 6H2O and FeCl2 · 4H2O) was dissolved in an aqueous solution of HCl, whereas a dextran solution was prepared in aqueous ammonia solution and placed on a digital vortex meter. Next, the acidic iron salt solution was poured into the ammonia solution of dextran under vigorous stirring condition. Following this protocol, we obtained poorly crystalline, spherical nanocrystals of 20 ( 5 nm in diameter and poor R2 relaxivity (<1 mM-1 s-1 ). This poor relaxivity contrasts with the relaxivity obtained with other published in situ procedures where relaxivity values between 60 and 100 mM-1 s-1 are obtained.

We then investigated if a stepwise approach will result in larger iron oxide nanocrystals and an improvement in R2 relaxivity. In this approach, a dextran solution was added at a particular time (*θ*) after initiating the iron oxide nanocystal's nucleation process. In initial optimization experiments, we measured T2 relaxivity (R2) and obtained TEM images of a series of dextran coated iron oxide nanoparticles prepared after adding dextran at different (*θ*) times (1, 10, 30, and 60 s). Following this approach, we obtained nanorods for which their size and R2 relaxivity can be fine-tuned by varying the time of dextran's addition (*θ*) (Table 1). No significant difference was observed in the cystallinity and magnetic properties (particularly R2) of the nanorods synthesized at *θ* g 30 s. However, the yield of the iron oxide nanorods was greatly reduced under these conditions (*θ* g 30 s), based on measurements of the iron concentrations of the nanorods' suspension.11,23 The observed low yield at *θ* g 30 s could be due to the fact that a higher number of larger (micrometer-size) crystals are formed when the stabilizing agent (dextran) is added at a later time after initiation of the nucleation process. These micrometer-size particles tend to precipitate easily and are removed from suspension during the purification process. Because the most optimal preparation was obtained when dextran was added 30 s after initiating the iron oxide nucleation, we then adopted these conditions in our nanorods synthesis.

TEM studies (Figure 1a) of the DIONrods preparation (R2 ) 300 mM-1 s-1 ) reveal monodisperse rod-shaped iron oxide crystals, with an average length of 310 ( 10 nm and width of 135 ( 5 nm, for an aspect ratio of 2.3. Corresponding HRTEM (Figure 1b) analysis and selected area electron diffraction (**inset of** Figure 1b) confirm the formation of highly crystalline nanocrystals. X-ray diffraction pattern of DIONrods Figure 1c indicates eight distinct peaks at 18.2, 30.1, 35.6, 37, 44.2, 53.6, 57, and 62.5°, accounting for crystal planes 111, 200, 311, 222, 400, 422, 511, and 440. These X-ray diffraction data correspond to the formation of magnetite (Fe3O4) nanocrystals.24 Meanwhile, XPS was performed to determine the oxidation state of the iron present. Two distinct peaks at 715 and 728 eV representing Fe2p3/2 and Fe2p1/2 orbital electrons, as shown in Figure 1d, confirmed the formation of magnetite in the solution.25

Using SQUID magnetometry, we studied the magnetic properties of the DIONrods.26 First, hysteresis loops measured at three different temperatures (Figure 2a) demonstrated a coercivitiy of 500 ( 10 G at 5 K that disappeared at 100 and 200 K, which is typical of superparamagnetic behavior. Zero-field-cooled (ZFC) and field-cooled (FC) dc susceptibility studies (Figure 2b) show that the ZFC magnetic moment increased as the temperature increased, reaching a maximum at 28 K (the blocking temperature, *T*B); it then decreased with a further increase in temperature. In the FC process, above the blocking temperature (*T*B), the data followed the ZFC curve but deviated from ZFC curve below *T*B, showing a slow increase in the moment with decreasing temperature. The maximum found in the ZFC curve (at *T*B) is where a maximum number of particles exhibit superparamagnetic behavior. Below *T*B, the relaxation times of the particles are longer than the experimental measurement time; hence the particles acquire a blocked state. In the ac susceptibility, both real and imaginary components *-*′(*T*) and *-*′′(*T*), at different frequencies ranging from 1 Hz to 1kHz exhibited a frequency-dependent maximum (panels c and d in Figure 2), which shifted to higher temperatures with increasing frequency. This may be due to either spin glass or superparamagnetic behavior. To clearly distinguish between these two behaviors, we calculated the Mydosh parameter (Φ) from the real part of the ac susceptibility according to the following equation27

$$\Phi = \frac{\Delta T_{\rm m}}{T_{\rm m} [\Delta \log_{10}(\nu)]}$$

Here, *T*M is the temperature corresponding to the observed maximum at the lower-frequency end.27 We used the *-*′(1

- (25) Zou, G.; Xiong, K.; Jiang, C.; Li, H.; Li, T.; Du, J.; Qian, Y. *J. Phys. Chem. B* **2005**, *109* (39), 18356–60.
- (26) Magana, D.; Perera, S. C.; Harter, A. G.; Dalal, N. S.; Strouse, G. F. *J. Am. Chem. Soc.* **2006**, *128* (9), 2931–9.
- (27) Mydosh, J. A. *Spin Glasses*; Taylor & Francis: Washington D.C., 1993.

<sup>(23)</sup> Shen, T.; Weissleder, R.; Papisov, M.; Bogdanov, A., Jr.; Brady, T. J. *Magn. Reson. Med.* **1993**, *29* (5), 599–604.

<sup>(24)</sup> Jun, Y. W.; Huh, Y. M.; Choi, J. S.; Lee, J. H.; Song, H. T.; Kim, S.; Yoon, S.; Kim, K. S.; Shin, J. S.; Suh, J. S.; Cheon, J. *J. Am. Chem. Soc.* **2005**, *127* (16), 5732–3.

<DESCRIPTION_FROM_IMAGE>The image consists of four panels labeled (a), (b), (c), and (d), each presenting different analytical data related to a nanomaterial study.

(a) Transmission Electron Microscopy (TEM) image:
This panel shows a TEM micrograph of nanoparticles dispersed on a substrate. The nanoparticles appear as dark, rod-shaped structures against a lighter background. The scale bar indicates 500 nm, allowing for size estimation of the nanoparticles. The particles seem to be approximately 100-200 nm in length and 30-50 nm in width.

(b) High-Resolution TEM (HRTEM) image:
This panel presents a high-resolution TEM image of a single nanoparticle, showing lattice fringes that indicate crystallinity. The scale bar indicates 5 nm. In the top right corner, there's an inset showing a selected area electron diffraction (SAED) pattern, which appears as a series of bright spots arranged in concentric circles, confirming the crystalline nature of the nanoparticle.

(c) X-ray Diffraction (XRD) pattern:
This graph shows an XRD pattern with intensity (counts) on the y-axis and 2θ (degrees) on the x-axis, ranging from 0 to 80 degrees. Several peaks are labeled with their corresponding 2θ values:
- 111 at approximately 22°
- 220 at approximately 32°
- 311 (the most intense peak) at approximately 36°
- 400 at approximately 43°
- 422 at approximately 53°
- 511 and 440 (overlapping) at approximately 63°

The presence of these peaks and their positions suggest a cubic crystal structure, possibly belonging to a spinel-type oxide.

(d) X-ray Photoelectron Spectroscopy (XPS) spectrum:
This graph shows an XPS spectrum focusing on the Fe 2p region. The x-axis represents binding energy in electron volts (eV), ranging from 700 to 730 eV. The y-axis shows intensity in arbitrary units (a.U.). Two main peaks are labeled:
- Fe2p3/2 at approximately 711 eV
- Fe2p1/2 at approximately 724 eV

The presence of these peaks and their positions confirm the presence of iron in the sample, likely in the Fe3+ oxidation state, which is consistent with iron oxide nanoparticles.

Overall, these four panels provide complementary information about the morphology, crystal structure, and chemical composition of iron oxide nanoparticles, likely magnetite (Fe3O4) or maghemite (γ-Fe2O3).</DESCRIPTION_FROM_IMAGE>

**Figure 1.** (a) TEM, (b) HRTEM and SAED (inset), (c) XRD, and (d) XPS analyses of DIONrods.

Hz) and *-*′′(1kHz) data to calculate Φ. The calculated value of Φ is 0.072, which is close to the average value of ∼0.1 for superparamagnetic systems.26-29 Taken together, these results show that our DIONrods exhibit superparamagnetic behavior.

Furthermore, we performed experiments to assess the quality and stability of our nanorods in aqueous suspensions. First, the presence of dextran on nanorods' surface was confirmed by performing clustering experiments with Concanavalin-A (ConA).30,31 Specifically, the presence of dextran on the nanoparticles' surface can be identified via ConAinduced nanoparticle clustering, due to the strong affinity and multivalency of ConA toward carbohydrates, such as dextran. DLS experiments (Figure 3a) show a time-dependent increase in particle size distribution upon ConA addition, due to formation of nanoparticle assemblies. Most importantly, a fast and reproducible change in T2 relaxation time was observed (Figure 3b), indicating not only the association of dextran with the nanoparticle but also the feasibility of our DIONrods as magnetic relaxation sensors.

FT-IR experiments (Figure 3c) further confirmed the presence of characteristic dextran peaks on the DIONrod preparations. Most importantly, the prepared DIONrods can

- (28) Goya, G. F. B., T. S.; Fonseca, F. C.; M, P. *J. Appl. Phys.* **2003**, *94*, 3520.
- (29) Culp, J. T.; Park, J. H.; Meisel, M. W.; Talham, D. R. *Inorg. Chem.* **2003**, *42* (9), 2842–8.
- (30) Nath, S.; Kaittanis, C.; Tinkham, A.; Perez, J. M. *Anal. Chem.* **2008**, *80* (4), 1033–8.
- (31) Perez, J. M.; Asati, A.; Nath, S.; Kaittanis, C. *Small* **2008**, *4* (5), 552– 6.

be concentrated in PBS by ultrafiltration, obtaining highly concentrated preparations without nanoparticle precipitation even upon storage at 4 °C for more than 12 months (see Figure 1 in the Supporting Information). Taken together, these results demonstrate the robustness of the dextran coating on the nanorods, making them suitable for biomedical applications.

These experiments encouraged us to study the use of our DIONrods as magnetic sensors for bacterial detection. The need for developing fast, sensitive, and reliable detection methods for bacteria in food, the environment, and clinical samples is crucial, in order to safeguard public health. We hypothesized that nanoparticles with larger R2 relaxivity would allow us to use lower amount of nanoparticles (lower amount of iron) and potentially improve the detection limit. We tested our hypothesis using *Mycobacterium a*V*ium* spp. *paratuberculosis* (MAP) as our model organism, because the identification of MAP using current methods is difficult due to the bacterium very slow growth. Recently, we reported the detection of MAP in milk with magnetic nanoparticles within 45 min.22 Therefore, we examined if the iron oxide nanorods described herein, having enhanced magnetic properties, can improve the assay's bacterial detection kinetics. For these experiments, we first cross-linked and aminated the dextran of the iron oxide nanorods to yield aminated-DIONrods, before conjugation with anti-MAP antibodies via protein G as previously described.22 The resulting anti-MAP DIONrods (2 *µ*g of Fe per mL) were stable in aqueous solutions and complex media (e.g., PBS, milk) and had an average of 40 antibodies per nanoparticle. This high number

<DESCRIPTION_FROM_IMAGE>The image contains four separate graphs labeled (a), (b), (c), and (d), each depicting different aspects of magnetic properties.

(a) Magnetization (σ) vs. Applied Magnetic Field (T):
This graph shows hysteresis loops at three different temperatures: 5K, 100K, and 200K. The y-axis represents magnetization (σ) in emu/g, ranging from -8 to 8. The x-axis shows the applied magnetic field (T) from -2 to 2 Tesla. The loops demonstrate ferromagnetic behavior, with the 5K curve showing the largest saturation magnetization and coercivity, followed by 100K and 200K curves, indicating a decrease in magnetic ordering with increasing temperature.

(b) Magnetic Susceptibility (χ) vs. Temperature (K):
This graph shows the temperature dependence of magnetic susceptibility (χ) in emu g⁻¹. The x-axis represents temperature from 0 to 250 K. The y-axis shows χ values from 0 to 2.5 emu g⁻¹. The graph includes two curves: FC (Field Cooled) and ZFC (Zero Field Cooled). The FC curve shows a sharp increase in susceptibility at low temperatures, peaking around 25 K, followed by a gradual decrease. The ZFC curve shows a similar trend but with lower values at low temperatures.

(c) Real part of AC Susceptibility (χ') vs. Temperature (K):
This graph displays the temperature dependence of the real part of AC susceptibility (χ') for different frequencies: 1 Hz, 10 Hz, 100 Hz, and 1000 Hz. The x-axis shows temperature from 0 to 140 K, while the y-axis represents χ' values from 0 to 0.10 emu/g. All curves show a similar pattern with a peak around 40 K, but the peak height decreases and slightly shifts to higher temperatures as frequency increases.

(d) Imaginary part of AC Susceptibility (χ") vs. Temperature (K):
This graph shows the temperature dependence of the imaginary part of AC susceptibility (χ") for the same frequencies as in graph (c): 1 Hz, 10 Hz, 100 Hz, and 1000 Hz. The x-axis represents temperature from 0 to 140 K, while the y-axis shows χ" values from 0 to 0.008 emu/g. All curves exhibit a peak, with the peak position shifting to higher temperatures and becoming broader as frequency increases. The 1 Hz curve peaks around 30 K, while the 1000 Hz curve peaks closer to 40 K.

These graphs collectively provide information about the magnetic properties of the material, including its response to applied fields, temperature dependence, and frequency-dependent behavior, suggesting complex magnetic dynamics possibly related to superparamagnetism or spin glass behavior.</DESCRIPTION_FROM_IMAGE>

**Figure 2.** (a) Hysteresis loops obtained at temperatures 5, 100, and 200 K; (b) zero-field-cooled (ZFC) and field-cooled (FC) magnetic susceptibilities in an external magnetic field *H* ) 200 G; (c) real and (d) imaginary components of ac susceptibility at different frequencies.

of antibodies per particle is due to the larger volume (and therefore surface area) available for binding, which facilitates a larger number of protein G and antibody being conjugated per particle. In our first set of sensing experiments, we used the anti-MAP DIONrods to sense and quantify MAP bacteria in milk. Figure 4a shows a fast response of the anti-MAP DIONrods in the presence of bacteria (100 cfu or colony forming units) in milk, indicated by prominent changes in T2 that plateau at approximately 20 ( 1 ms, 30 min postbacterial addition. In control experiments, using protein G conjugated DIONrods and no anti-MAP antibodies as well as in saturation experiments where the MAP bacteria was preincubated with the anti-MAP antibodies before sensing, no significant time-dependent increase in T2 was observed. These results to indicate that the fast and sensitive detection of MAP is dependent on the anti-MAP antibody attached to the nanorods.

These results encouraged us to perform dose-dependent experiments using lower bacterial concentrations and a shorter incubation time. We hypothesized that detection could be obtained within minutes after addition of the DIONrods, due to the nanorods' high R2 and the high number of antibodies per nanorods. For these experiments, bacterial solutions of MAP were prepared through serial dilutions in milk from an initial stock of 100 cfu of MAP. Afterward, a solution containing the DIONrods (2 *µ*g of Fe per mL) was treated with 20 *µ*L of the corresponding bacterial dilution and incubated for only 5 min at room temperature before measurements were taken. The changes in the T2 relaxation times were monitored with respect to control containing same amount of nanosensor and 20 *µ*L of milk. Results show a linear correlation between ∆T2 and the amount of MAP bacteria in cfu within 5 min of incubation (Figure 4b). Notably, the detection limit (6 cfu) and detection kinetics (5 min) of the assay in milk were improved when the nanorods were used as compared to previous reports with spherical nanoparticles.22 Hence, the observed improvement in bacterial detection using the developed anti-MAP DIONrods can be attributed to both their high magnetic water relaxivity and their large number of antibodies per nanoparticle.

One of the most interesting properties of nanomaterials is the enhanced catalytic activities that some of these materials exhibit. Recently, the peroxidase-like activity of iron oxide nanoparticles has been reported.32,33 Therefore, we decided to investigate if our DIONrods, being larger and with a different core geometry (nanorods instead of nanospheres), still possess similar peroxidase-like activity. In these experiments, we incubated DIONrods (2 *µ*g of Fe per mL) with the peroxidase-sensitive dye 3,3′,5,5′-Tetramethylbenzidine (TMB, 0.4 mM), which develops a blue color upon oxidation in the presence of hydrogen peroxide and a peroxidase. Results showed that the DIONrods possess peroxidase-like

<sup>(32)</sup> Gao, L. Z., J.; Nie, L.; Zhang, J.; Zhang, Y.; Gu, N.; Wang, T.; Feng, J.; Yang, D.; Perrett, S.; Yan, X. *Nat. Nanotechnol.* **2007**, *2*, 577z– 583.

<sup>(33)</sup> Perez, J. M. *Nat. Nanotechnol.* **2007**, *2* (9), 535–536.

<DESCRIPTION_FROM_IMAGE>The image contains three separate graphs labeled (a), (b), and (c).

Graph (a):
This graph shows the relationship between Size (nm) and Time (min). The x-axis represents Time ranging from 0 to 60 minutes. The y-axis represents Size, ranging from 320 to 480 nm. The plot shows an increasing trend that plateaus. Data points are shown at 0, 40, and 60 minutes with error bars. The initial size at 0 minutes is approximately 330 nm, increasing to about 450 nm at 40 minutes, and slightly higher at 60 minutes.

Graph (b):
This graph depicts ΔT2 (ms) versus Time (min). The x-axis represents Time from 0 to 200 minutes. The y-axis shows ΔT2 values from 0 to 30 ms. The plot shows a rapid increase from 0 to about 30 ms within the first few minutes, followed by a plateau. Data points with error bars are shown at regular intervals up to 200 minutes, maintaining a consistent ΔT2 value of approximately 30 ms after the initial increase.

Graph (c):
This graph presents FTIR spectra, showing %T (percent transmittance) against Wavenumber (cm^-1). The x-axis represents Wavenumber ranging from 500 to 4000 cm^-1. The y-axis shows %T from 70% to 100%. Two spectra are shown and labeled: "DION" and "Dextran". Both spectra exhibit multiple peaks and troughs characteristic of FTIR spectra. The Dextran spectrum shows a prominent sharp peak around 1000 cm^-1, while the DION spectrum has notable features around 1000 cm^-1 and 3000 cm^-1.

These graphs likely represent data from an experiment involving the characterization of nanoparticles or a similar system, showing size evolution over time, relaxometry measurements (ΔT2), and FTIR spectral analysis of the components.</DESCRIPTION_FROM_IMAGE>

**Figure 3.** (a) Dynamic light scattering study of DIONrods with ConA. (b) Time-dependent response in T2 of DIONrods (200 *µ*L, 0.002 mg of Fe per mL) when treated with 10 *µ*L ConA (1 mg in 1 mL of 1X PBS). (c) FTIR spectra of free dextran and DIONrods.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled (a) and (b).

Graph (a):
This graph shows the relationship between Time (min) on the x-axis and ΔT2 (ms) on the y-axis. The x-axis ranges from 0 to 200 minutes, while the y-axis ranges from 0 to 20 ms. The plot shows a rapid increase in ΔT2 from 0 to about 20 ms within the first 20 minutes, after which it plateaus and remains constant at approximately 20 ms for the remainder of the time up to 200 minutes. The data points are represented by small squares with error bars, and a curve is fitted through these points.

Graph (b):
This graph depicts the relationship between MAP (CFU) on the x-axis and ΔT2 (ms) on the y-axis. The x-axis is on a logarithmic scale ranging from 1 to 100 CFU, while the y-axis ranges from 3 to 8 ms. The plot shows a linear increase in ΔT2 as MAP (CFU) increases. Data points are represented by squares with error bars, and a straight line is fitted through these points. The relationship appears to be directly proportional, with ΔT2 increasing from about 4 ms at 1 CFU to about 8 ms at 100 CFU.

Both graphs use ΔT2 (ms) as the y-axis, suggesting they are related measurements, possibly from the same experiment or study. The abbreviation MAP likely stands for Mycobacterium avium subspecies paratuberculosis, and CFU stands for Colony Forming Units, a measure of viable bacterial cells. These graphs could be representing the detection or growth of MAP over time (graph a) and the relationship between MAP concentration and some measured parameter ΔT2 (graph b).</DESCRIPTION_FROM_IMAGE>

**Figure 4.** (a) Time-dependent response of anti-MAP DIONrods (200 *µ*L, 0.002 mg of Fe per mL) incubated with 100 cfus of MAP in milk after a 30 min incubation. (b) Dose-dependent responses of MAP at different cfus after a 5 min incubation with anti-MAP DIONrods. MAP was diluted in milk and added to the nanosensors' solutions (200 *µ*L, containing 0.002 mg of Fe per mL) and changes in T2 were monitored with respect to control containing milk.

activity as judged by their ability to oxidize the TMB dye in the presence of hydrogen peroxide within 30 min (Figure 5a, vial 2). The observed peroxidase-like activity of our DIONrods is pH-dependent as no oxidation of the dye is observed at pH 7. These results are in line with those recently reported using nanospheres; however, it is worth mentioning that our nanoparticles are bigger, of different shape (nanorods instead of nanospheres), and more magnetic than those previously used. Furthermore, we determined the kinetic parameters of the DIONrods peroxidase-like activity, utilizing TMB as the peroxidase substrate. Specifically, a Michaelis constant, (*K*m) of 0.5 mM and a maximal reaction velocity (*V*max) of 11.6 × 10-8 M/s were obtained from the corresponding LineWeaver-Burk plot (Figure 5b). Notably, the DIONrods' *V*max is higher than the ones reported for spherical iron oxide nanoparticles and horseradish peroxidase (20 and 33%, respectively), while having TMB as the peroxidase substrate.32 Furthermore, the DIONrods' affinity toward TMB is 300 times higher than that of iron oxide nanospheres that have a *K*m of ∼150 mM.32 Taken together, these data demonstrate the enhanced intrinsic peroxidase-like activity of our DIONrods.

*Superparamagnetic Dextran-Coated Iron Oxide Nanorods Chem. Mater., Vol. 21, No. 8, 2009* 1767

<DESCRIPTION_FROM_IMAGE>The image consists of two parts, labeled (a) and (b).

(a) This part shows three glass vials with black screw caps, labeled 1, 2, and 3. Vials 1 and 3 contain clear, colorless liquids. Vial 2 contains a liquid with a distinct appearance from the others.

(b) This part displays a graph, specifically a Lineweaver-Burk plot, which is commonly used in enzyme kinetics studies. The x-axis represents 1/[S] (reciprocal of substrate concentration) in units of nM^-1, ranging from -4 to 12. The y-axis represents 1/v (reciprocal of reaction velocity) in units of s/nM, ranging from 0 to 0.06.

The graph shows a linear relationship between 1/[S] and 1/v. Data points are plotted as small squares, and a best-fit line is drawn through these points. The equation of this line is provided: y = 0.0039x + 0.0086, with a correlation coefficient (R) of 0.99, indicating a strong linear relationship.

Two important kinetic parameters are derived from this plot:
1. V_max (maximum velocity) = 11.6 x 10^-8 M/s
2. K_m (Michaelis constant) = 0.5 mM

These parameters provide crucial information about the enzyme's kinetics, with V_max indicating the maximum rate of the enzyme-catalyzed reaction and K_m representing the substrate concentration at which the reaction rate is half of V_max.

The Lineweaver-Burk plot is a valuable tool for determining these kinetic constants and understanding the behavior of enzymes under varying substrate concentrations.</DESCRIPTION_FROM_IMAGE>

**Figure 5.** (a) Peroxidase-like activity of DIONrods. TMB in citrate buffer (pH 4) was treated with H2O2 only as a control (**1**), with H2O2 and DIONrods (**2**), and with DIONrods and no H2O2 (**3**). (b) Kinetics of peroxidase-like activity of DIONrods prepared from high-purity 10-K dextran (Amersham-GE).

Finally, we investigated the reproducibility and the role of the dextran's purity on the nanorods formation. Previous work by Alivisatos and others has shown that the level of purity of the stabilizer or capping agent plays a key role in the geometry of the resulting nanocrytals.34 For the synthesis of our DIONrods, we have used a 10-K dextran polymer (Amersham) with a high degree of purity. Therefore, we examined whether dextrans of lower purity could affect the formation of the nanorods. For these studies, we obtained dextrans of different degrees of purity (Sigma, and Fisher) and used them to synthesize dextran-coated iron oxide nanoparticles. We found that high-purity dextrans reproducibly yield monodisperse rods, whereas dextrans of lower purity (Sigma and Fisher) always yield polydisperse spherical nanoparticles using our procedure (see Figure 2 in the Supporting Information). These results are significant as they point to the dextran level of purity as a key factor in the formation of the DIONrods.

It has been reported that dextrans of different molecular weight adopt a particular coil conformation in solutions with distinct dimensions and sizes. For instance, typically a 500-K dextran has a diameter of 29.4 nm (Stokes radius ) 14.7 nm), whereas a 10-K dextran is roughly 4.8 nm (Stokes radius ≈ 2.4 nm).35 Hence, through dynamic light scattering (DLS), we determined that the Amersham dextrans had an average diameter of 4.84 nm, with a narrow size distribution (see Figure 2a in the Supporting Information). However, the Sigma and Fisher dextrans had two distinct broad population distributions. Specifically, 87% of the population had an average diameter of 4.8 nm, whereas the remaining 13% had significantly larger size (see Figure 2b in the Supporting Information). Interestingly, this small amount of larger molecular size fractions presumably is enough to affect the shape of the iron oxide nanoparticles (see Figure 2c,d in the Supporting Information). Additionally, the spherical iron oxide nanoparticles obtained with the less pure dextrans displayed poor crystallinity, lower T2 relaxation, and lower peroxidase activity. Specifically, the peroxidase activity of these spherical nanoparticles is lower than that of the DIONrods (*K*m ) 1.3 mM; *V*max ) 9.8 × 10-8 M/s) (see Figure 3 in the Supporting Information). The observed formation of iron oxide nanorods, when a high purity dextran polymer with narrow size distribution and average size of 4.84 nm is used, can be explained by the preferential binding of these polymers to particular surfaces in the initially formed iron oxide crystals. This initiates preferential growth of the nanoparticles in one direction. As the number of highermolecular-weight and therefore larger-sized (>100 nm) dextran impurities increases, they start interfering with this preferential growth process, therefore resulting in a polydisperse spherical iron oxide preparation.

## **Conclusion**

In summary, we have demonstrated a facile, aqueousbased, and room-temperature synthesis of polymer-coated Fe3O4 nanorod. The as-synthesized dextran-coated iron oxide nanorods (DIONrods) exhibit superparamagnetic behavior as well as enhanced water spin-spin relaxation and peroxidase activity. Furthermore, their polymer coating can be easily functionalized with amine groups and conjugated with antibodies for targeting and sensing applications. It is expected that this new type of polymer-coated iron oxide nanorod may find use in many applications including magnetic sensing and diagnostics, hyperthermia and imaging, catalytic oxidations, and the fabrication of devices and nanocomposites with dual magnetic and catalytic activity.

**Acknowledgment.** The study was partially funded by NIH Grants CA101781 and R01 GM084331, both awarded to Dr. J. Manuel Perez. The work at FSU was supported in part by the NSF (DMR 0506946 and DMR 0701462).

**Supporting Information Available:** (1) Photograph of DIONrods aqueous suspension, (2) DLS and TEM of DIONrods prepared with dextran form different ventors, (3) kinetics of peroxidase activity of DIONrods prepared using a dextran of lower purity (PDF). This material is available free of charge via the Internet at http://pubs.acs.org.

```
CM8031863
```
<sup>(34)</sup> Manna, L. S., E. C.; Alivisatos, A. P. *J. Am. Chem. Soc.* **2000**, *122*, 12700–12706.

<sup>(35)</sup> Jaiswal, J. K.; Chakrabarti, S.; Andrews, N. W.; Simon, S. M. *PLoS Biol.* **2004**, *2* (8), E233.