The image contains four separate graphs labeled (a), (b), (c), and (d), each depicting different aspects of magnetic properties.

(a) Magnetization (σ) vs. Applied Magnetic Field (T):
This graph shows hysteresis loops at three different temperatures: 5K, 100K, and 200K. The y-axis represents magnetization (σ) in emu/g, ranging from -8 to 8. The x-axis shows the applied magnetic field (T) from -2 to 2 Tesla. The loops demonstrate ferromagnetic behavior, with the 5K curve showing the largest saturation magnetization and coercivity, followed by 100K and 200K curves, indicating a decrease in magnetic ordering with increasing temperature.

(b) Magnetic Susceptibility (χ) vs. Temperature (K):
This graph shows the temperature dependence of magnetic susceptibility (χ) in emu g⁻¹. The x-axis represents temperature from 0 to 250 K. The y-axis shows χ values from 0 to 2.5 emu g⁻¹. The graph includes two curves: FC (Field Cooled) and ZFC (Zero Field Cooled). The FC curve shows a sharp increase in susceptibility at low temperatures, peaking around 25 K, followed by a gradual decrease. The ZFC curve shows a similar trend but with lower values at low temperatures.

(c) Real part of AC Susceptibility (χ') vs. Temperature (K):
This graph displays the temperature dependence of the real part of AC susceptibility (χ') for different frequencies: 1 Hz, 10 Hz, 100 Hz, and 1000 Hz. The x-axis shows temperature from 0 to 140 K, while the y-axis represents χ' values from 0 to 0.10 emu/g. All curves show a similar pattern with a peak around 40 K, but the peak height decreases and slightly shifts to higher temperatures as frequency increases.

(d) Imaginary part of AC Susceptibility (χ") vs. Temperature (K):
This graph shows the temperature dependence of the imaginary part of AC susceptibility (χ") for the same frequencies as in graph (c): 1 Hz, 10 Hz, 100 Hz, and 1000 Hz. The x-axis represents temperature from 0 to 140 K, while the y-axis shows χ" values from 0 to 0.008 emu/g. All curves exhibit a peak, with the peak position shifting to higher temperatures and becoming broader as frequency increases. The 1 Hz curve peaks around 30 K, while the 1000 Hz curve peaks closer to 40 K.

These graphs collectively provide information about the magnetic properties of the material, including its response to applied fields, temperature dependence, and frequency-dependent behavior, suggesting complex magnetic dynamics possibly related to superparamagnetism or spin glass behavior.