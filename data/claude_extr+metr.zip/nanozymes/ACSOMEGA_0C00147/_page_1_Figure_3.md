The image contains two UV-Vis absorption spectra labeled as (a) and (b).

(a) This graph shows the UV-Vis absorption spectra of three different samples:
1. PEI (Polyethyleneimine)
2. K2PtCl4 (Potassium tetrachloroplatinate)
3. PEI+K2PtCl4 (mixture of the two)

The x-axis represents the wavelength in nanometers (nm) ranging from 200 to 800 nm. The y-axis shows the absorbance values ranging from 0 to 1.0.

All three spectra show a sharp increase in absorbance below 300 nm. The PEI+K2PtCl4 mixture shows two small peaks around 300-400 nm that are not present in the individual component spectra.

(b) This graph displays the UV-Vis absorption spectra of three Pt-PEI (Platinum-Polyethyleneimine) nanoparticle samples with different platinum loadings:
1. Pt50-PEI
2. Pt100-PEI
3. Pt150-PEI

The x-axis represents the wavelength in nanometers (nm) ranging from 200 to 800 nm. The y-axis shows the absorbance values ranging from 0 to 2.0.

All three spectra show a gradual decrease in absorbance as the wavelength increases. The absorbance intensity increases with higher platinum loading, with Pt150-PEI showing the highest absorbance, followed by Pt100-PEI, and then Pt50-PEI.

An inset image shows three vials containing the nanoparticle solutions, with increasing darkness corresponding to higher platinum loading (50, 100, 150).

These spectra provide information about the optical properties and formation of Pt-PEI nanoparticles with different platinum loadings.