<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

[http://pubs.acs.org/journal/acsodf](http://pubs.acs.org/journal/acsodf?ref=pdf) Article

### Polyethyleneimine-Stabilized Platinum Nanoparticles as Peroxidase Mimic for Colorimetric Detection of Glucose

[Yanshuai Cui,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Yanshuai+Cui"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [Xiang Lai,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Xiang+Lai"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [Bo Liang,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Bo+Liang"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf)[*](#page-6-0) [Ying Liang,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Ying+Liang"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [Haotian Sun,](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Haotian+Sun"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf) [and Longgang Wang](https://pubs.acs.org/action/doSearch?field1=Contrib&text1="Longgang+Wang"&field2=AllField&text2=&publication=&accessType=allContent&Earliest=&ref=pdf)

|        | Cite This: https://dx.doi.org/10.1021/acsomega.0c00147 | Read Online             |                            |
|--------|--------------------------------------------------------|-------------------------|----------------------------|
| ACCESS | Metrics & More                                         | Article Recommendations | *sı Supporting Information |
|        |                                                        |                         |                            |

ABSTRACT: Colorimetric detection of glucose using enzyme-mimic nanoparticles (NPs) has been drawing great attention. However, many NPs lack good stability in solution, which results in reduced color change of substrates in colorimetric detection. Liner soluble macromolecules with high cationic density may be suitable candidates for the stabilization of NPs. Herein, we prepared polyethyleneimine-stabilized platinum NPs (Ptn-PEI NPs) for colorimetric detection of glucose. The platinum NPs (Pt NPs) used in this system had small size (from 3.21 to 3.70 nm) and narrow size distribution. Pt50-PEI NPs had high

stability within one week with a hydrodynamic size of ∼25 nm and slightly positive zeta potential. Pt50-PEI NPs-catalyzed oxidation of 3,3′,5,5′-tetramethylbenzidine (TMB) in the presence of H2O2, generating blue oxidized TMB (oxTMB), which indicated the peroxidase-like property of Pt50-PEI NPs. The optimal condition for this reaction was pH = 4.0 at 30 °C. More importantly, Pt50-PEI NPs were successfully used to detect glucose concentration by a colorimetric method with high selectivity. The established method had a linear concentration range from 10 to 5000 μM with a detection limit of 4.2 μM. For example, the concentration of glucose in saliva was tested to be 0.15 mM using our method. The high stability of Pt50-PEI NPs enhanced the high accessibility of the active center of Pt NPs for substrates and consequent excellent catalytic property. This established method has great potential to be used in various applications for glucose detection in the future.

### 1. INTRODUCTION

Natural enzymes have high catalytic efficiency and excellent specificity[.1](#page-6-0) These properties lead to their wide application in detection,[2](#page-6-0) drug delivery,[3](#page-6-0) and the degradation of organic pollutants.[4](#page-6-0) As for the detection, natural horseradish peroxidase (HRP) has been used in the catalytic oxidation of colorless 3,3,5,5-tetramethylbenzidine (TMB) into blue oxidized TMB (oxTMB) in the bio-related detection, and oxTMB has a high molar absorption coefficient[.5](#page-6-0) However, natural enzymes are relatively expensive and easy to be inactivated by the surrounding environment. It is important to seek mimic enzymes to overcome the shortage and maintain the merit of natural enzymes. Gao and co-workers first reported that magnetic Fe3O4 nanoparticles (NPs) possessed peroxidase-like activity[.6](#page-6-0) Besides, many other nanomaterials have been demonstrated to exhibit good peroxidase-like properties, such as Co3O4, [7](#page-6-0) Co4N nanowires,[8](#page-7-0) Prussian blue,[9](#page-7-0) graphene oxide,[10](#page-7-0) and noble metal nanoparticle.[11](#page-7-0) These nanomaterials have more flexible structures and higher chemical stability compared with HRP. They are capable of catalyzing the oxidation of TMB into blue oxTMB, which have been further used to detect glucose concentration. For example, core−shell gold nanorods were used for the colorimetric determination of glucose in the range of 2.5− 200 μM;[12](#page-7-0) TiO2-encapsulated Au (Au@TiO2) yolk−shell had a linear range in 5−100 μM and a detection limit of 4.0 μM[.13](#page-7-0) However, many nanomaterials lack high stability in solution, which restrains their catalytic efficiency.

Platinum element is widely used in chemical industries. Several platinum NPs (Pt NPs) possess mimetic activities.[14](#page-7-0)−[17](#page-7-0) The improvement of the catalytic activity of Pt NPs still has received increasing attention.[18](#page-7-0)−[20](#page-7-0) Smaller NPs often have larger specific surface areas. However, they are likely to form aggregation in aqueous solution because of their larger surface energy, which would restrict their catalytic efficiency. In fact, the catalytic efficiency of Pt NPs is dependent on the number of available active sites on the surface of NPs. Stable Pt NPs in aqueous solution tend to have more accessible active sites. Thus, many substances have been employed to stabilize the metal NPs, and a substantial fraction of the surface of the metal NPs participates in catalytic reactions.[21](#page-7-0),[22](#page-7-0) These substances include bovine serum albumin,[23](#page-7-0) yeast extract[,24](#page-7-0) sodium polyacrylate,[25](#page-7-0) polyvinylpyrrolidone (PVP),[26](#page-7-0) and dendrimers.[27](#page-7-0) Platinum NPs using bovine serum albumin have salt-resistant property.[23](#page-7-0) Small Pt nanoclusters were prepared using yeast extract as the reductant and stabilizer[.24](#page-7-0) Sodium polyacrylate-stabilized Pt NPs had 3.25 times higher hydrogen generation activity than that of Pt NPs without stabilization under the same conditions.[25](#page-7-0) Pt nanocubes were capped by

Received: January 12, 2020 Accepted: March 12, 2020

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image contains two UV-Vis absorption spectra labeled as (a) and (b).

(a) This graph shows the UV-Vis absorption spectra of three different samples:
1. PEI (Polyethyleneimine)
2. K2PtCl4 (Potassium tetrachloroplatinate)
3. PEI+K2PtCl4 (mixture of the two)

The x-axis represents the wavelength in nanometers (nm) ranging from 200 to 800 nm. The y-axis shows the absorbance values ranging from 0 to 1.0.

All three spectra show a sharp increase in absorbance below 300 nm. The PEI+K2PtCl4 mixture shows two small peaks around 300-400 nm that are not present in the individual component spectra.

(b) This graph displays the UV-Vis absorption spectra of three Pt-PEI (Platinum-Polyethyleneimine) nanoparticle samples with different platinum loadings:
1. Pt50-PEI
2. Pt100-PEI
3. Pt150-PEI

The x-axis represents the wavelength in nanometers (nm) ranging from 200 to 800 nm. The y-axis shows the absorbance values ranging from 0 to 2.0.

All three spectra show a gradual decrease in absorbance as the wavelength increases. The absorbance intensity increases with higher platinum loading, with Pt150-PEI showing the highest absorbance, followed by Pt100-PEI, and then Pt50-PEI.

An inset image shows three vials containing the nanoparticle solutions, with increasing darkness corresponding to higher platinum loading (50, 100, 150).

These spectra provide information about the optical properties and formation of Pt-PEI nanoparticles with different platinum loadings.</DESCRIPTION_FROM_IMAGE>

Figure 1. (a) UV−vis spectra of PEI, K2PtCl4, PEI + K2PtCl4, (b) UV−vis spectra, and photos of Ptn-PEI NPs.

PVP,[28](#page-7-0) and Pt NPs were prepared using dendrimers terminated with alkyl chains as the template.[29](#page-7-0) However, polyvinylpyrrolidone may cause cancers, and dendrimers are too expensive to be scaled up. In contrast, polyethyleneimine (PEI) has an affordable price and the highest cationic density among water-soluble polymers, providing its potential to stabilize metal NPs in large scale. In addition, the linear PEI molecule should keep most of the catalytic center of Pt NPs available. The higher amount of catalytic center could lead to the higher catalytic oxidation of TMB and obvious change. Pt NPs (12.9−70.7 nm) have been successfully prepared by PEI molecules with molecular weights from 300, 1200, and 10,000[.30](#page-7-0) However, the sizes of aforementioned Pt NPs are relatively big, and the stability of prepared NPs is not investigated. Thus, it is still necessary to obtain smaller Pt NPs with high stability in solution.

In this work, a facile method to prepare PEI (Mw 70,000) stabilized platinum NPs (Ptn-PEI NPs) was developed. The monodispersed Ptn-PEI NPs were highly stable. Ptn-PEI NPs efficiently catalyzed TMB with H2O2 to produce blue oxTMB. More importantly, the blue color of this system was dependent on the concentration of glucose. Thus, a colorimetric method based on Ptn-PEI NPs to sensitively detect glucose concentration was established for the first time. The glucose concentration of saliva was measured, suggesting the great potential of Ptn-PEI NPs for bio-related detection.

### 2. RESULTS AND DISCUSSION

2.1. Characterization of Ptn-PEI NPs. The Ptn-PEI NPs were prepared by mixing PEI solution (pH = 4.0, 1 mg/mL) and K2PtCl4 (2 mM) aqueous solution in PE tubes, where PEI was used as the template and NaBH4 was used as the reducing agent. All the tubes were located in a constant temperature metal mixer at 20 °C for 20 min. PtCl4 2− and nitrogen atom of the PEI formed a complex. The concentration of PtCl4 2− around nitrogen atoms of the PEI was much higher than that of bulk solution. Then, PtCl4 2− was very quickly reduced to zero-valent Pt atoms by the addition of strong reducing agent NaBH4. These Pt atoms gathered together to Pt NPs which stabilized by PEI. This reduction process was monitored by UV−vis spectra. Figure 1a showed that the K2PtCl4 had an obvious characteristic absorption peak at 320 and 383 nm corresponding to d−d transitions.[31](#page-7-0) Two peaks were weakened after incubation of K2PtCl4 with PEI. After the addition of NaBH4, a broad and continuous absorption appeared. In addition, as shown in Figure 1b, when the molar ratio of K2PtCl4 to PEI increased from 50 to 150, the absorbance of Ptn-PEI NPs gradually increased. The Ptn-PEI NPs were well dissolved in aqueous solution. PAMAM dendrimer-encapsulated Pt NPs also had similar results.[29](#page-7-0) Taken together, the results indicated the successful preparation of Ptn-PEI NPs.

As shown in Figure 2, PEI had several peaks from 2.45 to 2.74 ppm, which were assigned to the proton of −CH2−CH2−

<DESCRIPTION_FROM_IMAGE>The image presents two 1H NMR spectra comparing PEI (Polyethyleneimine) and Pt50-PEI (Platinum-modified Polyethyleneimine). The x-axis represents the chemical shift in parts per million (ppm), ranging from 0 to 7 ppm. The y-axis shows the signal intensity in arbitrary units.

For the PEI spectrum (top):
- A sharp, intense peak is observed at approximately 2.7-2.8 ppm, which is characteristic of the CH2 protons in the ethylene units of PEI.
- The spectrum is relatively clean with no other significant peaks, indicating a pure PEI sample.

For the Pt50-PEI spectrum (bottom):
- A broad, intense peak is observed at around 5 ppm, which is likely due to the interaction of platinum with the amine groups of PEI.
- Multiple peaks are visible in the region of 2.5-3.5 ppm, showing a more complex splitting pattern compared to pure PEI. This indicates changes in the chemical environment of the CH2 protons due to platinum coordination.
- The peaks in the 2.5-3.5 ppm region show varying intensities and some overlap, suggesting different types of platinum-amine interactions or different degrees of platinum coordination to the PEI structure.

The comparison of these spectra clearly demonstrates the structural changes in PEI upon platinum coordination, as evidenced by the appearance of new peaks and the shift in existing peaks. This spectral analysis provides valuable information about the nature of the Pt-PEI complex formation and the distribution of platinum within the polymer structure.</DESCRIPTION_FROM_IMAGE>

Figure 2. 1 H NMR spectra of PEI and Pt50-PEI.

from the PEI skeleton. After the stabilization of Pt NPs by PEI, the 1 H NMR spectrum of Pt50-PEI had a wider range from 2.45 to 3.28 ppm than that of PEI. The difference should be due to the encapsulation some proton peaks of −CH2−CH2− from the PEI skeleton by Pt NPs.

The size of metal NPs has a great impact on their catalytic efficiency. As shown in [Figure 3](#page-2-0), the sizes of prepared Pt NPs stabilized by PEI were examined by transmission electron microscopy (TEM). The sizes of Pt NPs for Pt50-PEI, Pt100- PEI, and Pt150-PEI were 3.21 ± 0.87, 3.38 ± 0.74, and 3.7 ± 0.75 nm, respectively. It should be noted that as the molar ratio of K2PtCl4 to PEI increased, the sizes of Pt NPs increased. Thus, Pt NPs had very small sizes with a narrow size distribution. They also had high dispersity without aggregation and high specific surface areas. However, the Pt NPs without stabilization by PEI showed obvious aggregation and big size ([Figure S1](http://pubs.acs.org/doi/suppl/10.1021/acsomega.0c00147/suppl_file/ao0c00147_si_001.pdf)). Thus, PEI with proper molecular weight was important for the high stability and size control of Pt NPs. One of the most common methods selected to synthesize Pt NPs involves the use of sodium polyacrylat[e25](#page-7-0) and polyvinylpyrrolidone.[26](#page-7-0) The size of Pt NPs with sodium polyacrylate was about 50 nm with certain aggregation[.25](#page-7-0) PVP is a nonionic polymer, while PEI is a cationic polymer. Spherical Pt NPs are prepared within the size from 16 to 23 nm using Punica garanatum peel extract[.32](#page-7-0) The Pt NPs (10−50 nm) are synthesized using Prunus × yedoensis tree gum.[33](#page-7-0) In short, a facile method of preparation of Ptn-PEI was established, where PEI (70,000) was used to control the size of Pt NPs and enhance the stability of Ptn-PEI.

<DESCRIPTION_FROM_IMAGE>The image presents three sets of data labeled a, b, and c, each consisting of a transmission electron microscopy (TEM) image and a corresponding histogram showing the size distribution of nanoparticles.

a) TEM image: Shows scattered nanoparticles on a light background. The scale bar indicates 20 nm. The particles appear as dark spots, varying in size and distribution, with some areas of higher concentration.

Histogram: Displays the frequency distribution of particle diameters ranging from 1 to 6 nm. The peak frequency is approximately 31% at 3 nm diameter. The distribution is slightly right-skewed, with frequencies decreasing more rapidly towards larger diameters.

b) TEM image: Similar to (a), but with fewer visible particles and a more uniform distribution. The scale bar is also 20 nm.

Histogram: Shows particle diameter distribution from 1 to 5 nm. The peak frequency is about 26% at 4 nm diameter. The distribution appears more symmetrical compared to (a).

c) TEM image: Displays a higher density of nanoparticles compared to (a) and (b), with particles more evenly distributed across the image. The scale bar remains 20 nm.

Histogram: Presents particle diameter distribution from 2 to 6 nm. The peak frequency is approximately 22% at 4 nm diameter. The distribution is relatively symmetrical, with a slight left skew.

Overall, the images demonstrate the synthesis of nanoparticles with different size distributions and concentrations, possibly representing different experimental conditions or synthesis methods. The progression from (a) to (c) shows an increase in particle density and a shift towards larger average particle sizes.</DESCRIPTION_FROM_IMAGE>

Figure 3. TEM images and relevant size distribution of Pt NPs inside of (a) Pt50-PEI, (b) Pt100-PEI, and (c) Pt150-PEI. Pt NPs stabilized by PEI had a small size from 3.21 to 3.70 nm.

<DESCRIPTION_FROM_IMAGE>The image contains two X-ray photoelectron spectroscopy (XPS) spectra labeled as (a) and (b).

(a) This graph shows a wide-scan XPS spectrum. The x-axis represents Binding Energy in electron volts (eV), ranging from 0 to 800 eV. The y-axis represents Intensity in arbitrary units (a.u.). Several peaks are visible and labeled:

1. Pt 4f: A small double peak at the lowest binding energy (around 70-80 eV)
2. C 1s: The highest intensity peak at approximately 285 eV
3. N 1s: A medium intensity peak at about 400 eV
4. O 1s: A high intensity peak at approximately 530 eV

The spectrum shows the presence of platinum, carbon, nitrogen, and oxygen in the sample.

(b) This graph shows a high-resolution XPS spectrum of the Pt 4f region. The x-axis represents Binding Energy in eV, ranging from 71 to 77 eV. The y-axis represents Intensity in arbitrary units (a.u.).

The graph contains four overlaid spectra:
1. Exp. peak (black line): The experimental data showing two main peaks.
2. Fitted peak (red line): A fitted curve closely matching the experimental data.
3. Baseline (blue line): A slightly declining baseline.
4. Pt⁰ (metallic) (pink line): A fitted curve representing metallic platinum.

Two main peaks are visible and labeled:
1. 4f7/2: The higher intensity peak at lower binding energy (around 72-73 eV)
2. 4f5/2: The lower intensity peak at higher binding energy (around 75-76 eV)

This spectrum indicates the presence of metallic platinum (Pt⁰) in the sample, as evidenced by the characteristic doublet structure of the 4f orbital split into 4f7/2 and 4f5/2 peaks. The fitting suggests that most of the platinum in the sample is in its metallic state.</DESCRIPTION_FROM_IMAGE>

Figure 4. (a) XPS spectrum of Pt50-PEI NPs and (b) binding energy of Pt 4f. Pt NPs were successfully stabilized by PEI.

X-ray photoelectron spectroscopy (XPS) is commonly used to study the surface element composition and valence state of metal composite materials[.34](#page-7-0) Herein, as shown in Figure 4a, the peaks at 284.6 and 398.9 eV were assigned to C 1s and N 1s, respectively. They were from PEI. The peak at 529.3 eV was attributed to O 1s indicating the presence of H2O, which

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled 'a' and 'b', both showing data as a function of pH ranging from 1 to 10.

Graph a:
Title: Hydrodynamic size (nm) vs pH
This graph shows two data series:
1. Pt50-PEI: represented by black squares
2. Pt50-PEI after one week: represented by red squares

Both series show relatively stable hydrodynamic size across the pH range, with values mostly between 20-30 nm. There are slight fluctuations, but no clear trend with changing pH. The error bars appear to be relatively small, indicating good precision in measurements.

Graph b:
Title: Zeta potential (mV) vs pH
This graph shows a single data series represented by black squares with error bars.

The zeta potential values are all positive, ranging approximately from 5 to 10 mV across the pH range. There is a slight downward trend as pH increases, but the change is minimal. The error bars are more pronounced than in graph a, suggesting more variability in these measurements.

Key observations:
1. The hydrodynamic size of Pt50-PEI particles remains stable around 20-30 nm across a wide pH range (1-10), even after one week.
2. The zeta potential of the particles is consistently positive (5-10 mV) across the pH range, indicating good colloidal stability.
3. The stability in both size and zeta potential suggests that the Pt50-PEI system is robust against pH changes, which could be beneficial for various applications requiring stability in different pH environments.</DESCRIPTION_FROM_IMAGE>

Figure 5. (a) Hydrodynamic size and (b) zeta potential of Pt50-PEI NPs in buffer. Pt50-PEI NPs had good stability and slightly positive charge.

<DESCRIPTION_FROM_IMAGE>The image consists of two parts, labeled 'a' and 'b'.

Part a:
This is a graph showing absorbance spectra for different chemical combinations. The x-axis represents wavelength in nanometers (nm), ranging from 500 to 800 nm. The y-axis shows absorbance, ranging from 0 to 0.75.

Four different spectra are plotted:
1. TMB+H2O2 (black line)
2. TMB+Pt50-PEI (green line)
3. H2O2+Pt50-PEI (blue line)
4. TMB+Pt50-PEI+H2O2 (red line)

The red line (TMB+Pt50-PEI+H2O2) shows a significant peak in absorbance, reaching a maximum of about 0.5 at approximately 650 nm. The other three spectra show very low absorbance across the entire wavelength range, with values close to zero.

Part b:
This section shows four glass vials labeled (1), (2), (3), and (4). The contents of the vials are as follows:
(1) Clear solution
(2) Clear solution
(3) Clear or very slightly cloudy solution
(4) Turquoise blue solution

The difference in color of vial (4) likely corresponds to the high absorbance peak seen in the red line of the graph in part a, indicating a reaction or change has occurred in this sample.

The chemical abbreviations used in the graph legend can be interpreted as follows:
TMB: 3,3',5,5'-Tetramethylbenzidine
H2O2: Hydrogen peroxide
Pt50-PEI: Likely refers to platinum nanoparticles (50 nm) stabilized with polyethyleneimine

This experiment appears to be demonstrating a colorimetric reaction involving TMB, hydrogen peroxide, and platinum nanoparticles, commonly used in various sensing and catalytic applications.</DESCRIPTION_FROM_IMAGE>

Figure 6. (a) Spectra of different solutions: [TMB + H2O2], [TMB + Pt50-PEI], [H2O2 + Pt50-PEI], and [TMB + Pt50-PEI + H2O2] and (b) corresponding solution. Pt50-PEI NPs had peroxidase-like activity.

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled 'a' and 'b', both showing the relative activity of an enzyme or chemical process under different conditions.

Graph a:
This graph shows the relationship between pH and relative activity. The x-axis represents pH values ranging from 2 to 12, while the y-axis shows relative activity as a percentage from 0% to 120%.

Key observations for graph a:
1. The activity peaks sharply at pH 4, reaching nearly 100% relative activity.
2. There's a steep increase in activity from pH 2 to 4.
3. After the peak, there's a rapid decline in activity between pH 4 and 6.
4. From pH 6 to 12, the activity remains very low, close to 0%.

This graph suggests that the enzyme or process has an optimal pH of 4 and is highly sensitive to pH changes, especially in the acidic range.

Graph b:
This graph illustrates the effect of temperature on relative activity. The x-axis shows temperature in degrees Celsius from 10°C to 60°C, while the y-axis represents relative activity as a percentage from 0% to 100%.

Key observations for graph b:
1. The activity peaks at 30°C, reaching 100% relative activity.
2. There's a gradual increase in activity from 10°C to 30°C.
3. After the peak, there's a steady decline in activity from 30°C to 60°C.
4. At 60°C, the activity drops to about 5%.

This graph indicates that the optimal temperature for the enzyme or process is 30°C. The activity is more tolerant to temperature changes compared to pH changes, showing a broader peak and more gradual changes.

Both graphs include error bars, suggesting that multiple measurements were taken for each data point. The connecting lines between data points are straight, indicating that these are likely discrete measurements rather than continuous data.

These graphs are typical of enzyme activity studies, showing how environmental factors like pH and temperature affect the efficiency of a biological or chemical process.</DESCRIPTION_FROM_IMAGE>

Figure 7. Effects of (a) pH and (b) temperature on the catalytic property of Pt50-PEI. The optimal conditions were pH for 4.0 and temperature for 30 °C.

was because of the strong binding water ability of PEI. [Figure](#page-2-0) [4b](#page-2-0) further showed that the binding energy of the Pt 4f had two characteristic peaks at 72.6 and 75.8 eV, which belonged to the Pt 4f7/2 and Pt 4f5/2 orbits, respectively. Pt NPs with zero valence prepared by Natarajan Prabu had 72.21 and 75.81 eV. Thus, Pt(II) has been reduced by NaBH4 to generate Pt (0). The slight difference should be due to the different size of Pt NPs and surface properties.[35](#page-7-0) In short, XPS results demonstrated the successful preparation of Pt (0) stabilized by PEI.

Furthermore, the hydration status and stability of Pt50-PEI NPs were measured using DLS technology. The changes of the hydrodynamic size of Pt50-PEI NPs under different pH from 4 to 9 were used to evaluate their stability. As shown in Figure 5a, the hydrodynamic size of Pt50-PEI NPs was about 25 nm within one week, indicating their high stability for a long time. In contrast, the Pt NPs without the stabilization of PEI gradually precipitated. The hydrodynamic size of Pt50-PEI NPs included the PEI molecule, which was bigger than the size of Pt NPs measured by using TEM. Furthermore, Figure 5b showed that the zeta potential of Pt50-PEI NPs changed from 9.4 ± 2.7 mV at pH 1 to 4.9 ± 2.6 mV at pH 10. The stability of NPs was dependent on the zeta potential and polymer template. High zeta potential of NPs (>30 mV) means their good stability[.36](#page-7-0),[37](#page-7-0) In addition, the polymer template inhibits agglomeration of NPs by steric effects[.38](#page-7-0),[39](#page-7-0) As for Pt50-PEI NPs, electrostatic repulsion and steric hindrance between Pt50- PEI NP result in their high stability which was beneficial to catalytic oxidation of TMB for a long time[.40](#page-7-0) In short, Pt50-PEI NPs had high stability with a hydrodynamic size of ∼25 nm and slightly positive charge.

2.2. Peroxidase-like Activity Assays. Many substrates such as TMB and 2,2′-azino-bis(3-ethylbenzothiazoline-6 sulfonic acid) diammonium salt (ABTS) can be effectively catalyzed by HRP. Herein, TMB was catalyzed by Pt50-PEI NPs in the presence of H2O2 at pH 4. Figure 6 showed that Pt50-PEI catalyzed the oxidation of TMB with H2O2 to generate a characteristic absorption peak at 652 nm (A = 0.488) which corresponded to blue oxTMB solution.[41](#page-7-0) However, other groups were still colorless and the absorbance (A = 0.046) was lower than 0.488, indicating the absence of oxTMB. These results demonstrated that the Pt50-PEI NPs catalyzed the oxidation of TMB in the presence of H2O2, indicating their peroxidase-like activity. In addition, the bottom

<DESCRIPTION_FROM_IMAGE>The image contains four separate graphs labeled a, b, c, and d, each showing different relationships related to enzyme kinetics.

Graph a:
X-axis: H2O2 concentration (M), ranging from 0 to 0.20 M
Y-axis: v (10^-9 M s^-1), ranging from 4 to 7
The graph shows a non-linear relationship between H2O2 concentration and reaction rate (v). The curve appears to follow Michaelis-Menten kinetics, with the rate increasing rapidly at low concentrations and then leveling off as it approaches saturation at higher concentrations.

Graph b:
X-axis: TMB concentration (mM), ranging from 0 to 0.25 mM
Y-axis: v (10^-7 M s^-1), ranging from 0 to 2.0
This graph shows a linear relationship between TMB concentration and reaction rate. The rate increases proportionally with increasing TMB concentration, suggesting first-order kinetics with respect to TMB.

Graph c:
X-axis: 1/H2O2 concentration (M^-1), ranging from 5 to 25 M^-1
Y-axis: 1/v (10^7 M^-1 s), ranging from 1.5 to 2.5
This is a Lineweaver-Burk plot for H2O2, showing a linear relationship between the reciprocal of H2O2 concentration and the reciprocal of reaction rate. This plot is used to determine enzyme kinetic parameters.

Graph d:
X-axis: 1/TMB concentration (mM^-1), ranging from 0 to 60 mM^-1
Y-axis: 1/v (10^7 M^-1 s), ranging from 0 to 10
This is a Lineweaver-Burk plot for TMB, also showing a linear relationship between the reciprocal of TMB concentration and the reciprocal of reaction rate.

All graphs include error bars on the data points, indicating experimental uncertainty. The red lines in each graph represent the best fit to the data points.

These graphs collectively provide information about the enzyme kinetics, likely for a peroxidase enzyme using H2O2 as a substrate and TMB as a chromogenic reagent. The Michaelis-Menten plot (a) and Lineweaver-Burk plots (c and d) allow for the determination of important kinetic parameters such as Km and Vmax for both H2O2 and TMB.</DESCRIPTION_FROM_IMAGE>

Figure 8. Effect of (a) H2O2 concentration and (b) TMB concentration on the initial reaction rate (v) and (c,d) double-reciprocal plots of (a,b), respectively.

of the bottle was clear, suggesting the high stability of Pt50-PEI NPs in the catalytic process. Stable Pt50-PEI NPs in aqueous solution tend to have more available active sites. TMB molecules and H2O2 molecules were absorbed on the active sites of Pt NPs. The free electron was transferred from TMB to H2O2 on the active sites of Pt NPs. Platinum NPs decorated on nickel- and nitrogen-doped graphene nanotubes also have peroxidase-like activity; the corresponding groups have obvious absorbance at 652 nm[.42](#page-7-0) In short, Pt50-PEI NPs had significant peroxidase-like activity.

2.3. Catalytic Activity. Generally, the catalytic activity of natural enzymes is dependent on their structure and conformation, which were influenced by the surrounding conditions (pH and temperature). Herein, the effects of pH values (from 2 to 12) and the temperature (from 10 to 60 °C) on the catalytic activities of Pt50-PEI were carefully investigated, respectively. As shown in [Figure 7](#page-3-0)a, the maximum relative activity of Pt50-PEI was pH 4.0. Thus, pH 4.0 was optimal pH values for the TMB oxidation reaction, which was similar to those of other NPs.[43,44](#page-8-0) In addition, as shown in [Figure 7b](#page-3-0), when the temperature was from 10 to 60 °C, the catalytic reaction reached the highest relative activity at 30 °C. In short, pH 4.0 and temperature 30 °C were the optimal conditions and were chosen for subsequent experiments.[45](#page-8-0)−[47](#page-8-0)

2.4. Kinetic and Mechanism Study. Furthermore, the peroxidase-like catalytic performance of Pt50-PEI with H2O2 or TMB as substrates was measured using the steady-state kinetics. The enzymatic kinetic parameters were measured under conditions with altering concentrations of H2O2 or TMB while fixing the other one invariable. The initial reaction rate was calculated on the basis of the production of oxTMB over time. The molar absorption coefficient of oxTMB was 39,000 M−1 ·cm−1 . As shown in Figure 8a and Figure 8b, the initial reaction rate (v) of Pt50-PEI was dependent on the substrate (TMB or H2O2) concentration. Both curves confirmed that the catalytic reaction of Pt50-PEI followed a typical Michaelis− Menten equation. MoS2−Pt74Ag26, Fe-doped CeO2 nanorods, and PVP-functionalized ultra-small MoS2 NPs also exhibit typical Michaelis−Menten kinetics.[48](#page-8-0)−[50](#page-8-0) As shown in Figure 8c,d, the 1/v was proportional to 1/H2O2 concentration and 1/TMB concentration, respectively. The Michaelis constant (Vmax and Km) was shown in Table 1. The Vmax values toward

Table 1. Kinetic Parameters of Pt50-PEI NPs and HRP

| catalyst | substrate | Km (mM) | Vmax (10−8 Ms−1<br>) | reference |
|----------|-----------|---------|----------------------|-----------|
| Pt50-PEI | TMB       | 2.02    | 115                  | this work |
| Pt50-PEI | H2O2      | 43.6    | 8.50                 | this work |
| HRP      | TMB       | 0.434   | 10.00                | 6         |
| HRP      | H2O2      | 3.70    | 8.71                 | 6         |
| PtNPs/GO | TMB       | 0.1864  | 10.20                | 53        |
| PtNPs/GO | H2O2      | 221.4   | 12.45                | 53        |
|          |           |         |                      |           |

TMB of Pt50-PEI NPs were much bigger than that of HRP, indicating that Pt50-PEI NPs had higher catalytic activity than HRP. The high catalytic activity should be due to free access to the active sites of NPs for the substrates. Water-soluble PEI enhanced the stability of small Pt NPs, while PEI should not occupy the active sites of Pt NPs. It has been reported that PVP was strongly adsorbed onto the surface of NPs, and surface-adsorbed PVP blocked reactant molecules to access the active sites of NPs.[51](#page-8-0) Chen and co-worker found that the peroxidase-like activity of graphene oxide−Fe3O4 magnetic nanocomposites follows a ping-pong mechanism.[52](#page-8-0) The peroxidase-like activity of Pt50-PEI NPs should also follow a ping-pong mechanism. In short, Pt50-PEI NPs had typical Michaelis−Menten equation for the catalytic oxidation of TMB.

2.5. Glucose Detection. The Pt50-PEI-catalyzed TMB to generate blue oxTMB which had an obvious absorbance peak at 652 nm in the UV−vis spectra. Thus, the concentration of oxTMB can be calculated based on its absorbance at 652 nm. The concentration of oxTMB was proportional to H2O2 concentration. It has been reported that the H2O2 concentration was dependent on the glucose concentration in the

<DESCRIPTION_FROM_IMAGE>The image contains two graphs labeled 'a' and 'b'.

Graph a:
This is a linear calibration curve showing the relationship between glucose concentration and absorbance at 652nm. The x-axis represents glucose concentration in millimolar (mM) units, ranging from 0 to 5 mM. The y-axis shows absorbance at 652nm, ranging from 0.15 to 0.45. The data points form a clear linear trend with a positive slope, indicating that absorbance increases proportionally with glucose concentration. The line of best fit is drawn through the data points.

Graph b:
This is a bar graph comparing the absorbance at 652nm for different sugar solutions. The x-axis lists five conditions: Blank, Maltose, Lactose, Fructose, and Glucose. The y-axis shows absorbance at 652nm, ranging from 0 to 0.5. Each bar represents the mean absorbance value for the corresponding sugar, with error bars (likely representing standard deviation) visible on top of each bar. The glucose bar shows the highest absorbance (approximately 0.42), while the blank has the lowest (about 0.06). Maltose, lactose, and fructose show intermediate absorbance values, all lower than glucose but higher than the blank.

This set of graphs appears to be demonstrating the specificity and sensitivity of a glucose detection method, likely using a colorimetric assay that produces a color change measurable at 652nm. The linear relationship in graph 'a' allows for quantification of glucose concentrations, while graph 'b' shows the method's selectivity for glucose compared to other common sugars.</DESCRIPTION_FROM_IMAGE>

Figure 9. Glucose detection by using Pt50-PEI (a) linear plot between the absorbance and the glucose concentration in the range of 0.01−5 mM. (b) Selectivity of detection of glucose.

|  |  |  |  |  | Table 2. Linear Range and Detection Limit of Mimetic Enzyme |  |  |  |  |  |
|--|--|--|--|--|-------------------------------------------------------------|--|--|--|--|--|
|--|--|--|--|--|-------------------------------------------------------------|--|--|--|--|--|

| mimetic enzyme                    | linear range (μM) | detection limit (μM) | method           | reference |
|-----------------------------------|-------------------|----------------------|------------------|-----------|
| Pt50-PEI                          | 10−5000           | 4.2                  | colorimetry      | yhis work |
| Pt200-JP NCs                      | 10−1000           | 5.47                 | colorimetry      | 57        |
| Pt NPs                            | 1−50              | 1                    | colorimetry      | 58        |
| GNRs-CQDs                         | 10−2000           | 3.0                  | colorimetry      | 59        |
| NiFe-LDHNS                        | 50−2000           | 23                   | colorimetry      | 60        |
| MoS2 NPs                          | 15−135            | 7                    | colorimetry      | 61        |
| Por-ZnFe2O4 HSs                   | 6−90              | 5.5                  | colorimetry      | 62        |
| Ag@Fabric                         | 100−2000          | 80                   | colorimetry      | 63        |
| Cys-MoS2 NFs                      | 50−1000           | 33.51                | colorimetry      | 54        |
| PtPd/PHNG-2                       | 100−4000          | 1.82                 | electrochemistry | 64        |
| Pt−Pd nanoflakes                  | 0−16,000          | 20.6                 | electrochemistry | 65        |
| Pt−Pb bimetallic nanostructure/Au | 0−12,000          | 8.4                  | electrochemistry | 66        |

glucose oxidase (GOD)-catalyzed reaction in the presence of glucose and oxygen. Thus, combining two catalytic reactions using Pt50-PEI and GOD, the concentration of oxTMB should be dependent on the glucose concentration. Figure 9a showed that the absorbance of oxTMB at 652 nm was positively correlated with the glucose concentration which was from 10− 5000 μM. The standard response equation of glucose concentration was A = 0.0485Cglucose + 0.191. The detection limit was 4.2 μM, which was relatively small when it was compared with other reported NPs (Table 2). Cysteinemodified MoS2 nanoflakes (Cys−MoS2 NFs) were used for the colorimetric detection of glucose with a detection limit for 33.51 μM and the linear range from 0.05−1 mM[.54](#page-8-0) The high stability of Pt50-PEI NPs was good for the quick color change of TMB. Saliva was used as the real sample to test the glucose concentration. The glucose concentration was 0.15 mM, which was within a normal glucose concentration of human saliva (0.008−0.21 mM).[55](#page-8-0) This confirmed the validity of this method. Thus, a sensitive colorimetric method for glucose detection was established based on the peroxidase-like activity of Pt50-PEI NPs.

Furthermore, selectivity of glucose detection was evaluated by using maltose, fructose, and lactose as control groups. The concentrations of glucose and other sugars were 5 and 10 mM, respectively. As shown in Figure 9b, the absorbance of control groups was much lower than that of glucose when the concentration of glucose was half of that of other sugars. Thus, this detection method had high selectivity toward glucose, which was because of the specificity of GOD toward the catalytic oxidation of β-d-glucose to gluconic acid using molecular oxygen.[56](#page-8-0) In addition, the developed method showed acceptable reproducibility. In short, a selective method using Ptn-PEI NPs was demonstrated. Compared with the electrochemical method, a colorimetric method using Ptn-PEI NPs has many merits such as convenience, low cost, simplicity, and practicality.

### 3. CONCLUSIONS

In summary, PEI (70,000) was used as a template to construct water-soluble, stable, and monodispersed Ptn-PEI NPs. Based on the peroxidase-like activity of Pt50-PEI NPs, a highly sensitive method for the detection of glucose concentration was established. The size of Pt NPs inside Ptn-PEI NPs ranged from 3.21 to 3.70 nm. Pt50-PEI NPs had a hydrodynamic size of ∼25 nm and slightly positive charge. Furthermore, Pt50-PEI NPs showed peroxidase-like reaction, which was used to detect the glucose concentration. This detective method had a linear glucose concentration range from 10 to 5000 μM, low detection limit, and high selectivity. The concentration of glucose in saliva was tested to be 0.15 mM. The suitable molecular-weight PEI was used to keep high stability of Pt NPs (3.21 nm) inside of Pt50-PEI NPs in solution. Pt50-PEI NPs could be prepared in large scale because of affordable price. This high stability of Pt50-PEI NPs was beneficial to the sensitive detection of glucose concentration in the solution system. Our future work will focus on the relationship between surface groups of soluble macromolecules and the catalytic ability of metal NPs. This established method has great potential to be used for glucose detection in the future.

### 4. METHODS

4.1. Synthesis of Ptn-PEI NPs. The synthesis of Ptn-PEI NPs was as follows: as for Pt50-PEI NPs, 357 μL of K2PtCl4 (2 mM) aqueous solution and 1000 μL of PEI solution (pH = 4.0, 1 mg/mL) were mixed and added in a PE tube. As for Pt100- PEI NPs, 357 μL of K2PtCl4 (2 mM) aqueous solution and <span id="page-6-0"></span>500 μL of PEI solution (pH = 4.0, 1 mg/mL) were mixed and added in a PE tube. As for Pt150-PEI NPs, 535.5 μL of K2PtCl4 (2 mM) aqueous solution and 500 μL of PEI solution (pH = 4.0, 1 mg/mL) were mixed and added in a PE tube. The molar ratio of K2PtCl4 to PEI was 50:1, 100:1, and 150:1, respectively. All the tubes were located in a constant temperature metal mixer at 20 °C for 20 min. Then, NaBH4 (1 mg/mL) solution was dissolved in 0.3 M NaOH and added into each tube. The amount of NaBH4 was 135 μL for Pt50-PEI NPs, 135 μL for Pt100-PEI NPs, and 203 μL for Pt150-PEI NPs. After 10 min, the solution was tuned to a pH of 7 with 1 M HCl. The solution was shaken at 500 rpm for another 3 h. Each group solution was collected and dialyzed against ultrapure water to obtain Ptn-PEI NPs (n = 50, 100, 150).

4.2. Catalytic Activity. The catalytic activity of Pt50-PEI NPs under different pH (2.0−12.0) was evaluated as follows: 200 μL of Pt50-PEI (6 μM) and 800 μL of HAc-NaAc buffer (pH 2.0−12.0, 0.2 M) were incubated for 10 min; 200 μL of TMB (0.6 mM) was mixed for 10 min; Then, 200 μL of H2O2 (0.3 M) was added for 10 min. The absorbance was recorded at 652 nm. The catalytic activity of Pt50-PEI NPs under different temperatures (10−60 °C) was carried out with the same procedure at pH 4.0.

4.3. Michaelis−Menten Kinetic Analysis. The effect of the H2O2 concentration (0.039−0.177 mM) and TMB concentration (0.018−0.357 mM) on the catalytic activity of Pt50-PEI was studied at 30 °C, respectively. Briefly, the kinetic assays of Pt50-PEI with H2O2 as the substrate were performed by adding 25 μL of Pt50-PEI (2 μM), 1400 μL of TMB (0.8 mM), and different amounts of H2O2 (3 M). The kinetic assays of Pt50-PEI with TMB as the substrate were performed by adding 100 μL of Pt50-PEI (6 μM), 300 μL of H2O2 (0.3 M), and different amounts of TMB solution (0.2 M HAc-NaAc, pH 4.0). Catalytic parameters were determined based on Michaelis−Menten eq 1.

$$\frac{1}{\frac{1}{\nu}} = \frac{K_{\rm m}}{V_{\rm max}} \frac{1}{[S]} + \frac{1}{V_{\rm max}} \tag{1}$$

4.4. Glucose Detection. (a) GOD (100 μL, 5 mg/mL) and glucose (200 μL) solutions with different concentrations were incubated at 37 °C for 30 min, the glucose was dissolved in HAc-NaAc buffer (pH = 5.2, 0.2 M); (b) 800 μL of TMB (0.6 mM) and 100 μL of the Pt50-PEI solution (6 μM) were mixed at 30 °C for 5 min. This (b) solution was added into 300 μL of (a) solution, the mixed solution was incubated at 30 °C for 30 min, and the absorbance was recorded at 652 nm. Glucose (5 mM) and other sugars (10 mM) were also measured to compare the selectivity of this method. The glucose concentration of saliva was measured using our method.

# ■ ASSOCIATED CONTENT

### *sı Supporting Information

The Supporting Information is available free of charge at [https://pubs.acs.org/doi/10.1021/acsomega.0c00147](https://pubs.acs.org/doi/10.1021/acsomega.0c00147?goto=supporting-info).

> Materials, characterization, peroxidase-like activity assays, and TEM images of Pt NPs without PEI ([PDF](http://pubs.acs.org/doi/suppl/10.1021/acsomega.0c00147/suppl_file/ao0c00147_si_001.pdf))

# ■ AUTHOR INFORMATION

#### Corresponding Author

Bo Liang − State Key Laboratory of Metastable Materials Science and Technology, College of Materials Science and

Engineering, Yanshan University, Qinhuangdao 066004, China; Phone: +86-03358074780; Email: [liangbo@ysu.edu.cn](mailto:liangbo@ysu.edu.cn)

#### Authors

Yanshuai Cui − State Key Laboratory of Metastable Materials Science and Technology, College of Materials Science and Engineering and Key Laboratory of Applied Chemistry, College of Environmental and Chemical Engineering, Yanshan University, Qinhuangdao 066004, China; [orcid.org/0000-](http://orcid.org/0000-0002-0960-1676) [0002-0960-1676](http://orcid.org/0000-0002-0960-1676)

- Xiang Lai − Key Laboratory of Applied Chemistry, College of Environmental and Chemical Engineering, Yanshan University, Qinhuangdao 066004, China
- Ying Liang − Key Laboratory of Applied Chemistry, College of Environmental and Chemical Engineering, Yanshan University, Qinhuangdao 066004, China
- Haotian Sun − Department of Chemical and Biological Engineering, University at Buffalo, The State University of New York, Buffalo, New York 14260, United States
- Longgang Wang − Key Laboratory of Applied Chemistry, College of Environmental and Chemical Engineering, Yanshan University, Qinhuangdao 066004, China

Complete contact information is available at: [https://pubs.acs.org/10.1021/acsomega.0c00147](https://pubs.acs.org/doi/10.1021/acsomega.0c00147?ref=pdf)

#### Author Contributions

The manuscript was written through contributions of all the authors. All the authors have given approval to the final version of the manuscript.

#### Notes

The authors declare no competing financial interest.

# ■ ACKNOWLEDGMENTS

The authors appreciate financial support Natural Science Foundation of Hebei Province (B2017203229) and China Postdoctoral Science Foundation (2016M601284).

# ■ REFERENCES

(1) Yin, Y.; Dong, Z.; Luo, Q.; Liu, J[. Biomimetic catalysts designed](https://dx.doi.org/10.1016/j.progpolymsci.2012.04.001) [on macromolecular scaffolds.](https://dx.doi.org/10.1016/j.progpolymsci.2012.04.001) Prog. Polym. Sci. 2012, 37, 1476−1509. (2) Hu, T.; Zhang, L.; Wen, W.; Zhang, X.; Wang, S[. Enzyme](https://dx.doi.org/10.1016/j.bios.2015.09.068) [catalytic amplification of miRNA-155 detection with graphene](https://dx.doi.org/10.1016/j.bios.2015.09.068) [quantum dot-based electrochemical biosensor.](https://dx.doi.org/10.1016/j.bios.2015.09.068) Biosens. Bioelectron. 2016, 77, 451−456.

(3) Callmann, C. E.; Barback, C. V.; Thompson, M. P.; Hall, D. J.; Mattrey, R. F.; Gianneschi, N. C[. Therapeutic enzyme-responsive](https://dx.doi.org/10.1002/adma.201501803) [nanoparticles for targeted delivery and accumulation in tumors.](https://dx.doi.org/10.1002/adma.201501803) Adv. Mater. 2015, 27, 4611−4615.

(4) Li, J.; Zhang, Y.; Huang, Q.; Shi, H.; Yang, Y.; Gao, S.; Mao, L.; Yang, X[. Degradation of organic pollutants mediated by extracellular](https://dx.doi.org/10.1016/j.jhazmat.2017.02.033) [peroxidase in simulated sunlit humic waters: A case study with 17](https://dx.doi.org/10.1016/j.jhazmat.2017.02.033)β[estradiol.](https://dx.doi.org/10.1016/j.jhazmat.2017.02.033) J. Hazard. Mater. 2017, 331, 123−131.

(5) Busa, L. S. A.; Maeki, M.; Ishida, A.; Tani, H.; Tokeshi, M. [Simple and sensitive colorimetric assay system for horseradish](https://dx.doi.org/10.1016/j.snb.2016.06.013) [peroxidase using microfluidic paper-based devices.](https://dx.doi.org/10.1016/j.snb.2016.06.013) Sens. Actuators, B 2016, 236, 433−441.

(6) Gao, L.; Zhuang, J.; Nie, L.; Zhang, J.; Zhang, Y.; Gu, N.; Wang, T.; Feng, J.; Yang, D.; Perrett, S.; Yan, X[. Intrinsic peroxidase-like](https://dx.doi.org/10.1038/nnano.2007.260) [activity of ferromagnetic nanoparticles.](https://dx.doi.org/10.1038/nnano.2007.260) Nat. Nanotechnol. 2007, 2, 577.

(7) Fan, S.; Zhao, M.; Ding, L.; Li, H.; Chen, S[. Preparation of](https://dx.doi.org/10.1016/j.bios.2016.09.108) [Co3O4/crumpled graphene microsphere as peroxidase mimetic for](https://dx.doi.org/10.1016/j.bios.2016.09.108) [colorimetric assay of ascorbic acid.](https://dx.doi.org/10.1016/j.bios.2016.09.108) Biosens. Bioelectron. 2017, 89, 846−852.

<span id="page-7-0"></span>(8) Li, Y.-Z.; Li, T.-T.; Chen, W.; Song, Y.-Y[. Co 4 N Nanowires:](https://dx.doi.org/10.1021/acsami.7b09861) [Noble-metal-free peroxidase mimetic with excellent salt- and](https://dx.doi.org/10.1021/acsami.7b09861) [temperature-resistant abilities.](https://dx.doi.org/10.1021/acsami.7b09861) ACS Appl. Mater. Interfaces 2017, 9, 29881.

(9) Chen, J.; Wang, Q.; Huang, L.; Zhang, H.; Rong, K.; Zhang, H.; Dong, S[. Prussian blue with intrinsic heme-like structure as peroxidase](https://dx.doi.org/10.1007/s12274-018-2079-8) [mimic.](https://dx.doi.org/10.1007/s12274-018-2079-8) Nano Res. 2018, 11, 4905−4913.

(10) Peng, J.; Weng, J[. Enhanced peroxidase-like activity of MoS2/](https://dx.doi.org/10.1016/j.bios.2015.12.034) [graphene oxide hybrid with light irradiation for glucose detection.](https://dx.doi.org/10.1016/j.bios.2015.12.034) Biosens. Bioelectron. 2017, 89, 652−658.

(11) Cui, Y.; Lai, X.; Liu, K.; Liang, B.; Ma, G.; Wang, L. [Ginkgo](https://dx.doi.org/10.1039/d0ra00680g) [Biloba leaf polysaccharide stabilized palladium nanoparticles with](https://dx.doi.org/10.1039/d0ra00680g) [enhanced peroxidase-like property for the colorimetric detection of](https://dx.doi.org/10.1039/d0ra00680g) [glucose.](https://dx.doi.org/10.1039/d0ra00680g) RSC Adv. 2020, 10, 7012−7018.

(12) Tan, F.; Wang, Z.; Yang, Y.; Xie, X.; Hua, X.; Yang, X.; Huang, H[. Facile preparation of peroxidase-like core-shell nanorods and](https://dx.doi.org/10.1016/j.talanta.2019.06.005) [application as platform for colorimetric determination of glucose,](https://dx.doi.org/10.1016/j.talanta.2019.06.005) [insulin and glucose/insulin ratio.](https://dx.doi.org/10.1016/j.talanta.2019.06.005) Talanta 2019, 204, 285−293.

(13) Peng, X.; Wan, G.; Wu, L.; Zeng, M.; Lin, S.; Wang, G. [Peroxidase-like activity of Au@TiO2](https://dx.doi.org/10.1016/j.snb.2017.10.146) yolk-shell nanostructure and its [application for colorimetric detection of H2O2](https://dx.doi.org/10.1016/j.snb.2017.10.146) and glucose. Sens. Actuators, B 2018, 257, 166−177.

(14) Ge, C.; Wu, R.; Chong, Y.; Fang, G.; Jiang, X.; Pan, Y.; Chen, C.; Yin, J.-J. [Synthesis of Pt hollow nanodendrites with Enhanced](https://dx.doi.org/10.1002/adfm.201801484) [peroxidase-like activity against bacterial infections: Implication for](https://dx.doi.org/10.1002/adfm.201801484) [wound healing.](https://dx.doi.org/10.1002/adfm.201801484) Adv. Funct. Mater. 2018, 28, 1801484.

(15) Deng, H.-H.; Lin, X.-L.; Liu, Y.-H.; Li, K.-L.; Zhuang, Q.-Q.; Peng, H.-P.; Liu, A.-L.; Xia, X.-H.; Chen, W. [Chitosan-stabilized](https://dx.doi.org/10.1039/c7nr03399k) [platinum nanoparticles as effective oxidase mimics for colorimetric](https://dx.doi.org/10.1039/c7nr03399k) [detection of acid phosphatase.](https://dx.doi.org/10.1039/c7nr03399k) Nanoscale 2017, 9, 10292−10300.

(16) Zhao, Y.; Zhang, J.; Xie, D.; Sun, H.; Yu, S.; Guo, X. [Ultra-small](https://dx.doi.org/10.1080/09205063.2020.1716298) [and biocompatible platinum nanoclusters with peroxidase-like activity](https://dx.doi.org/10.1080/09205063.2020.1716298) [for facile glucose detection in real samples.](https://dx.doi.org/10.1080/09205063.2020.1716298) J. Biomater. Sci., Polym. Ed. 2020, 1−15.

(17) Guo, Y.; Sun, Y.; Yang, D.-P.; Dai, J.; Liu, Z.; Chen, Y.; Huang, J.; Li, Q. Biogenic Pt/CaCO3 [nanocomposite as a robust catalyst](https://dx.doi.org/10.1021/acsami.9b18490) [toward benzene oxidation.](https://dx.doi.org/10.1021/acsami.9b18490) ACS Appl. Mater. Interfaces 2020, 12, 2469−2480.

(18) Çelik, B.; Erken, E.; Eris, S.; Y ̧ ıldız, Y.; Şahin, B.; Pamuk, H.; Sen, F. [Highly monodisperse Pt(0)@AC NPs as highly efficient and](https://dx.doi.org/10.1039/c5cy01371b) [reusable catalysts: the effect of the surfactant on their catalytic](https://dx.doi.org/10.1039/c5cy01371b) [activities in room temperature dehydrocoupling of DMAB.](https://dx.doi.org/10.1039/c5cy01371b) Catal. Sci. Technol. 2016, 6, 1685−1692.

(19) Ayranci, R.; Demirkan, B.; Sen, B.; Şavk, A.; Ak, M.; Şen, F. [Use](https://dx.doi.org/10.1016/j.msec.2019.02.040) [of the monodisperse Pt/Ni@rGO nanocomposite synthesized by](https://dx.doi.org/10.1016/j.msec.2019.02.040) [ultrasonic hydroxide assisted reduction method in electrochemical](https://dx.doi.org/10.1016/j.msec.2019.02.040) [nonenzymatic glucose detection.](https://dx.doi.org/10.1016/j.msec.2019.02.040) Mater. Sci. Eng., B 2019, 99, 951− 956.

(20) Aday, B.; Yıldız, Y.; Ulus, R.; Eris, S.; Sen, F.; Kaya, M[. One](https://dx.doi.org/10.1039/c5nj02098k)[pot, efficient and green synthesis of acridinedione derivatives using](https://dx.doi.org/10.1039/c5nj02098k) [highly monodisperse platinum nanoparticles supported with reduced](https://dx.doi.org/10.1039/c5nj02098k) [graphene oxide.](https://dx.doi.org/10.1039/c5nj02098k) New J. Chem. 2016, 40, 748−754.

(21) Li, Y.; Boone, E.; El-Sayed, M. A. [Size effects of PVP](https://dx.doi.org/10.1021/la011469q)−Pd [nanoparticles on the catalytic suzuki reactions in aqueous solution.](https://dx.doi.org/10.1021/la011469q) Langmuir 2002, 18, 4921−4925.

(22) Ncube, P.; Hlabathe, T.; Meijboom, R[. The preparation of well](https://dx.doi.org/10.1016/j.apsusc.2015.09.123)[defined dendrimer-encapsulated palladium and platinum nano](https://dx.doi.org/10.1016/j.apsusc.2015.09.123)[particles and their catalytic evaluation in the oxidation of morin.](https://dx.doi.org/10.1016/j.apsusc.2015.09.123) Appl. Surf. Sci. 2015, 357, 1141−1149.

(23) He, S.-B.; Deng, H.-H.; Liu, A.-L.; Li, G.-W.; Lin, X.-H.; Chen, W.; Xia, X.-H. [Synthesis and peroxidase-like activity of salt-resistant](https://dx.doi.org/10.1002/cctc.201400011) [platinum nanoparticles by using bovine serum albumin as the scaffold.](https://dx.doi.org/10.1002/cctc.201400011) ChemCatChem 2014, 6, 1543−1548.

(24) Jin, L.; Meng, Z.; Zhang, Y.; Cai, S.; Zhang, Z.; Li, C.; Shang, L.; Shen, Y. [Ultrasmall Pt nanoclusters as robust peroxidase mimics](https://dx.doi.org/10.1021/acsami.7b01616) [for colorimetric detection of glucose in human serum.](https://dx.doi.org/10.1021/acsami.7b01616) ACS Appl. Mater. Interfaces 2017, 9, 10027−10033.

(25) Kong, C.; Han, Y.-x.; Hou, L.-j.; Li, Y.-y. [Gathered sensitizer on](https://dx.doi.org/10.1016/j.jphotochem.2017.05.034) [the surface of catalyst by sodium polyacrylate for highly efficient](https://dx.doi.org/10.1016/j.jphotochem.2017.05.034) [photocatalytic hydrogen evolution.](https://dx.doi.org/10.1016/j.jphotochem.2017.05.034) J. Photochem. Photobiol., A 2017, 345, 92−97.

(26) Safo, I. A.; Oezaslan, M. [Electrochemical cleaning of](https://dx.doi.org/10.1016/j.electacta.2017.04.118) [polyvinylpyrrolidone-capped Pt nanocubes for the oxygen reduction](https://dx.doi.org/10.1016/j.electacta.2017.04.118) [reaction.](https://dx.doi.org/10.1016/j.electacta.2017.04.118) Electrochim. Acta 2017, 241, 544−552.

(27) Cui, Y.; Zhang, J.; Yu, Q.; Guo, X.; Chen, S.; Sun, H.; Liu, S.; Wang, L.; Lai, X.; Gao, D[. Highly biocompatible zwitterionic](https://dx.doi.org/10.1039/c9nj01101c) [dendrimer-encapsulated platinum nanoparticles for sensitive detection](https://dx.doi.org/10.1039/c9nj01101c) [of glucose in complex medium.](https://dx.doi.org/10.1039/c9nj01101c) New J. Chem. 2019, 43, 9076−9083.

(28) Ye, H.; Liu, Y.; Chhabra, A.; Lilla, E.; Xia, X[. Polyvinylpyrro](https://dx.doi.org/10.1002/cnma.201600268)[lidone (PVP)-capped Pt nanocubes with superior peroxidase-like](https://dx.doi.org/10.1002/cnma.201600268) [activity.](https://dx.doi.org/10.1002/cnma.201600268) ChemNanoMat 2017, 3, 33−38.

(29) Chen, T.; Cheng, Z.; Yi, C.; Xu, Z[. Synthesis of platinum](https://dx.doi.org/10.1039/c8cc05106b) [nanoparticles templated by dendrimers terminated with alkyl chains.](https://dx.doi.org/10.1039/c8cc05106b) Chem. Commun. 2018, 54, 9143−9146.

(30) Nagao, H.; Ichiji, M.; Hirasawa, I[. Synthesis of platinum](https://dx.doi.org/10.1002/ceat.201600656) [nanoparticles by reductive crystallization using polyethyleneimine.](https://dx.doi.org/10.1002/ceat.201600656) Chem. Eng. Technol. 2017, 40, 1242−1246.

(31) Nie, Y.; Li, L.; Wei, Z. [Recent advancements in Pt and Pt-free](https://dx.doi.org/10.1039/c4cs00484a) [catalysts for oxygen reduction reaction.](https://dx.doi.org/10.1039/c4cs00484a) Chem. Soc. Rev. 2015, 44, 2168−2201.

(32) Dauthal, P.; Mukhopadhyay, M. [Biofabrication, character](https://dx.doi.org/10.1016/j.jiec.2014.07.009)[ization, and possible bio-reduction mechanism of platinum nano](https://dx.doi.org/10.1016/j.jiec.2014.07.009)[particles mediated by agro-industrial waste and their catalytic activity.](https://dx.doi.org/10.1016/j.jiec.2014.07.009) J. Ind. Eng. Chem. 2015, 22, 185−191.

(33) Velmurugan, P.; Shim, J.; Kim, K.; Oh, B.-T. [Prunus](https://dx.doi.org/10.1016/j.matlet.2016.03.069) × [yedoensis tree gum mediated synthesis of platinum nanoparticles with](https://dx.doi.org/10.1016/j.matlet.2016.03.069) [antifungal activity against phytopathogens.](https://dx.doi.org/10.1016/j.matlet.2016.03.069) Mater. Lett. 2016, 174, 61−65.

(34) Liu, L.; Zhang, J.; Wang, X.; Hou, W.; Liu, X.; Xu, M.; Yang, J.; Liang, B. [Preparation and fluorescence properties of a Cr3+:](https://dx.doi.org/10.1016/j.matlet.2019.126811)γ-AlON [powder by high temperature solid state reaction.](https://dx.doi.org/10.1016/j.matlet.2019.126811) Mater. Lett. 2020, 258, 126811.

(35) Fu, X.; Wang, Y.; Wu, N.; Gui, L.; Tang, Y. [Surface](https://dx.doi.org/10.1006/jcis.2001.7861) [modification of small platinum nanoclusters with alkylamine and](https://dx.doi.org/10.1006/jcis.2001.7861) [alkylthiol: an XPS study on the influence of organic ligands on the Pt](https://dx.doi.org/10.1006/jcis.2001.7861) [4f binding energies of small platinum nanoclusters.](https://dx.doi.org/10.1006/jcis.2001.7861) J. Colloid Interface Sci. 2001, 243, 326−330.

(36) Silvestri, D.; Wacławek, S.; Sobel, B.; Torres-Mendieta, R.; Novotny, V.; Nguyen, N. H. A.; S ́ ̌ evců , A.; Padil, V. V. T.; Müllerova,́ J.; Stuchlík, M.; Papini, M. P.; Č erník, M.; Varma, R. S[. A poly(3](https://dx.doi.org/10.1039/c8gc02495b) hydroxybutyrate)−[chitosan polymer conjugate for the synthesis of](https://dx.doi.org/10.1039/c8gc02495b) [safer gold nanoparticles and their applications.](https://dx.doi.org/10.1039/c8gc02495b) Green Chem. 2018, 20, 4975−4982.

(37) Wang, L.; Zhang, X.; Cui, Y.; Guo, X.; Chen, S.; Sun, H.; Gao, D.; Yang, Q.; Kang, J[. Polyethyleneimine-oleic acid micelle-stabilized](https://dx.doi.org/10.1007/s11243-019-00353-z) [gold nanoparticles for reduction of 4-nitrophenol with enhanced](https://dx.doi.org/10.1007/s11243-019-00353-z) [performance.](https://dx.doi.org/10.1007/s11243-019-00353-z) Transition Met. Chem. 2020, 45, 31−39.

(38) Crooks, R. M.; Zhao, M.; Sun, L.; Chechik, V.; Yeung, L. K. [Dendrimer-encapsulated metal nanoparticles: synthesis, character](https://dx.doi.org/10.1021/ar000110a)[ization, and applications to catalysis.](https://dx.doi.org/10.1021/ar000110a) Acc. Chem. Res. 2001, 34, 181− 190.

(39) Wang, L.; Zhu, L.; Bernards, M. T.; Chen, S.; Sun, H.; Guo, X.; Xue, W.; Cui, Y.; Gao, D. [Dendrimer-Based Biocompatible](https://dx.doi.org/10.1021/acsapm.9b00026) [Zwitterionic Micelles for Efficient Cellular Internalization and](https://dx.doi.org/10.1021/acsapm.9b00026) [Enhanced Antitumor Effects.](https://dx.doi.org/10.1021/acsapm.9b00026) ACS Appl. Polym. Mater. 2020, 2, 159−171.

(40) Zhang, X.; Fan, L.; Cui, Y.; Cui, T.; Chen, S.; Ma, G.; Hou, W.; Wang, L. [Green synthesis of gold nanoparticles using longan](https://dx.doi.org/10.1142/s1793292020500022) [polysaccharide and their reduction of 4-nitrophenol and biological](https://dx.doi.org/10.1142/s1793292020500022) [applications.](https://dx.doi.org/10.1142/s1793292020500022) Nano 2020, 15, 2050002.

(41) Jiang, X.; Sun, C.; Guo, Y.; Nie, G.; Xu, L[. Peroxidase-like](https://dx.doi.org/10.1016/j.bios.2014.08.078) [activity of apoferritin paired gold clusters for glucose detection.](https://dx.doi.org/10.1016/j.bios.2014.08.078) Biosens. Bioelectron. 2015, 64, 165−170.

(42) Fakhri, N.; Salehnia, F.; Mohammad Beigi, S.; Aghabalazadeh, S.; Hosseini, M.; Ganjali, M. R. [Enhanced peroxidase-like activity of](https://dx.doi.org/10.1007/s00604-019-3489-3) [platinum nanoparticles decorated on nickel- and nitrogen-doped](https://dx.doi.org/10.1007/s00604-019-3489-3) [graphene nanotubes: colorimetric detection of glucose.](https://dx.doi.org/10.1007/s00604-019-3489-3) Microchim. Acta 2019, 186, 385.

H

<span id="page-8-0"></span>(43) Wang, Z.; Dong, K.; Liu, Z.; Zhang, Y.; Chen, Z.; Sun, H.; Ren, J.; Qu, X[. Activation of biologically relevant levels of reactive oxygen](https://dx.doi.org/10.1016/j.biomaterials.2016.10.041) species by Au/g-C3N4 [hybrid nanozyme for bacteria killing and](https://dx.doi.org/10.1016/j.biomaterials.2016.10.041) [wound disinfection.](https://dx.doi.org/10.1016/j.biomaterials.2016.10.041) Biomaterials 2017, 113, 145−157.

(44) Zou, X.; Shi, H.; Huang, X.; Shi, J.; Zhai, X.; Jiang, C.; Li, Z. Colorimetric detection of rogor using gold nanoparticles as peroxidase mimetics. Food Sci. 2018, 39, 224−230.

(45) Wang, Q.; Zhang, L.; Shang, C.; Zhang, Z.; Dong, S[. Triple](https://dx.doi.org/10.1039/c6cc00194g)[enzyme mimetic activity of nickel](https://dx.doi.org/10.1039/c6cc00194g)−palladium hollow nanoparticles [and their application in colorimetric biosensing of glucose.](https://dx.doi.org/10.1039/c6cc00194g) Chem. Commun. 2016, 52, 5410−5413.

(46) Liu, Q.; Jiang, Y.; Zhang, L.; Zhou, X.; Lv, X.; Ding, Y.; Sun, L.; Chen, P.; Yin, H[. The catalytic activity of Ag2S-montmorillonites as](https://dx.doi.org/10.1016/j.msec.2016.04.007) [peroxidase mimetic toward colorimetric detection of H2O2.](https://dx.doi.org/10.1016/j.msec.2016.04.007) Mater. Sci. Eng., C 2016, 65, 109−115.

(47) Niu, X.; He, Y.; Pan, J.; Li, X.; Qiu, F.; Yan, Y.; Shi, L.; Zhao, H.; Lan, M. [Uncapped nanobranch-based CuS clews used as an](https://dx.doi.org/10.1016/j.aca.2016.10.013) [efficient peroxidase mimic enable the visual detection of hydrogen](https://dx.doi.org/10.1016/j.aca.2016.10.013) [peroxide and glucose with fast response.](https://dx.doi.org/10.1016/j.aca.2016.10.013) Anal. Chim. Acta 2016, 947, 42−49.

(48) Cai, S.; Han, Q.; Qi, C.; Lian, Z.; Jia, X.; Yang, R.; Wang, C. Pt74Ag26 [nanoparticle-decorated ultrathin MoS2](https://dx.doi.org/10.1039/c5nr08038j) nanosheets as novel [peroxidase mimics for highly selective colorimetric detection of H2O2](https://dx.doi.org/10.1039/c5nr08038j) [and glucose.](https://dx.doi.org/10.1039/c5nr08038j) Nanoscale 2016, 8, 3685−3693.

(49) Jampaiah, D.; Srinivasa Reddy, T.; Kandjani, A. E.; Selvakannan, P. R.; Sabri, Y. M.; Coyle, V. E.; Shukla, R.; Bhargava, S. K. Fe-doped CeO2 [nanorods for enhanced peroxidase-like activity](https://dx.doi.org/10.1039/c6tb00422a) [and their application towards glucose detection.](https://dx.doi.org/10.1039/c6tb00422a) J. Mater. Chem. B. 2016, 4, 3874−3885.

(50) Yu, J.; Ma, X.; Yin, W.; Gu, Z[. Synthesis of PVP-functionalized](https://dx.doi.org/10.1039/c6ra18050g) ultra-small MoS2 [nanoparticles with intrinsic peroxidase-like activity](https://dx.doi.org/10.1039/c6ra18050g) for H2O2 [and glucose detection.](https://dx.doi.org/10.1039/c6ra18050g) RSC Adv. 2016, 6, 81174−81183.

(51) Luo, M.; Hong, Y.; Yao, W.; Huang, C.; Xu, Q.; Wu, Q. [Facile](https://dx.doi.org/10.1039/c4ta05250a) [removal of polyvinylpyrrolidone (PVP) adsorbates from Pt alloy](https://dx.doi.org/10.1039/c4ta05250a) [nanoparticles.](https://dx.doi.org/10.1039/c4ta05250a) J. Mater. Chem. A. 2015, 3, 2770−2775.

(52) Dong, Y.-l.; Zhang, H.-g.; Rahman, Z. U.; Su, L.; Chen, X.-j.; Hu, J.; Chen, X.-g. Graphene oxide-Fe3O4 [magnetic nanocomposites](https://dx.doi.org/10.1039/c2nr12109c) [with peroxidase-like activity for colorimetric detection of glucose.](https://dx.doi.org/10.1039/c2nr12109c) Nanoscale 2012, 4, 3969−3976.

(53) Zhang, L.-N.; Deng, H.-H.; Lin, F.-L.; Xu, X.-W.; Weng, S.-H.; Liu, A.-L.; Lin, X.-H.; Xia, X.-H.; Chen, W. [In situ growth of porous](https://dx.doi.org/10.1021/ac404104j) [platinum nanoparticles on graphene oxide for colorimetric detection](https://dx.doi.org/10.1021/ac404104j) [of cancer cells.](https://dx.doi.org/10.1021/ac404104j) Anal. Chem. 2014, 86, 2711−2718.

(54) Yu, J.; Ma, D.; Mei, L.; Gao, Q.; Yin, W.; Zhang, X.; Yan, L.; Gu, Z.; Ma, X.; Zhao, Y. [Peroxidase-like activity of MoS2](https://dx.doi.org/10.1039/c7tb02676e) nanoflakes [with different modifications and their application for H2O2](https://dx.doi.org/10.1039/c7tb02676e) and [glucose detection.](https://dx.doi.org/10.1039/c7tb02676e) J. Mater. Chem. B. 2018, 6, 487−498.

(55) Vinita; Nirala, N. R.; Tiwari, M.; Prakash, R[. A nanoporous](https://dx.doi.org/10.1007/s00604-018-2776-8) [palladium(II) bridged coordination polymer acting as a peroxidase](https://dx.doi.org/10.1007/s00604-018-2776-8) [mimic in a method for visual detection of glucose in tear and saliva.](https://dx.doi.org/10.1007/s00604-018-2776-8) Microchim. Acta 2018, 185, 245.

(56) Bankar, S. B.; Bule, M. V.; Singhal, R. S.; Ananthanarayan, L. [Glucose oxidase-An overview.](https://dx.doi.org/10.1016/j.biotechadv.2009.04.003) Biotechnol. Adv. 2009, 27, 489−501.

(57) Guo, X.; Suo, Y.; Zhang, X.; Cui, Y.; Chen, S.; Sun, H.; Gao, D.; Liu, Z.; Wang, L. [Ultra-small biocompatible jujube polysaccharide](https://dx.doi.org/10.1039/c9an01053j) [stabilized platinum nanoclusters for glucose detection.](https://dx.doi.org/10.1039/c9an01053j) Analyst 2019, 144, 5179−5185.

(58) Ju, Y.; Kim, J[. Dendrimer-encapsulated Pt nanoparticles with](https://dx.doi.org/10.1039/c5cc06055a) [peroxidase-mimetic activity as biocatalytic labels for sensitive](https://dx.doi.org/10.1039/c5cc06055a) [colorimetric analyses.](https://dx.doi.org/10.1039/c5cc06055a) Chem. Commun. 2015, 51, 13752−13755.

(59) Zhong, Q.; Chen, Y.; Qin, X.; Wang, Y.; Yuan, C.; Xu, Y. [Colorimetric enzymatic determination of glucose based on etching of](https://dx.doi.org/10.1007/s00604-019-3291-2) [gold nanorods by iodine and using carbon quantum dots as](https://dx.doi.org/10.1007/s00604-019-3291-2) [peroxidase mimics.](https://dx.doi.org/10.1007/s00604-019-3291-2) Microchim. Acta 2019, 186, 161.

(60) Zhan, T.; Kang, J.; Li, X.; Pan, L.; Li, G.; Hou, W[. NiFe layered](https://dx.doi.org/10.1016/j.snb.2017.09.074) [double hydroxide nanosheets as an efficiently mimic enzyme for](https://dx.doi.org/10.1016/j.snb.2017.09.074) [colorimetric determination of glucose and H2O2.](https://dx.doi.org/10.1016/j.snb.2017.09.074) Sens. Actuators, B 2018, 255, 2635−2642.

(61) Zhao, Y.; Huang, Y.; Wu, J.; Zhan, X.; Xie, Y.; Tang, D.; Cao, H.; Yun, W. [Mixed-solvent liquid exfoliated MoS2](https://dx.doi.org/10.1039/c7ra12584d) NPs as peroxidase [mimetics for colorimetric detection of H2O2](https://dx.doi.org/10.1039/c7ra12584d) and glucose. RSC Adv. 2018, 8, 7252−7259.

(62) Bian, B.; Liu, Q.; Yu, S[. Enhanced peroxidase-like activity of](https://dx.doi.org/10.1039/c8nj00720a) [porphyrin functionalized ZnFe2O4](https://dx.doi.org/10.1039/c8nj00720a) hollow nanospheres for rapid [detection of H2O2](https://dx.doi.org/10.1039/c8nj00720a) and glucose. New J. Chem. 2018, 42, 18189− 18200.

(63) Karim, M. N.; Anderson, S. R.; Singh, S.; Ramanathan, R.; Bansal, V[. Nanostructured silver fabric as a free-standing NanoZyme](https://dx.doi.org/10.1016/j.bios.2018.03.025) [for colorimetric detection of glucose in urine.](https://dx.doi.org/10.1016/j.bios.2018.03.025) Biosens. Bioelectron. 2018, 110, 8−15.

(64) Salah, A.; Al-Ansi, N.; Adlat, S.; Bawa, M.; He, Y.; Bo, X.; Guo, L. [Sensitive nonenzymatic detection of glucose at PtPd/porous holey](https://dx.doi.org/10.1016/j.jallcom.2019.04.021) [nitrogen-doped graphene.](https://dx.doi.org/10.1016/j.jallcom.2019.04.021) J. Alloys Compd. 2019, 792, 50−58.

(65) Niu, X.; Lan, M.; Chen, C.; Zhao, H. [Nonenzymatic](https://dx.doi.org/10.1016/j.talanta.2012.07.039) [electrochemical glucose sensor based on novel Pt](https://dx.doi.org/10.1016/j.talanta.2012.07.039)−Pd nanoflakes. Talanta 2012, 99, 1062−1067.

(66) Guo, M. Q.; Wang, R.; Xu, X. H[. Electrosynthesis of pinecone](https://dx.doi.org/10.1016/j.msec.2011.07.023)shaped Pt−[Pb nanostructures based on the application in glucose](https://dx.doi.org/10.1016/j.msec.2011.07.023) [detection.](https://dx.doi.org/10.1016/j.msec.2011.07.023) Mater. Sci. Eng., C 2011, 31, 1700−1705.