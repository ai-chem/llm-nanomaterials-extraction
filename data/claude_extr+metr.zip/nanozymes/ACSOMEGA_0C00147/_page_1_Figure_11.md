The image presents two 1H NMR spectra comparing PEI (Polyethyleneimine) and Pt50-PEI (Platinum-modified Polyethyleneimine). The x-axis represents the chemical shift in parts per million (ppm), ranging from 0 to 7 ppm. The y-axis shows the signal intensity in arbitrary units.

For the PEI spectrum (top):
- A sharp, intense peak is observed at approximately 2.7-2.8 ppm, which is characteristic of the CH2 protons in the ethylene units of PEI.
- The spectrum is relatively clean with no other significant peaks, indicating a pure PEI sample.

For the Pt50-PEI spectrum (bottom):
- A broad, intense peak is observed at around 5 ppm, which is likely due to the interaction of platinum with the amine groups of PEI.
- Multiple peaks are visible in the region of 2.5-3.5 ppm, showing a more complex splitting pattern compared to pure PEI. This indicates changes in the chemical environment of the CH2 protons due to platinum coordination.
- The peaks in the 2.5-3.5 ppm region show varying intensities and some overlap, suggesting different types of platinum-amine interactions or different degrees of platinum coordination to the PEI structure.

The comparison of these spectra clearly demonstrates the structural changes in PEI upon platinum coordination, as evidenced by the appearance of new peaks and the shift in existing peaks. This spectral analysis provides valuable information about the nature of the Pt-PEI complex formation and the distribution of platinum within the polymer structure.