Contents lists available at [ScienceDirect](www.sciencedirect.com/science/journal/00236438) 

## LWT

journal homepage: [www.elsevier.com/locate/lwt](https://www.elsevier.com/locate/lwt)

# Oxidase-like Fe–Mn bimetallic nanozymes for colorimetric detection of ascorbic acid in kiwi fruit

Yaru Han a , Linpin Luo a , Liang Zhang a , Yi Kang a , Hao Sun a , Jie Dan a , Jing Sun b , Wentao Zhang a,* , Tianli Yue a , Jianlong Wang a

a *College of Food Science and Engineering, Northwest A&F University, Yangling, 712100, Shaanxi, China* 

b *Qinghai Provincial Key Laboratory of Qinghai-Tibet Plateau Biological Resources, Northwest Institute of Plateau Biology, Chinese Academy of Sciences, Xining, 810008, Qinghai, China* 

## ARTICLE INFO

*Keywords:*  Fe-Mn bimetallic nanozymes Oxidase mimic Colorimetric biosensor for ascorbic acid Kiwi fruit Detection method

#### ABSTRACT

Nanozymes have become a frontier of research recently and possess broad application prospects in the field of analytical sensing. Herein, a Fe–Mn bimetallic nanozyme (FeMnzyme) was proposed for colorimetric analysis of ascorbic acid (AA). The FeMnzyme, with high specific surface area, consisted of Fe–Mn mixed oxide amorphous core and α-FeOOH nanorod shell characterized by scanning electron microscope (SEM) and Powder X-ray diffraction (XRD). It exhibits typical oxidase-like properties to catalyze oxidation of colorless 3,3′ ,5,5′ -tetramethylbenzidine (TMB) to generate visible blue oxidized TMB (oxTMB) without exogenous H2O2. Due to the reducibility of AA to oxTMB, the FeMnzyme/oxTMB system can be employed as a promising colorimetric sensor for quantitative analysis of AA. The method has a good linear concentration range of 8 μmol L− 1 to 56 μmol L− 1 , and the detection limit is as low as 0.88 μmol L− 1 (3σ). Finally, the proposed biosensor has been favorably put into use to determine AA content in kiwi fruit, indicating its reliability for practical application.

#### **1. Introduction**

Ascorbic acid (AA), also named as vitamin C, is a key redox cofactor in numerous biological metabolic processes ([Bendich et al., 1986)](#page-6-0). Vitamin C makes unique contributions to maintaining human health, such as preventing and treating the cold ([Padayatty et al., 2004](#page-6-0)), the scurvy (Steinberg & [Rucker, 2013](#page-6-0)) and cancer (Qi [Chen et al., 2005)](#page-6-0). Since the human liver cannot synthesize L-gulonolactone oxidase (GLO), an enzyme that converts blood sugar into AA, humans need exogenous sources of AA daily to survive ([Stone, 1979)](#page-6-0). Therefore, it is profoundly crucial to create an efficient and accurate strategy for monitoring AA content in food samples.

So far, a variety of detection methods have been established to quantify AA, including traditional enzymatic methods ([Kumar et al.,](#page-6-0) [2008)](#page-6-0), oxidant titration (Kirk & [Sawyer, 1991)](#page-6-0), chromatographic techniques ([Lima et al., 2016)](#page-6-0), electrochemical analysis ([Wen et al., 2010)](#page-6-0), etc. However, the above methods often undergo the defects of the need of trained technicians, the requirement of expensive equipment, and cumbersome operations. In this case, establishing a colorimetric sensor for on-site visual AA inspection with naked eyes is a promising method

to avoid these drawbacks. As an extremely critical biocatalyst, natural enzymes are involved in a wide range of colorimetric biosensing fields, owing to its reaction characteristics of high efficiency, specificity and mildness. However, the fatal disadvantages of natural enzymes, such as poor stability, easy degradation and high preparation costs, which limit the practical application of natural enzymes ([Ding et al., 2020;](#page-6-0) [Gao](#page-6-0)  [et al., 2007)](#page-6-0). In the past few decades, researchers have explored artificial enzymes with strong stability, large-scale preparation and affordable prices to substitute for natural enzymes (Xinnan [Liu et al., 2020](#page-6-0)). Currently, some nanomaterials, such as fullerene derivatives (tris-malonic acid derivative of C60, C(60)-poly(2-ethyl-2-oxazoline)s) [(Ali](#page-6-0)  [et al., 2004;](#page-6-0) [Tong et al., 2011](#page-6-0)), nanoceria (engineered cerium oxide nanoparticles (NPs), mixed-valence Ce-BPyDC MOFs) [(Luo et al., 2019](#page-6-0); [Tarnuzzer et al., 2005](#page-6-0)), manganese nanostructures (BSA-templated MnO2 NPs, HAS-templated MnO2 nanosheets) ([Ge et al., 2018](#page-6-0); X. [Liu](#page-6-0)  [et al., 2012](#page-6-0)) and ferromagnetic nanomaterials (Magnetoferritin NPs, Fe3O4 magnetic NPs) ([Fan et al., 2012;](#page-6-0) [Gao et al., 2007](#page-6-0)), have been confirmed to perform unexpected enzyme mimetic properties (including superoxide dismutase (SOD), catalase, oxidase, peroxidase, etc.). These artificial nanozymes have similarities with natural enzymes in terms of

* Corresponding author. *E-mail address:* [zhangwt@nwsuaf.edu.cn](mailto:zhangwt@nwsuaf.edu.cn) (W. Zhang).

<https://doi.org/10.1016/j.lwt.2021.112821>

Available online 17 November 2021 0023-6438/© 2021 The Authors. Published by Elsevier Ltd. This is an open access article under the CC BY-NC-ND license ([http://creativecommons.org/licenses/by-nc-nd/4.0/)](http://creativecommons.org/licenses/by-nc-nd/4.0/). Received 2 July 2021; Received in revised form 12 November 2021; Accepted 13 November 2021

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image appears to be the cover or title page of a scientific journal called "LWT - Food Science and Technology". Here are the key details:

1. Journal Title: LWT - Food Science and Technology

2. Publisher: The logo at the top of the page indicates this is published by Elsevier, a major scientific publishing company.

3. Visual Elements: The background contains faded images that appear to be related to food science, such as what look like microscopic views of food structures or ingredients. However, these are stylized and not meant to convey specific scientific information.

4. Color Scheme: The cover uses a green color scheme, which is often associated with freshness and nature, fitting for a food science journal.

5. Additional Text: At the bottom, there appears to be some additional text, likely volume or issue information, but it's not clearly legible in this image.

This cover page serves to identify the journal and doesn't contain specific scientific data or chemical structures. Its purpose is to brand the publication and give a visual representation of its focus on food science and technology.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image appears to be an icon or logo, likely for a software application or digital service. It consists of a stylized representation of a document or file with a checkmark symbol overlaid on top. The overall design is simple and uses basic geometric shapes. Given that this does not convey specific scientific or chemical information, I would classify this as:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<span id="page-1-0"></span>general size, structure and surface charge, and follow principles of enzymatic kinetics, which enable nanomaterials to simulate natural enzymes ([Kotov, 2010](#page-6-0)). Compared with natural enzymes, artificial nanozymes have the advantages of low cost, robustness to harsh environments, large-scale production, long-term storage and tunable activity, as mentioned above, but they still have a certain gap with natural enzymes in terms of biocompatibility, efficiency, specificity and selectivity. Therefore, rational design of the nanozymes with high biocompatibility, high catalytic efficiency, high substrate specificity and high selectivity has become a major challenge for researchers.

Herein, a Fe–Mn bimetallic nanozyme (FeMnzyme) with unique 3D urchin-like structure, high specific surface area, superior electronic conductivity, outstanding framework stability, and excellent catalytic performance, was reported for colorimetric detection of AA. The unique 3D urchin-like structure provides sufficient active sites to effectively catalyze self-adsorbed O2 to generate O2 **.**– , and accelerate the transfer of electrons in TMB. Therefore, the FeMnzyme exhibits typical oxidase-like activities to catalyze oxidation of colorless 3,3′ ,5,5′ -tetramethylbenzidine (TMB) to generate visible blue oxidized TMB (oxTMB) without exogenous H2O2. The FeMnzyme/oxTMB system can be employed as a promising colorimetric biosensor for trace analysis of specific substances. On account of the premium oxidase-mimic property of FeMnzyme, a rapid trace assay for AA was proposed. AA can directly reduce the oxTMB substrate to TMB, which causes the blue FeMnzyme/oxTMB system to fade. By monitoring the absorbance difference of the UV–vis spectrum, a valid colorimetric biosensor for AA determination was developed without external H2O2 (Fig. 1a). It showed the advantages of fast detection speed, high accuracy, simple preparation and convenient operation.

## **2. Experimental**

## *2.1. Materials and reagents*

Ascorbic acid (AA), alanine (Ala), citric acid (CA), fructose (Fru) glycine (Gly), histidine (His), sucrose (Suc), tartaric acid (TA) and starch purchased from Aladdin reagent Co., Ltd. (China). 3,3′ ,5,5′ -tetramethylbenzidine (TMB) and *o*-phenylenediamine (OPD) were gotten from Sigma-Aldrich (USA). Arginine (Arg), glucose (Glu), acetic acid (HAc), lysine (Lys), sodium acetate (NaAc), threonine (Thr), NaOH, NaCl, MgCl2, CaCl2, CuCl2, ZnCl2, FeSO4⋅7H2O and KMnO4 were acquired from Sinopharm Chemical Reagent Co., Ltd (China). All these chemical reagents were analytical grade or better and utilized as obtained unless otherwise indicated.

Kiwi fruit (Xu xiang) were purchased from local store (Yangling, China).

#### *2.2. Apparatus*

Ultraviolet–visible (UV–vis) spectra from the solution of reaction systems were collected by UV-2550 spectrophotometer (Shimadzu, Japan). After the powdered material was diluted, it was added dropwise to the silicon wafer to observe the surface morphology by scanning electron microscope (SEM, Hitachi S-4800, Japan). The X-ray photoelectron spectroscopy (XPS) samples were prepared by the following steps: sprinkle the sample powder evenly on the tape adhered to the aluminum foil, cover the entire tape surface, fold the aluminum foil in half, and place it on the tablet press for tableting. After the tablet is pressed, remove the aluminum foil and cut the aluminum foil around the compressed sample for testing. XPS data were recorded through ESCA-LAB 250 spectrometer (Thermo, American) with 150 W monochromatized Al Kα radiation (1486.6 eV) and analyzed included elements and valence by XPS Peak software. Powder X-ray diffraction (XRD) samples were prepared by the following steps: use a medicine spoon to sample in the groove in the middle of the glass sample holder, then gently press the sample with a glass slide, and scrape off the excess powder to make the surface of the sample flat before testing. XRD patterns were recorded via powder diffractometer (Bruker D8 Advanced Diffractometer System, Germany) with a Ni filter, Cu Kα radiation source (λ = 1.5418 Å, tube voltage: 40 kV, tube current: 40 mA, scanning rate: 6◦ min− 1 , angular variation: 10–90◦) source, and analyzed the phases of as-prepared samples by Jade 6 software ([Luo et al., 2019](#page-6-0); [Zhong et al., 2018)](#page-6-0). The oven (Shanghai Jinghong, DHG-9240 A, 2200w, China) was purchased to dry the material.

<DESCRIPTION_FROM_IMAGE>The image depicts two parts, labeled 'a' and 'b', illustrating a chemical reaction process and the synthesis of a nanozyme.

Part a:
This section shows a series of test tubes and chemical structures. From left to right:

1. "FeMnzyme" - represented by a circular structure.
2. "AA" - Ascorbic acid, with its chemical structure shown. SMILES: C(C(C1C(=C(C(=O)O1)O)O)O)O
3. Four test tubes showing a color reaction and fading process:
   - First tube: Clear solution with particles
   - Second tube: Blue solution labeled "Color reaction"
   - Third and fourth tubes: Progressively lighter blue solutions labeled "fading"
4. Chemical structures on the right:
   - "oxAA" (oxidized ascorbic acid). SMILES: O=C1OC(C(O)C1=O)CO
   - "oxTMB" (oxidized 3,3',5,5'-tetramethylbenzidine). SMILES: CC1=CC(=C(C=C1N)C2=CC(=C(C=C2N)C)C)C
   - "TMB" (3,3',5,5'-tetramethylbenzidine). SMILES: CC1=CC(=C(C=C1N)C2=CC(=C(C=C2N)C)C)C

Part b:
This section illustrates the synthesis process of FeMnzyme:

1. Starting material: KMnO4 (potassium permanganate)
2. First step: Addition of FeSO4 (iron(II) sulfate) under boiling conditions, forming FeMnOy
3. Second step: Addition of NaOH (sodium hydroxide) under boiling conditions, causing growth of the nanostructure
4. Third step: Further addition of NaOH under boiling conditions, resulting in the final FeMnzyme structure

The image demonstrates the colorimetric detection method using the synthesized FeMnzyme and its interaction with ascorbic acid (AA) and TMB, showing the color change and subsequent fading process.</DESCRIPTION_FROM_IMAGE>

**Fig. 1.** (a) Diagram of the colorimetric biosensor for AA quantification based on FeMnzyme/oxTMB system. (b) Illustration of synthesis process for FeMnzyme.

## *2.3. Synthesis of FeMnzyme*

FeMnzyme was obtained by a facile one-pot template-free method according to the previous report ([Zhong et al., 2018](#page-6-0)). Typically, 3.13 g FeSO4⋅7H2O and 0.60 g KMnO4 were first dissolved in 50 mL distilled water, respectively. After heating KMnO4 solution to boiling, FeSO4 solution was gradually added to KMnO4 solution under the robust magnetic stirring. Then, NaOH solution (6.5 ml, 5 mol L− 1 ) was added dropwise to the boiling mixture. After natural cooling, the precipitate was collected after washing five times with distilled water. Finally, the formed FeMnzyme was dried in an oven at 80 ◦C ± 5 ◦C until constant weight (12 h).

## *2.4. Oxidase-like catalytic characteristics of FeMnzyme*

The oxidase-like activities of the FeMnzyme were investigated by catalyzing the colorimetric reaction of TMB. In detail, FeMnzyme (140 μL, 125 μg mL− 1 ) and TMB (25 μL, 20 mmol L− 1 ) were mixed with 335 μL NaAc-HAc buffer (0.2 mol L− 1 , pH 4.0). After reacting for 5 min at room temperature, the absorbance of the blue reaction system attributing to the oxidation of TMB at 652 nm was obtained by UV–vis ([Luo](#page-6-0)  [et al., 2019)](#page-6-0). To optimize the oxidase-like activity of FeMnzyme, the time- and concentration-dependent kinetics of FeMnzyme was carried out by adding various concentrations of FeMnzyme into TMB (25 μL, 20 mmol L− 1 ) and 0.2 mol L− 1 NaAc-HAc buffer (pH 4.0). Under time scan mode (0–300 s), the absorbance at 652 nm was monitored at the moment when FeMnzyme was added to the TMB and 0.2 mol L− 1 NaAc-HAc buffer system, and we regarded this time point as the first point (0 s), and the dead-time was set to 10 s, which meant that the absorbance at 652 nm of the reaction system was monitored every 10 s. Temperature test was accomplished from 10 ◦C to 40 ◦C under 0.2 mol L− 1 NaAc-HAc buffer (pH 4.0), and pH test was implemented at room temperature from pH 2 to pH 7.

## *2.5. Kinetic tests of the FeMnzyme*

Under the optimal conditions with various concentrations of substrate (TMB), the kinetic tests were operated in time scan mode at 652 nm by microplate reader. The Vmax and Km were derived via the following equation ([Luo et al., 2019](#page-6-0)):

$$\nu = V_{\text{max}}[\mathbf{S}] / (K_{\text{m}} + [\mathbf{S}])$$

Where ν is the initial velocity, *Vmax* is the maximum velocity of reaction, *Km* is the constant of Michaelis-Menten, and [S] is the concentration of the substrate.

## *2.6. Detection of AA based on the FeMnzyme/oxTMB system*

Briefly, FeMnzyme (140 μL, 125 μg L− 1 ), TMB (25 μL, 20 mmol L− 1 ), and various concentrations of AA (0–32 μL, 1 mmol L− 1 ) were added to 0.2 mol L− 1 NaAc-HAc buffer (pH 3.0). The final volume of the reaction system was 500 μL. After 5 min of incubation, the absorbance of the reacted system at 652 nm was analyzed by UV–vis. The concentration of AA in analytes was determined through a calibration curve of the absorbance difference (ΔAbs).

In order to explore the selectivity of FeMnzyme/oxTMB system for AA detection, some potential interferences in real samples were added into the reaction system, including Zn2+, Cu2+, Mg2+, Ca2+, Glucose (Glu), tartaric acid (TA), citric acid (CA), starch, sucrose (Suc), fructose (Fru), alanine (Ala), arginine (Arg), glycine (Gly), histidine (His), lysine (Lys) and threonine (Thr). The 500 μL total system consists of FeMnzyme (140 μL, 125 μg L− 1 ), TMB (25 μL, 20 mmol L− 1 ), AA (20 μL, 1 mmol L− 1 ), the interfering substance (20 μL, 100 mmol L− 1 ) and 315 μL NaAc-HAc buffer (315 μL, 0.2 mol L− 1 , pH 3.0), after incubating for 5 min at room temperature, monitor the absorbance of the reacted system at 652

nm.

## *2.7. Analysis of AA content in the spiked kiwi fruit samples*

The pretreated sample solution was extracted 20 μL and spiked with 1 mmol L− 1 AA standard solution (0 μL, 7.5 μL, 10 μL, 12.5 μL). The AA content in the kiwi fruit was measured by FeMnzyme/oxTMB system as described above. All assay samples were measured at least triplicate and expressed as the mean values ± standard deviation (SD).

The following step is the process of real sample pretreatment. First, kiwi fruits were removed peels. Then, kiwi fruits were squeezed in a mortar, and add an equal volume of 400 mmol L− 1 NaAc-HAc buffer (pH 3.0) to prevent oxidation. After that, the pomace was separated and collected by centrifugation at 9280*g* for 15 min at 4 ◦C. Finally, the supernatant was diluted 10-fold with 200 mmol L− 1 NaAc-HAc buffer (pH 3.0) and stored at 4 ◦C in the dark (wrapped with tin foil to avoid light). The kiwi fruit samples were diluted 20-fold in total ([Nishiyama](#page-6-0)  [et al., 2004)](#page-6-0).

#### *2.8. Statistical analysis*

All results were obtained from at least triplicate and expressed as the mean values ± standard deviation (SD). To compare the mean, the oneway analysis of variance (ANOVA) was performed on the data and compared by the least significant difference (LSD) test. Values of p *<* 0.05 were considered statistically significant, and values of p *<* 0.01 were considered extremely significant. Statistical analysis of the acquired data was performed by IBM SPSS Statistics software 26.0.

#### **3. Results and discussion**

## *3.1. Characterizations of FeMnzyme*

The FeMnzyme was prepared through a one-pot no template method. As shown in [Fig. 1b](#page-1-0), amorphous FeMnxOy NPs were first synthesized by a redox reaction, and then α-FeOOH nanorods grew on the surface of these FeMnxOy NPs via a boiling-stirring process. The morphology and size of FeMnzyme were exhibited by SEM. The overall structure of FeMnzyme presents a 3D-urchin shape with an average diameter of 500 nm ([Fig. 2](#page-3-0)a). Consisting of core-shell two parts, the diameter of the spherical core formed before adding NaOH is about 250 nm, while the length of the nanorods is approximately 125 nm [(Fig. 2](#page-3-0)b). The structure of the prepared FeMnzyme was further analyzed by XRD. Before adding NaOH, the XRD pattern confirms that no distinguishable signal is observed ([Zhong et al., 2018)](#page-6-0), indicating that the synthesized FeMnxOy NPs are probably amorphous. After adding NaOH, several typical diffraction peaks ([Fig. 2c](#page-3-0)) attributed to α-FeOOH (JCPDS: 029–0713) are found ([Zhang et al., 2012)](#page-6-0). The binging state of FeMnzyme was informed by high-resolution XPS ([Fig. 2](#page-3-0)d). The XPS spectrum of Fe 2p ([Fig. 2](#page-3-0)e) is divided into two main peaks: Fe 2p3/2 satellite (711.3 eV) and Fe 2p1/2 satellite (724.6 eV), which agrees with the positions reported for Fe3+ compounds ([Mou et al., 2011)](#page-6-0). As shown in [Fig. 2f](#page-3-0), two remarkable peaks at 654.3 eV and 642.6 eV are attributed to Mn4+ 2p1/2 and Mn4+ 2p3/2, respectively, matching the positions reported for Mn4+ compounds (J. [Liu et al., 2017](#page-6-0)). The above results suggest that FeMnzyme was successfully synthesized ([Zhong et al., 2018](#page-6-0)).

#### *3.2. Oxidase-like activities of FeMnzyme*

For verifying the catalytic activities of FeMnzyme as a mimetic oxidase, the catalytic oxidation performance of FeMnzyme towards the chromogenic substrates (TMB and OPD) was determined without exogenous H2O2. As illustrated in [Fig. 3](#page-3-0)a, FeMnzyme/oxTMB system was blue with an absorption at 652 nm, while FeMnzyme/oxOPD system was yellow with an absorption at 447 nm. On the contrary, the TMB and OPD of the control groups were colorless and showed no corresponding

<DESCRIPTION_FROM_IMAGE>This image is a composite of six panels labeled a through f, presenting various analytical results for a material referred to as FeMnzyme.

Panel a: Scanning electron microscopy (SEM) image showing a porous, flower-like nanostructure. The scale bar indicates 500 nm.

Panel b: Higher magnification SEM image revealing rod-like nanostructures arranged in a radial pattern. The scale bar indicates 200 nm.

Panel c: X-ray diffraction (XRD) pattern comparison. The top pattern (blue) represents FeMnzyme, while the bottom pattern (black) is a reference for α-FeOOH (JCPDS: 029-0713). The x-axis shows 2 Theta values from 20 to 80 degrees, and the y-axis represents intensity in arbitrary units (a.u.).

Panel d: X-ray photoelectron spectroscopy (XPS) survey spectrum. The x-axis shows binding energy from 0 to 800 eV, and the y-axis represents intensity (a.u.). Peaks are labeled for Fe2p, O1s, Mn2p, C1s, and Fe3p.

Panel e: High-resolution XPS spectrum for Fe 2p. The x-axis shows binding energy from 705 to 740 eV, and the y-axis represents intensity (a.u.). Two peaks are visible, labeled as Fe 2p3/2 and Fe 2p1/2.

Panel f: High-resolution XPS spectrum for Mn 2p. The x-axis shows binding energy from 635 to 660 eV, and the y-axis represents intensity (a.u.). Two peaks are visible, labeled as Mn 2p3/2 and Mn 2p1/2.

These results collectively provide information on the morphology, crystal structure, and elemental composition of the FeMnzyme material, indicating it is likely an iron-manganese oxide-based nanostructure.</DESCRIPTION_FROM_IMAGE>

**Fig. 2.** Characterization of the prepared FeMnzyme: (a)–(b) SEM images of FeMnzyme. (c) XRD pattern of FeMnzyme. (d) XPS wide scanning spectrum. (e) XPS pattern for Fe 2p of FeMnzyme. (f) XPS pattern for Mn 2p of FeMnzyme.

<DESCRIPTION_FROM_IMAGE>This image contains four separate graphs labeled a, b, c, and d, each presenting different data related to chemical analysis.

Graph a:
This graph shows the absorption spectra of two compounds, TMB (3,3',5,5'-Tetramethylbenzidine) and OPD (o-Phenylenediamine), plotted against wavelength (nm) on the x-axis and absorbance (a.u.) on the y-axis. The wavelength range is from 300 to 800 nm. TMB shows a major peak around 650 nm and a smaller peak around 370 nm. OPD shows a small peak around 450 nm. An inset image shows four vials: two clear (labeled "Blank"), one blue (labeled "TMB"), and one yellow (labeled "OPD").

Graph b:
This graph displays the absorbance over time for different concentrations of a substance. The x-axis represents time (s) from 0 to 300 seconds, and the y-axis shows absorbance from 0 to 2.0. There are eight curves representing different concentrations: 0, 5, 10, 15, 25, 35, 45, and 55 μg·mL⁻¹. The curves show an increase in absorbance over time, with higher concentrations resulting in steeper curves and higher final absorbance values.

Graph c:
This graph illustrates the relationship between pH and relative activity (%). The x-axis shows pH values from 2 to 7, and the y-axis represents relative activity from 0 to 100%. The curve peaks around pH 3 (labeled 'b') with nearly 100% relative activity. Activity decreases sharply on both sides of this optimum, reaching about 20% at pH 7 (labeled 'f'). Points on the curve are labeled 'a' through 'f' in order of increasing pH.

Graph d:
This graph demonstrates the effect of temperature on relative activity (%). The x-axis shows temperature (°C) from 10 to 40°C, and the y-axis represents relative activity from 20 to 100%. The curve peaks at 20°C (labeled 'c') with 100% relative activity. Activity decreases on both sides of this optimum, reaching about 40% at 10°C and 35% at 40°C. Points on the curve are labeled 'a' through 'd', with 'c' being the optimum and 'a' appearing twice at the temperature extremes.

All graphs include error bars for data points, indicating the precision of the measurements.</DESCRIPTION_FROM_IMAGE>

**Fig. 3.** Catalytic activity of FeMnzyme oxidase: (a) The UV–Vis absorption spectra of FeMnzyme (35 μg mL− 1 ) towards different oxidation substrates TMB (red curve) and OPD (blue curve), the corresponding dotted line indicates that only TMB (yellow curve) or OPD (green curve) is used. (b) The timeand concentration-dependent kinetics of FeMnzyme at 652 nm (c) The influence of PH value on the catalytic activity of FeMnzyme. (d) The effect of temperature on the catalytic activity of FeMnzyme (the maximum enzyme activity is set at 100%). The values in (c)–(d) are expressed as mean ± SD, and different lowercase letters in the curve indicate significant differences (P *<* 0.05). (For interpretation of the references to color in this figure legend, the reader is referred to the Web version of this article.)

absorption peaks. The above phenomenon proves that FeMnzyme has catalytic activities as a mimetic oxidase. Due to the low toxicity of TMB, it was used as a chromogenic substrate for further research (Qiumeng Chen et al., 2020).

In order to optimize the enzyme activity of FeMnzyme, the effects of reaction time, FeMnzyme concentration, pH value and temperature on the oxidase-like activity of FeMnzyme were studied. Fig. 3b shows the change in absorbance of the FeMnzyme/oxTMB reaction system at 652

nm with time and FeMnzyme concentration. It was found that the initial reaction rate increased as the concentration of FeMnzyme increased. In the range of 0–300 s, the absorbance value gradually increased within 0–250 s, and changed little change after 250 s. The absorbance value after the reaction equilibrium increased with the increase of the FeMnzyme concentration. Similar to other nanomaterials to mimic oxidase ([Ding et al., 2020;](#page-6-0) [Qin et al., 2014](#page-6-0); Xuefang [Zheng, Lian, Zhou,](#page-6-0)  Jiang, & [Gao, 2020)](#page-6-0), the oxidase-like activity of FeMnzyme was closely related to pH and temperature. The mimetic enzyme activity of FeMnzyme was relatively strong in the pH range of 2.0–4.0 ([Fig. 3](#page-3-0)c) and the temperature range of 20–25 ◦C [(Fig. 3](#page-3-0)d), respectively. Therefore, the optimized reactions were carried out at room temperature and incubated in 0.2 mol L− 1 NaAc-HAc buffer (pH 3.0) for 5 min, where TMB (25 μL, 20 mmol L− 1 ), FeMnzyme (140 μL, 125 μg mL− 1 ), and the final volume (500 μL) of the whole system.

## *3.3. Proposed catalysis mechanism of FeMnzyme as an oxidase mimic*

To investigate the catalysis mechanism of FeMnzyme as an oxidase mimic, a series of tests were carried out. As presented in Fig. S1, comparing the catalytic properties of the FeMnzyme leachate obtained through centrifugation (9391 g, 15 min) with these of original FeMnzyme system, under the same conditions, the dissolved ions of the leachate showed no contribution to catalyze the oxidation of TMB ([Luo](#page-6-0)  [et al., 2019)](#page-6-0). Due to FeMnzyme with the high specific surface area, oxygen molecules are not only dissolved in water, but also adsorbed by FeMnzyme. Fig. S2 manifested that there was no obvious difference between the oxidation reaction of TMB in air-saturated solution and that of N2 saturated solution, which proved that dissolved oxygen had no effect on the FeMnzyme/TMB system ([Qin et al., 2014](#page-6-0)). Unlike some reported nanoparticle-based oxidase mimics (Qiumeng [Chen et al.,](#page-6-0)  [2020; Wu et al., 2019](#page-6-0); Xuefang [Zheng et al., 2020](#page-6-0)), the O2 adsorbed by FeMnzyme instead of the O2 dissolved in water oxidized TMB. T-butanol or isopropanol, NaN3 and p-benzoquinone were chosen to identify the possible existence of reaction intermediates ( **.** OH, 1 O2 and O2 **.**– ), respectively ([Wu et al., 2019;](#page-6-0) Xuefang [Zheng et al., 2020](#page-6-0)). The results show that presence of **.** OH and 1 O2 was negligible, but the p-benzoquinone (O2 **.**– scavenger), whose addition amount was only 5% of that of **.** OH scavenger and 1 O2 scavenger, exhibited a visible effect (P *<* 0.05) (Fig. S3). The above results indicate that under acidic conditions, FeMnzyme catalyzed the self-adsorbed O2 to generate O2 **.**– and accelerated the transfer of electrons in TMB, and the intermediate product O2 **.**– with strong oxidizing properties oxidized TMB to blue oxTMB (Fig. S4).

## *3.4. Enzymatic kinetic tests of FeMnzyme*

The Oxidase-like activity of FeMnzyme was analyzed through kinetic parameters obtaining through changing the concentration of TMB (0–1 mmol L− 1 ). By fitting the Michaelis-Menten curve (Fig. S5a) and Lineweaver-Burk plot (Fig. S5b), important physical parameters of enzymatic kinetics, such as the maximum initial reaction rate (*Vmax*) and the Michaelis constant (*Km*), were obtained. The *Vmax* value represents the reaction rate when all the active sites of the enzyme are occupied by the substrate. The *Km* is a pivotal parameter to evaluate the interaction between the enzyme and the substrate, and its value is the substrate concentration when the reaction rate attains half of *Vmax*. Therefore, the lower *Km* value, the stronger the affinity of the enzyme to the substrate.

As shown in Table 1, FeMnzyme exhibited a lower *Km* (0.20 mmol L− 1 ) and a higher *Vmax* (10.25 × 10− 8 mol L− 1 s − 1 ). As an excellent

#### **Table 1**

| Comparison of Km and Vmax of different nanozymes based on TMB substrate. |  |
|--------------------------------------------------------------------------|--|
|--------------------------------------------------------------------------|--|

| catalysts    | Km (mmol<br>L− 1<br>) | Vmax (10− 8 mol L− 1<br>− 1<br>s<br>) | Reference          |
|--------------|-----------------------|---------------------------------------|--------------------|
| FeMnzyme     | 0.20                  | 10.25                                 | This work          |
| HRP          | 0.43                  | 10                                    | Cai et al. (2016)  |
| NiFe2O4 MNPs | 0.55                  | 4.57                                  | Su et al. (2015)   |
| 3DRGO        | 0.34                  | 20                                    | Zheng et al.       |
| Fe3O4–Pd     |                       |                                       | (2015)             |
| Fe3O4/N-GQDs | 0.19                  | 13.8                                  | Shi et al. (2016)  |
| GO-Fe3O4     | 0.43                  | 10                                    | Dong et al. (2012) |
| CuMnO2       | 0.58                  | 8.15                                  | Chen et al. (2019) |
|              |                       |                                       |                    |

oxidase-mimicking nanozyme, FeMnzyme with high specific surface area possessed sufficient active sites. As a result, it performed excellent affinity for the substrate TMB, and its kinetic parameters were distinctly better than some other nanomaterials (Table 1) ([Cai et al., 2016;](#page-6-0) Y. [Chen](#page-6-0)  [et al., 2019; Dong et al., 2012; Shi et al., 2016](#page-6-0); [Su et al., 2015;](#page-6-0) Xuejing [Zheng et al., 2015)](#page-6-0).

#### *3.5. Colorimetric detection of AA*

The reducibility of AA can reduce blue oxTMB to colorless TMB, which itself is oxidized to DHA ([Ding et al., 2020)](#page-6-0). Based on the above properties, FeMnzyme/oxTMB system can be used to detect AA concentration by monitoring the absorbance at 652 nm with the UV–vis spectrophotometer. Under optimized experimental conditions, a series concentration of AA was added to the FeMnzyme/oxTMB system and incubated at room temperature for 5 min. [Fig. 4](#page-5-0)c indicates that ΔAbs, where ΔAbs = Abs (blank, 652 nm) – Abs (AA, 652 nm), increased with the concentration of AA (0 μmol L− 1 -64 μmol L− 1 ) increasing in the system, and the visible blue of the system was faded gradually until eventually colorless ([Fig. 4](#page-5-0)b). [Fig. 4](#page-5-0)d shows a good linear correlation in the range of 8 μmol L− 1 -56 μmol L− 1 , and the calibration equation for AA detection was fitted as y = 0.0288 x + 0.0339 (R2 = 0.9947, n = 7). The low limit of detection (LOD) for AA was 0.88 μmol L− 1 (3σ), which was lower than some other reported nanomaterial-based colorimetric methods for detecting AA (Table S1) ([Ai et al., 2013](#page-6-0); S. [Chen et al., 2017](#page-6-0); [Darabdhara et al., 2017;](#page-6-0) [Luo et al., 2019](#page-6-0); [Szoke et al., 2019](#page-6-0)).

In order to explore the selectivity of FeMnzyme/oxTMB system for AA detection, some potential interfering substances in real samples were added into the reaction system, including Ca2+, Cu2+, Mg2+, Zn2+, citric acid (CA), fructose (Fru), Glucose (Glu), tartaric acid (TA), starch, sucrose (Suc), alanine (Ala), arginine (Arg), glycine (Gly), histidine (His), lysine (Lys) and threonine (Thr). As shown in [Fig. 5](#page-5-0), the concentration of interfering substances was 100 times to AA, but it had no obvious effect on absorbance, indicating that the assay had strong anti-interference selectivity for AA (P *<* 0.05). In addition, the stability of FeMnzyme was tested. Within 7 days, the change in catalytic activity was within 5% (Fig. S6), and the difference between batches was within 3% (Fig. S7). The above results prove that the FeMnzyme has perfect stability and strong reproducibility between batches.

## *3.6. Detection of AA in the spiked kiwi fruit samples*

To evaluate the reliability of the reported colorimetric biosensor, FeMnzyme/oxTMB system was applied to analyze AA content in kiwi fruit samples and validated by the standard addition method. Without adding or with adding different standard concentrations of AA, the concentrations of AA in a 20-fold diluted kiwi fruit samples were determined. As presented in [Table 2](#page-5-0), the recovery rate of the spiked samples was from 98.39% to 105.90%, and the relative standard deviation (RSD) was in the range of 0.24% to 1.43%. The results confirm that the FeMnzyme/oxTMB system possesses the potential to be applied to the analysis of AA content in real samples*.* 

#### **4. Conclusions**

In summary, we have constructed a colorimetric biosensor based on FeMnzyme/oxTMB system for facile detection and quantification of AA within 5 min. The FeMnzyme, with the strong affinity to the substrate TMB, exhibits excellent power to catalyze the oxidization of TMB to generate the chromogenic reactions without H2O2 or bio-enzyme. According to the anti-interference experiment, the interfering substances have no obvious effect, indicating that the method has satisfactory selectivity toward AA detection. The FeMnzyme/oxTMB system was suitably employed to quantify AA in kiwi fruit samples with standard method validation, and the recovery rates of spiked samples were 98.39% to 105.90% with RSD less than 2%, proving its feasibility in

<DESCRIPTION_FROM_IMAGE>The image contains four panels labeled a, b, c, and d.

Panel a: This is a graph showing absorption spectra. The x-axis represents wavelength in nanometers (nm) ranging from 550 to 750 nm. The y-axis represents absorbance (Abs) in arbitrary units (a.u.) ranging from 0 to 2.0. Multiple spectra are shown, with the highest peak around 650 nm. The spectra decrease in intensity from top to bottom, corresponding to concentrations from 0 μmol L⁻¹ to 64 μmol L⁻¹.

Panel b: This appears to be a circular image showing a radial pattern. Without describing visual characteristics, this image likely represents a physical or chemical phenomenon related to the study, possibly a diffusion or reaction pattern.

Panel c: This graph shows the relationship between AA Concentration (μmol L⁻¹) on the x-axis (ranging from 0 to 60) and ΔAbs (652 nm) on the y-axis (ranging from 0 to 1.8). The plot shows a non-linear relationship with increasing ΔAbs as AA Concentration increases. Error bars are visible on each data point.

Panel d: This graph is similar to panel c, showing AA Concentration (μmol L⁻¹) on the x-axis (0 to 60) and ΔAbs (652 nm) on the y-axis (0 to 1.8). However, this plot shows a linear relationship. A linear regression line is fitted to the data points, with the equation y = 0.0288x + 0.0339 and R² = 0.9947. Error bars are also visible on each data point.

These graphs collectively represent an analysis of absorption characteristics, likely related to a chemical compound (possibly AA, which could stand for ascorbic acid or another compound) at various concentrations, with a focus on the absorbance at 652 nm.</DESCRIPTION_FROM_IMAGE>

**Fig. 4.** AA colorimetric detection based on FeMnzyme/oxTMB system: (a) UV–vis absorbance spectra of FeMnzyme/oxTMB system after adding different concentrations of AA. (b) The picture of distinguishable color changes of the reaction systems after adding different concentrations of AA. (c) The plot of AA standard concentration (0 μmol L− 1 - 64 μmol L− 1 ) based on FeMnzyme/oxTMB system at 652 nm. (d) The calibration curve of AA standard concentrations (8 μmol L− 1 to 56 μmol L− 1 ) based on FeMnzyme/oxTMB system at 652 nm. Conditions: 35 μg mL− 1 FeMnzyme and 1 mmol L− 1 TMB incubated in 0.2 mol L− 1 NaAc-HAc buffer (pH 3.0) for 5 min, room temperature. The values are expressed as mean ± SD. (For interpretation of the references to color in this figure legend, the reader is referred to the Web version of this article.)

<DESCRIPTION_FROM_IMAGE>This image contains a bar graph and an inset circular diagram, both related to a chemical analysis.

The bar graph shows the change in absorbance (ΔAbs) in arbitrary units (a.u.) for various chemical species. The y-axis ranges from 0 to 1.25 a.u. The x-axis lists different chemical species and compounds:

AA, Ca2+, Cu2+, Mg2+, Zn2+, Glu, Fru, Suc, CA, TA, Starch, Lys, Arg, Gly, His, Thr, Ala

The highest bar corresponds to AA (likely Ascorbic Acid) with a ΔAbs value of approximately 1.18 a.u. All other species show significantly lower values, mostly below 0.25 a.u. The next highest values are for CA (Citric Acid) at about 0.19 a.u. and Lys (Lysine) at about 0.15 a.u.

There are error bars on each column, indicating the uncertainty of measurements.

Above the AA bar, there is a double asterisk (**) which likely indicates statistical significance.

The inset circular diagram shows a colorimetric assay result. It's a circular arrangement of samples, each labeled with the chemical species corresponding to those in the bar graph. The samples show varying intensities of blue color, with AA appearing to have the most intense coloration, correlating with its high ΔAbs value in the bar graph.

This image likely represents a selectivity or interference study for a colorimetric assay, possibly for the detection of ascorbic acid (AA), showing its response compared to other potential interfering species.</DESCRIPTION_FROM_IMAGE>

**Fig. 5.** Selective test of potential interferences in real samples. Condition: AA concentration is 40 μmol L− 1 , other interfering substance concentration is 4 mmol L− 1 . The values are expressed as mean ± SD, and **p *<* 0.01 was extremely significant.

| Table 2 |
|---------|
|         |

Real-sample analysis of spiked kiwi fruit samples.

| Sample           | Added AA (μmol<br>L− 1<br>)     | Found AA (μmol<br>L− 1<br>)                                  | Recovery<br>(%)                | RSD (%, n<br>= 3)            |
|------------------|---------------------------------|--------------------------------------------------------------|--------------------------------|------------------------------|
| 5% kiwi<br>fruit | 0.00<br>15.00<br>20.00<br>25.00 | 27.10 ± 0.18<br>42.83 ± 0.10<br>46.69 ± 0.35<br>53.48 ± 0.76 | -<br>105.45<br>98.39<br>105.90 | 0.68<br>0.24<br>0.76<br>1.43 |

evaluating AA content in practical application. The method provides a promising strategy to rationally design a portable colorimetric biosensor based on FeMnzyme/oxTMB system for on-site detection of AA in complex food systems.

## **CRediT authorship contribution statement**

**Yaru Han:** Conceptualization, Data curation, Investigation, Methodology, Resources, Writing – original draft, Visualization, Formal analysis, Writing – review & editing. **Linpin Luo:** Data curation, Software. **Liang Zhang:** Investigation. **Yi Kang:** Investigation. **Hao Sun:**  Investigation. **Jie Dan:** Methodology. **Jing Sun:** Resources. **Wentao Zhang:** Conceptualization, Supervision, Resources, Project administration, Writing – review & editing. **Tianli Yue:** Resources. **Jianlong Wang:** Investigation, Resources.

#### **Declaration of competing interest**

The authors declare no competing financial interest.

#### **Acknowledgements**

The authors thank the National Natural Science Foundation of China (31901794, 21675127), the National Postdoctoral Program for Innovative Talents (BX20180263), the Development Project of Qinghai Provincial Key Laboratory (2017-ZJ-Y10), the Young Talent Fund of University Association for Science and Technology in Shaanxi, China (2019-02-03), and the Tang Scholar by Cyrus Tang Foundation.

#### **Appendix A. Supplementary data**

Supplementary data to this article can be found online at [https://doi.](https://doi.org/10.1016/j.lwt.2021.112821)  [org/10.1016/j.lwt.2021.112821.](https://doi.org/10.1016/j.lwt.2021.112821)

#### <span id="page-6-0"></span>*Y. Han et al.*

#### **References**

- Ai, L. H., Li, L. L., Zhang, C. H., Fu, J., & Jiang, J. (2013). MIL-53(Fe): A metal-organic framework with intrinsic peroxidase-like catalytic activity for colorimetric biosensing. [Article]. *Chemistry-a European Journal, 19*(45), 15105–15108. [https://](https://doi.org/10.1002/chem.201303051) [doi.org/10.1002/chem.201303051](https://doi.org/10.1002/chem.201303051)
- Ali, S. S., Hardt, J. I., Quick, K. L., Sook Kim-Han, J., Erlanger, B. F., Huang, T.-t., … Dugan, L. L. (2004). A biologically effective fullerene (C60) derivative with superoxide dismutase mimetic properties. *Free Radical Biology and Medicine, 37*(8), 1191–1202. <https://doi.org/10.1016/j.freeradbiomed.2004.07.002>
- Bendich, A., Machlin, L. J., Scandurra, O., Burton, G. W., & Wayner, D. D. M. (1986). The antioxidant role of vitamin C. *Advances in Free Radical Biology & Medicine, 2*(2), 419–444. <https://doi.org/10.1016/S8755-9668(86)80021-7>
- Cai, R., Yang, D., Chen, X., Huang, Y., Lyu, Y., He, J., … Tan, W. (2016). Three dimensional multipod superstructures based on Cu(OH)2 as a highly efficient nanozyme. [10.1039/C6TB01233G]. *Journal of Materials Chemistry B, 4*(27), 4657–4661. <https://doi.org/10.1039/C6TB01233G>
- Chen, Y., Chen, T., Wu, X., & Yang, G. (2019). CuMnO2 nanoflakes as pH-switchable catalysts with multiple enzyme-like activities for cysteine detection. *Sensors and Actuators B: Chemical, 279*, 374–384. <https://doi.org/10.1016/j.snb.2018.09.120>
- Chen, S., Chi, M., Yang, Z., Gao, M., Wang, C., & Lu, X. (2017). Carbon dots/Fe3O4 hybrid nanofibers as efficient peroxidase mimics for sensitive detection of H2O2 and ascorbic acid. [10.1039/C7QI00308K]. *Inorganic Chemistry Frontiers, 4*(10), 1621–1627. <https://doi.org/10.1039/C7QI00308K>
- Chen, Q., Espey, M. G., Krishna, M. C., Mitchell, J. B., Corpe, C. P., Buettner, G. R., … Levine, M. (2005). Pharmacologic ascorbic acid concentrations selectively kill cancer cells: Action as a pro-drug to deliver hydrogen peroxide to tissues. *Proceedings of the National Academy of Sciences of the United States of America, 102*(38), 13604. <https://doi.org/10.1073/pnas.0506390102>
- Chen, Q., Li, S., Liu, Y., Zhang, X., Tang, Y., Chai, H., & Huang, Y. (2020). Sizecontrollable Fe-N/C single-atom nanozyme with exceptional oxidase-like activity for sensitive detection of alkaline phosphatase. *Sensors and Actuators B: Chemical, 305*, 127511. <https://doi.org/10.1016/j.snb.2019.127511>
- Darabdhara, G., Sharma, B., Das, M. R., Boukherroub, R., & Szunerits, S. (2017). Cu-Ag bimetallic nanoparticles on reduced graphene oxide nanosheets as peroxidase mimic for glucose and ascorbic acid detection. [Article]. *Sensors and Actuators B: Chemical, 238*, 842–851. <https://doi.org/10.1016/j.snb.2016.07.106>
- Ding, Y., Zhao, M., Yu, J., Li, Z., Zhang, X., Ma, Y., … Chen, S. (2020). Preparation of NiMn2O4/C necklace-like microspheres as oxidase mimetic for colorimetric determination of ascorbic acid. *Talanta, 219*, 121299. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.talanta.2020.121299)  [talanta.2020.121299](https://doi.org/10.1016/j.talanta.2020.121299)
- Dong, Y.-l., Zhang, H.-g., Rahman, Z. U., Su, L., Chen, X.-j., Hu, J., & Chen, X.-g. (2012). Graphene oxide-Fe3O4 magnetic nanocomposites with peroxidase-like activity for colorimetric detection of glucose. *Nanoscale, 4*(13), 3969–3976. [https://doi.org/](https://doi.org/10.1039/c2nr12109c)  [10.1039/c2nr12109c](https://doi.org/10.1039/c2nr12109c)
- Fan, K., Cao, C., Pan, Y., Lu, D., Yang, D., Feng, J., … Yan, X. (2012). Magnetoferritin nanoparticles for targeting and visualizing tumour tissues. *Nature Nanotechnology, 7*  (7), 459–464. <https://doi.org/10.1038/nnano.2012.90>
- Gao, L., Zhuang, J., Nie, L., Zhang, J., Zhang, Y., Gu, N., … Yan, X. (2007). Intrinsic peroxidase-like activity of ferromagnetic nanoparticles. *Nature Nanotechnology, 2*(9), 577–583. <https://doi.org/10.1038/nnano.2007.260>
- Ge, J., Xing, K., Geng, X., Hu, Y. L., Shen, X. P., Zhang, L., & Li, Z. H. (2018). Human serum albumin templated MnO(2) nanosheets are oxidase mimics for colorimetric determination of hydrogen peroxide and for enzymatic determination of glucose. *Mikrochimica Acta, 185*(12), 559. <https://doi.org/10.1007/s00604-018-3099-5>
- Kirk, S., & Sawyer, R. (1991). *Pearson'[s composition and analysis of foods](http://refhub.elsevier.com/S0023-6438(21)01974-5/sref15)*. Longman Group [Ltd.](http://refhub.elsevier.com/S0023-6438(21)01974-5/sref15)
- Kotov, N. A. (2010). Inorganic nanoparticles as protein mimics. *Science, 330*(6001), 188. <https://doi.org/10.1126/science.1190094>
- Kumar, S. A., Lo, P.-H., & Chen, S.-M. (2008). Electrochemical selective determi**nation of ascorbic acid at redox active polymer modified electrode derived from direct blue 71**. *Biosensors and Bioelectronics, 24*(4), **518**–**523**. [https://doi.org/10.1016/j.](https://doi.org/10.1016/j.bios.2008.05.007)  [bios.2008.05.007](https://doi.org/10.1016/j.bios.2008.05.007)
- Lima, D. R. S., Cossenza, M., Garcia, C. G., Portugal, C. C., Marques, F. F.d. C., Paes-de-Carvalho, R., & Pereira Netto, A. D. (2016). Determination of ascorbic acid in the retina during chicken embryo development using high performance liquid chromatography and UV detection. *Analytical Methods, 8*(27), 5441–5447. [https://](https://doi.org/10.1039/c6ay01249c) [doi.org/10.1039/c6ay01249c](https://doi.org/10.1039/c6ay01249c)
- Liu, X., Huang, L., Wang, Y., Sun, J., Yue, T., Zhang, W., & Wang, J. (2020). One-pot bottom-up fabrication of a 2D/2D heterojuncted nanozyme towards optimized peroxidase-like activity for sulfide ions sensing. *Sensors and Actuators B: Chemical, 306*, 127565. <https://doi.org/10.1016/j.snb.2019.127565>
- Liu, J., Meng, L., Fei, Z., Dyson, P. J., Jing, X., & Liu, X. (2017). MnO2 nanosheets as an artificial enzyme to mimic oxidase for rapid and sensitive detection of glutathione. *Biosensors and Bioelectronics, 90*, 69–74.<https://doi.org/10.1016/j.bios.2016.11.046>

- Liu, X., Wang, Q., Zhao, H., Zhang, L., Su, Y., & Lv, Y. (2012). BSA-templated MnO2 nanoparticles as both peroxidase and oxidase mimics. *Analyst, 137*(19), 4552–4558. <https://doi.org/10.1039/c2an35700c>
- Luo, L., Huang, L., Liu, X., Zhang, W., Yao, X., Dou, L., … Wang, J. (2019). Mixed-valence Ce-BPyDC metal–organic framework with dual enzyme-like activities for colorimetric biosensing. *Inorganic Chemistry, 58*(17), 11382–11388. [https://doi.org/](https://doi.org/10.1021/acs.inorgchem.9b00661) [10.1021/acs.inorgchem.9b00661](https://doi.org/10.1021/acs.inorgchem.9b00661)
- Mou, F., Guan, J., Xiao, Z., Sun, Z., Shi, W., & Fan, X.-a. (2011). Solvent-mediated synthesis of magnetic Fe2O3 chestnut-like amorphous-core/γ-phase-shell hierarchical nanostructures with strong As(v) removal capability. [10.1039/ C0JM03726E]. *Journal of Materials Chemistry, 21*(14), 5414–5421. [https://doi.org/](https://doi.org/10.1039/C0JM03726E)  [10.1039/C0JM03726E](https://doi.org/10.1039/C0JM03726E)
- Nishiyama, I., Yamashita, Y., Yamanaka, M., Shimohashi, A., Fukuda, T., & Oota, T. (2004). Varietal difference in vitamin C content in the fruit of Kiwifruit and other actinidia species. *Journal of Agricultural and Food Chemistry, 52*(17), 5472–5475. <https://doi.org/10.1021/jf049398z>
- Padayatty, S. J., Sun, H., Wang, Y., Riordan, H. D., Hewitt, S. M., Katz, A., … Levine, M. (2004). Vitamin C pharmacokinetics: Implications for oral and intravenous use. *Annals of Internal Medicine, 140*(7), 533–537. [https://doi.org/10.7326/0003-4819-](https://doi.org/10.7326/0003-4819-140-7-200404060-00010)  [140-7-200404060-00010](https://doi.org/10.7326/0003-4819-140-7-200404060-00010)
- Qin, W., Su, L., Yang, C., Ma, Y., Zhang, H., & Chen, X. (2014). Colorimetric detection of sulfite in foods by a TMB–O2–Co3O4 nanoparticles detection system. *Journal of Agricultural and Food Chemistry, 62*(25), 5827–5834. [https://doi.org/10.1021/](https://doi.org/10.1021/jf500950p) [jf500950p](https://doi.org/10.1021/jf500950p)
- Shi, B., Su, Y., Zhang, L., Huang, M., Li, X., & Zhao, S. (2016). Facilely prepared Fe3O4/ nitrogen-doped graphene quantum dot hybrids as a robust nonenzymatic catalyst for visual discrimination of phenylenediamine isomers. *Nanoscale, 8*(20), 10814–10822. <https://doi.org/10.1039/c6nr02725c>
- [Steinberg, F. M., & Rucker, R. B. (2013). Vitamin C. In W. J. Lennarz, & M. D. Lane (Eds.),](http://refhub.elsevier.com/S0023-6438(21)01974-5/sref28) *[Encyclopedia of biological chemistry](http://refhub.elsevier.com/S0023-6438(21)01974-5/sref28)* (2nd ed., pp. 530–534). Waltham: Academic [Press.](http://refhub.elsevier.com/S0023-6438(21)01974-5/sref28)
- Stone, I. (1979). Homo sapiens ascorbicus, a biochemically corrected robust human mutant. *Medical Hypotheses, 5*(6), 711–721. [https://doi.org/10.1016/0306-9877(79)](https://doi.org/10.1016/0306-9877(79)90093-8) [90093-8](https://doi.org/10.1016/0306-9877(79)90093-8)
- Su, L., Qin, W., Zhang, H., Rahman, Z. U., Ren, C., Ma, S., & Chen, X. (2015). The peroxidase/catalase-like activities of MFe2O4 (M = Mg, Ni, Cu) MNPs and their application in colorimetric biosensing of glucose. *Biosensors and Bioelectronics, 63*, 384–391. <https://doi.org/10.1016/j.bios.2014.07.048>
- Szoke, A., Zsebe, Z., Turdean, G. L., & Muresan, L. M. (2019). Composite electrode material based on electrochemically reduced graphene oxide and gold nanoparticles for electrocatalytic detection of ascorbic acid. *Electrocatalysis, 10*(5), 573–583. <https://doi.org/10.1007/s12678-019-00543-4>
- Tarnuzzer, R. W., Colon, J., Patil, S., & Seal, S. (2005). Vacancy engineered ceria nanostructures for protection from radiation-induced cellular damage. *Nano Letters, 5*(12), 2573–2577. <https://doi.org/10.1021/nl052024f>
- Tong, J., Zimmerman, M. C., Li, S., Yi, X., Luxenhofer, R., Jordan, R., & Kabanov, A. V. (2011). Neuronal uptake and intracellular superoxide scavenging of a fullerene (C60)-poly(2-oxazoline)s nanoformulation. *Biomaterials, 32*(14), 3654–3665. <https://doi.org/10.1016/j.biomaterials.2011.01.068>
- Wen, D., Guo, S., Dong, S., & Wang, E. (2010). Ultrathin Pd nanowire as a highly active electrode material for sensitive and selective detection of ascorbic acid. *Biosensors and Bioelectronics, 26*(3), 1056–1061. <https://doi.org/10.1016/j.bios.2010.08.054>
- Wu, T., Ma, Z., Li, P., Liu, M., Liu, X., Li, H., … Yao, S. (2019). Colorimetric detection of ascorbic acid and alkaline phosphatase activity based on the novel oxidase mimetic of Fe–Co bimetallic alloy encapsulated porous carbon nanocages. *Talanta, 202*, 354–361. <https://doi.org/10.1016/j.talanta.2019.05.034>
- Zhang, L., Wu, H. B., Madhavi, S., Hng, H. H., & Lou, X. W. (2012). Formation of Fe2O3 microboxes with hierarchical shell structures from metal–organic frameworks and their lithium storage properties. *Journal of the American Chemical Society, 134*(42), 17388–17391. <https://doi.org/10.1021/ja307475c>
- Zheng, X., Lian, Q., Zhou, L., Jiang, Y., & Gao, J. (2020). Urchin-like trimanganese tetraoxide particles with oxidase-like activity for glutathione detection. *Colloids and Surfaces A: Physicochemical and Engineering Aspects, 606*, 125397. [https://doi.org/](https://doi.org/10.1016/j.colsurfa.2020.125397)  [10.1016/j.colsurfa.2020.125397](https://doi.org/10.1016/j.colsurfa.2020.125397)
- Zheng, X., Zhu, Q., Song, H., Zhao, X., Yi, T., Chen, H., & Chen, X. (2015). In situ synthesis of self-assembled three-dimensional graphene-magnetic palladium nanohybrids with dual-enzyme activity through one-pot strategy and its application in glucose probe. *ACS Applied Materials and Interfaces, 7*(6), 3480–3491. [https://doi.](https://doi.org/10.1021/am508540x) [org/10.1021/am508540x](https://doi.org/10.1021/am508540x)
- Zhong, L.-B., Liu, Q., Zhu, J.-Q., Yang, Y.-S., Weng, J., Wu, P., & Zheng, Y.-M. (2018). Rational design of 3D urchin-like FeMnxOy@FeOOH for water purification and energy storage. *ACS Sustainable Chemistry & Engineering, 6*(3), 2991–3001. [https://](https://doi.org/10.1021/acssuschemeng.7b02689)  [doi.org/10.1021/acssuschemeng.7b02689](https://doi.org/10.1021/acssuschemeng.7b02689)