#### **ORIGINAL ARTICLE**

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo for CrossMark. It consists of a stylized circular design with a red rectangular shape in the center, likely representing a book or document. The text "CrossMark" is displayed to the right of the circular logo. This image does not contain any scientific or chemistry-related content that requires detailed interpretation in the context of applied chemistry or science.</DESCRIPTION_FROM_IMAGE>

# **Unveiling the role of ATP in amplifcation of intrinsic peroxidase‑like activity of gold nanoparticles**

**Juhi Shah1 · Sanjay Singh1**

Received: 4 December 2017 / Accepted: 29 December 2017 © Springer-Verlag GmbH Germany, part of Springer Nature 2018

#### **Abstract**

Peroxidase enzyme-like activity of gold nanoparticles (AuNPs) is currently being investigated for the potential application in the several realms of biomedicines. However, little is explored about the peroxidase activity of AuNPs decorated with diferent surface charges. It is well-documented that the catalytic activity and the interaction with mammalian cells are signifcantly diferent among AuNPs carrying diferent surface charges. We have recently reported that ATP enhances the peroxidase-like activity of AuNPs and iron oxide nanoparticles. However, a comprehensive and systematic study to reveal the role of surface charge on nanoparticles peroxidase-like activity has not been studied. In this work, we have shown that AuNPs coated with PEG (PEG AuNPs), citrate (citrate AuNPs) or CTAB (CTAB AuNPs) exhibit varying peroxidase-like activity and the boosting efect imparted by ATP was also diferent. We found that the peroxidase-like activity of PEG AuNPs and citrate AuNPs is dependent on hydroxyl radical formation, whereas CTAB AuNPs did not show any signifcant activity under the same experimental conditions. We also studied the boosting efect of ATP on the peroxidase-like activity of PEG and citrate AuNPs. Although the use of ATP resulted in enhanced peroxidase-like activity; however, contrary to the expectation, it did not facilitate the enhanced production of hydroxyl radical. In further studies, we found that the likely mechanism of boosting efect by ATP is the stabilization of oxidized TMB after peroxidase reaction. ATP imparts stabilization to the oxidized TMB produced due to PEG AuNPs, citrate AuNPs as well as HRP.

**Keywords** Nanozymes · Biomimetic nanoparticles · Artifcial enzymes · Metal nanoparticles · Hydroxyl radicals

## **Introduction**

Currently, immense interest has been developed for constructing artifcial enzymes due to the several disadvantages associated with natural enzymes such as extreme sensitivity of catalytic activity towards environmental conditions, less operational stability (prone to digestion and degradation) and high cost of synthesis and purifcation. These limitations restrict the broad spectrum applications of natural enzymes. Therefore, to circumvent the aforementioned limitations, nanomaterials have been developed as artifcial enzymes

**Electronic supplementary material** The online version of this article [(https://doi.org/10.1007/s13205-017-1082-1](https://doi.org/10.1007/s13205-017-1082-1)) contains supplementary material, which is available to authorized users.

* Sanjay Singh sanjay.singh@ahduni.edu.in (nanozymes), exhibiting the properties and catalytic activities demonstrated by natural enzymes (Lin et al. [2014b;](#page-10-0) Manea et al. [2004a](#page-10-1); Yang et al. [2017](#page-11-0)). Nanomaterials-based artifcial enzymes ofer several advantages such as facile synthesis, tunability of catalytic efciency, high stability under stringent reaction conditions, long-term storage and easy availability (Lin et al. [2014a)](#page-10-2). Several nanomaterials have been recently discovered which possess unique enzyme mimetic activity, such as AuNPs (Comotti et al. [2004;](#page-10-3) Luo et al. [2010;](#page-10-4) Manea et al. [2004b;](#page-10-5) Pengo et al. [2005;](#page-10-6) Zheng et al. [2011](#page-11-1)), cerium oxide (Asati et al. [2009a](#page-10-7), [2011b](#page-10-8); Heckert et al. [2008](#page-10-9); Singh et al. [2011](#page-10-10)), graphene oxide (Song et al. [2010a](#page-10-11)), carbon nanotubes (Cui et al. [2011](#page-10-12); Song et al. [2010b)](#page-11-2), V2O5 nanowires (Andre et al. [2011)](#page-10-13), Co3O4 (Mu et al. [2012](#page-10-14)), CuO (Hong et al. [2013](#page-10-15)), and iron oxide (Fu et al. [2017](#page-10-16); Gao et al. [2007;](#page-10-17) Vallabani et al. [2017)](#page-11-3). These nanomaterials exhibit excellent peroxidase-like activity by catalyzing the oxidation of peroxidase substrate in the presence of H2O2. Due to the well-established surface chemistry, the enzyme-like activities of AuNPs are further explored

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<sup>1</sup> Division of Biological and Life Sciences, School of Arts and Sciences, Ahmedabad University, Central Campus, Navrangpura, Ahmedabad, Gujarat 380009, India

in several applications such as biosensing, environmental chemistry and therapeutics (Ahmed et al. [2017](#page-10-18); Deng et al. [2016](#page-10-19); Ni et al. [2014](#page-10-20); Sharma et al. [2014](#page-10-21); Zhan et al. [2014](#page-11-4); Stefan et al. [2012)](#page-11-5). Although due to high surface to volume ratio, AuNPs ofer several advantages as nanozymes, however, sufer from several limitations as well such as lower binding afnity and specifcity for the substrate, relatively low catalytic activity as compared to natural enzymes and lower stability in biologically relevant bufers of high salt concentration. Such events may compromise the catalytic efciency and efcacy of AuNP-based enzyme mimetics in the real system and impede further development and application. To circumvent these concerns, it is imperative to develop strategies which could lead to improving the nanozymatic activity of AuNPs. In this context, Lin et al. have demonstrated Au/SiO2 based hetero-nanocomposite as a robust and recyclable artifcial peroxidase enzyme performing the catalytic activity at high temperature under the infuence of ionic liquid. Although ionic liquid acts as a positive modulator of catalytic activity and enhanced the thermal stability of the product, it completely inhibited the catalytic activity of nanozymes due to high viscosity and ionic strength (Lin et al. [2013](#page-10-22)). Nonetheless, compounds exhibiting boosting efect to the catalytic activity of nanozymes as well as imparting enhanced thermal stability to the reaction product would be ideal to be explored.

Surface charge is another factor which infuences the properties of nanomaterials such as fabrication process, stability, redox property, and catalytic properties. It is wellestablished that AuNPs are stabilized by the dynamic balance between electrostatic repulsion and van der Waals attraction forces operational between the charged particles, which are controlled by the ionic strength of the suspension (Singh et al. [2007)](#page-10-23). The addition of ions causes interruption to these forces leading to the aggregation of the colloidal particles, which may decrease the peroxidase-like activity of AuNPs. Wang et al. have investigated the role of charge present on AuNPs surface in peroxidase-like activity by considering the amino-modifed (positively charged) or citratecapped nanoparticles (negatively charged) and unmodifed (no charge) AuNPs (Wang et al. [2012](#page-11-6)). It was found that unmodifed AuNPs exhibited better peroxidase-like activity than charged nanoparticles. Furthermore, Jv et al. have compared the peroxidase-like activity of positively charged (cysteamine coated) and negatively charged (citrate coated) AuNPs and reported that the former exhibited excellent activity than the latter (Jv et al. [2010)](#page-10-24).

Additionally, a report suggests that certain ions such as Ag+, Bi3+, Pb2+, Pt4+ and Hg2+ ions, induce boosting efect to the nanozyme activity of AuNPs and showed signifcant improvement in catalytic activity (Lien et al. [2013](#page-10-25)). It was argued that these ions may deposit on the surface of AuNPs and facilitate the catalytic activity through competitive and

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or branding element rather than a scientific diagram or chemical structure. It contains stylized text and graphical elements that do not convey specific scientific or chemical information relevant to the context of applied chemistry or scientific research. Therefore, I've classified this as an abstract image as per the instructions.</DESCRIPTION_FROM_IMAGE>

synergistic interaction between them and AuNPs. We have previously reported that ATP also imparts boosting efect to the peroxidase-like activity exhibited by citrate-capped (negatively charged) AuNPs as well as iron oxides (Shah et al. [2015)](#page-10-26). With our AuNPs study, we found that the boosting efect is size-dependent as ~ 30 nm size AuNPs exhibited strong peroxidase-like activity than 15, 50 and 70 nm. However, the efect of ATP on the peroxidase-like activity of positively and uncharged AuNPs is so far unexplored. Furthermore, the mechanism behind the boosting efect of ATP over artifcial peroxidase activity of diferently charged AuNPs remains to be studied.

In this study, we have used polyethylene glycol (PEG), citrate and CTAB-coated AuNPs to explore their peroxidaselike activity in presence of ATP. The reaction kinetics and enzyme kinetic parameters are also determined. We found that PEG AuNPs and citrate AuNPs show strong peroxidaselike activity than CTAB AuNPs. Furthermore, the peroxidase reaction performed in presence of ATP showed lower *K*m and higher *V*max than the reaction executed in absence of ATP. We also found that ATP stabilizes the oxidized TMB for a longer period of time, which is probably the reason behind the observed boosting efect.

## **Materials and experimental methods**

#### **Materials**

Cetyl-*N*,*N*,*N*-trimethylammonium bromide (CTAB), adenosine triphosphate disodium salt (ATP), citric acid monohydrate, trisodium citrate dehydrate, horse radish peroxidase (HRP), terephthalic acid were purchased from Hi-Media (Mumbai, India). 3,3′,5,5′-Tetramethylbenzidine (TMB), polyethylene glycol (6000) was purchased from Acros Organics (Geel, Belgium). 30% hydrogen peroxide (H2O2), sodium borohydride LR, chloroauric acid (HAuCl4·3H2O) were purchased from SD fne chemicals (Mumbai, India).

#### **Synthesis of PEG AuNPs**

For a preparation of PEG AuNPs, 100 µL of 100 mM HAuCl4 was added to 5.9 mL of Milli-Q water and heated with stirring until it starts refuxing, then it was mixed with 4 mL of PEG solution (325 mg mL−1-PEG 6000 MW.) and allowed to mix for 3 min. 300 µL of NaOH 1% was added dropwise to this solution under vigorous stirring with heating until the transparent solution turns into ruby red color (Stiufuc et al. [2013)](#page-11-7). The particle size distribution histogram was obtained by measuring the size of 200 individual nanoparticles from 15 diferent images using the software (image-J).

## **Synthesis of citrate AuNPs**

150 µL of 100 mM HAuCl4 solution was added in 14.85 mL of Milli-Q water and heated until it started refuxing. 1.0 mL of 38.8 mM trisodium citrate was added dropwise with vigorous stirring, and solution was boiled for 5 min until solution turns dark red (Shah et al. [2015)](#page-10-26).

### **Synthesis CTAB AuNPs**

5 mL of HAuCl4 (2 mM) aqueous solution was mixed with 5.0 mL (0.2 M) CTAB solution and allowed to mix at 37 °C until solution develops a dark yellow color. Then, reduction was accomplished by adding 600 µL of ice-cold NaBH4 (0.1 M) dropwise. The vials were stirred vigorously for ~ 24 h and kept occasionally opened to release any evolved hydrogen gas (Narayanan et al. [2008)](#page-10-27). The suspension was in red color and allowed to age for 5 days. This seed solution was used for experiment.

#### **Characterization of AuNPs**

UV–Vis absorption spectra of AuNPs were acquired using Biotek (Synergy HT spectrophotometer) at room temperature in a quartz cuvette of 1 cm path length. Particle size was measured using transmission electron microscope (TEM) equipped with 120 kV (Jeol, JEM1400 plus) on a carbon-coated copper TEM grid. Zeta potential studies of AuNPs were carried out using dynamic light scattering (Zetasizer Nano-Zs, ZEN3600 Malvern Instruments Ltd) using a laser with wavelength of 633 nm.

## **Preparation of bufer**

Citric acid and trisodium citrate solutions were prepared in 100 mL of Milli-Q water. Into this, stock citric acid and trisodium citrate was added in a 59:41 ratio to obtain the citrate bufer solution 0.1 M which was further diluted to obtain the 0.01 M of concentration which was used in the peroxidase-like activity.

#### **Peroxidase‑like activity**

Kinetic study was performed in a total reaction volume of 500 µL with diferent concentrations of AuNPs (5–100 µg) of PEG, citrate and CTAB AuNPs and fxed concentrations of H2O2 (1 M), TMB (1 mM) and 2.0 mM ATP in citrate bufer solution (pH = 4) at 37 °C for 20 min. To investigate the efect of ATP on the peroxidase-like activity of AuNPs, the study was performed in presence and absence of ATP. Absorbance was monitored at 652 nm.

## **Efect of temperature and pH on peroxidase‑like activity**

Experiments were carried out using 55 µg PEG and citrate AuNPs, 2 mM ATP, 1 mM TMB and 1 M H2O2 in 500 µL citrate bufer. The reactions were carried out at diferent pH (2–10) and a wide range of temperature (20–70 °C) in presence and absence of ATP. For pH reactions, temperature was set as 37 °C and temperatures studies were carried out at pH 4. Change in absorbance was measured at 652 nm after 20 min of time interval.

#### **Kinetic parameter analysis**

Kinetic assays were carried out at 37 °C using 35 µg of PEG AuNPs and citrate AuNPs, 0.5 mM TMB with varying concentrations of H2O2 0.05–2 M in presence and absence of 2 mM ATP and a fxed concentration of H2O2 (1 M), citrate and PEG AuNPs 55 µg with varying concentrations of TMB 0.05–2 mM in 500 µL of citrate bufer at pH = 4. All reactions were monitored at 652 nm using kinetics mode. The kinetic parameter was calculated based on Lineweaver–Burk plot.

$$\frac{1}{\nu} = \frac{K_{\text{m}}}{V_{\text{max}}} \left( \frac{1}{[S]} + \frac{1}{K_{\text{m}}} \right)^{\nu}$$

where *v* is the initial velocity, *K*m is Michaelis constant, *V*max represents the maximal reaction velocity and [*S*] is the substrate concentration.

#### **Terephthalic acid based test of hydroxyl radicals**

Terephthalic acid readily reacts with · OH radicals to generate 2-hydroxyl terephthalic acid, a highly fuorescent product. 2.1 mL of citrate bufer (pH = 4) containing 0.5 mM aqueous solution of terephthalic acid in 50 mM NaOH was subjected to react in presence of H2O2 (1 M) with diferent concentrations of PEG and citrate AuNPs (35–100 µg) for 20 min at an ambient temperature. Citrate AuNPs samples were centrifuged at 10,000 rpm for 10 min and PEG AuNPs samples were centrifuged four times at 10,000 rpm for 10 min and prior to the fourth centrifugation, add 0.4% NaCl to complete sedimentation of the AuNPs. Supernatants were used for measurements of PL intensity with an excitation wavelength of 315 nm using Cary Eclipse Fluorescence Spectrophotometer (Agilent Technologies).

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

## **Comparison of the stability of PEG, citrate and CTAB AuNPs**

In 3.0 mL of citrate bufer (pH 4), 0.5 ng HRP and 15 µg PEG and citrate AuNPs were oxidized by 1 mM TMB using 10 mM H2O2 and incubated at 37 °C in presence and absence of ATP (2 mM) for diferent time intervals till 24 h. Peroxidase-like activity was measured by change in absorbance at 652 nm. Before recording absorbance, all samples were centrifuged at 13,000 rpm for 3 min and supernatants were used to monitor the absorbance.

## **Results and discussion**

#### **Characterization of AuNPs**

Figure [1](#page-3-0)a shows the UV–Vis spectra of PEG AuNPs, citrate AuNPs, and CTAB AuNPs deciphering clear SPR band at ~ 521, ~ 524 and ~ 523 nm, respectively, which is contributed to the excitation of transverse surface plasmon resonance (Turkevich et al. [1951)](#page-11-8). Figure [1](#page-3-0)b–g represents the TEM image (Fig. [1](#page-3-0)b, d and f) and average particle size distribution (Fig. [1c](#page-3-0), e, and g) of PEG AuNPs, citrate AuNPs, and CTAB AuNPs. As clearly evident from TEM image (Fig. [1](#page-3-0)b), PEG AuNPs are spherical in shape with high polydispersity as the particles size distribution is scattered from 4 to 16 nm with an average

<DESCRIPTION_FROM_IMAGE>The image shows a graph of normalized absorbance (in arbitrary units, a.u.) versus wavelength (in nanometers, nm) for three different types of gold nanoparticles (AuNPs): PEG AuNPs, Citrate AuNPs, and CTAB AuNPs.

The main graph spans wavelengths from 400 nm to 700 nm on the x-axis, with normalized absorbance values from 0 to 1.0 on the y-axis.

All three types of AuNPs show a similar overall spectral profile:
1. A peak in absorbance around 520-530 nm
2. Lower absorbance at shorter wavelengths (400-500 nm)
3. Decreasing absorbance at longer wavelengths (550-700 nm)

The peak absorbance for all three types occurs at approximately 525 nm, with a normalized absorbance value close to 1.0.

There are slight differences between the three types of AuNPs:
1. PEG AuNPs (black line) show the highest absorbance at wavelengths below 500 nm.
2. Citrate AuNPs (red line) show the lowest absorbance at wavelengths below 500 nm.
3. CTAB AuNPs (green line) fall between PEG and Citrate AuNPs in absorbance at wavelengths below 500 nm.

An inset graph in the lower right corner provides a magnified view of the peak region, spanning wavelengths from 500 nm to 540 nm. This inset shows more clearly that the peak positions for the three types of AuNPs are slightly different:
1. Citrate AuNPs peak at the shortest wavelength
2. CTAB AuNPs peak at an intermediate wavelength
3. PEG AuNPs peak at the longest wavelength

These spectral differences likely reflect variations in the surface chemistry and possibly the size distributions of the different AuNP preparations.</DESCRIPTION_FROM_IMAGE>

size distribution of ~ 8.1 nm (Fig. [1](#page-3-0)c). Citrate AuNPs are also spherical in shape (Fig. [1](#page-3-0)d) with relatively monodispersed distribution of particles with average particle size distribution of ~ 15.3 nm (Fig. [1](#page-3-0)e). Similarly, TEM image of CTAB AuNPs (Fig. [1](#page-3-0)f) reveals that particles are spherical in shape with an average size distribution of ~ 7.2 nm (Fig. [1](#page-3-0)g). The three types of AuNPs were synthesized to represent the positively charged (CTAB AuNPs), negatively charged (citrate AuNPs) and uncharged (PEG AuNPs) nanoparticles. Table [1](#page-3-1) represents the average zeta potential values of these AuNPs suspension. CTAB AuNPs and citrate AuNPs carry a zeta potential value of + 50.87 ± 5.41 and − 23.45 ± 4.06 mV, respectively. However, PEG AuNPs suspension showed − 5.86 ± 0.97 mV zeta potential, suggesting that the particles have nearly zero charge. It is expected that PEG AuNPs are stabilized by the steric repulsion between the PEG chains, which is dependent on the PEG chain length (Stiufuc et al. [2013)](#page-11-7).

<span id="page-3-1"></span>**Table 1** Zeta potential values of aqueous suspended PEG AuNPs, citrate AuNPs and CTAB AuNPs

|               | Zeta potential (mV) |
|---------------|---------------------|
| PEG AuNPs     | − 5.86 ± 0.97       |
| Citrate AuNPs | − 23.45 ± 4.06      |
| CTAB AuNPs    | + 50.87 ± 5.41      |

<DESCRIPTION_FROM_IMAGE>The image presents a series of transmission electron microscopy (TEM) images and corresponding size distribution histograms for nanoparticles. The image is divided into three rows, each containing a TEM image and its associated size distribution graph.

Row 1:
(b) TEM image showing small nanoparticles dispersed in a V-shaped pattern. The scale bar indicates 50 nm.
(c) Size distribution histogram for the particles in (b). The x-axis shows particle size (d.nm) from 4 to 18 nm, and the y-axis shows the number of particles from 0 to 60. The distribution is approximately normal, with a peak around 8-10 nm. The mean particle size is indicated as 8.1 nm.

Row 2:
(d) TEM image displaying larger, more uniformly sized nanoparticles distributed across the field of view. The scale bar indicates 50 nm.
(e) Size distribution histogram for the particles in (d). The x-axis shows particle size (d.nm) from 10 to 35 nm, and the y-axis shows the number of particles from 0 to 70. The distribution is slightly right-skewed, with a peak around 15-20 nm. The mean particle size is indicated as 15.3 nm.

Row 3:
(f) TEM image showing a mixture of smaller and larger nanoparticles, with a higher concentration of particles compared to (b) and (d). The scale bar indicates 50 nm.
(g) Size distribution histogram for the particles in (f). The x-axis shows particle size (d.nm) from 4 to 14 nm, and the y-axis shows the number of particles from 0 to 40. The distribution is approximately normal, with a peak around 6-8 nm. The mean particle size is indicated as 7.2 nm.

These images and histograms provide information about the size distribution and morphology of different nanoparticle samples, likely synthesized under varying conditions or using different methods. The analysis allows for comparison of particle size, uniformity, and distribution across the three samples.</DESCRIPTION_FROM_IMAGE>

<span id="page-3-0"></span>**Fig. 1** Characterization of AuNPs: **a** Normalized UV–Visible absorption spectra of PEG AuNPs (black curve), citrate AuNPs (red curve) and CTAB AuNPs (green curve). Inset shows zoom image of absorbance spectrum. The representative transmission electron micrograph

1 3

of PEG AuNPs (**b**), Citrate AuNPs (**d**) and CTAB AuNPs (**f**) are obtained from the respective suspension. Mean particle size distribution of PEG AuNPs (**c**), Citrate AuNPs (**e**) and CTAB AuNPs (**g**) were calculated from ~ 200 particles

## **Artifcial peroxidase activity of AuNPs is surface charge dependent**

It has been reported that the catalytic activity of nanomaterials is predominantly controlled by superficial charge present on the nanoparticle surface (Campbell et al. [2014;](#page-10-28) Pirmohamed et al. [2010](#page-10-29)). However, studies on the effect of superficial charge on the peroxidase-like activity are unexplored, which motivated us to study the effect of different charges on the peroxidase-like activity of PEG AuNPs, citrate AuNPs and CTAB AuNPs, representing neutral, negatively and positively charged AuNPs, respectively. To demonstrate the peroxidase-like activity of AuNPs, the catalytic oxidation of peroxidase substrate (TMB) in presence of H2O2 was tested. Figure [2](#page-4-0) clearly reveals that the colorless TMB (reduced) solution is converted into blue colored TMB (oxidized) when incubated with H2O2 in presence of AuNPs. Different concentrations (5, 15, 25, 35, 45, 55, 65, 75 and 100 µg) of PEG AuNPs (Fig. [2a](#page-4-0)), and citrate AuNPs (Fig. [2b](#page-4-0)) showed a concentration-dependent increase in absorbance at 652 nm, which is the characteristic absorbance–wavelength of oxidized TMB. The concomitant intensity of the blue color solution of oxidized TMB can be seen in the respective photographs of reaction tubes (Fig. [2](#page-4-0)a, b, insets). Interestingly, CTAB AuNPs did not exhibit any absorbance at 652 nm suggesting that positively charged AuNPs are not peroxidase active. The color of the solution in reaction tubes (Fig. [2](#page-4-0)c, inset) remains colorless, which further confirms our observation. Additionally, we also followed the peroxidase reaction kinetics for 20 min (Fig. [2](#page-4-0)d–f). PEG AuNPs and citrate AuNPs showed time and concentration-dependent increase in the absorbance at 652 nm. As expected, CTAB AuNPs did not show any

<DESCRIPTION_FROM_IMAGE>This image contains multiple graphs and data representations related to chemical analysis, specifically focusing on absorbance measurements across different wavelengths and over time. The image is divided into six main parts, labeled (a) through (f), each showing different aspects of the experiment.

Top row: Three sets of test tubes showing color gradients, corresponding to different concentrations of substances.

Graphs (a), (b), and (c):
These graphs show absorbance spectra across wavelengths from 400 to 800 nm. Each line represents a different concentration or condition:

(a) Wavelength range: 500-800 nm
Peak absorbance: ~2.1 a.u. at ~650 nm
Highest absorbance: 100 μg sample

(b) Wavelength range: 500-800 nm
Peak absorbance: ~0.75 a.u. at ~650 nm
Highest absorbance: 75 μg sample

(c) Wavelength range: 400-800 nm
No clear peak, generally decreasing absorbance with increasing wavelength
Highest absorbance: 65 μg and 75 μg samples at lower wavelengths

Graphs (d), (e), and (f):
These graphs show normalized absorbance at 652 nm over time (0-20 minutes):

(d) Increasing absorbance over time for all samples
Highest normalized absorbance: ~0.8 for 100 μg sample at 20 minutes

(e) Similar trend to (d), but with lower overall absorbance
Highest normalized absorbance: ~0.55 for 100 μg sample at 20 minutes

(f) More complex behavior
Some samples show increasing absorbance, others decreasing
Range: -0.04 to 0.04 normalized absorbance

Legend:
Various concentrations are tested: Control, PEG, CTAB, and concentrations from 5 μg to 100 μg.

This experiment appears to be studying the absorbance properties of different concentrations of a substance (possibly nanoparticles) over time and across different wavelengths, potentially to analyze their optical properties or aggregation behavior.</DESCRIPTION_FROM_IMAGE>

<span id="page-4-0"></span>**Fig. 2** Evolution of oxidized TMB followed by recording the absorbance at 652 nm in presence of diferent concentrations of PEG AuNPs (**a**), Citrate AuNPs (**b**) and CTAB AuNPs (**c**). Images of tubes represent the production of color intensity of TMB in presence of H2O2, ATP, and diferent concentrations of AuNPs. **a** (inset), tubes 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 and 11 represent control (no AuNPs), PEG only, 5, 15, 25, 35, 45, 55, 65, 75 and 100 µg of PEG AuNPs, respectively. **b** (inset), tubes 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 represent control (no AuNPs), 5, 15, 25, 35, 45, 55, 65, 75 and 100 µg of Citrate AuNPs, respec-

tively. **c** (inset), tubes 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 represent control (no AuNPs), CTAB only, 5, 15, 25, 35, 45, 55, 65, 75 and 100 µg of CTAB AuNPs, respectively. Time-dependent change in absorbance of oxidized TMB at 652 nm in presence of diferent concentrations of PEG AuNPs (**d**), Citrate AuNPs (**e**) and CTAB AuNPs (**f**). All reactions were carried out in 500 µl 10 mM citrate bufer in presence of 1 M H2O2 and 1 mM TMB. Error bars represents the standard deviation (SD) calculated from one of the best representing experiment performed in triplicate

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or branding element rather than a scientific diagram or chemical structure. It contains stylized text and graphic elements that do not convey specific scientific or chemistry-related information. Therefore, in accordance with the instructions, I am responding with ABSTRACT_IMAGE.</DESCRIPTION_FROM_IMAGE>

significant increase in absorbance at 652 nm (Fig. [2](#page-4-0)f). The control experiments were also conducted where the solution containing only TMB and H2O2 neither showed any development of blue color nor increase in absorbance at 652 nm, suggesting that the oxidation of TMB requires AuNPs. The intensity of the blue color of the solution was much deeper for PEG AuNPs than the other two systems with the same concentration of citrate AuNPs and CTAB AuNPs, suggesting that PEG AuNPs shows the best peroxidase activity.

## **ATP enhances the artifcial peroxidase activity of PEG AuNPs and citrate AuNPs**

As described earlier by Singh and co-workers that ATP enhances the peroxidase-like activity of citrate AuNPs and Fe3O4 NPs (Shah et al. [2015](#page-10-26); Vallabani et al. [2017](#page-11-3)), therefore, we asked the question that how ATP infuences the catalytic activity of AuNPs with varying surface charges (Fig. [3)](#page-5-0). As expected, citrate AuNPs exhibited ~ 1.5 fold increase in peroxidase-like activity in presence of ATP when compared with the reaction performed without ATP (Fig. [3b](#page-5-0) and ESM 1b). Interestingly, PEG AuNPs exhibited ~ 3.0

<DESCRIPTION_FROM_IMAGE>This image presents a comprehensive study of the absorbance characteristics of different chemical solutions under various conditions. The image is divided into six panels (a-f), each showing different aspects of the experiment.

Top row: Three sets of microcentrifuge tubes showing color changes in solutions.

Panels a, b, c: UV-Vis absorption spectra
- X-axis: Wavelength (nm) from 500 to 800 nm
- Y-axis: Absorbance (a.u.)
- Each graph shows multiple curves representing different experimental conditions

Panel (a):
- Highest absorbance: 55 μg + ATP (black line), peak around 650 nm
- Lowest absorbance: Control, PEG, PEG + ATP (near zero)
- Intermediate absorbance: 35 μg, 35 μg + ATP, 55 μg

Panel (b):
- Highest absorbance: 35 μg + ATP (pink line), peak around 650 nm
- Lowest absorbance: Control, ATP (near zero)
- Intermediate absorbance: 35 μg, 55 μg, 55 μg + ATP

Panel (c):
- Overall lower absorbance compared to (a) and (b)
- Highest absorbance: 35 μg + ATP and 55 μg (around 0.18-0.20 a.u.)
- Lowest absorbance: Control (black line)
- Other conditions show similar intermediate absorbance

Panels d, e, f: Time-dependent normalized absorbance at 652 nm
- X-axis: Time (min) from 0 to 20 minutes
- Y-axis: Normalized Absorbance (652 nm)

Panel (d):
- Highest increase: 55 μg + ATP
- Lowest increase: Control, PEG, ATP, PEG + ATP (near zero)
- Intermediate increase: 35 μg, 35 μg + ATP, 55 μg

Panel (e):
- Highest increase: 55 μg + ATP
- Lowest increase: Control, ATP (near zero)
- Intermediate increase: 35 μg, 35 μg + ATP, 55 μg

Panel (f):
- More complex behavior compared to (d) and (e)
- Some conditions show negative absorbance values
- Highest increase: 35 μg + ATP, 55 μg + ATP
- Lowest values: CTAB, CTAB + ATP (negative absorbance)
- Other conditions show intermediate behavior

The image demonstrates the effects of different concentrations (35 μg and 55 μg), the presence of ATP, and various additives (PEG, CTAB) on the absorbance characteristics of the solutions over time and across different wavelengths.</DESCRIPTION_FROM_IMAGE>

<span id="page-5-0"></span>**Fig. 3** Evolution of oxidized TMB followed by recording the absorbance at 652 nm in presence of ATP (2 mM) and diferent concentrations of PEG AuNPs (**a**), Citrate AuNPs (**b**) and CTAB AuNPs (**c**). Images of tubes represent the production of color intensity of TMB in presence of H2O2, ATP, and diferent concentration (35 and 55 µg) of AuNPs. **a** (inset), tubes 1, 2, 3, 4, 5, 6, 7 and 8 represents the color of reaction mixture containing TMB + H2O2, TMB + H2O2 + ATP, PEG + TMB + H2O2, PEG + TMB + H2O2 + ATP, PEG AuNPs (35 µg) + TMB + H2O2, PEG AuNPs (35 µg) + TMB + H2O2 + ATP (2 mM), PEG AuNPs (55 µg) + TMB + H2O2, and PEG AuNPs (55 µg) + TMB + H2O2 + ATP (2 mM), respectively. **b** (inset), tubes 1, 2, 3, 4, 5, and, represents the color of reaction mixture containing TMB + H2O2, TMB + H2O2 + ATP, Citrate AuNPs (35 µg) + TMB + H2O2, Citrate AuNPs (35 µg) + TMB + H2O2 + ATP, Cit-

1 3

rate AuNPs (55 µg) + TMB + H2O2, Citrate AuNPs (55 µg) + TMB + H2O2 + ATP (2 mM), respectively. **c** (inset), tubes 1, 2, 3, 4, 5, 6, 7 and 8 represents the color of reaction mixture containing TMB + H2O2, TMB + H2O2 + ATP, CTAB + TMB + H2O2, CTAB + TMB + H2O2 + ATP, CTAB AuNPs (35 µg) + TMB + H2O2, CTAB AuNPs (35 µg) + TMB + H2O2 + ATP (2 mM), CTAB AuNPs (55 µg) + TMB + H2O2, and CTAB AuNPs (55 µg) + TMB + H2O2 + ATP (2 mM), respectively. Time-dependent change in absorbance of oxidized TMB at 652 nm in presence of diferent concentrations of PEG AuNPs (**d**), Citrate AuNPs (**e**) and CTAB AuNPs (**f**). All reactions were carried out in 500 µL 10 mM citrate bufer in presence of 1 M H2O2 and 1 mM TMB. Error bars represents the standard deviation (SD) calculated from one of the best representing experiment performed in triplicate

fold increase in peroxidase-like activity when performed in presence of ATP (Fig. [3a](#page-5-0) and ESM 1a) suggesting that ATP synergizes better with uncharged AuNPs than charged (positively and negatively) particles. We performed this study with two concentrations of PEG AuNPs (35 and 55 µg), however, the maximum enhancement in peroxidaselike activity was observed with 35 µg concentration, other higher or lower concentrations did not produce much higher activity. The color of resultant oxidized TMB solution is shown in respective insets from Fig. [3a](#page-5-0), b, which clearly show that in presence of ATP, deep blue color solution was obtained. Additionally, the peroxidase reaction kinetics was also performed, which further supported that in presence of ATP, PEG AuNPs (Fig. [3d](#page-5-0)) and citrate AuNPs (Fig. [3e](#page-5-0)) catalyze the peroxidase reaction much faster than without ATP. CTAB AuNPs were also examined for any peroxidase-like activity in presence of ATP. However, we did not observe any enhancement in peroxidase-like activity (Fig. [3c](#page-5-0)). The color of TMB also remains colorless even after long time incubation with CTAB AuNPs with ATP (Fig. [3c](#page-5-0), inset). The pH and temperature-dependent peroxidase activity of PEG AuNPs and citrate AuNPs (ESM 3 and ESM 4) further revealed that inclusion of ATP improves the enzyme-like activity of nanoparticles for a broad range of pH (2–10) and temperature (20–70 °C). The optimum pH and temperature remains similar to the peroxidase activity of AuNPs with or without ATP suggesting that inclusion of ATP does not alter the properties of AuNPs-based nanozyme but only enhances the catalytic activity at a broad range of physiological conditions.

## **Study of kinetic parameters (***K***m and** *V***max) during artifcial peroxidase activity of PEG AuNPs and citrate AuNPs**

The steady state kinetic studies of TMB oxidation by PEG AuNPs and citrate AuNPs showed a hyperbolic relationship between the substrate concentration and rate of reaction, like a typical Michaelis–Menten reaction (Figs. [4,](#page-6-0) [5)](#page-7-0). Since only PEG AuNPs and citrate AuNPs showed peroxidase-like activity, we did not study the reaction kinetic parameters for CTAB AuNPs. The kinetic parameters *K*m and *V*max were determined for substrate (TMB) and H2O2, from Lineweaver–Burk plot. In the case of PEG AuNPs, the *K*m and *V*max values for TMB was found 0.155 mM and 8.32 × 10−8 Ms−1, respectively (Fig. [4](#page-6-0)a, b). However, when oxidation of TMB performed in presence of ATP, the *K*m and *V*max values for TMB was found 0.197 mM and 14.7 × 10−8 Ms−1, respectively (Fig. [4c](#page-6-0), d). These results suggest that although the afnity of the substrate with catalyst does not improve, due to increase in *K*m value, but the overall velocity of the reaction is enhanced when peroxidase-like activity was performed in presence of ATP. We also studied the *K*m and *V*max values for H2O2 was during the peroxidase reaction performed with PEG AuNPs. The *K*m and *V*max values for H2O2 were found to be 191 mM and 6.38 × 10−8 Ms−1, respectively (Fig. [4e](#page-6-0), f), whereas when reaction was performed in presence of ATP, the *K*m and *V*max values were 175 mM and 8.76 × 10−8 Ms−1 (Fig. [4](#page-6-0)g, h). These kinetic parameter values suggest that H2O2 also facilitates the enhancement of peroxidase-like activity of PEG AuNPs.

<DESCRIPTION_FROM_IMAGE>The image contains eight graphs labeled (a) through (h), arranged in two rows of four graphs each. These graphs represent kinetic data for enzymatic reactions, likely involving the oxidation of TMB (3,3',5,5'-tetramethylbenzidine) by hydrogen peroxide (H2O2). Here's a detailed description of each graph:

(a) Michaelis-Menten plot for TMB:
X-axis: TMB Concentration (mM), range 0-2 mM
Y-axis: V (10^-6 mM s^-1), range 0-100
The plot shows a typical hyperbolic curve characteristic of Michaelis-Menten kinetics, with velocity increasing rapidly at low substrate concentrations and approaching a plateau at higher concentrations.

(b) Lineweaver-Burk plot for TMB:
X-axis: 1/TMB Concentration (mM^-1), range -10 to 20
Y-axis: 1/V (10^6 s mM^-1), range 0-6
This is a linear transformation of the Michaelis-Menten equation, showing a straight line with a positive slope and y-intercept.

(c) Michaelis-Menten plot for TMB (higher velocity range):
X-axis: TMB Concentration (mM), range 0-2 mM
Y-axis: V (10^-6 mM s^-1), range 0-150
Similar to graph (a) but with a higher velocity range, showing the same hyperbolic relationship.

(d) Lineweaver-Burk plot for TMB (corresponding to graph c):
X-axis: 1/TMB Concentration (mM^-1), range -10 to 20
Y-axis: 1/V (10^6 s mM^-1), range 0-4
Linear plot corresponding to graph (c), with a positive slope and y-intercept.

(e) Michaelis-Menten plot for H2O2:
X-axis: H2O2 Concentration (mM), range 0-2000 mM
Y-axis: V (10^-6 mM s^-1), range 0-80
Hyperbolic curve showing the relationship between H2O2 concentration and reaction velocity.

(f) Lineweaver-Burk plot for H2O2:
X-axis: 1/H2O2 Concentration (mM^-1), range -0.008 to 0.012
Y-axis: 1/V (10^6 s mM^-1), range 0-4.5
Linear transformation of graph (e), showing a straight line with positive slope and y-intercept.

(g) Michaelis-Menten plot for H2O2 (different enzyme concentration or conditions):
X-axis: H2O2 Concentration (mM), range 0-2000 mM
Y-axis: V (10^-6 mM s^-1), range 0-100
Similar to graph (e) but with slightly different kinetic parameters.

(h) Lineweaver-Burk plot for H2O2 (corresponding to graph g):
X-axis: 1/H2O2 Concentration (mM^-1), range -0.012 to 0.016
Y-axis: 1/V (10^6 s mM^-1), range 0-2.8
Linear transformation of graph (g), showing a straight line with positive slope and y-intercept.

These graphs collectively provide information about the kinetic parameters (Km and Vmax) for the enzyme's interaction with both TMB and H2O2 substrates under different conditions or enzyme concentrations.</DESCRIPTION_FROM_IMAGE>

<span id="page-6-0"></span>**Fig. 4** Efect of ATP on the kinetic parameters (*K*m and *V*max) of PEG AuNPs: The Michaelis–Menten curves for the peroxidase-like activity of PEG AuNPs at fxed concentration of H2O2 (**a**, **c**) and TMB (**e**, **g**) in absence (**a**, **e**) and presence (**c**, **g**) of ATP were drawn. For varying concentrations of TMB, the concentrations of H2O2 was fxed 1 M and a concentration of TMB was varied from 0.05 to 2 mM (**a**–

**d**) and for varying H2O2, the concentration of TMB was fxed 0.5 mM and a concentration of H2O2 was varied from 0.05 to 2 M (**e**–**h**). The double reciprocal plots of TMB (**b**, **d**) and H2O2 (**f**, **h**) was made from the respective Michaelis–Menten Curve in absence (**b**, **f**) and presence (**d**, **h**) of ATP

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or branding element rather than a scientific diagram or chemical structure. It contains stylized text and graphical elements that do not convey specific scientific or chemical information relevant to the context of applied chemistry or scientific research. Therefore, I have classified this as an abstract image as per the instructions.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image contains eight graphs labeled (a) through (h), showing various relationships between reaction velocity (V) and substrate concentrations for enzymatic reactions. Here's a detailed description of each graph:

(a) Shows the relationship between reaction velocity (V) in 10^-6 mM s^-1 and TMB (3,3',5,5'-Tetramethylbenzidine) concentration in mM. The graph displays a typical Michaelis-Menten kinetics curve, with V increasing rapidly at low TMB concentrations and then leveling off at higher concentrations, approaching a maximum velocity.

(b) Presents a Lineweaver-Burk plot (double reciprocal plot) of 1/V vs 1/[TMB]. This linear transformation of the Michaelis-Menten equation shows a straight line, allowing for easier determination of kinetic parameters.

(c) Similar to (a), shows the relationship between V (10^-6 mM s^-1) and TMB concentration (mM), but with a different scale and potentially different enzyme or conditions.

(d) Another Lineweaver-Burk plot for TMB, similar to (b) but with different scales and potentially different conditions.

(e) Displays the relationship between V (10^-6 mM s^-1) and H2O2 concentration (mM). The curve shape is similar to a Michaelis-Menten plot but doesn't appear to reach saturation within the concentration range shown.

(f) A Lineweaver-Burk plot for H2O2, showing 1/V vs 1/[H2O2]. The linear relationship allows for determination of kinetic parameters for the H2O2-dependent reaction.

(g) Similar to (e), shows V vs H2O2 concentration, but with different scales and potentially different conditions.

(h) Another Lineweaver-Burk plot for H2O2, but with a much smaller range of 1/[H2O2] values compared to (f).

These graphs collectively provide information about the kinetics of enzymatic reactions involving TMB and H2O2 as substrates. The Michaelis-Menten plots (a, c, e, g) give direct visualization of the reaction velocity dependence on substrate concentration, while the Lineweaver-Burk plots (b, d, f, h) allow for easier determination of kinetic parameters such as Km (Michaelis constant) and Vmax (maximum velocity).</DESCRIPTION_FROM_IMAGE>

<span id="page-7-0"></span>**Fig. 5** Efect of ATP on the kinetic parameters (*K*m and *V*max) of citrate AuNPs: The Michaelis–Menten curves for the peroxidase-like activity of citrate AuNPs at fxed concentration of H2O2 (**a**, **c**) and TMB (**e**, **g**) in absence (**a**, **e**) and presence (**c**, **g**) of ATP were drawn. For varying concentrations of TMB, the concentrations of H2O2 was fxed 1 M and a concentration of TMB was varied from 0.05 to 2 mM

(**e**–**h**). The double reciprocal plots of TMB (**b**, **d**) and H2O2 (**f**, **h**) was made from the respective Michaelis–Menten Curve in absence (**b**, **f**) and presence (**d**, **h**) of ATP

(**a**–**d**) and for varying H2O2, the concentration of TMB was fxed 0.5 mM and a concentration of H2O2 was varied from 0.05 to 2 M

Furthermore, when studying the kinetic parameters for citrate AuNPs, the *K*m and *V*max values for TMB was found to be 0.134 mM and 9.65 × 10−8 Ms−1, respectively (Fig. [5a](#page-7-0), b), whereas, when oxidation of TMB was performed in presence of ATP, the *K*m and *V*max values for TMB was found to be 0.168 mM and 13.1 × 10−8 Ms−1, respectively (Fig. [5c](#page-7-0), d). These results clearly suggest that ATP enhances the velocity of peroxidase activity exhibited by citrate AuNPs. Furthermore, it must also be noted that the increase in reaction velocity (due to ATP) is more in PEG AuNPs than citrate AuNPs, which is in accordance with the data shown in Figs. [2,](#page-4-0) [3.](#page-5-0) The *K*m and *V*max values for H2O2 were found to be 213 mM and 10.6 × 10−8 Ms−1, respectively (Fig. [5e](#page-7-0), f), whereas when the reaction was performed in presence of ATP, the *K*m and *V*max values were 196 mM and 9.83 × 10−8 Ms−1 (Fig. [5](#page-7-0)g, h). Unlike PEG AuNPs, citrate AuNPs did not infuence the kinetic parameters of H2O2 a lot suggesting that the peroxidase-like activity of citrate AuNPs is not signifcantly dependent on H2O2, therefore, the *K*m and *V*max values are not improved when the reaction was performed in presence of ATP.

The kinetic parameters (*K*m and *V*max) of TMB and H2O2 for PEG AuNPs and citrate AuNPs were compared with literature reported values for HRP (Table [2)](#page-7-1). The comparison data clearly shows that the *K*m value of HRP for TMB is higher than PEG AuNPs and citrate AuNPs, suggest that AuNPs (with or without ATP) have better substrate afnity than HRP, which leads to the strong peroxidase-like activity. Furthermore, the velocity of the reaction was found more when PEG AuNPs and citrate AuNPs are used in peroxidase reaction with ATP than HRP (based on *V*max values). Similarly, the *V*max value of HRP for H2O2 is lesser than PEG AuNPs and citrate AuNPs (with ATP) suggesting that peroxidase reaction is faster when AuNPs are used.

<span id="page-7-1"></span>

| Table 2 Comparison of kinetic |
|-------------------------------|
| parameters (Km and Vmax) of   |
| PEG AuNPs, citrate AuNPs and  |
| HRP in absence and presence   |
| of ATP, where Km is the       |
| Michaelis–Menten constant and |
| Vmax is the maximum reaction  |
| velocity                      |

<DESCRIPTION_FROM_IMAGE>This image presents a table comparing the catalytic properties of different gold nanoparticle (AuNP) systems and horseradish peroxidase (HRP) for the oxidation of 3,3',5,5'-tetramethylbenzidine (TMB) and hydrogen peroxide (H2O2). The table has five columns: Catalyst, Substrate, Km (mM), Vmax (M S^-1), and References.

The catalysts listed are:
1. PEG AuNPs (polyethylene glycol-coated gold nanoparticles)
2. PEG AuNPs + ATP (adenosine triphosphate)
3. Citrate AuNPs
4. Citrate AuNPs + ATP
5. HRP (horseradish peroxidase)

For each catalyst, the table provides Km and Vmax values for both TMB and H2O2 substrates, except for HRP where only one set of values is given.

Key observations:
1. Km values for TMB are generally much lower (0.134-0.434 mM) compared to H2O2 (3.7-213 mM), indicating higher affinity of the catalysts for TMB.
2. The addition of ATP to both PEG and Citrate AuNPs slightly increases Km for TMB but decreases it for H2O2.
3. Vmax values are in the range of 10^-8 M S^-1 for all catalysts and substrates.
4. HRP shows the highest Km for TMB (0.434 mM) but the lowest for H2O2 (3.7 mM) among all catalysts.
5. The Vmax values for AuNP systems are comparable to or higher than HRP, suggesting their potential as peroxidase mimics.

All data for the AuNP systems are from "This work," while the HRP data is referenced from Gao et al. (2007).

This table provides a comprehensive comparison of the kinetic parameters for different nanozyme systems, allowing for the evaluation of their catalytic efficiency in comparison to the natural enzyme HRP.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

## **Role of hydroxyl radicals in artifcial peroxidase activity of PEG AuNPs and citrate AuNPs**

It has been reported that peroxidase-like activity exhibited by nanomaterials are dependent on the formation of hydroxyl radicals due to the breakdown of H2O2. Therefore, we explored that if there is any relation between the charge of AuNPs surface and hydroxyl radical (· OH) production during the peroxidase reaction. The formation of · OH radical was determined by fuorescence method using terephthalic acid as probe molecule where ·OH radical reacts with terephthalic acid to generate 2-hydroxy terephthalic acid which is a highly fuorescent product (Dalui et al. [2015)](#page-10-30). Figure [6](#page-8-0) clearly reveals that there is PEG AuNPs and citrate AuNPs concentration-dependent increase in the ·OH radical formation during the peroxidase-like activity exhibited by nanoparticles. It is expected that AuNPs would catalyze the degradation of H2O2 into ·OH radicals that can oxidize TMB and develop a blue color solution. Although there is ~ fourfold increase in ·OH radical formation when citrate AuNPs used instead of PEG AuNPs (~ threefold), which is in accordance with the *V*max values of H2O2 for these particles (Table [2)](#page-7-1), where citrate AuNPs (10.6 × 10−8 Ms−1) show high *V*max value than PEG AuNPs (6.38 × 10 −8 Ms−1). However, when compared the peroxidase activity, PEG AuNPs show better activity than citrate AuNPs, which suggest that ·OH radicals are not the only factor that controls the peroxidase activity. We also compared the ·OH radical formation by PEG AuNPs and citrate AuNPs in presence of ATP (Fig. S2). To our surprise, a decrease in ·OH radical production was observed, which was proportional to the concentration of AuNPs used. We tested the ·OH radical production at two concentrations (55 and 100 µg) of PEG AuNPs and citrate AuNPs, which resulted in almost same trend of decrease in ·OH radical formation in both the nanoparticle types, suggesting that nanoparticle charge or capping molecule does not play any signifcant role in hydroxyl radical generation.

### **ATP imparts stability to oxidized TMB**

Since our ·OH radical formation study revealed that there are other factors which control the peroxidase-like activity of AuNPs, we explored if ATP imparts any potential stability to the oxidized TMB. In this investigation, we performed the peroxidase-like activity of PEG AuNPs, citrate AuNPs and HRP enzyme in presence or absence of ATP for 20 min at 37 °C. Next, we followed the absorbance of oxidized TMB at 652 nm from 20 min to 24 h (Fig. [7](#page-9-0)). As evident from Fig. [7](#page-9-0)a, in absence of ATP, as time progress, the absorbance intensity of oxidized TMB was signifcantly reduced in all the three test conditions. Although it was found that TMB oxidized by PEG AuNPs (Fig. [7](#page-9-0)a) and citrate AuNPs (Fig. [7](#page-9-0)b) show lesser decrease in intensity than HRP (Fig. [7](#page-9-0)c). The inset image shows the representative color of oxidized TMB (due to peroxidase reaction of PEG AuNPs, citrate AuNPs, and HRP) in presence or absence of ATP after 24 h. This observation suggests that ATP facilitates the stability to the oxidized TMB, however, TMB oxidized in absence of ATP results in the quick reduction of TMB due to which the absorbance intensity decreases. It has been reported that ATP stabilizes the colored end products of TMB and ABTS via single electron transfer reaction (Kong et al. [2010](#page-10-31); Lin et al. [2014a](#page-10-2); Shah et al. [2015](#page-10-26); Stefan et al. [2012](#page-11-5)).

Mechanistically, it has been reported that peroxidase-like activity of nanomaterials is due to the ability of nanoparticles to catalyze the reduction of H2O2 by transfer of electron by charge transfer to produce hydroxyl radicals (Shi et al. [2011)](#page-10-32). However, in the present study, this process does not seem to dominate when the peroxidase-like activity of PEG AuNPs and citrate AuNPs are performed in presence of ATP, which rather promotes the decrease in hydroxyl radical production. This clearly suggests that use of ATP in peroxidase reaction promotes the stability of oxidized TMB, than enhanced hydroxyl radical production (Stefan et al. [2012)](#page-11-5). Furthermore, reports show that ATP acts similar to the distal histidine residue of the biological peroxidase enzyme.

<span id="page-8-0"></span>**Fig. 6** Efect of AuNPs concentrations in the generation of hydroxyl radicals using terephthalic acid as a fuorescent probe: Evaluation for generation of ·OH radicals during peroxidase-like activity by photoluminescence using terephthalic acid (0.5 mM) in presence of diferent concentrations of PEG AuNPs (**a**) and Citrate AuNPs (**b**) in citrate bufer. The excitation and emission wavelengths were 315 and 425 nm, respectively

<DESCRIPTION_FROM_IMAGE>The image contains two bar graphs labeled (a) and (b), both showing the relationship between the concentration of gold nanoparticles (AuNPs) and fluorescence intensity.

Graph (a):
Title: Concentration of PEG AuNPs (μg) vs Fluorescence Intensity (%)
X-axis: Concentration of PEG AuNPs (μg)
Y-axis: Fluorescence Intensity (%)
Data points:
- Control: ~100%
- 35 μg: ~170%
- 55 μg: ~210%
- 65 μg: ~260%
- 75 μg: ~270%
- 100 μg: ~310%

Interpretation: As the concentration of PEG AuNPs increases, the fluorescence intensity generally increases. The relationship appears to be roughly linear, with a slight plateau between 65 and 75 μg.

Graph (b):
Title: Concentration of Citrate AuNPs (μg) vs Fluorescence Intensity (%)
X-axis: Concentration of Citrate AuNPs (μg)
Y-axis: Fluorescence Intensity (%)
Data points:
- Control: ~100%
- 35 μg: ~240%
- 55 μg: ~250%
- 65 μg: ~280%
- 75 μg: ~330%
- 100 μg: ~390%

Interpretation: Similar to graph (a), the fluorescence intensity increases with increasing concentration of Citrate AuNPs. However, the overall fluorescence intensities are higher for Citrate AuNPs compared to PEG AuNPs at the same concentrations. The relationship also appears more linear for Citrate AuNPs.

Overall comparison: Both PEG and Citrate AuNPs show a concentration-dependent increase in fluorescence intensity. However, Citrate AuNPs generally produce higher fluorescence intensities than PEG AuNPs at the same concentrations, suggesting that Citrate AuNPs may be more effective at enhancing fluorescence in this particular system.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image presents three bar graphs (a, b, and c) showing peroxidase activity over time under different conditions. Each graph is accompanied by a small inset image of two test tubes labeled 1 and 2.

Common features across all graphs:
- Y-axis: Peroxidase activity (%)
- X-axis: Time (Hours), with data points at 20 min, 1, 3, 6, 8, and 24 hours
- Two conditions compared: +ATP (black bars) and -ATP (gray bars)

Graph (a):
- +ATP condition: Peroxidase activity remains consistently high (around 100%) across all time points
- -ATP condition: Activity starts at about 80% at 20 min, gradually decreases to about 60% by 24 hours

Graph (b):
- +ATP condition: Similar to (a), activity remains high (around 100%) across all time points
- -ATP condition: Activity starts high (about 95%) at 20 min, decreases more rapidly than in (a), reaching about 50% by 24 hours

Graph (c):
- +ATP condition: Again, activity remains high (around 100%) across all time points
- -ATP condition: Activity starts at about 70% at 20 min, decreases more dramatically than in (a) and (b), reaching about 30% by 24 hours

Inset images:
Each graph has an inset image showing two test tubes labeled 1 and 2. In all cases, tube 1 contains a blue-green solution, while tube 2 contains a clear or very light blue solution.

Interpretation:
These graphs demonstrate the effect of ATP on peroxidase activity over time. In all cases, the presence of ATP (+ATP condition) maintains high peroxidase activity throughout the 24-hour period. Without ATP (-ATP condition), peroxidase activity decreases over time, with the rate of decrease varying between the three experiments (a, b, and c). The inset images likely represent the visual difference in peroxidase activity between the +ATP (tube 1) and -ATP (tube 2) conditions.</DESCRIPTION_FROM_IMAGE>

<span id="page-9-0"></span>**Fig. 7** ATP imparts stability to the oxidized TMB: 15 µg of PEG AuNPs (**a**), Citrate AuNPs (**b**) and 0.5 ng of HRP (**c**) was incubated for 24 h during the peroxidase reaction for at 37 °C in absence or presence of 2 mM ATP. The change in the absorbance of oxidized TMB (1 mM) by H2O2 (10 mM) was followed at 652 nm by record-

ing the absorbance at diferent time intervals. Image (inset) shows the representative color of oxidized TMB over a period of 24 h with (1) and without ATP (2). Activity in presence of ATP at each time point was set as 100%

However, it must also be noticed that the surface capping molecules also play a major role in determining the catalytic activity of AuNPs, therefore, the CTAB AuNPs did not exhibit any signifcant peroxidase-like activity.

## **Conclusion**

In summary, we report here that the peroxidase-like activity of AuNPs signifcantly depends on the surface charge and type of capping molecule on the surface of nanoparticles. Uncharged AuNPs (PEG AuNPs) exhibited the maximum peroxidase-like activity than citrate AuNPs or CTAB AuNPs. It has been reported that citrate AuNPs show better activity when positively charged peroxidase substrate such as TMB is used. Therefore, it is expected that the electrostatic attraction between negatively charged citrate AuNPs and positively charged TMB may temporarily exhibit peroxidase-like activity, however, the same extent of enhancement would not be possible with negatively charged peroxidase substrate such as ABTS (2,2′-azino-bis(3-ethylbenzothiazoline-6-sulphonic acid). In this context, PEG AuNPs will be an excellent choice to be used with both positively and negatively charged peroxidase substrate with similar activity. ATP acts as a boosting agent for PEG AuNPs and citrate AuNPs but works well with PEG AuNPs, which could be due to the imparting stability to the oxidized TMB. The reaction kinetic study (*V*max) revealed that ATP enhances the velocity of peroxidase activity exhibited by PEG AuNPs and citrate AuNPs. The results from PEG AuNPs suggest that although the afnity of the substrate with catalyst (PEG AuNPs) does not improve, (high *K*m value), the overall velocity of the reaction is enhanced when peroxidase-like

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or branding element rather than a scientific diagram or chemical structure. It contains stylized text and graphical elements that do not convey specific scientific or chemical information relevant to the context of applied chemistry or scientific research. Therefore, I've classified this as an abstract image as per the instructions.</DESCRIPTION_FROM_IMAGE>

activity was performed in the presence of ATP. However, the kinetic parameter values for H2O2 suggest that hydrogen peroxide also facilitates the enhancement of peroxidaselike activity of PEG AuNPs. Contrary to PEG AuNPs, the peroxidase-like activity of citrate AuNPs is not signifcantly dependent on H2O2, therefore, the *K*m and *V*max values are not improved when reaction was performed in presence of ATP. Hydroxyl radicals are found to play a signifcant role in the peroxidase-like activity of PEG AuNPs and citrate AuNPs, however, did not show any efect when ATP was used to boost the peroxidase activity. Interestingly, ATP was observed to impart stability to the oxidized form of TMB in the order of PEG AuNPs > citrate AuNPs > HRP, suggesting that ATP can also be used in conjunction with natural enzymes to boost their biocatalytic activity. Taken together, this study could be used to tune the peroxidase and other enzyme-like activities of nanomaterials and fnd a wide range of new applications in biosensing, theranostics, and nanomedicines.

**Acknowledgements** Juhi Shah would like to thank the Department of Science and Technology (DST), New Delhi for providing INSPIRE Junior Research Fellowship (JRF). The fnancial assistance for the Centre for Nanotechnology Research and Applications (CENTRA) by The Gujarat Institute for Chemical Technology (GICT) is acknowledged. The funding from the Department of Science and Technology-Science and Engineering Research Board (SERB) (Grant No.: ILS/ SERB/2015-16/01) to Dr Sanjay Singh under the scheme of Start-Up Research Grant (Young Scientists) in Life Sciences is also gratefully acknowledged.

#### **Compliance with ethical standards**

**Conflict of interest** The authors declare that they have no confict of interest.

#### Page 11 of 12 67

## **References**

- <span id="page-10-18"></span>Ahmed SR, Takemeura K, Li TC, Kitamoto N, Tanaka T, Suzuki T, Park EY (2017) Size-controlled preparation of peroxidase-like graphene-gold nanoparticle hybrids for the visible detection of norovirus-like particles. Biosens Bioelectron 87:558–565. [http](https://doi.org/10.1016/j.bios.2016.08.101) [s://doi.org/10.1016/j.bios.2016.08.101](https://doi.org/10.1016/j.bios.2016.08.101)
- <span id="page-10-13"></span>Andre R, Natálio F, Humanes M, Leppin J, Heinze K, Wever R, Schro¨der HC, Müller WE, Tremel W (2011) V2O5 nanowires with an intrinsic peroxidase-like activity. Adv Funct Mater 21:501–509
- <span id="page-10-7"></span>Asati A, Santra S, Kaittanis C, Nath S, Perez JM (2009) Oxidase-like activity of polymer-coated cerium oxide nanoparticles. Angew Chem Int Ed Engl 48:2308–2312
- <span id="page-10-8"></span>Asati A, Kaittanis C, Santra S, Perez JM (2011) pH-tunable oxidaselike activity of cerium oxide nanoparticles achieving sensitive fuorigenic detection of cancer biomarkers at neutral pH. Anal Chem 83(7):2547–2553. <https://doi.org/10.1021/ac102826k>
- <span id="page-10-28"></span>Campbell AS, Dong C, Meng F, Hardinger J, Perhinschi G, Wu N, Dinu CZ (2014) Enzyme catalytic efciency: a function of bionano interface reactions. ACS Appl Mater Interfaces 6(8):5393– 5403. <https://doi.org/10.1021/am500773g>
- <span id="page-10-3"></span>Comotti M, Della Pina C, Matarrese R, Rossi M (2004) The catalytic activity of "naked" gold particles. Angew Chem Int Ed Engl 43(43):5812–5815. <https://doi.org/10.1002/anie.200460446>
- <span id="page-10-12"></span>Cui R, Han Z, Zhu JJ (2011) Helical carbon nanotubes: intrinsic peroxidase catalytic activity and its application for biocatalysis and biosensing. Chemistry 17(34):9377–9384. [https://doi.](https://doi.org/10.1002/chem.201100478) [org/10.1002/chem.201100478](https://doi.org/10.1002/chem.201100478)
- <span id="page-10-30"></span>Dalui A, Pradan B, Thupakula U, Khan AH, Kumar GS, Ghosh T, Satpati B, Acharya S (2015) Insight into the mechanism revealing the peroxidase mimetic catalytic activity of quaternary CuZnFeS nanocrystals: colorimetric biosensing of hydrogen peroxide and glucose. Nanoscale 7:9062–9074. [https://doi.](https://doi.org/10.1039/c5nr01728a) [org/10.1039/c5nr01728a](https://doi.org/10.1039/c5nr01728a)
- <span id="page-10-19"></span>Deng HH, Hong GL, Lin FL, Liu AL, Xia XH, Chen W (2016) Colorimetric detection of urea, urease, and urease inhibitor based on the peroxidase-like activity of gold nanoparticles. Anal Chim Acta 915:74–80. <https://doi.org/10.1016/j.aca.2016.02.008>
- <span id="page-10-16"></span>Fu S, Wang S, Zhang X, Qi A, Liu Z, Yu X, Chen C, Li L (2017) Structural efect of Fe3O4 nanoparticles on peroxidase-like activity for cancer therapy. Colloids Surf B Biointerfaces 154:239–245. <https://doi.org/10.1016/j.colsurfb.2017.03.038>
- <span id="page-10-17"></span>Gao L, Zhuang J, Nie L, Zhang J, Zhang Y, Gu N, Wang T, Feng J, Yang D, Perrett S, Yan X (2007) Intrinsic peroxidase-like activity of ferromagnetic nanoparticles. Nat Nanotechnol 2:577–583. <https://doi.org/10.1038/nnano.2007.260>
- <span id="page-10-9"></span>Heckert EG, Karakoti AS, Seal S, Self WT (2008) The role of cerium redox state in the SOD mimetic activity of nanoceria. Biomaterials 29(18):2705–2709. [https://doi.org/10.1016/j.biomaterials](https://doi.org/10.1016/j.biomaterials.2008.03.014) [.2008.03.014](https://doi.org/10.1016/j.biomaterials.2008.03.014)
- <span id="page-10-15"></span>Hong L, Liu AL, Li GW, Chen W, Lin XH (2013) Chemiluminescent cholesterol sensor based on peroxidase-like activity of cupric oxide nanoparticles. Biosens Bioelectron 43:1–5. [https://doi.](https://doi.org/10.1016/j.bios.2012.11.031) [org/10.1016/j.bios.2012.11.031](https://doi.org/10.1016/j.bios.2012.11.031)
- <span id="page-10-24"></span>Jv Y, Li B, Cao R (2010) Positively-charged gold nanoparticles as peroxidase mimic and their application in hydrogen peroxide and glucose detection. Chem Commun 46(42):8017–8019. [http](https://doi.org/10.1039/c0cc02698k) [s://doi.org/10.1039/c0cc02698k](https://doi.org/10.1039/c0cc02698k)
- <span id="page-10-31"></span>Kong DM, Xu J, Shen HX (2010) Positive efects of ATP on G-quadruplex-hemin DNAzyme-mediated reactions. Anal Chem 82(14):6148–6153. <https://doi.org/10.1021/ac100940v>
- <span id="page-10-25"></span>Lien CW, Chen YC, Chang HT, Huang CC (2013) Logical regulation of the enzyme-like activity of gold nanoparticles by using heavy

metal ions. Nanoscale 5(17):8227–8234. [https://doi.org/10.1039](https://doi.org/10.1039/c3nr01836a) [/c3nr01836a](https://doi.org/10.1039/c3nr01836a)

- <span id="page-10-22"></span>Lin Y, Zhao A, Tao Y, Ren J, Qu X (2013) Ionic liquid as an efcient modulator on artifcial enzyme system: toward the realization of high-temperature catalytic reactions. J Am Chem Soc 135(11):4207–4210. <https://doi.org/10.1021/ja400280f>
- <span id="page-10-2"></span>Lin Y, Huang Y, Ren J, Qu X (2014a) Incorporating ATP into biomimetic catalysts for realizing exceptional enzymatic performance over a broad temperature range. NPG Asia Mater 6:e114
- <span id="page-10-0"></span>Lin Y, Ren J, Qu X (2014b) Catalytically active nanomaterials: a promising candidate for artifcial enzymes. Acc Chem Res 47(4):1097–1105. <https://doi.org/10.1021/ar400250z>
- <span id="page-10-4"></span>Luo W, Zhu C, Su S, Li D, He Y, Huang Q, Fan C (2010) Selfcatalyzed, self-limiting growth of glucose oxidase-mimicking gold nanoparticles. ACS Nano 4(12):7451–7458. [https://doi.](https://doi.org/10.1021/nn102592h) [org/10.1021/nn102592h](https://doi.org/10.1021/nn102592h)
- <span id="page-10-1"></span>Manea F, Houillon FB, Pasquato L, Scrimin P (2004a) Nanozymes: gold-nanoparticle-based transphosphorylation catalysts. Angew Chem Int Ed Engl 43(45):6165–6169. [https://doi.org/10.1002](https://doi.org/10.1002/anie.200460649) [/anie.200460649](https://doi.org/10.1002/anie.200460649)
- <span id="page-10-5"></span>Manea F, Houillon FB, Pasquato L, Scrimin P (2004b) Nanozymes: gold-nanoparticle-based transphosphorylation catalysts. Angew Chem Int Ed 43:6165–6169
- <span id="page-10-14"></span>Mu J, Wang Y, Zhao M, Zhang L (2012) Intrinsic peroxidase-like activity and catalase-like activity of Co3O4 nanoparticles. Chem Commun 48(19):2540–2542. [https://doi.org/10.1039/c2cc1701](https://doi.org/10.1039/c2cc17013b) [3b](https://doi.org/10.1039/c2cc17013b)
- <span id="page-10-27"></span>Narayanan R, Lipert RJ, Porter MD (2008) Cetyltrimethylammonium bromide-modifed spherical and cube-like gold nanoparticles as extrinsic Raman labels in surface-enhanced Raman spectroscopy based heterogeneous immunoassays. Anal Chem 80:2265–2271
- <span id="page-10-20"></span>Ni P, Dai H, Wang Y, Sun Y, Shi Y, Hu J, Li Z (2014) Visual detection of melamine based on the peroxidase-like activity enhancement of bare gold nanoparticles. Biosens Bioelectron 60:286–291. [http](https://doi.org/10.1016/j.bios.2014.04.029) [s://doi.org/10.1016/j.bios.2014.04.029](https://doi.org/10.1016/j.bios.2014.04.029)
- <span id="page-10-6"></span>Pengo P, Polizzi S, Pasquato L, Scrimin P (2005) Carboxylate-imidazole cooperativity in dipeptide-functionalized gold nanoparticles with esterase-like activity. J Am Chem Soc 127:1616–1617. [http](https://doi.org/10.1021/ja043547c) [s://doi.org/10.1021/ja043547c](https://doi.org/10.1021/ja043547c)
- <span id="page-10-29"></span>Pirmohamed T, Dowding JM, Singh S, Wasserman B, Heckert E, Karakoti AS, King JE, Seal S, Self WT (2010) Nanoceria exhibit redox state-dependent catalase mimetic activity. Chem Commun 46(16):2736–2738.<https://doi.org/10.1039/b922024k>
- <span id="page-10-26"></span>Shah J, Purohit R, Singh R, Karakoti AS, Singh S (2015) ATPenhanced peroxidase-like activity of gold nanoparticles. J Colloid Interface Sci 456:100–107. [https://doi.org/10.1016/j.jcis.2015](https://doi.org/10.1016/j.jcis.2015.06.015) [.06.015](https://doi.org/10.1016/j.jcis.2015.06.015)
- <span id="page-10-21"></span>Sharma TK, Ramanathan R, Weerathunge P, Mohammadtaheri M, Daima HK, Shukla R, Bansal V (2014) Aptamer-mediated 'turnof/turn-on' nanozyme activity of gold nanoparticles for kanamycin detection. Chem Commun 50(100):15856–15859. [https://doi.](https://doi.org/10.1039/c4cc07275h) [org/10.1039/c4cc07275h](https://doi.org/10.1039/c4cc07275h)
- <span id="page-10-32"></span>Shi W, Wang Q, Long Y, Cheng Z, Chen S, Zheng H, Huang Y (2011) Carbon nanodots as peroxidase mimetics and their applications to glucose detection. Chem Commun 47(23):6695–6697. [https://doi.](https://doi.org/10.1039/c1cc11943e) [org/10.1039/c1cc11943e](https://doi.org/10.1039/c1cc11943e)
- <span id="page-10-23"></span>Singh S, Pasricha R, Bhatta UM, Satyam P, Sastry M, Prasad B (2007) Efect of halogen addition to monolayer protected gold nanoparticles. J Mater Chem 17:1614–1619
- <span id="page-10-10"></span>Singh S, Dosani T, Karakoti AS, Kumar A, Seal S, Self WT (2011) A phosphate-dependent shift in redox state of cerium oxide nanoparticles and its efects on catalytic properties. Biomaterials 32(28):6745–6753. [https://doi.org/10.1016/j.biomaterials.2011](https://doi.org/10.1016/j.biomaterials.2011.05.073) [.05.073](https://doi.org/10.1016/j.biomaterials.2011.05.073)
- <span id="page-10-11"></span>Song Y, Qu K, Zhao C, Ren J, Qu X (2010a) Graphene oxide: intrinsic peroxidase catalytic activity and its application to glucose

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

detection. Adv Mater 22(19):2206–2210. [https://doi.org/10.1002](https://doi.org/10.1002/adma.200903783) [/adma.200903783](https://doi.org/10.1002/adma.200903783)

- <span id="page-11-2"></span>Song Y, Wang X, Zhao C, Qu K, Ren J, Qu X (2010b) Label-free colorimetric detection of single nucleotide polymorphism by using single-walled carbon nanotube intrinsic peroxidase-like activity. Chemistry 16(12):3617–3621. [https://doi.org/10.1002/chem.2009](https://doi.org/10.1002/chem.200902643) [02643](https://doi.org/10.1002/chem.200902643)
- <span id="page-11-5"></span>Stefan L, Denat F, Monchaud D (2012) Insights into how nucleotide supplements enhance the peroxidase-mimicking DNAzyme activity of the G-quadruplex/hemin system. Nucleic Acids Res 40(17):8759–8772.<https://doi.org/10.1093/nar/gks581>
- <span id="page-11-7"></span>Stiufuc R, Iacovita C, Nicoara R, Stiufuc G, Florea A, Achim M, Lucaciu CM (2013) One-step synthesis of pegylated gold nanoparticles with tunable surface charge. J Nanomater 2013:1–7
- <span id="page-11-8"></span>Turkevich J, Stevenson PC, Hillier J (1951) A study of the nucleation and growth processes in the synthesis of colloidal gold Farady Soc 11:55–75
- <span id="page-11-3"></span>Vallabani NV, Karakoti AS, Singh S (2017) ATP-mediated intrinsic peroxidase-like activity of Fe3O4-based nanozyme: one step

detection of blood glucose at physiological pH. Colloids Surf B Biointerfaces 153:52–60. [https://doi.org/10.1016/j.colsurfb.2017](https://doi.org/10.1016/j.colsurfb.2017.02.004) [.02.004](https://doi.org/10.1016/j.colsurfb.2017.02.004)

- <span id="page-11-6"></span>Wang S, Chen W, Liu AL, Hong L, Deng HH, Lin XH (2012) Comparison of the peroxidase-like activity of unmodifed, amino-modifed, and citrate-capped gold nanoparticles. ChemPhysChem 13:1199– 1204.<https://doi.org/10.1002/cphc.201100906>
- <span id="page-11-0"></span>Yang H, Xiao J, Su L, Feng T, Lv Q, Zhang X (2017) Oxidase-mimicking activity of the nitrogen-doped Fe3C@C composites. Chem Commun 53(27):3882–3885.<https://doi.org/10.1039/c7cc00610a>
- <span id="page-11-4"></span>Zhan L, Li CM, Wu WB, Huang CZ (2014) A colorimetric immunoassay for respiratory syncytial virus detection based on gold nanoparticles-graphene oxide hybrids with mercury-enhanced peroxidase-like activity. Chem Commun 50(78):11526–11528. <https://doi.org/10.1039/c4cc05155f>
- <span id="page-11-1"></span>Zheng X, Liu Q, Jing C, Li Y, Li D, Luo W, Wen Y, He Y, Huang Q, Long YT, Fan C (2011) Catalytic gold nanoparticles for nanoplasmonic detection of DNA hybridization. Angew Chem Int Ed Engl 50(50):11994–11998.<https://doi.org/10.1002/anie.201105121>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>
