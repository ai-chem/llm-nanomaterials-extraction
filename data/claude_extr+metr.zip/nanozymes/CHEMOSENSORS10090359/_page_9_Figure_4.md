The image presents a graph and schematic diagrams illustrating the size distribution and structure of Pd@Pt nanoparticles (NDs) before and after conjugation with streptavidin (SA).

Graph interpretation:
The graph shows the size distribution of two types of nanoparticles: Pd@Pt ND and Pd@Pt ND-SA. The x-axis represents the size in nanometers (nm) on a logarithmic scale from 10 to 1000 nm. The y-axis shows the intensity percentage from 0 to 16%.

Two peaks are visible:
1. Pd@Pt ND (solid line): Peak at 58.27 nm
2. Pd@Pt ND-SA (dashed line): Peak at 94.89 nm

The shift in peak position indicates an increase in particle size after conjugation with streptavidin.

Schematic diagrams:
Two schematic representations are provided to the right of the graph:

1. Pd@Pt ND: Depicted as a square-shaped core (likely palladium) surrounded by a shell of smaller particles (likely platinum).

2. Pd@Pt ND-SA: Shows the same nanoparticle structure with an additional component (streptavidin) attached to one side, represented by a distinct shape.

The diagrams illustrate the structural change that occurs when streptavidin is conjugated to the Pd@Pt nanoparticle, corresponding to the size increase observed in the graph.

This image demonstrates the successful conjugation of streptavidin to Pd@Pt nanoparticles and the resulting increase in particle size, which is crucial information for applications in bioconjugation and targeted delivery systems in nanomedicine and biosensing.