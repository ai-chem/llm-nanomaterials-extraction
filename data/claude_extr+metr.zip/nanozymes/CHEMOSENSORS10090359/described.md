<DESCRIPTION_FROM_IMAGE>The image contains a logo and text that appears to be a brand or publication name for a chemistry-related entity. The logo consists of a simplified representation of a chemical structure, likely a benzene ring with an additional fused ring, alongside a stylized heartbeat or electrocardiogram line. Next to this logo is the text "chemosensors" in lowercase letters. This combination suggests the brand or publication is related to chemical sensors or monitoring devices used in chemistry or biochemistry applications. However, as this image does not contain specific scientific data, graphs, or detailed chemical structures to analyze, I will classify this as:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>This image depicts the logo of MDPI (Multidisciplinary Digital Publishing Institute), a prominent open-access academic publisher. The logo consists of the letters "MDPI" in a bold, sans-serif font. Above the letters is a simple line drawing of a house or roof shape, with two angled lines meeting at a peak. The logo is presented in a single color against a white background.

While this logo is associated with a publisher that frequently publishes scientific and chemistry-related content, the image itself does not contain any specific chemical structures, graphs, diagrams, or scientific data. Therefore, in the context of applied chemistry or scientific content, this would be classified as an:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

# *Article* **Pd@Pt Nanodendrites as Peroxidase Nanomimics for Enhanced Colorimetric ELISA of Cytokines with Femtomolar Sensitivity**

**Zhuangqiang Gao [*](https://orcid.org/0000-0001-9097-1799) , Chuanyu Wang [,](https://orcid.org/0000-0003-4544-8864) Jiacheng He and Pengyu Chen [*](https://orcid.org/0000-0003-3380-872X)**

Materials Research and Education Center, Materials Engineering, Department of Mechanical Engineering, Auburn University, Auburn, AL 36849, USA

***** Correspondence: zzg0028@auburn.edu (Z.G.); pengyuc@auburn.edu (P.C.)

**Abstract:** Colorimetric enzyme-linked immunosorbent assay (ELISA) has been widely applied as the gold-standard method for cytokine detection for decades. However, it has become a critical challenge to further improve the detection sensitivity of ELISA, as it is limited by the catalytic activity of enzymes. Herein, we report an enhanced colorimetric ELISA for ultrasensitive detection of interleukin-6 (IL-6, as a model cytokine for demonstration) using Pd@Pt core@shell nanodendrites (Pd@Pt NDs) as peroxidase nanomimics (named "Pd@Pt ND ELISA"), pushing the sensitivity up to femtomolar level. Specifically, the Pd@Pt NDs are rationally engineered by depositing Pt atoms on Pd nanocubes (NCs) to generate rough dendrite-like Pt skins on the Pd surfaces via Volmer–Weber growth mode. They can be produced on a large scale with highly uniform size, shape, composition, and structure. They exhibit significantly enhanced peroxidase-like catalytic activity with catalytic constants (Kcat) more than 2000-fold higher than those of horseradish peroxidase (HRP, an enzyme commonly used in ELISA). Using Pd@Pt NDs as the signal labels, the Pd@Pt ND ELISA presents strong colorimetric signals for the quantitative determination of IL-6 with a wide dynamic range of 0.05–100 pg mL−1 and an ultralow detection limit of 0.044 pg mL−1 (1.7 fM). This detection limit is 21-fold lower than that of conventional HRP-based ELISA. The reproducibility and specificity of the Pd@Pt ND ELISA are excellent. More significantly, the Pd@Pt ND ELISA was validated for analyzing IL-6 in human serum samples with high accuracy and reliability through recovery tests. Our results demonstrate that the colorimetric Pd@Pt ND ELISA is a promising biosensing tool for ultrasensitive determination of cytokines and thus is expected to be applied in a variety of clinical diagnoses and fundamental biomedical studies.

**Keywords:** cytokine; interleukin-6; enzyme-linked immunosorbent assay; ultrasensitive colorimetric detection; Pd@Pt core@shell nanodendrites; peroxidase nanomimics

# **1. Introduction**

Cytokines are a class of bioactive proteins with molecular weights of 6–70 kDa, secreted by immune cells (e.g., T lymphocytes, B lymphocytes, macrophages, monocytes, natural killer cells, and mast cells), epidermal cells, endothelial cells, fibroblasts, etc. [\[1](#page-12-0)[–4\]](#page-12-1). As cell signaling molecules, they participate in a diverse and broad spectrum of biological activities, such as cell-to-cell communication, modulation of immune responses, and regulation of cell maturation, growth, development, and differentiation [\[5](#page-12-2)[–8\]](#page-12-3). As disease biomarkers, they are strongly associated with the immune status of hosts in many diseases, such as infection, inflammation, trauma, lupus, sepsis, and cancer [\[4](#page-12-1)[,9–](#page-13-0)[12\]](#page-13-1). For example, interleukin-6 (IL-6) is a pleiotropic cytokine that plays an important role in host defense by modulating immune and inflammatory responses. It activates various immune-related biological effects, e.g., the induction of B lymphocyte differentiation to produce immunoglobulin, the promotion of T lymphocyte proliferation and growth, and the enhancement of blood cell differentiation, through cytokine network and cell-to-cell communication, thereby motivating the immune system for host defense [\[13–](#page-13-2)[15\]](#page-13-3). It also induces the production of C-reactive protein and

<DESCRIPTION_FROM_IMAGE>This image does not contain scientific content related to chemistry or other technical information. Instead, it appears to be a simple graphic icon or logo. The image shows a yellow checkmark or tick symbol inside a circular shape. Next to this circular element is text that says "check for updates". Given the instructions to respond with ABSTRACT_IMAGE for logos or non-scientific imagery, my response is:

ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

**Citation:** Gao, Z.; Wang, C.; He, J.; Chen, P. Pd@Pt Nanodendrites as Peroxidase Nanomimics for Enhanced Colorimetric ELISA of Cytokines with Femtomolar Sensitivity. *Chemosensors* **2022**, *10*, 359. [https://doi.org/10.3390/](https://doi.org/10.3390/chemosensors10090359) [chemosensors10090359](https://doi.org/10.3390/chemosensors10090359)

Academic Editor: Jun Wang

Received: 3 August 2022 Accepted: 5 September 2022 Published: 8 September 2022

**Publisher's Note:** MDPI stays neutral with regard to jurisdictional claims in published maps and institutional affiliations.

<DESCRIPTION_FROM_IMAGE>This image depicts a Creative Commons license icon. It consists of two circular elements side by side:

1. On the left is the standard Creative Commons "CC" logo, which is two "C" letters inside a circle.

2. On the right is an "i" information symbol inside a circle.

Below these circular elements is the text "BY" in capital letters.

This specific combination represents the Creative Commons Attribution license (CC BY). This license allows others to distribute, remix, adapt, and build upon the work, even commercially, as long as they credit the original creator.

While this image is related to licensing and attribution rather than directly depicting chemical structures or scientific data, it is commonly used in academic and scientific publications to indicate the terms under which the content is shared. Therefore, it has relevance in the context of scientific communication and publishing, including in the field of chemistry.</DESCRIPTION_FROM_IMAGE>

**Copyright:** © 2022 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license [(https://](https://creativecommons.org/licenses/by/4.0/) [creativecommons.org/licenses/by/](https://creativecommons.org/licenses/by/4.0/) 4.0/).

procalcitonin and is directly related to the inflammatory status in patients, thus serving as a key biomarker for early diagnosis of inflammatory diseases, e.g., the prediction of occurrence of sepsis and cytokine storm syndrome [\[10](#page-13-4)[,13](#page-13-2)[,16–](#page-13-5)[19\]](#page-13-6). Therefore, obtaining information about the qualitative and quantitative nature of cytokine expression and release is crucial for understanding immune-related physiological and pathological processes and facilitating early diagnosis and treatment of inflammatory diseases.

Colorimetric enzyme-linked immunosorbent assay (ELISA) has been broadly recognized as the gold-standard analytical method for cytokine detection due to its competitive advantages in simplicity, practicality, low cost, and easy operation [\[4](#page-12-1)[,11](#page-13-7)[,20,](#page-13-8)[21\]](#page-13-9). However, the major drawback of conventional colorimetric ELISA is the relatively low sensitivity, with detection limits in the range of 0.7–1437 pg/mL (i.e., 26.9–145,152 fM, see Table S2) [\[22](#page-13-10)[,23\]](#page-13-11), making it insufficient for monitoring cytokines at ultra-low levels (e.g., fM level). It should be emphasized that in many cases, the levels of expressed/released cytokines in biological samples are typically below the detection limit of conventional colorimetric ELISA, and the improvement of its sensitivity has become essential to acquiring more valuable information about the immune status with cytokines at ultra-low levels [\[3,](#page-12-4)[4](#page-12-1)[,11](#page-13-7)[,24](#page-13-12)[,25\]](#page-13-13). Because the detection signal of colorimetric ELISA mainly originates from the catalysis of enzymes (e.g., horseradish peroxidase (HRP)) toward substrates to produce colored products, the detection sensitivity is essentially restricted by the inherent catalytic efficiency of enzymes. Specifically, enzymes with higher catalytic efficiency can produce more colored products, thus generating stronger colorimetric signals for more sensitive detection. As a result, a lower concentration of cytokines can be detected. Hence, there is an urgent need to explore new catalysts with higher catalytic efficiency to further improve the sensitivity of colorimetric ELISA for ultrasensitive cytokine detection.

Recent studies on peroxidase mimics made of inorganic nanostructures (i.e., peroxidase nanomimics) have unveiled their potential in advanced bioassay systems [\[26–](#page-13-14)[29\]](#page-13-15). Through rationally controlling the size, shape, composition, and structure, the catalytic properties of peroxidase nanomimics can be precisely tailored to meet the requirements of advanced bioassays. The first peroxidase nanomimic was reported by the Yan group with the discovery of peroxidase-like catalytic activity of Fe3O4 nanoparticles in 2007 [\[30\]](#page-13-16). Since then, a variety of inorganic nanostructures have been actively reported to possess peroxidase-like catalytic properties [\[26](#page-13-14)[–29\]](#page-13-15). Notable examples include metal oxide nanomaterials (e.g., Co3O4 nanoparticles, MnO2 nanowires, and V2O5 nanowires) [\[31–](#page-13-17)[33\]](#page-13-18), metal sulfide nanomaterials (e.g., MoS2 and WS2 nanosheets) [\[34](#page-13-19)[,35\]](#page-13-20), carbon nanomaterials (graphene oxide and carbon nanotubes) [\[35](#page-13-20)[,36\]](#page-13-21), and noble metal nanomaterials (e.g., Au, Ag, Pd, Pt, Ir, and Ru nanoparticles) [\[37–](#page-13-22)[42\]](#page-14-0). Compared with natural peroxidases, these peroxidase nanomimics have some demerits, including increased toxicity, decreased accessibility, and more complicated considerations regarding waste disposal procedures, but they show interesting merits including high catalytic activity, excellent stability, facile synthesis, and easy storage, making them appealing candidates for peroxidases in bioassays [\[26](#page-13-14)[–29\]](#page-13-15). Among these nanostructures, Pt nanodendrites (NDs) have recently emerged as an innovative peroxidase nanomimic for ultrasensitive colorimetric immunoassays because of several more important advantages [\[43–](#page-14-1)[49\]](#page-14-2). First, the nanoparticles made of Pt element show a much higher peroxidase-like catalytic activity than those of other elements. Second, the rough dendrite-like surface structure offers more active sites for the catalytic reaction. Third, the nanoparticles can be easily functionalized with various functional molecules through thiol-Pt chemistry. Thus, the development of Pt ND peroxidase nanomimics as an alternative to enzyme labels has become a viable approach to greatly improve the sensitivity of colorimetric ELISA for cytokine detection. However, it has been challenging to large-scale production of Pt NDs while finely controlling the uniformity of their size and shape, which seriously hinders their widespread implementation in sensitive cytokine immunoassays.

In this work, we developed an enhanced colorimetric ELISA for ultrasensitive detection of IL-6 (as a model cytokine) by employing Pd@Pt core@shell nanodendrites (Pd@Pt NDs) as the peroxidase nanomimics (named "Pd@Pt ND ELISA", Scheme [1)](#page-2-0). The Pd@Pt

NDs were synthesized by coating Pd nanocubes (Pd NCs) with a layer of rough dendritelike Pt skins on the surfaces. Different from the previously reported dendrite-like Pt nanoparticles, the Pd@Pt NDs can be mass-produced with high uniformity in terms of both size and shape, showing highly efficient peroxidase-like activity with catalytic constants (*K*cat) up to 7–9 × 106 s −1 , 2000-fold higher than those of HRP. The immunoassay was carried out in anti-IL-6 capture-antibody (CAb)-immobilized microplate plates by coupling with biotin-conjugated anti-IL-6 detection antibody (biotin-anti-IL-6 DAb) as the recognition element and Pd@Pt ND-labeled streptavidin (Pd@Pt ND-SA) as the signal probe. In this way, a sandwich-type immunocomplex (i.e., anti-IL-6 CAb/IL-6/biotin-anti-IL-6 DAb/Pd@Pt ND-SA) was formed on the microplate plates. Upon addition of substrates (i.e., 3,3',5,5'-tetramethylbenzidine (TMB) and hydrogen peroxide (H2O2)), the labeled Pd@Pt NDs catalyzed the oxidation of TMB by H2O2 to generate an intense colorimetric signal for ultrasensitive detection of IL-6. Using conventional HRP-based ELISA as a benchmark, we demonstrate that the sensitivity of our Pd@Pt ND ELISA could be enhanced by one order of magnitude (21 times).

<DESCRIPTION_FROM_IMAGE>This image depicts a schematic representation of an immunoassay for the detection of Interleukin-6 (IL-6) using a colorimetric method with femtomolar (fM) sensitivity. The diagram illustrates the following components and processes:

1. Microtiter plate: Serves as the base for the assay.

2. Antibody sandwich complex:
   - Anti-IL-6 CAb (Capture Antibody): Attached to the microtiter plate
   - IL-6: The target analyte
   - Anti-IL-6 DAb (Detection Antibody): Binds to IL-6
   - Biotin: Attached to the detection antibody
   - Streptavidin: Binds to biotin

3. Signal amplification system:
   - Pd (Palladium) nanoparticles: Surrounded by Pt (Platinum) nanoparticles
   - TMB (3,3',5,5'-Tetramethylbenzidine) + H2O2: Substrate for the colorimetric reaction

4. Reaction process:
   - The Pd/Pt nanoparticle complex catalyzes the oxidation of TMB by H2O2
   - H2SO4 is added to stop the reaction, resulting in oxTMB (oxidized TMB)

5. Colorimetric detection:
   - A color gradient is shown, ranging from clear to deep yellow
   - The intensity of the color correlates with the IL-6 concentration
   - The scale ranges from 0 to 100 fM of IL-6

The image demonstrates how the assay achieves high sensitivity through the use of nanoparticle-based signal amplification and a sandwich immunoassay format. The colorimetric readout allows for quantification of IL-6 concentrations in the femtomolar range, which is crucial for detecting low levels of this important inflammatory cytokine.</DESCRIPTION_FROM_IMAGE>

**Scheme 1.** Schematic illustration of the enhanced colorimetric ELISA for ultrasensitive detection of IL-6 using Pd@Pt ND peroxidase nanomimics as the signal labels.

# <span id="page-2-1"></span>**2. Materials and Methods**

#### *2.1. Preparation of 18 nm Pd NCs*

Pd NCs with an edge length of 18 nm were prepared using a simple one-pot synthesis protocol with some modifications [\[50\]](#page-14-3). Initially, 4.0 mL of 52.5 mg/mL poly(vinylpyrrolidone) (PVP, *M*W ≈ 55,000) aqueous solution, 4.0 mL of 30 mg/mL L-ascorbic acid (AA) aqueous solution, and 8.0 mL of 150 mg/mL KBr aqueous solution were hosted in a 40 mL glass vial and preheated at 80 ◦C under magnetic stirring for 20 min. Then, 6.0 mL of 19 mg/mL Na2PdCl4 aqueous solution was added to the vial. The mixed solution was incubated at 80 ◦C for 3 h. After cool-down, the 18 nm Pd NCs as products were collected via centrifugation, and re-dispersed in 20 mL of DI water in a 40 mL glass vial for further use (19.4 mM of Pd atomic molarity, 48.8 nM of particle concentration).

# *2.2. Synthesis of Pd@Pt NDs*

The Pd@Pt NDs were synthesized using a facile seed-mediated growth procedure with the as-prepared 18 nm Pd NCs as the seeds. In a standard synthesis, 300 µL of the 18 nm Pd NCs suspension was added to 5.0 mL of 0.02% PVP aqueous solution in a 20 mL glass vial. Subsequently, 100 µL of 50 mM Na2PtCl6 aqueous solution and 600 µL of 100 mM AA aqueous solution were added to the vial in sequence, followed by vigorous shaking. The mixed solution was allowed to react at 80 ◦C in an oven for 3 h and then cooled down to room temperature. After being washed once with DI water via centrifugation, the Pd@Pt NDs as products were stored in 2.4 mL of DI water in a 20 mL glass vial for future use (6.10 nM in particle concentration). The molar ratio of Pt to Pd for this Pd@Pt ND sample was 0.860.

To synthesize Pd@Pt NDs with different molar ratios (*x*) of Pt to Pd (i.e., Pd@Pt*x* NDs, *x* = 0–3.44), similar procedures to those described above were used, except for adding varied volumes of 50 mM Na2PtCl6 aqueous solution in the range of 0–400 µL.

For the 60-fold scaled-up synthesis, the synthesis procedure remained the same except that the volumes of all reagents were increased 60-fold and the 20 mL glass vial was changed to a 500 mL round-bottom flask. This scaled-up synthesis could result in the production of 144 mL of 6.10 nM Pd@Pt ND aqueous suspension, which contains 37.1 mg of Pd and 58.5 mg of Pt (95.6 mg in total).

# *2.3. Apparent Steady-State Kinetic Assays*

The steady-state kinetic assays were performed according to our recent reports with minor modifications [\[51](#page-14-4)[,52\]](#page-14-5). In brief, a series of 1 mL substrate solutions with different concentrations of TMB and H2O2 were prepared in citrate-phosphate buffer (pH 4.0) in cuvettes with a path length (*l*) of 1.0 cm at room temperature. For kinetic assays toward TMB, the H2O2 concentration was fixed at 7.0 M, and the TMB concentration was altered in the range of 0.02–0.8 mM. For kinetic assays toward H2O2, the TMB concentration was fixed at 0.8 mM, and the H2O2 concentration was altered in the range of 0.2–7.0 M. Subsequently, 1 µL of Pd@Pt NDs (0.0244 nM) was added to each of the substrate solutions and mixed thoroughly. Right after mixing the substrate solution with Pd@Pt NDs, the absorbance (at 652 nm) of each reaction solution was measured as a function of time with intervals of 5 s for 5 min using a UV-vis spectrophotometer. The obtained "absorbance vs. time" curve was the kinetic curve of each reaction. The slope at the initial point (SlopeInitial) of the kinetic curve was calculated using OriginPro 2021b software (No. 9.850201, OriginLab Corporation, Northampton, MA, USA), and thus the initial rate (*ν*) of each reaction could be calculated by the equation *ν* = SlopeInitial/(*ε*oxTMB-652 nm × *l*), where *ε*oxTMB-652 nm is the molar absorption coefficient of oxidized TMB (oxTMB) at 652 nm (*ε*oxTMB-652 nm = 3.9 × 104 M−1 cm−1 ). Finally, the apparent steady-state kinetic parameters (including *V*max, *K*m, and *K*cat) could be obtained from the double-reciprocal plots of *ν* versus substrate concentrations, the Lineweaver-Burk equation, 1/*v* = *K*m/*V*max 1/[*S*] + 1/*V*max, and the catalytic constant equation, *K*cat = *V*max/[*E*], where *V*max, [*S*], *K*m, *K*cat, and [*E*] represent the maximal reaction rate, the concentration of substrate, the Michaelis constant, the catalytic constant, and the concentration of catalyst, respectively.

#### *2.4. Preparation of Streptavidin-Conjugated Pd@Pt NDs (Pd@Pt ND-SA Conjugates)*

The Pd@Pt ND-SA conjugates were prepared through chemical modifications based on our recently published procedures with some modifications [\[51](#page-14-4)[,53\]](#page-14-6). Briefly, 200 µL of the Pd@Pt NDs (6.10 nM) was mixed with 200 µL of 20 mg mL−1 HS-PEG-COOH aqueous solution. The mixture was incubated at room temperature for 3 h under gentle shaking, followed by centrifugation at 13,000 rpm for 20 min. The obtained nanoparticles were washed twice with DI water and then redispersed in 400 µL of 10 mM phosphate-buffered saline (PBS, pH 7.4). After that, 100 µL of an aqueous solution containing 25 mM EDC and 50 mM NHS was added to the nanoparticle suspension. After incubation at room temperature for 20 min, the nanoparticles were collected via centrifugation, washed twice with DI water, and redispersed in 500 µL of PBS (pH 7.4). Subsequently, 10 µL of 1 mg mL−1 streptavidin (SA) was added to the nanoparticle suspension, and the resulting mixture was incubated at 4 ◦C in a fridge overnight with gentle shaking. Then, 200 µL of 10% BSA in PBS (pH 7.4) was added to the reaction suspension. After incubation at room temperature for 60 min, the products (i.e., Pd@Pt ND-SA conjugates) were washed with PBST [PBS (pH 7.4) containing 0.05% Tween 20] three times via centrifugation, redispersed in 100 µL of PBST containing 1% BSA and 0.02% NaN3, and finally stored at 4 ◦C in a fridge for future use (12.2 nM).

#### *2.5. Colorimetric Pd@Pt ND ELISA of IL-6*

Before detection, the 96-well microtiter plates were coated with 50 µL of 2.5 µg mL−1 anti-IL-6 CAb in 10 mM carbonate-bicarbonate buffer (pH 9.6) at 4 ◦C overnight. After washing with washing buffer (PBST) five times, the plates were blocked by 350 µL of block-fix buffer (PBST containing 1% BSA and 15% sucrose) at room temperature for 3 h. Then, the block-fix buffer was aspirated, and the plates were dried at room temperature. After being sealed with desiccant, the plates were stored at 4 ◦C in a fridge for further use. In a standard assay procedure, 100 µL of IL-6 standards with different concentrations in dilution buffer (PBST containing 1% BSA) and 50 µL of 0.2 µg mL−1 biotin-anti-IL-6 DAb in dilution buffer were sequentially added to each well of the plates. After incubation at room temperature for 2 h under shaking, the plates were washed five times with washing buffer, followed by the addition of 100 µL of Pd@Pt ND-SA conjugates (0.122 nM) in dilution buffer into each well. After incubation at room temperature for 30 min under shaking, the plates were washed again. Afterward, 100 µL of substrate solution [0.8 mM TMB and 7.0 M H2O2 in citrate-phosphate buffer (pH 4.0)] was added to each well. After 20-min incubation at room temperature, 50 µL of 0.5 M H2SO4 was added to stop the reaction, and the absorbance at 450 nm of the reaction solution in each well was measured with a microplate reader.

The procedure for HRP-based ELISA of IL-6 was the same as the standard procedure for Pd@Pt ND ELISA of IL-6 except that the Pd@Pt ND-SA conjugates were substituted with HRP-SA conjugates and the substrate solution was changed to 0.8 mM TMB and 2 mM H2O2 in citrate-phosphate buffer (pH 4.0).

# **3. Results and Discussion**

# *3.1. Synthesis and Characterization of Pd@Pt NDs*

The Pd@Pt NDs were synthesized by rapidly depositing a mass number of Pt atoms on the surfaces of PdNCs via a facile seed-mediated growth method. Pd NCs with an edge length of 18 nm were selected as the seeds, because they can be easily prepared on a large scale with high uniformity, purity, and quantity through a simple one-pot synthesis (see Figure [1a](#page-5-0)–c) [\[50\]](#page-14-3), making it conducive to producing Pd@Pt NDs of high quality. The Pt dendritic nanostructures were chosen as the shells because they can exhibit highly efficient peroxidase-like catalytic activity [\[43](#page-14-1)[–49\]](#page-14-2), making it possible to produce Pd@Pt NDs with high catalytic activity. In addition, the lattice mismatch between Pd and Pt can be negligible (~0.8%) [\[54\]](#page-14-7), and thereby Pt atoms can be more easily deposited on the surface of Pd nanocubes for the successful synthesis of Pd@Pt core@shell dendritic nanostructures. By combining the advantages of Pd NC seeds and Pt dendritic nanoshells, the resulting Pd@Pt NDs can not only be easily prepared on a large scale with high quantity, but also exhibit high peroxidase-like catalytic activity. Other sizes, shapes, and elements of noble metal nanoparticles may either require complicated synthesis procedures with low purity and uniformity or exhibit relatively low peroxidase-like catalytic activity [\[55](#page-14-8)[–58\]](#page-14-9).

In a standard synthesis of Pd@Pt NDs, three aqueous solutions including 18 nm Pd NCs as the seeds, Na2PtCl4 as the precursor, and AA as the reductant were simply mixed and heated at 80 ◦C for 3 h (see Materials and Methods for the detailed synthesis procedure). Figure [1d](#page-5-0),e show representative low- and high-magnification transmission electron microscope (TEM) images of the Pd@Pt NDs obtained from a standard synthesis, respectively. It can be observed that after the growth of Pt atoms on Pd NCs, (i) the edge length of the Pd NCs was increased from 18 nm to 27 nm; (ii) a layer of rough dendritelike shells was uniformly coated on the surface of each Pd NC; and (iii) the resulting nanoparticles presented well-preserved uniformity in size and shape as the pristine Pd NCs. The full energy-dispersive X-ray (EDX) spectra of the Pd@Pt NDs and Pd NCs confirm that the Pd@Pt NDs were primarily composed of Pd and Pt elements, while the initial 18 nm Pd NC seeds consisted of Pd element only (Figure [1c](#page-5-0),f), indicating that the rough dendrite-like shells were mainly constructed by Pt. These results demonstrate the successful formation of Pd@Pt core@dendrite-like-shell nanostructures for the Pd@Pt NDs. The formation of dendrite-like Pt shells on Pd NC cores is mainly because Pt grows as a set of branches on Pd surfaces following the Volmer–Weber growth mode under the condition of fast reduction at relatively low temperature [\[59](#page-14-10)[–61\]](#page-14-11). It is worth noting that the edge lengths of the Pd@Pt NDs synthesized from three different batches were measured to be 27.3 ± 1.4 nm, 27.2 ± 1.5 nm, and 26.8 ± 1.5 nm, respectively, with the coefficient of variation (CV) of 1.0% (*n* = 3, Figure S1), indicating that the Pd@Pt NDs can be readily reproduced with high uniformity. In addition, these Pd@Pt NDs can be easily scaled up 60-fold to achieve a production of 95.6 mg per batch without compromising the quality (Figure S2), while previously reported porous Pt NDs could only be produced at the scale of several milligrams per batch [\[43–](#page-14-1)[49\]](#page-14-2). Such a large-scale production (144 mL of 6.10 nM Pd@Pt NDs) could allow 72,000 tests for the following Pd@Pt ND ELISA (100 µL of 0.122 nM per assay). Therefore, the Pd@Pt NDs designed in this work can be readily produced in large quantities with high quality, and thus they have great potential for application in the large-scale production of ELISA kits.

<DESCRIPTION_FROM_IMAGE>The image presents a series of microscopic and spectroscopic analyses of palladium (Pd) and platinum-palladium (Pt-Pd) nanocrystals (NCs). It is divided into six panels labeled a through f.

Panel a: Transmission electron microscopy (TEM) image of Pd NCs at 100 nm scale. The NCs appear as uniform square-shaped particles dispersed across the field. An inset shows a schematic representation of a Pd NC.

Panel b: Higher magnification TEM image of Pd NCs at 50 nm scale, providing a closer view of the square-shaped nanocrystals.

Panel c: Energy-dispersive X-ray spectroscopy (EDS) spectrum of Pd NCs. The x-axis represents energy in keV (0-12 keV range), and the y-axis represents counts in arbitrary units. A prominent peak for Pd is observed at approximately 2.8-3.0 keV. An inset TEM image at 50 nm scale shows the Pd NCs.

Panel d: TEM image of Pt-Pd core-shell NCs at 100 nm scale. The particles appear similar to those in panel a. An inset shows a schematic representation of a Pt-Pd core-shell NC, with Pd core surrounded by Pt shell.

Panel e: Higher magnification TEM image of Pt-Pd core-shell NCs at 50 nm scale, showing the square-shaped nanocrystals in greater detail.

Panel f: EDS spectrum of Pt-Pd core-shell NCs. The x-axis represents energy in keV (0-12 keV range), and the y-axis represents counts in arbitrary units. Two prominent peaks are observed: Pt at approximately 2.0-2.2 keV and Pd at 2.8-3.0 keV. Additional Pt peaks are visible at higher energies (around 9-11 keV). An inset TEM image at 50 nm scale shows the Pt-Pd core-shell NCs.

The images and spectra demonstrate the successful synthesis of Pd NCs and Pt-Pd core-shell NCs, confirming their morphology and elemental composition.</DESCRIPTION_FROM_IMAGE>

**Figure 1.** Characterization of 18 nm Pd NCs and Pd@Pt NDs. (**a**,**b**) Low- (**a**) and high- (**b**) magnification TEM images of 18 nm Pd NCs. (**c**) EDX spectrum of 18 nm Pd NCs deposited on a silicon substrate. (**d**,**e**) Low- (**d**) and high- (**e**) magnification TEM images of Pd@Pt NDs. (**f**) EDX spectrum of Pd@Pt NDs deposited on a silicon substrate. Insets in (**c**,**f**) show the corresponding scanning electron microscope (SEM) images of the region where the EDX spectra were acquired.

# *3.2. Peroxidase-Like Catalytic Activity of Pd@Pt NDs*

The peroxidase-like catalytic activity of Pd@Pt NDs was then investigated through their catalysis toward the oxidation of TMB by H2O2. As shown in Figure [2a](#page-6-0), (i) when Pd@Pt NDs were added to TMB+H2O2 substrate solution, the reaction solution turned from colorless to blue and exhibited a new distinct absorbance peak at 652 nm; and (ii) when H2SO4 solution was further added to stop the catalytic reaction, the color of the reaction solution changed from blue to yellow, and its absorbance peak shifted from 652 nm to 450 nm. These results indicate that the Pd@Pt NDs could catalyze the oxidation of TMB by H2O2 to produce oxidized TMB (oxTMB), which was consistent with many reported Pt-based peroxidase nanomimics [\[40,](#page-14-12)[43](#page-14-1)[–49](#page-14-2)[,51,](#page-14-4)[62](#page-14-13)[–64\]](#page-15-0), demonstrating the intrinsic peroxidase-like catalytic property of Pd@Pt NDs. Similar to the enzyme HRP and many other peroxidase nanomimics [\[30,](#page-13-16)[40](#page-14-12)[,43](#page-14-1)[–49,](#page-14-2)[51](#page-14-4)[,62–](#page-14-13)[64\]](#page-15-0), the peroxidase-like catalytic efficiency of Pd@Pt NDs is strongly dependent on the concentrations of substrates (e.g., TMB and H2O2), the pH of reaction solution, and the reaction temperature. The effects of these factors on the catalytic efficiency of Pd@Pt NDs were systematically examined, and the

optimal catalytic conditions for Pd@Pt NDs toward TMB+H2O2 reaction were found to be a TMB concentration of 0.8 mM, a H2O2 concentration of 7.0 M, a reaction pH of 4.0, and a reaction temperature of 40 ◦C (Figure [2b](#page-6-0)–e). It should be noted that there was only a 27% reduction in the catalytic efficiency when the reaction temperature is decreased from 40 ◦C to room temperature (~22 ◦C). Considering the simplification and practicability for the use of Pd@Pt NDs in the following Pd@Pt ND ELISA, room temperature (~22 ◦C) was selected for the catalytic reaction throughout the experiment while the other optimal catalytic conditions remained unchanged.

<DESCRIPTION_FROM_IMAGE>The image contains multiple graphs and a set of test tubes, providing information about a chemical reaction involving TMB (3,3',5,5'-Tetramethylbenzidine), H2O2, and Pd@Pt NDs (Palladium-Platinum core-shell nanoparticles). Here's a detailed description of each component:

a) UV-Vis absorption spectra and corresponding test tube images:
- Three absorption spectra are shown for different reaction conditions:
  i. TMB + H2O2 (black line)
  ii. TMB + H2O2 + Pd@Pt NDs (blue line)
  iii. TMB + H2O2 + Pd@Pt NDs + H2SO4 (yellow line)
- The blue line (ii) shows a peak at 652 nm
- The yellow line (iii) shows a peak at 450 nm
- Corresponding test tube images show:
  i. Colorless solution
  ii. Blue solution
  iii. Yellow solution

b) Graph of relative activity vs TMB concentration:
- X-axis: TMB concentration (mM), range 0-1 mM
- Y-axis: Relative activity (%), range 0-100%
- The curve shows a rapid increase in activity up to about 0.4 mM TMB, then levels off
- A vertical dotted line is drawn at 0.8 mM TMB

c) Graph of relative activity vs H2O2 concentration:
- X-axis: H2O2 concentration (M), range 0-10 M
- Y-axis: Relative activity (%), range 0-100%
- The curve shows a rapid increase in activity up to about 4 M H2O2, then levels off
- A vertical dotted line is drawn at 7 M H2O2

d) Graph of relative activity vs pH:
- X-axis: pH, range 2-10
- Y-axis: Relative activity (%), range 0-100%
- The curve shows a sharp peak at pH 4, with activity dropping rapidly on either side
- A vertical dotted line is drawn at pH 4

e) Graph of relative activity vs temperature:
- X-axis: Temperature (°C), range 10-60°C
- Y-axis: Relative activity (%), range 0-100%
- The curve shows increasing activity up to 40°C, then a sharp decrease
- Vertical dotted lines are drawn at 22°C and 40°C
- A horizontal dotted line is drawn at 73% relative activity

This image provides comprehensive information about the optimal conditions for the TMB-H2O2-Pd@Pt NDs reaction system, including substrate concentrations, pH, and temperature dependencies.</DESCRIPTION_FROM_IMAGE>

**Figure 2.** Verification and optimization of the peroxidase-like catalytic activity of Pd@Pt NDs. (**a**) UV-vis spectra of TMB+H2O2 substrate solution (i), (TMB+H2O2 )+Pd@Pt NDs solution (ii), and (TMB + H2O2 )+Pd@Pt NDs + H2SO4 solution (iii). The bottom-right panel shows the corresponding photographs taken from the three solutions. (**b**–**e**) Effect of TMB concentration (**b**), H2O2 concentration (**c**), pH (**d**), and temperature (**e**) on the peroxidase-like catalytic activity of Pd@Pt NDs. The maximum point in each curve is set as 100%.

To further evaluate the peroxidase-like catalytic activity of Pd@Pt NDs, their catalytic efficiency was quantified by determining the apparent steady-state kinetic parameters for the catalytic reaction of Pd@Pt NDs toward the oxidation of TMB by H2O2. Initially, a series of *ν* for the catalytic reaction of Pd@Pt NDs toward TMB and H2O2 were measured from the steady-state kinetic assays by varying the concentration of one substrate (TMB or H2O2) while fixing the concentration of the other substrate (H2O2 or TMB, see Materials and Methods for the detailed experimental procedures). Then, by plotting the *ν* against TMB and H2O2 concentrations, typical Michaelis–Menten plots were observed for both TMB and H2O2 (Figure [3a](#page-7-0),c). To calculate the apparent steady-state kinetic parameters of the reaction, the Michaelis–Menten plots were further converted into the double-reciprocal plots (Figure [3b](#page-7-0),d). It can be seen that for each of the plots, the reciprocal of the *v* was in a linear relationship with the reciprocal of the substrate concentration, which could be fitted to the Lineweaver–Burk equation:

<DESCRIPTION_FROM_IMAGE>The image contains four graphs labeled a, b, c, and d, representing enzyme kinetics data for two different substrates: TMB (3,3',5,5'-tetramethylbenzidine) and hydrogen peroxide (H2O2).

Graph a: Michaelis-Menten plot for TMB
X-axis: TMB concentration (mM), range 0-0.8 mM
Y-axis: Reaction velocity v (10^-8 M s^-1), range 0-12
The plot shows a typical hyperbolic curve characteristic of Michaelis-Menten kinetics.

Graph b: Lineweaver-Burk plot for TMB
X-axis: 1/TMB concentration (mM^-1), range 0-50 mM^-1
Y-axis: 1/v (10^8 s M^-1), range 0-1.6
The plot shows a linear relationship with the equation:
y = 2,996,000x + 4,518,000
R^2 = 0.988
Km = 0.663 mM
kcat = 9.07 x 10^6 s^-1

Graph c: Michaelis-Menten plot for H2O2
X-axis: H2O2 concentration (M), range 0-7 M
Y-axis: Reaction velocity v (10^-8 M s^-1), range 0-12
The plot shows a hyperbolic curve similar to graph a, but with a different substrate concentration range.

Graph d: Lineweaver-Burk plot for H2O2
X-axis: 1/H2O2 concentration (M^-1), range 0-5 M^-1
Y-axis: 1/v (10^8 s M^-1), range 0-1.2
The plot shows a linear relationship with the equation:
y = 20,452,000x + 5,380,000
R^2 = 0.998
Km = 3.82 M
kcat = 7.62 x 10^6 s^-1

These graphs provide a comprehensive kinetic analysis of an enzyme's activity with two different substrates, TMB and H2O2. The Michaelis-Menten plots (a and c) show the relationship between substrate concentration and reaction velocity, while the Lineweaver-Burk plots (b and d) provide linearized data for easier determination of kinetic parameters Km and kcat.</DESCRIPTION_FROM_IMAGE>

1/*v* = (*K*m/*V*max) (1/[*S*]) + 1/*V*max

**Figure 3.** Steady-state kinetic analysis of the peroxidase-like catalytic activity of Pd@Pt NDs. (**a**,**b**) Kinetic analysis toward TMB: (**a**) plot of *v* versus TMB concentration, in which 7.0 M H2O2 was used; (**b**) double-reciprocal plot converted from (**a**). (**c**,**d**) Kinetic analysis toward H2O2 : (**c**) plot of *v* versus H2O2 concentration, in which 0.8 mM TMB was used; (**d**) double-reciprocal plot converted from (**c**).

By coupling the linear fitting regression equation of the double-reciprocal plots with the Lineweaver–Burk equation, the *K*m and *V*max of Pd@Pt NDs toward TMB and H2O2 could be calculated, and the *K*cat could be obtained by the equation *K*cat = *V*max/[*E*]. The calculated apparent steady-state kinetic parameters including *K*m, *V*max, and *K*cat are summarized in Table [1.](#page-8-0) For comparison, the kinetic parameters for HRP [\[30\]](#page-13-16) and many other reported peroxidase nanomimics are also listed in Tables [1](#page-8-0) and S1, respectively. Because the *K*cat determines the catalytic efficiency of a catalyst, which is directly correlated with the detection sensitivity of ELISA, we mainly compared the *K*cat values of Pd@Pt NDs, HRP, and other reported peroxidase nanomimics. As shown in Table [1,](#page-8-0) the *K*cat values of Pd@Pt NDs toward TMB and H2O2 were calculated to be 9.06 × 106 s −1 and 7.62 × 106 s −1 , respectively, which were more than 2000 times larger than those of HRP, indicating that Pd@Pt NDs had much higher catalytic efficiency than HRP. More significantly, Pd@Pt NDs also showed a predominantly larger *K*cat value, and thereby higher catalytic efficiency, compared to most of the reported peroxidase nanomimics (Table S1) [\[30,](#page-13-16)[31,](#page-13-17)[33,](#page-13-18)[42](#page-14-0)[,51,](#page-14-4)[52,](#page-14-5)[62,](#page-14-13)[63,](#page-14-14)[65–](#page-15-1)[69\]](#page-15-2). The higher peroxidase-like catalytic efficiency of Pd@Pt NDs could be attributed to the fact that (i) Pt nanoparticles generally show much higher peroxidase-like catalytic activity than nanoparticles made of other elements; and (ii) the rough dendrite-like nanosurfaces of Pd@Pt NDs provide a larger surface area per particle and therefore more active sites for the reaction [\[48](#page-14-15)[,70\]](#page-15-3).

| Catalyst              | [E] (M)                                                    | Substance                  | Km (M)                                                | Vmax (M s−1)                                           | Kcat (s−1)                                         |
|-----------------------|------------------------------------------------------------|----------------------------|-------------------------------------------------------|--------------------------------------------------------|----------------------------------------------------|
| Pd@Pt NDs<br>HRP [30] | 2.44 × 10−14<br>2.44 × 10−14<br>2.5 × 10−11<br>2.5 × 10−11 | TMB<br>H2O2<br>TMB<br>H2O2 | 6.63 × 10−4<br>3.82 × 100<br>4.3 × 10−4<br>3.7 × 10−3 | 2.21 × 10−7<br>1.86 × 10−7<br>1.0 × 10−7<br>8.7 × 10−8 | 9.06 × 106<br>7.62 × 106<br>4.0 × 103<br>3.5 × 103 |

<span id="page-8-0"></span>**Table 1.** Comparison of the kinetic parameters of Pd@Pt NDs and HRP toward the TMB + H2O2 reaction *a* .

*a* [*E*] is the catalyst concentration, *K*m is the Michaelis–Menten constant, *V*max is the maximal reaction rate, and *K*cat is the catalytic constant, where *K*cat = *V*max/[*E*].

In addition to the high catalytic efficiency, the catalytic activities of Pd@Pt NDs remained relatively stable after they had been incubated at a range of pH values from 0 to 12 for 2 h, treated at a range of temperatures from 22 ◦C to 90 ◦C for 2 h, and stored for half a year, demonstrating the outstanding chemical, thermal, and storage stabilities of Pd@Pt NDs, respectively (Figure S3). As such, the excellent peroxidase-like catalytic property and outstanding stability of Pd@Pt NDs suggest them as ideal signal labels to substitute HRP for constructing more efficient ELISAs for ultrasensitive detection of cytokines.

## *3.3. Effect of Pt Content on the Peroxidase-Like Catalytic Activity of Pd@Pt NDs*

To better understand the role of Pt content in determining the peroxidase-like catalytic efficiency of Pd@Pt NDs, a set of Pd@Pt NDs with different molar ratios (*x*) of Pt to Pd (i.e., Pd@Pt*x* NDs, *x* = 0–3.44) were prepared using the standard synthesis procedure by adjusting the amount of Pt precursor added (see Materials and Methods for the detailed synthesis procedures), and their peroxidase-like catalytic efficiencies were evaluated using the steady-state kinetic assays. Here, the *K*cat value toward TMB was used to evaluate the catalytic efficiency. Figure [4](#page-8-1) compares the *K*cat values of these Pd@Pt*x* NDs in the *x* range of 0–3.44. The *K*cat value increased drastically from 0 to 3.10 × 106 in the range of *x* from 0 to 0.086. Further increase of *x* to 0.860 leaded to a steady rise of the *K*cat value to 9.06 × 106 , followed by a graduate elevation to the plateau. These results indicate that the catalytic efficiency of Pd@Pt NDs possessed a strong positive relationship with the content of Pt in Pd@Pt NDs. The insets of Figure [4](#page-8-1) show the TEM images of four representative Pd@Pt*x* NDs with *x* = 0, 0.086, 0.860, and 3.44, from which it can be seen that the particle size of Pd@Pt*x* NDs increased with increasing value of *x*. For the Pd@Pt0.860 NDs (i.e., the sample shown in Figure [1d](#page-5-0),e): (i) the catalytic efficiency of Pd@Pt NDs and the utilization efficiency of Pt element were well balanced; and (ii) the average particle size was 27 nm, with excellent dispersion stability; therefore, they were chosen as the optimized Pd@Pt NDs in this study.

<DESCRIPTION_FROM_IMAGE>The image presents a graph showing the relationship between the molar ratio of Platinum (Pt) to Palladium (Pd) and the rate constant (k_cat) toward trimethylborane (TMB). The x-axis represents the molar ratio of Pt to Pd, ranging from 0 to 3.5. The y-axis shows the rate constant (k_cat) on a logarithmic scale, ranging from 10^5 to 10^7 s^-1.

The graph displays a curve that increases rapidly at first and then levels off as the Pt:Pd ratio increases. The curve is plotted with circular data points connected by a solid line.

Embedded within the graph are three transmission electron microscopy (TEM) images, each corresponding to a specific point on the curve:

1. At the lowest Pt:Pd ratio (around 0.1), the TEM image shows square-shaped nanoparticles with well-defined edges.

2. At a Pt:Pd ratio of approximately 1, the TEM image reveals nanoparticles with a more irregular shape, appearing as a mixture of squares and rounded particles.

3. At the highest Pt:Pd ratio (around 3.5), the TEM image displays spherical nanoparticles with a flower-like morphology.

Each TEM image has a scale bar indicating 20 nm.

The graph demonstrates that as the molar ratio of Pt to Pd increases, the catalytic activity (represented by k_cat) also increases, with the most significant change occurring between ratios of 0 to 1. After a ratio of about 1.5, the increase in catalytic activity becomes less pronounced, suggesting a plateau effect.

This image illustrates the impact of Pt:Pd ratio on both the morphology of the nanoparticles and their catalytic performance toward TMB. The transition from square to spherical particles correlates with an increase in catalytic activity.</DESCRIPTION_FROM_IMAGE>

**Figure 4.** Effect of Pt content on the peroxidase-like catalytic efficiency of Pd@Pt NDs. A plot comparing the *K*cat values toward TMB of Pd@Pt NDs with different molar ratios (*x*) of Pt to Pd (i.e., Pd@Pt*x* NDs, *x* = 0–3.44). Insets show the TEM images of four representative Pd@Pt*x* NDs with *x* = 0 (i), 0.0860 (ii), 0.860 (iii), and 3.44 (iv).

# *3.4. Preparation and Characterization of Pd@Pt ND-SA Conjugates*

To realize the application of Pd@Pt NDs in colorimetric ELISA, Pd@Pt NDs were bio-functionalized with SA to form Pd@Pt ND-SA conjugates (see Section [2](#page-2-1) for the detailed preparation procedure). To verify whether the Pd@Pt ND-SA conjugates could be successfully prepared using the above protocol, DLS analysis was carried out to measure the hydrodynamic sizes of the Pd@Pt NDs before and after the bio-functionalization of SA. As seen in Figure [5,](#page-9-0) the average hydrodynamic size of the Pd@Pt NDs increased evidently from 58.27 nm to 94.89 nm after they were conjugated with SA, suggesting the presence of SA biomolecules on the surface of the Pd@Pt NDs [\[71](#page-15-4)[,72\]](#page-15-5). Here, the increment of the hydrodynamic size (36.62 nm) was much larger than the size of a SA biomolecule (~5 nm) [\[72\]](#page-15-5). The reason for this can be ascribed to the fact that (i) HS-PEG-COOH polymer (Mw = 3400) is used as the linker for the conjugation of Pd@Pt NDs with streptavidin biomolecules, and thus the increase in the particle size would be the combined effect of HS-PEG-COOH polymer and SA biomolecules; and (ii) the absorption of proteins (e.g., SA) on the surface of nanoparticles (e.g., Pd@Pt NDs) creates the characteristic hard and soft protein coronas, and thereby the DLS hydrodynamic size of Pd@Pt ND-SA conjugates is usually larger than their physical size [\[73\]](#page-15-6).

<DESCRIPTION_FROM_IMAGE>The image presents a graph and schematic diagrams illustrating the size distribution and structure of Pd@Pt nanoparticles (NDs) before and after conjugation with streptavidin (SA).

Graph interpretation:
The graph shows the size distribution of two types of nanoparticles: Pd@Pt ND and Pd@Pt ND-SA. The x-axis represents the size in nanometers (nm) on a logarithmic scale from 10 to 1000 nm. The y-axis shows the intensity percentage from 0 to 16%.

Two peaks are visible:
1. Pd@Pt ND (solid line): Peak at 58.27 nm
2. Pd@Pt ND-SA (dashed line): Peak at 94.89 nm

The shift in peak position indicates an increase in particle size after conjugation with streptavidin.

Schematic diagrams:
Two schematic representations are provided to the right of the graph:

1. Pd@Pt ND: Depicted as a square-shaped core (likely palladium) surrounded by a shell of smaller particles (likely platinum).

2. Pd@Pt ND-SA: Shows the same nanoparticle structure with an additional component (streptavidin) attached to one side, represented by a distinct shape.

The diagrams illustrate the structural change that occurs when streptavidin is conjugated to the Pd@Pt nanoparticle, corresponding to the size increase observed in the graph.

This image demonstrates the successful conjugation of streptavidin to Pd@Pt nanoparticles and the resulting increase in particle size, which is crucial information for applications in bioconjugation and targeted delivery systems in nanomedicine and biosensing.</DESCRIPTION_FROM_IMAGE>

**Figure 5.** Characterization of Pd@Pt ND-SA conjugates. DLS size distributions of Pd@Pt NDs (solid curve) and Pd@Pt ND-SA conjugates (dashed curve) dispersed in DI water.

To further verify the the functionalization of HS-PEG-COOH and conjugation of SA biomolecules on Pd@Pt NDs, FT-IR spectroscopy was performed on the Pd@Pt NDs before and after the functionalization and conjugation. As shown in Figure S4, no obvious peak was observed for the pristine Pd@Pt NDs in the wavenumber ranging from 750 to 4000 cm−1 (black curve). When HS-PEG-COOH was functionalized onto the Pd@Pt NDs, the specific peaks at 2878 cm−1 and 1104 cm−1 for HS-PEG-COOH were observed due to the C-H and C-O stretching of PEG monomer, respectively (red curve) [\[74](#page-15-7)[,75\]](#page-15-8), indicating the successful functionalization of HS-PEG-COOH on Pd@Pt NDs. When SA biomolecules were further bioconjugated to the HS-PEG-COOH-functionalized Pd@Pt NDs, the characteristic peaks at 1642 cm−1 and 1531 cm−1 related to amide I region (C-O stretching) and amide II region (N−H bending and C− stretching) of SA proteins were observed (blue curve) [\[75,](#page-15-8)[76\]](#page-15-9), revealing the successful conjugation of SA biomolecules on Pd@Pt NDs. These results demonstrate the successful preparation of Pd@Pt ND-SA conjugates using the above biofunctionalization protocol, thus providing the preconditions for the following colorimetric ELISA of IL-6 based on Pd@Pt NDs as the signal labels.

#### *3.5. Analytical Performance of the Colorimetric Pd@Pt ND ELISA for Detection of IL-6*

Based on the aforementioned studies of Pd@Pt NDs, including the synthesis, characterization, investigation of peroxidase-like catalytic activity, and bio-functionalization of SA, a colorimetric ELISA was developed for the detection of IL-6 using Pd@Pt NDs as the signal labels. The standard detection procedure can be found in the Materials and Methods. To demonstrate the features of Pd@Pt ND ELISA, its analytical performance toward IL-6 detection was evaluated, including the sensitivity, dynamic range, reproducibility, and specificity.

The sensitivity and dynamic range of Pd@Pt ND ELISA toward IL-6 detection were first evaluated by analyzing its response to IL-6 standards in the concentration range from 0 to 100 pg mL−1 . The blue curve in Figure [6a](#page-10-0) shows the calibration curve of Pd@Pt ND ELISA for IL-6 detection, which was established by plotting the absorbance at 450 nm of the final detection solution against IL-6 concentration. The absorbance at 450 nm increased with increasing IL-6 concentration, ranging from 0.05 to 100 pg mL−1 (four orders of magnitude), indicating a wide response range of Pd@Pt ND ELISA for IL-6 detection. As shown in Figure [6b](#page-10-0), a high-quality linear dependence (*R* 2 = 0.999) between the absorbance and the concentration of IL-6 was obtained in the range of 0.05–2 pg mL−1 with an ultralow quantitative limit of detection (LOD) of 0.044 pg mL−1 (1.7 fM), estimated at 3SD/*k*. Here, SD is the standard deviation of the background signal (*n* = 6), and *k* is the slope of the linear regression curve. It is worth pointing out that this LOD is 21-fold lower than the LOD of conventional HRP-based ELISA, where the same antibody pair and similar procedure were employed (the violet curves in Figure [6a](#page-10-0),c). More significantly, the achieved LOD at fM level presents the highest sensitivity among commercially available colorimetric IL-6 ELISA kits (Table S2). The high sensitivity of our colorimetric Pd@Pt ND ELISA could be ascribed to the outstanding peroxidase-like catalytic activity of Pd@Pt NDs.

<DESCRIPTION_FROM_IMAGE>This image contains three graphs (a, b, and c) showing the results of ELISA (Enzyme-Linked Immunosorbent Assay) tests for detecting IL-6 (Interleukin-6) using different methods. Here's a detailed description of each graph:

Graph a:
This graph compares two ELISA methods: Pd@Pt ND ELISA and HRP ELISA. The x-axis represents the IL-6 concentration in pg mL^-1 on a logarithmic scale from 0.01 to 100. The y-axis shows the absorbance at 450 nm in arbitrary units (a.u.) from 0 to 3.5.

The Pd@Pt ND ELISA (blue squares) shows a sigmoidal curve with a steep increase in absorbance between 1 and 10 pg mL^-1 of IL-6, reaching a maximum absorbance of about 3.3 a.u. at 100 pg mL^-1.

The HRP ELISA (purple circles) shows a less steep curve, with absorbance increasing more gradually and reaching about 1.5 a.u. at 100 pg mL^-1.

Graph b:
This graph focuses on the Pd@Pt ND ELISA method at lower IL-6 concentrations. The x-axis shows IL-6 concentration from 0 to 2 pg mL^-1, and the y-axis shows absorbance at 450 nm from 0 to 0.8 a.u.

The graph includes a linear fit equation: y = 0.3525x + 0.0622, with an R^2 value of 0.999, indicating a strong linear relationship. The Limit of Detection (LOD) is reported as 0.044 pg mL^-1.

An inset illustration shows a schematic of the Pd@Pt ND (nanodendrimer) structure.

Graph c:
This graph shows the results for the HRP ELISA method at higher IL-6 concentrations. The x-axis represents IL-6 concentration from 0 to 50 pg mL^-1, and the y-axis shows absorbance at 450 nm from 0 to 1.0 a.u.

The graph includes a linear fit equation: y = 0.0170x + 0.0589, with an R^2 value of 0.999, indicating a strong linear relationship. The Limit of Detection (LOD) is reported as 0.915 pg mL^-1.

An inset illustration shows a schematic of the HRP (Horseradish Peroxidase) enzyme structure.

Overall, these graphs demonstrate that the Pd@Pt ND ELISA method has a lower detection limit and higher sensitivity for IL-6 detection compared to the traditional HRP ELISA method.</DESCRIPTION_FROM_IMAGE>

**Figure 6.** Detection of IL-6 standards using the colorimetric Pd@Pt ND ELISA (blue curve) and conventional HRP ELISA (violet curve). (**a**) Calibration curves of Pd@Pt ND ELISA and HRP ELISA that were generated by plotting the absorbance at 450 nm of the final detection solution against IL-6 concentration. (**b**,**c**) Linear range regions of the calibration curves for Pd@Pt ND ELISA (**b**) and HRP ELISA (**c**).

It should be mentioned that the magnitude of color signal enhancement by Pd@Pt NDs relative to conventional HRP in ELISA tests was ~21 times (Figure [6)](#page-10-0), while the magnitude of color signal enhancement was ~2000 in the case where Pd@Pt NDs and HRP were suspended in aqueous solutions (Figure [3](#page-7-0) and Table [1)](#page-8-0). Please note that in ELISA tests, the Pd@Pt NDs needed to be functionalized with HS-PEG-COOH, modified with SA, reacted with biotin on the solid–liquid interface, and finally immobilized on the solid–liquid interface (i.e., the surface of ELISA microplates). Therefore, the relatively low signal enhancement in ELISA tests can be ascribed to the fact that: (i) the functionalization of HS-PEG-COOH on Pd@Pt NDs can partly inhibit the catalytic activity of Pd@Pt NDs due to the formation of Pt-S bond [\[64,](#page-15-0)[65\]](#page-15-1); (ii) the modification of SA biomolecules on Pd@Pt NDs can physically hide the active Pt surface in part; (iii) compared to HRP (4 nm in size), the larger size of Pd@Pt NDs (27 nm in edge length) impede the binding of Pd@Pt ND-SA conjugates with biotin-detection antibodies on the microplate surface because of steric hindrance effect; and (iv) the immobilization of Pd@Pt NDs on the microplate surface also reduces the total surface area of active Pt surface as compared to the Pd@Pt NDs suspended in aqueous solution.

The reproducibility of the Pd@Pt ND ELISA toward quantitative determination of IL-6 was then evaluated by repeatedly assaying three different IL-6 standards at low (0.1 pg mL−1 ), medium (1 pg mL−1 ), and high (10 pg mL−1 ) concentrations using the same and different batches of Pd@Pt ND-SA conjugates. The intra- and inter-batch coefficients of variation (CVs, *n* = 6) using the same and different batches of Pd@Pt ND-SA conjugates were determined. As summarized in Table S3, the intra-batch CVs were 5.22%, 3.82%, and 5.39% for 0.1, 1, and 10 pg mL−1 IL-6, respectively, while the inter-batch CVs were 8.70%, 5.06%, and 7.27% for the three concentrations of IL-6, respectively. The low CVs could be mainly due to the excellent uniformity and stability of Pd@Pt NDs, revealing the great reproducibility and repeatability of the colorimetric Pd@Pt ND ELISA and its potential for scaled-up production for practical application.

The specificity of Pd@Pt ND ELISA toward IL-6 detection was verified by challenging the assay with other possible interfering cytokines, e.g., tumor necrosis factor alpha (TNFα), interferon-gamma (IFN-γ), interleukin-1 beta (IL-1β), interleukin-2 (IL-2), interleukin-8 (IL-8), and interleukin-10 (IL-10). A low concentration of target IL-6 (1 pg mL−1 ) and a high concentration of interfering cytokines (100 pg mL−1 ) were used for evaluation. As seen from Figure S5, the absorbances at 450 nm obtained from the high-concentration TNF-α, IFN-γ, IL-1β, IL-2, IL-8, and IL-10 were lower than 0.0724 a.u., and were thus negligible as a background signal, whereas the absorbance at 450 nm for the low-concentration IL-6 showed a significantly higher value of 0.4198 a.u., providing highly specific detection of IL-6 by the Pd@Pt ND ELISA. It should be noted that the introduction of Pd@Pt NDs did not affect specificity, and could be applied to paired antibodies for any other target analytes using the conventional ELISA system.

# *3.6. Analysis of Real Samples and Method Validation*

To examine the practical application of Pd@Pt ND ELISA under clinical scenarios, we applied the assay to the analysis of six IL-6-spiked human serum samples. These samples were prepared by spiking IL-6 at concentrations of 0.2, 0.5, 1, 2, 5, 10 pg mL−1 into negative human serum (i.e., heat-inactivated and sterile-filtered human serum). The IL-6 level in each sample was quantified using the calibration and linear curves shown in Figure [6a](#page-10-0),b (the blue curves). The detection results were validated by recovery analysis, which is defined as the measured level of IL-6 divided by the spiked level of IL-6 in the samples. As summarized in Table [2,](#page-11-0) the recoveries for all six samples were determined to be in the range of 93.65–105.53%, and the CV values for all six samples were lower than 9.96% (*n* = 12). These data imply that the Pd@Pt ND ELISA maintained its high accuracy and reliability in serum with complex background components, confirming the excellent analytical performance of our colorimetric Pd@Pt ND ELISA in analyzing low-abundance IL-6 in real biological samples.

<span id="page-11-0"></span>**Table 2.** Analytical recoveries of Pd@Pt ND ELISA in detecting IL-6-spiked human serum samples.

| Sample<br>No. | IL-6 Level Spiked<br>(pg mL−1) | IL-6 Level Meaured<br>(pg mL−1) | CV<br>(%, n = 12) | Recovery (%) |
|---------------|--------------------------------|---------------------------------|-------------------|--------------|
| 1             | 0.2                            | 0.19                            | 9.96              | 94.69        |
| 2             | 0.5                            | 0.47                            | 7.55              | 93.65        |
| 3             | 1                              | 0.98                            | 5.60              | 97.55        |
| 4             | 2                              | 1.92                            | 6.70              | 96.12        |
| 5             | 5                              | 5.28                            | 8.86              | 105.53       |
| 6             | 10                             | 9.97                            | 8.34              | 99.74        |

#### **4. Conclusions**

In conclusion, we demonstrated an enhanced ELISA for colorimetric detection of cytokines (IL-6 as a model cytokine) with femtomolar sensitivity based on the rational design of Pd@Pt NDs with dendrite-like nanostructures as the signal labels. The Pd@Pt NDs possess outstanding peroxidase-like catalytic activity and stability, and can be scaled up for massive production with high purity, yield, and uniformity. Owing to these advantages, our colorimetric Pd@Pt ND ELISA: (i) enables highly sensitive detection of IL-6 with ultralow LOD down to 0.044 pg mL−1 (1.7 fM); (ii) exhibits excellent reproducibility and specificity; and (iii) is suitable for large-scale production and application in immunoassays. To the best of our knowledge, our study is the first to demonstrate a femtomolar-sensitivity ELISA for colorimetric detection of IL-6, where only one-step signal amplification is involved. The unprecedented LOD of our colorimetric Pd@Pt ND ELISA, one order of magnitude lower than the LOD of commonly used HRP-based colorimetric ELISA, allows the monitoring of lower levels of IL-6 in human serum with high accuracy and reliability. We believe that the colorimetric Pd@Pt ND ELISA presents a promising in vitro diagnostic tool for the quantitative detection of ultralow-level cytokines in real biological samples, and has a vast range of potential applications in fundamental biomedical research and practical clinical diagnosis.

**Supplementary Materials:** The following are available online at [https://www.mdpi.com/article/10](https://www.mdpi.com/article/10.3390/chemosensors10090359/s1) [.3390/chemosensors10090359/s1,](https://www.mdpi.com/article/10.3390/chemosensors10090359/s1) Figures S1 and S2: TEM image of Pd@Pt NDs, Figure S3: Stability evaluation for the peroxidase-like catalytic activity of Pd@Pt NDs, Figure S4: FT-IR spectra of Pd@Pt NDs, Pd@Pt ND-S-PEG-COOH complex, and Pd@Pt ND-SA conjugates, Figure S5: Specificity of Pd@Pt ND ELISA toward IL-6 detection, Table S1: Comparison of the kinetic parameters of various catalysts toward the TMB + H2O2 reaction, Table S2: Comparison of the limits of detection (LODs) of different IL-6 ELISA kits, and Table S3: Intra- and inter-batch coefficients of variation (CVs) of Pd@Pt ND ELISA in IL-6 detection. References [\[30,](#page-13-16)[31,](#page-13-17)[33,](#page-13-18)[42](#page-14-0)[,51](#page-14-4)[,52,](#page-14-5)[62,](#page-14-13)[63](#page-14-14)[,65](#page-15-1)[–69\]](#page-15-2) are cited in the Supplementary Materials.

**Author Contributions:** Z.G. designed the project, conducted all the experiments, and wrote the manuscript. C.W. assisted in the nanoparticle synthesis and electron microscope characterization. J.H. assisted in the detection of IL-6 using ELISA. P.C. provided constructive guidance for the overall design and direction of the experiments and manuscript editing. All authors have read and agreed to the published version of the manuscript.

**Funding:** This research was funded by the National Institutes of Health (NIH) MIRA R35GM133795 and National Science Foundation (NSF) CAREER CBET-1943302.

**Institutional Review Board Statement:** Not applicable.

**Informed Consent Statement:** Not applicable.

**Data Availability Statement:** Data are contained within the article.

**Conflicts of Interest:** The authors declare no conflict of interest.

# **References**

- <span id="page-12-0"></span>1. Thomson, A.W.; Lotze, M.T. *The Cytokine Handbook, Two-Volume Set*; Elsevier: Amsterdam, The Netherlands, 2003.
- <span id="page-12-4"></span>2. Preedy, V.R.; Hunter, R. *Cytokines*; Taylor & Francis: Abingdon, UK, 2011.
- <span id="page-12-1"></span>3. Stenken, J.A.; Poschenrieder, A.J. Bioanalytical chemistry of cytokines—A review. *Anal. Chim. Acta* **2015**, *853*, 95–115. [\[CrossRef\]](http://doi.org/10.1016/j.aca.2014.10.009)
- 4. Liu, C.; Chu, D.; Kalantar-Zadeh, K.; George, J.; Young, H.A.; Liu, G. Cytokines: From clinical significance to quantification. *Adv.*
- *Sci.* **2021**, *8*, 2004433. [\[CrossRef\]](http://doi.org/10.1002/advs.202004433)
- <span id="page-12-2"></span>5. Stanley, A.C.; Lacy, P. Pathways for cytokine secretion. *Physiology* **2010**, *25*, 218–229. [\[CrossRef\]](http://doi.org/10.1152/physiol.00017.2010)
- 6. Altan-Bonnet, G.; Mukherjee, R. Cytokine-mediated communication: A quantitative appraisal of immune complexity. *Nat. Rev. Immunol.* **2019**, *19*, 205–217. [\[CrossRef\]](http://doi.org/10.1038/s41577-019-0131-x)
- 7. Dembic, Z. *The Cytokines of the Immune System: The Role of Cytokines in Disease Related to Immune Response*; Academic Press: Cambridge, MA, USA, 2015.
- <span id="page-12-3"></span>8. Goldring, M.B.; Goldring, S.R. Cytokines and cell growth control. *Crit. Rev. Eukaryot. Gene Expr.* **1991**, *1*, 301–326.

- <span id="page-13-0"></span>9. Mizoguchi, I.; Higuchi, K.; Mitobe, K.; Tsunoda, R.; Mizuguchi, J.; Yoshimoto, T. *Cytokine Frontiers: Regulation of Immune Responses in Health and Disease*; Springer: Berlin/Heidelberg, Germany, 2013.
- <span id="page-13-4"></span>10. Cron, R.Q.; Behrens, E.M. *Cytokine Storm Syndrome*; Springer: Berlin/Heidelberg, Germany, 2019.
- <span id="page-13-7"></span>11. Vancurova, I. *Cytokine Bioassays*; Springer: Berlin/Heidelberg, Germany, 2016.
- <span id="page-13-1"></span>12. Chen, P.; Chung, M.T.; McHugh, W.; Nidetz, R.; Li, Y.; Fu, J.; Cornell, T.T.; Shanley, T.P.; Kurabayashi, K. Multiplex serum cytokine immunoassay using nanoplasmonic biosensor microarrays. *ACS Nano* **2015**, *9*, 4173–4181. [\[CrossRef\]](http://doi.org/10.1021/acsnano.5b00396)
- <span id="page-13-2"></span>13. Tanaka, T.; Narazaki, M.; Kishimoto, T. IL-6 in inflammation, immunity, and disease. *Cold Spring Harb. Perspect. Biol.* **2014**, *6*, a016295. [\[CrossRef\]](http://doi.org/10.1101/cshperspect.a016295)
- 14. Velazquez-Salinas, L.; Verdugo-Rodriguez, A.; Rodriguez, L.L.; Borca, M.V. The role of interleukin 6 during viral infections. *Front. Microbiol.* **2019**, *10*, 1057. [\[CrossRef\]](http://doi.org/10.3389/fmicb.2019.01057) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/31134045)
- <span id="page-13-3"></span>15. Schaper, F.; Rose-John, S. Interleukin-6: Biology, signaling and strategies of blockade. *Cytokine Growth Factor Rev.* **2015**, *26*, 475–487. [\[CrossRef\]](http://doi.org/10.1016/j.cytogfr.2015.07.004) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/26189695)
- <span id="page-13-5"></span>16. Hack, C.E.; De Groot, E.R.; Fert-Bersma, R.J.F.; Nuijens, J.H.; Strack Van Schijndel, R.J.M.; Eerenberg-Belmer, A.J.M.; Thijs, L.G.; Aarden, L.A. Increased plasma levels of interleukin-6 in sepsis. *Blood* **1989**, *74*, 1704–1710. [\[CrossRef\]](http://doi.org/10.1182/blood.V74.5.1704.1704) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/2790194)
- 17. Molano Franco, D.; Arevalo-Rodriguez, I.; Roqué i Figuls, M.; Montero Oleas, N.G.; Nuvials, X.; Zamora, J. Plasma interleukin-6 concentration for the diagnosis of sepsis in critically ill adults. *Cochrane Database Syst. Rev.* **2019**, *4*, CD011811. [\[CrossRef\]](http://doi.org/10.1002/14651858.CD011811.pub2) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/31038735)
- 18. Rincon, M. Interleukin-6: From an inflammatory marker to a target for inflammatory diseases. *Trends Immunol.* **2012**, *33*, 571–577. [\[CrossRef\]](http://doi.org/10.1016/j.it.2012.07.003) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/22883707)
- <span id="page-13-6"></span>19. Zhang, C.; Wu, Z.; Li, J.-W.; Zhao, H.; Wang, G.-Q. Cytokine release syndrome in severe COVID-19: Interleukin-6 receptor antagonist tocilizumab may be the key to reduce mortality. *Int. J. Antimicrob. Agents* **2020**, *55*, 105954. [\[CrossRef\]](http://doi.org/10.1016/j.ijantimicag.2020.105954) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/32234467)
- <span id="page-13-8"></span>20. Shankar, G.; Cohen, D.A. Enhanced cytokine detection by a novel cell culture-based elisa. *J. Immunoass.* **1997**, *18*, 371–388. [\[CrossRef\]](http://doi.org/10.1080/01971529708005828)
- <span id="page-13-9"></span>21. Liu, G.; Zhang, K.; Nadort, A.; Hutchinson, M.R.; Goldys, E.M. Sensitive cytokine assay based on optical fiber allowing localized and spatially resolved detection of interleukin-6. *ACS Sens.* **2017**, *2*, 218–226. [\[CrossRef\]](http://doi.org/10.1021/acssensors.6b00619)
- <span id="page-13-10"></span>22. Tongdee, M.; Yamanishi, C.; Maeda, M.; Kojima, T.; Dishinger, J.; Chantiwas, R.; Takayama, S. One-incubation one-hour multiplex ELISA enabled by aqueous two-phase systems. *Analyst* **2020**, *145*, 3517–3527. [\[CrossRef\]](http://doi.org/10.1039/D0AN00383B)
- <span id="page-13-11"></span>23. Schweitzer, B.; Roberts, S.; Grimwade, B.; Shao, W.; Wang, M.; Fu, Q.; Shu, Q.; Laroche, I.; Zhou, Z.; Tchernev, V.T.; et al. Multiplexed protein profiling on microarrays by rolling-circle amplification. *Nat. Biotechnol.* **2002**, *20*, 359–365. [\[CrossRef\]](http://doi.org/10.1038/nbt0402-359) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/11923841)
- <span id="page-13-12"></span>24. Adalsteinsson, V.; Parajuli, O.; Kepics, S.; Gupta, A.; Reeves, W.B.; Hahm, J.I. Ultrasensitive detection of cytokines enabled by nanoscale zno arrays. *Anal. Chem.* **2008**, *80*, 6594–6601. [\[CrossRef\]](http://doi.org/10.1021/ac800747q)
- <span id="page-13-13"></span>25. Liu, G.; Qi, M.; Hutchinson, M.R.; Yang, G.; Goldys, E.M. Recent advances in cytokine detection by immunosensing. *Biosens. Bioelectron.* **2016**, *79*, 810–821. [\[CrossRef\]](http://doi.org/10.1016/j.bios.2016.01.020)
- <span id="page-13-14"></span>26. Wei, H.; Wang, E. Nanomaterials with enzyme-like characteristics (nanozymes): Next-generation artificial enzymes. *Chem. Soc. Rev.* **2013**, *42*, 6060–6093. [\[CrossRef\]](http://doi.org/10.1039/c3cs35486e)
- 27. Wu, J.; Wang, X.; Wang, Q.; Lou, Z.; Li, S.; Zhu, Y.; Qin, L.; Wei, H. Nanomaterials with enzyme-like characteristics (nanozymes): Next-generation artificial enzymes (II). *Chem. Soc. Rev.* **2019**, *48*, 1004–1076. [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/30534770)
- 28. Ye, H.; Xi, Z.; Magloire, K.; Xia, X. Noble-metal nanostructures as highly efficient peroxidase mimics. *ChemNanoMat* **2019**, *5*, 860–868. [\[CrossRef\]](http://doi.org/10.1002/cnma.201900125)
- <span id="page-13-15"></span>29. Liu, X.; Huang, D.; Lai, C.; Qin, L.; Zeng, G.; Xu, P.; Li, B.; Yi, H.; Zhang, M. Peroxidase-like activity of smart nanomaterials and their advanced application in colorimetric glucose biosensors. *Small* **2019**, *15*, 1900133. [\[CrossRef\]](http://doi.org/10.1002/smll.201900133) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/30908899)
- <span id="page-13-16"></span>30. Gao, L.; Zhuang, J.; Nie, L.; Zhang, J.; Zhang, Y.; Gu, N.; Wang, T.; Feng, J.; Yang, D.; Perrett, S.; et al. Intrinsic peroxidase-like activity of ferromagnetic nanoparticles. *Nat. Nanotechnol.* **2007**, *2*, 577–583. [\[CrossRef\]](http://doi.org/10.1038/nnano.2007.260)
- <span id="page-13-17"></span>31. Mu, J.; Wang, Y.; Zhao, M.; Zhang, L. Intrinsic peroxidase-like activity and catalase-like activity of Co3O4 nanoparticles. *Chem. Comm.* **2012**, *48*, 2540–2542. [\[CrossRef\]](http://doi.org/10.1039/c2cc17013b) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/22288077)
- 32. Wan, Y.; Qi, P.; Zhang, D.; Wu, J.; Wang, Y. Manganese oxide nanowire-mediated enzyme-linked immunosorbent assay. *Biosens. Bioelectron.* **2012**, *33*, 69–74. [\[CrossRef\]](http://doi.org/10.1016/j.bios.2011.12.033)
- <span id="page-13-18"></span>33. André, R.; Natálio, F.; Humanes, M.; Leppin, J.; Heinze, K.; Wever, R.; Schröder, H.-C.; Müller, W.E.G.; Tremel, W. V2O5 nanowires with an intrinsic peroxidase-like activity. *Adv. Funct. Mater.* **2011**, *21*, 501–509. [\[CrossRef\]](http://doi.org/10.1002/adfm.201001302)
- <span id="page-13-19"></span>34. Lin, T.; Zhong, L.; Guo, L.; Fu, F.; Chen, G. Seeing diabetes: Visual detection of glucose based on the intrinsic peroxidase-like activity of MoS2 nanosheets. *Nanoscale* **2014**, *6*, 11856–11862. [\[CrossRef\]](http://doi.org/10.1039/C4NR03393K)
- <span id="page-13-20"></span>35. Lin, T.; Zhong, L.; Song, Z.; Guo, L.; Wu, H.; Guo, Q.; Chen, Y.; Fu, F.; Chen, G. Visual detection of blood glucose based on peroxidase-like activity of WS2 nanosheets. *Biosens. Bioelectron.* **2014**, *62*, 302–307. [\[CrossRef\]](http://doi.org/10.1016/j.bios.2014.07.001)
- <span id="page-13-21"></span>36. Song, Y.; Qu, K.; Zhao, C.; Ren, J.; Qu, X. Graphene oxide: Intrinsic peroxidase catalytic activity and its application to glucose detection. *Adv. Mater.* **2010**, *22*, 2206–2210. [\[CrossRef\]](http://doi.org/10.1002/adma.200903783)
- <span id="page-13-22"></span>37. Jv, Y.; Li, B.; Cao, R. Positively-charged gold nanoparticles as peroxidiase mimic and their application in hydrogen peroxide and glucose detection. *Chem. Comm.* **2010**, *46*, 8017–8019. [\[CrossRef\]](http://doi.org/10.1039/c0cc02698k) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/20871928)

- 38. Jiang, H.; Chen, Z.; Cao, H.; Huang, Y. Peroxidase-like activity of chitosan stabilized silver nanoparticles for visual and colorimetric detection of glucose. *Analyst* **2012**, *137*, 5560–5564. [\[CrossRef\]](http://doi.org/10.1039/c2an35911a)
- 39. Lan, J.; Xu, W.; Wan, Q.; Zhang, X.; Lin, J.; Chen, J.; Chen, J. Colorimetric determination of sarcosine in urine samples of prostatic carcinoma by mimic enzyme palladium nanoparticles. *Anal. Chim. Acta* **2014**, *825*, 63–68. [\[CrossRef\]](http://doi.org/10.1016/j.aca.2014.03.040) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/24767152)
- <span id="page-14-12"></span>40. Ma, M.; Zhang, Y.; Gu, N. Peroxidase-like catalytic activity of cubic Pt nanocrystals. *Colloids Surf. A Physicochem. Eng. Asp.* **2011**, *373*, 6–10. [\[CrossRef\]](http://doi.org/10.1016/j.colsurfa.2010.08.007)
- 41. Su, H.; Liu, D.-D.; Zhao, M.; Hu, W.-L.; Xue, S.-S.; Cao, Q.; Le, X.-Y.; Ji, L.-N.; Mao, Z.-W. Dual-enzyme characteristics of polyvinylpyrrolidone-capped iridium nanoparticles and their cellular protective effect against H2O2-induced oxidative damage. *ACS Appl. Mater. Interfaces* **2015**, *7*, 8233–8242. [\[CrossRef\]](http://doi.org/10.1021/acsami.5b01271) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/25826467)
- <span id="page-14-0"></span>42. Ye, H.; Mohar, J.; Wang, Q.; Catalano, M.; Kim, M.J.; Xia, X. Peroxidase-like properties of ruthenium nanoframes. *Sci. Bull.* **2016**, *61*, 1739–1745. [\[CrossRef\]](http://doi.org/10.1007/s11434-016-1193-9)
- <span id="page-14-1"></span>43. Jiang, T.; Song, Y.; Wei, T.; Li, H.; Du, D.; Zhu, M.-J.; Lin, Y. Sensitive detection of escherichia coli o157:H7 using Pt–Au bimetal nanoparticles with peroxidase-like amplification. *Biosens. Bioelectron.* **2016**, *77*, 687–694. [\[CrossRef\]](http://doi.org/10.1016/j.bios.2015.10.017)
- 44. Jiang, T.; Song, Y.; Du, D.; Liu, X.; Lin, Y. Detection of p53 protein based on mesoporous Pt–Pd nanoparticles with enhanced peroxidase-like catalysis. *ACS Sens.* **2016**, *1*, 717–724. [\[CrossRef\]](http://doi.org/10.1021/acssensors.6b00019)
- 45. Gao, Z.; Xu, M.; Lu, M.; Chen, G.; Tang, D. Urchin-like (gold core)@(platinum shell) nanohybrids: A highly efficient peroxidasemimetic system for in situ amplified colorimetric immunoassay. *Biosens. Bioelectron.* **2015**, *70*, 194–201. [\[CrossRef\]](http://doi.org/10.1016/j.bios.2015.03.039)
- 46. Kwon, E.Y.; Ruan, X.; Wang, L.; Lin, Y.; Du, D.; Van Wie, B.J. Mesoporous Pd@Pt nanoparticle-linked immunosorbent assay for detection of atrazine. *Anal. Chim. Acta* **2020**, *1116*, 36–44. [\[CrossRef\]](http://doi.org/10.1016/j.aca.2020.03.045)
- 47. Fu, Z.; Zeng, W.; Cai, S.; Li, H.; Ding, J.; Wang, C.; Chen, Y.; Han, N.; Yang, R. Porous Au@Pt nanoparticles with superior peroxidase-like activity for colorimetric detection of spike protein of SARS-CoV-2. *J. Colloid Interface Sci.* **2021**, *604*, 113–121. [\[CrossRef\]](http://doi.org/10.1016/j.jcis.2021.06.170) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/34265672)
- <span id="page-14-15"></span>48. Ge, C.; Wu, R.; Chong, Y.; Fang, G.; Jiang, X.; Pan, Y.; Chen, C.; Yin, J.-J. Synthesis of Pt hollow nanodendrites with enhanced peroxidase-like activity against bacterial infections: Implication for wound healing. *Adv. Funct. Mater.* **2018**, *28*, 1801484. [\[CrossRef\]](http://doi.org/10.1002/adfm.201801484)
- <span id="page-14-2"></span>49. Jiao, L.; Zhang, L.; Du, W.; Li, H.; Yang, D.; Zhu, C. Au@Pt nanodendrites enhanced multimodal enzyme-linked immunosorbent assay. *Nanoscale* **2019**, *11*, 8798–8802. [\[CrossRef\]](http://doi.org/10.1039/C8NR08741E) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/30820494)
- <span id="page-14-3"></span>50. Jin, M.; Liu, H.; Zhang, H.; Xie, Z.; Liu, J.; Xia, Y. Synthesis of Pd nanocrystals enclosed by {100} facets and with sizes < 10 nm for application in CO oxidation. *Nano Res.* **2011**, *4*, 83–91.
- <span id="page-14-4"></span>51. Gao, Z.; Lv, S.; Xu, M.; Tang, D. High-index {hk0} faceted platinum concave nanocubes with enhanced peroxidase-like activity for an ultrasensitive colorimetric immunoassay of the human prostate-specific antigen. *Analyst* **2017**, *142*, 911–917. [\[CrossRef\]](http://doi.org/10.1039/C6AN02722A) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/28225095)
- <span id="page-14-5"></span>52. Gao, Z.; Ye, H.; Tang, D.; Tao, J.; Habibi, S.; Minerick, A.; Tang, D.; Xia, X. Platinum-decorated gold nanoparticles with dual functionalities for ultrasensitive colorimetric in vitro diagnostics. *Nano Lett.* **2017**, *17*, 5572–5579. [\[CrossRef\]](http://doi.org/10.1021/acs.nanolett.7b02385) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/28813601)
- <span id="page-14-6"></span>53. Gao, Z.; Song, Y.; Hsiao, T.Y.; He, J.; Wang, C.; Shen, J.; MacLachlan, A.; Dai, S.; Singer, B.H.; Kurabayashi, K.; et al. Machinelearning-assisted microfluidic nanoplasmonic digital immunoassay for cytokine storm profiling in COVID-19 patients. *ACS Nano* **2021**, *15*, 18023–18036. [\[CrossRef\]](http://doi.org/10.1021/acsnano.1c06623)
- <span id="page-14-7"></span>54. Lu, N.; Wang, J.; Xie, S.; Brink, J.; McIlwrath, K.; Xia, Y.; Kim, M.J. Aberration corrected electron microscopy study of bimetallic Pd–Pt nanocrystal: Core–shell cubic and core–frame concave structures. *J. Phys. Chem. C* **2014**, *118*, 28876–28882. [\[CrossRef\]](http://doi.org/10.1021/jp509849a)
- <span id="page-14-8"></span>55. Shi, Y.; Lyu, Z.; Zhao, M.; Chen, R.; Nguyen, Q.N.; Xia, Y. Noble-metal nanocrystals with controlled shapes for catalytic and electrocatalytic applications. *Chem. Rev.* **2021**, *121*, 649–735. [\[CrossRef\]](http://doi.org/10.1021/acs.chemrev.0c00454)
- 56. Wei, Z.; Xi, Z.; Vlasov, S.; Ayala, J.; Xia, X. Nanocrystals of platinum-group metals as peroxidase mimics for in vitro diagnostics. *Chem. Commun.* **2020**, *56*, 14962–14975. [\[CrossRef\]](http://doi.org/10.1039/D0CC06575G)
- 57. Khoris, I.M.; Takemura, K.; Lee, J.; Hara, T.; Abe, F.; Suzuki, T.; Park, E.Y. Enhanced colorimetric detection of norovirus using in-situ growth of Ag shell on Au NPs. *Biosens. Bioelectron.* **2019**, *126*, 425–432. [\[CrossRef\]](http://doi.org/10.1016/j.bios.2018.10.067) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/30471568)
- <span id="page-14-9"></span>58. Choleva, T.G.; Gatselou, V.A.; Tsogas, G.Z.; Giokas, D.L. Intrinsic peroxidase-like activity of rhodium nanoparticles, and their application to the colorimetric determination of hydrogen peroxide and glucose. *Microchim. Acta* **2018**, *185*, 22. [\[CrossRef\]](http://doi.org/10.1007/s00604-017-2582-8) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/29594622)
- <span id="page-14-10"></span>59. Xie, S.; Choi, S.-I.; Lu, N.; Roling, L.T.; Herron, J.A.; Zhang, L.; Park, J.; Wang, J.; Kim, M.J.; Xie, Z.; et al. Atomic layer-by-layer deposition of Pt on Pd nanocubes for catalysts with enhanced activity and durability toward oxygen reduction. *Nano Lett.* **2014**, *14*, 3570–3576. [\[CrossRef\]](http://doi.org/10.1021/nl501205j) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/24797061)
- 60. Jiang, M.; Lim, B.; Tao, J.; Camargo, P.H.C.; Ma, C.; Zhu, Y.; Xia, Y. Epitaxial overgrowth of platinum on palladium nanocrystals. *Nanoscale* **2010**, *2*, 2406–2411. [\[CrossRef\]](http://doi.org/10.1039/c0nr00324g)
- <span id="page-14-11"></span>61. Fang, P.-P.; Duan, S.; Lin, X.-D.; Anema, J.R.; Li, J.-F.; Buriez, O.; Ding, Y.; Fan, F.-R.; Wu, D.-Y.; Ren, B.; et al. Tailoring Au-core Pd-shell Pt-cluster nanoparticles for enhanced electrocatalytic activity. *Chem. Sci.* **2011**, *2*, 531–539. [\[CrossRef\]](http://doi.org/10.1039/C0SC00489H)
- <span id="page-14-13"></span>62. Gao, Z.; Xu, M.; Hou, L.; Chen, G.; Tang, D. Irregular-shaped platinum nanoparticles as peroxidase mimics for highly efficient colorimetric immunoassay. *Anal. Chim. Acta* **2013**, *776*, 79–86. [\[CrossRef\]](http://doi.org/10.1016/j.aca.2013.03.034)
- <span id="page-14-14"></span>63. He, W.; Liu, Y.; Yuan, J.; Yin, J.-J.; Wu, X.; Hu, X.; Zhang, K.; Liu, J.; Chen, C.; Ji, Y.; et al. Au@Pt nanostructures as oxidase and peroxidase mimetics for use in immunoassays. *Biomaterials* **2011**, *32*, 1139–1147. [\[CrossRef\]](http://doi.org/10.1016/j.biomaterials.2010.09.040)

- <span id="page-15-0"></span>64. Gao, Z.; Tang, D.; Tang, D.; Niessner, R.; Knopp, D. Target-induced nanocatalyst deactivation facilitated by core@shell nanostructures for signal-amplified headspace-colorimetric assay of dissolved hydrogen sulfide. *Anal. Chem.* **2015**, *87*, 10153–10160. [\[CrossRef\]](http://doi.org/10.1021/acs.analchem.5b03008)
- <span id="page-15-1"></span>65. Xia, X.; Zhang, J.; Lu, N.; Kim, M.J.; Ghale, K.; Xu, Y.; McKenzie, E.; Liu, J.; Ye, H. Pd–Ir core–shell nanocubes: A type of highly efficient and versatile peroxidase mimic. *ACS Nano* **2015**, *9*, 9994–10004. [\[CrossRef\]](http://doi.org/10.1021/acsnano.5b03525)
- 66. Liu, X.; Wang, Q.; Zhao, H.; Zhang, L.; Su, Y.; Lv, Y. BSA-templated MnO2 nanoparticles as both peroxidase and oxidase mimics. *Analyst* **2012**, *137*, 4552–4558. [\[CrossRef\]](http://doi.org/10.1039/c2an35700c)
- 67. Wan, S.; Wang, Q.; Ye, H.; Kim, M.J.; Xia, X. Pd–Ru bimetallic nanocrystals with a porous structure and their enhanced catalytic properties. *Part. Part. Syst. Charact.* **2018**, *35*, 1700386. [\[CrossRef\]](http://doi.org/10.1002/ppsc.201700386)
- 68. Ye, H.; Liu, Y.; Chhabra, A.; Lilla, E.; Xia, X. Polyvinylpyrrolidone (PVP)-capped Pt nanocubes with superior peroxidase-like activity. *ChemNanoMat* **2017**, *3*, 33–38. [\[CrossRef\]](http://doi.org/10.1002/cnma.201600268)
- <span id="page-15-2"></span>69. Davidson, E.; Xi, Z.; Gao, Z.; Xia, X. Ultrafast and sensitive colorimetric detection of ascorbic acid with Pd-Pt core-shell nanostructure as peroxidase mimic. *Sens. Int.* **2020**, *1*, 100031. [\[CrossRef\]](http://doi.org/10.1016/j.sintl.2020.100031)
- <span id="page-15-3"></span>70. Lim, B.; Jiang, M.; Camargo, P.H.C.; Cho, E.C.; Tao, J.; Lu, X.; Zhu, Y.; Xia, Y. Pd-Pt bimetallic nanodendrites with high activity for oxygen reduction. *Science* **2009**, *324*, 1302–1305. [\[CrossRef\]](http://doi.org/10.1126/science.1170377) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/19443738)
- <span id="page-15-4"></span>71. Avvakumova, S.; Colombo, M.; Galbiati, E.; Mazzucchelli, S.; Rotem, R.; Prosperi, D. Chapter 6—Bioengineered approaches for site orientation of peptide-based ligands of nanomaterials. In *Biomedical Applications of Functionalized Nanomaterials*; Sarmento, B., das Neves, J., Eds.; Elsevier: Amsterdam, The Netherlands, 2018; pp. 139–169.
- <span id="page-15-5"></span>72. Kuzuya, A.; Numajiri, K.; Kimura, M.; Komiyama, M. Single-molecule accommodation of streptavidin in nanometer-scale wells formed in DNA nanostructures. *Nucleic Acids Symp. Ser.* **2008**, *52*, 681–682. [\[CrossRef\]](http://doi.org/10.1093/nass/nrn344) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/18776563)
- <span id="page-15-6"></span>73. Bhattacharjee, S. DLS and zeta potential—What they are and what they are not? *J. Control. Release* **2016**, *235*, 337–351. [\[CrossRef\]](http://doi.org/10.1016/j.jconrel.2016.06.017)
- <span id="page-15-7"></span>74. Mukhopadhyay, A.; Joshi, N.; Chattopadhyay, K.; De, G. A facile synthesis of PEG-coated magnetite (Fe3O4) nanoparticles and their prevention of the reduction of cytochrome C. *ACS Appl. Mater. Interfaces* **2012**, *4*, 142–149. [\[CrossRef\]](http://doi.org/10.1021/am201166m) [\[PubMed\]](http://www.ncbi.nlm.nih.gov/pubmed/22111689)
- <span id="page-15-8"></span>75. Leopold, L.F.; Tódor, I.S.; Diaconeasa, Z.; Rugină, D.; ¸Stefancu, A.; Leopold, N.; Coman, C. Assessment of PEG and BSA-PEG gold nanoparticles cellular interaction. *Colloids Surf. A* **2017**, *532*, 70–76. [\[CrossRef\]](http://doi.org/10.1016/j.colsurfa.2017.06.061)
- <span id="page-15-9"></span>76. Wang, C.; Huang, C.; Gao, Z.; Shen, J.; He, J.; MacLachlan, A.; Ma, C.; Chang, Y.; Yang, W.; Cai, Y.; et al. Nanoplasmonic sandwich immunoassay for tumor-derived exosome detection and exosomal PD-L1 profiling. *ACS Sens.* **2021**, *6*, 3308–3319. [\[CrossRef\]](http://doi.org/10.1021/acssensors.1c01101)