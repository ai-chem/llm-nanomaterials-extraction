The image presents a series of microscopic and spectroscopic analyses of palladium (Pd) and platinum-palladium (Pt-Pd) nanocrystals (NCs). It is divided into six panels labeled a through f.

Panel a: Transmission electron microscopy (TEM) image of Pd NCs at 100 nm scale. The NCs appear as uniform square-shaped particles dispersed across the field. An inset shows a schematic representation of a Pd NC.

Panel b: Higher magnification TEM image of Pd NCs at 50 nm scale, providing a closer view of the square-shaped nanocrystals.

Panel c: Energy-dispersive X-ray spectroscopy (EDS) spectrum of Pd NCs. The x-axis represents energy in keV (0-12 keV range), and the y-axis represents counts in arbitrary units. A prominent peak for Pd is observed at approximately 2.8-3.0 keV. An inset TEM image at 50 nm scale shows the Pd NCs.

Panel d: TEM image of Pt-Pd core-shell NCs at 100 nm scale. The particles appear similar to those in panel a. An inset shows a schematic representation of a Pt-Pd core-shell NC, with Pd core surrounded by Pt shell.

Panel e: Higher magnification TEM image of Pt-Pd core-shell NCs at 50 nm scale, showing the square-shaped nanocrystals in greater detail.

Panel f: EDS spectrum of Pt-Pd core-shell NCs. The x-axis represents energy in keV (0-12 keV range), and the y-axis represents counts in arbitrary units. Two prominent peaks are observed: Pt at approximately 2.0-2.2 keV and Pd at 2.8-3.0 keV. Additional Pt peaks are visible at higher energies (around 9-11 keV). An inset TEM image at 50 nm scale shows the Pt-Pd core-shell NCs.

The images and spectra demonstrate the successful synthesis of Pd NCs and Pt-Pd core-shell NCs, confirming their morphology and elemental composition.