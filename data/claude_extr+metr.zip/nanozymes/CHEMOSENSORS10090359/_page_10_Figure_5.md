This image contains three graphs (a, b, and c) showing the results of ELISA (Enzyme-Linked Immunosorbent Assay) tests for detecting IL-6 (Interleukin-6) using different methods. Here's a detailed description of each graph:

Graph a:
This graph compares two ELISA methods: Pd@Pt ND ELISA and HRP ELISA. The x-axis represents the IL-6 concentration in pg mL^-1 on a logarithmic scale from 0.01 to 100. The y-axis shows the absorbance at 450 nm in arbitrary units (a.u.) from 0 to 3.5.

The Pd@Pt ND ELISA (blue squares) shows a sigmoidal curve with a steep increase in absorbance between 1 and 10 pg mL^-1 of IL-6, reaching a maximum absorbance of about 3.3 a.u. at 100 pg mL^-1.

The HRP ELISA (purple circles) shows a less steep curve, with absorbance increasing more gradually and reaching about 1.5 a.u. at 100 pg mL^-1.

Graph b:
This graph focuses on the Pd@Pt ND ELISA method at lower IL-6 concentrations. The x-axis shows IL-6 concentration from 0 to 2 pg mL^-1, and the y-axis shows absorbance at 450 nm from 0 to 0.8 a.u.

The graph includes a linear fit equation: y = 0.3525x + 0.0622, with an R^2 value of 0.999, indicating a strong linear relationship. The Limit of Detection (LOD) is reported as 0.044 pg mL^-1.

An inset illustration shows a schematic of the Pd@Pt ND (nanodendrimer) structure.

Graph c:
This graph shows the results for the HRP ELISA method at higher IL-6 concentrations. The x-axis represents IL-6 concentration from 0 to 50 pg mL^-1, and the y-axis shows absorbance at 450 nm from 0 to 1.0 a.u.

The graph includes a linear fit equation: y = 0.0170x + 0.0589, with an R^2 value of 0.999, indicating a strong linear relationship. The Limit of Detection (LOD) is reported as 0.915 pg mL^-1.

An inset illustration shows a schematic of the HRP (Horseradish Peroxidase) enzyme structure.

Overall, these graphs demonstrate that the Pd@Pt ND ELISA method has a lower detection limit and higher sensitivity for IL-6 detection compared to the traditional HRP ELISA method.