The image contains four graphs labeled a, b, c, and d, representing enzyme kinetics data for two different substrates: TMB (3,3',5,5'-tetramethylbenzidine) and hydrogen peroxide (H2O2).

Graph a: Michaelis-Menten plot for TMB
X-axis: TMB concentration (mM), range 0-0.8 mM
Y-axis: Reaction velocity v (10^-8 M s^-1), range 0-12
The plot shows a typical hyperbolic curve characteristic of Michaelis-Menten kinetics.

Graph b: Lineweaver-Burk plot for TMB
X-axis: 1/TMB concentration (mM^-1), range 0-50 mM^-1
Y-axis: 1/v (10^8 s M^-1), range 0-1.6
The plot shows a linear relationship with the equation:
y = 2,996,000x + 4,518,000
R^2 = 0.988
Km = 0.663 mM
kcat = 9.07 x 10^6 s^-1

Graph c: Michaelis-Menten plot for H2O2
X-axis: H2O2 concentration (M), range 0-7 M
Y-axis: Reaction velocity v (10^-8 M s^-1), range 0-12
The plot shows a hyperbolic curve similar to graph a, but with a different substrate concentration range.

Graph d: Lineweaver-Burk plot for H2O2
X-axis: 1/H2O2 concentration (M^-1), range 0-5 M^-1
Y-axis: 1/v (10^8 s M^-1), range 0-1.2
The plot shows a linear relationship with the equation:
y = 20,452,000x + 5,380,000
R^2 = 0.998
Km = 3.82 M
kcat = 7.62 x 10^6 s^-1

These graphs provide a comprehensive kinetic analysis of an enzyme's activity with two different substrates, TMB and H2O2. The Michaelis-Menten plots (a and c) show the relationship between substrate concentration and reaction velocity, while the Lineweaver-Burk plots (b and d) provide linearized data for easier determination of kinetic parameters Km and kcat.