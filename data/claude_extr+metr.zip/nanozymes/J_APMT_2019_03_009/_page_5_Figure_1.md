The image consists of two graphs, labeled A and B.

Graph A:
This is a line graph showing absorbance spectra. The x-axis represents wavelength in nanometers (nm), ranging from 500 to 800 nm. The y-axis represents absorbance, ranging from 0 to 0.5.

There are four spectral lines labeled (a), (b), (c), and (d):
(a) - The lowest intensity spectrum, peaking around 650 nm with a maximum absorbance of about 0.05.
(b) - The second lowest intensity spectrum, peaking around 650 nm with a maximum absorbance of about 0.07.
(c) - The second highest intensity spectrum, peaking around 650 nm with a maximum absorbance of about 0.11.
(d) - The highest intensity spectrum, peaking around 650 nm with a maximum absorbance of about 0.46.

All spectra show a broad peak centered around 650 nm, with lower absorbance at both shorter and longer wavelengths.

Graph B:
This is a bar graph showing absorbance percentages for different samples. The x-axis lists different samples, while the y-axis represents absorbance percentage, ranging from 0 to 100%.

The samples, from left to right, are:
1. CeO₂-nt
2. CeO₂
3. 3% CoO/CeO₂-mix
4. 3% CoO/CeO₂-pg
5. 3% CoO/CeO₂-nt
6. 5% CoO/CeO₂
7. 7% CoO/CeO₂

The absorbance percentages for each sample (approximate values):
1. CeO₂-nt: 17%
2. CeO₂: 23%
3. 3% CoO/CeO₂-mix: 30%
4. 3% CoO/CeO₂-pg: 39%
5. 3% CoO/CeO₂-nt: 40%
6. 5% CoO/CeO₂: 99%
7. 7% CoO/CeO₂: 70%

Error bars are visible on each bar, indicating some degree of uncertainty in the measurements.

The graph shows a general trend of increasing absorbance percentage with increasing CoO content, with the 5% CoO/CeO₂ sample showing the highest absorbance, followed by a slight decrease for the 7% CoO/CeO₂ sample.