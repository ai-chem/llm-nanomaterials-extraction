## RSC Advances

#### PAPER

Cite this: RSC Adv., 2019, 9, 18815

Received 22nd December 2018 Accepted 8th March 2019

DOI: 10.1039/c8ra05487h

rsc.li/rsc-advances

## Introduction

Nanozymes are a class of nanomaterials with intrinsic enzymelike activities.1–3 Over the last decade, a wide variety of nanomaterials have been reported to possess natural enzyme-like activities.1–5 The biochemical reactions catalyzed by these types of nanozymes exhibit similar enzymatic kinetics as in the case of natural enzymes. Nanozymes exhibit comparable enzymatic activity but with much higher stability and lower cost as compared to natural enzymes. In addition, their activities are tunable, and they can be easily integrated with nanosystems to achieve multifunctionality;6,7 therefore, nanozymes possess signicant potential for a wide range of applications in biomedicine such as in immunoassays, biosensors, and antibacterial and antibiolm agents.4,8,9

As a classical magnetic nanomaterial, iron oxide (Fe3O4) nanoparticles are the rst reported nanozyme with intrinsic peroxidase-like activity.10,11 Fe3O4 nanozymes with intrinsic magnetic properties have been extensively used for biological applications including magnetic resonance imaging, magnetic drug delivery, magnetic hyperthermia and magnetic separation.12–14 Based on its newly discovered catalytic properties, the Fe3O4 nanozyme can act as a multifunctional enzyme mimetic for versatile biomedical applications.12

# A cobalt-doped iron oxide nanozyme as a highly active peroxidase for renal tumor catalytic therapy† **[View Article Online](https://doi.org/10.1039/c8ra05487h) [View Journal](https://pubs.rsc.org/en/journals/journal/RA) [| View Issue](https://pubs.rsc.org/en/journals/journal/RA?issueid=RA009033)**

Yixuan Wang, a Hongjun Li,*b Lihua Guo,a Qi Jianga and Feng Liua

The Fe3O4 nanozyme, the first reported nanozyme with intrinsic peroxidase-like activity, has been successfully employed for various diagnostic applications. However, only a few studies have been reported on the therapeutic applications of the Fe3O4 nanozyme partly due to its low affinity to the substrate H2O2. Herein, we report a new strategy for improving the peroxidase-like activity and affinity of the Fe3O4 nanozyme to H2O2 to generate reactive oxygen species (ROS) for kidney tumor catalytic therapy. We showed that cobalt-doped Fe3O4 (Co@Fe3O4) nanozymes possessed stronger peroxidase activity and a 100-fold higher affinity to H2O2 than the Fe3O4 nanozymes. The lysosome localization properties of Co@Fe3O4 enable Co@Fe3O4 to catalyze the decomposition of H2O2 at ultralow doses for the generation of ROS bursts to effectively kill human renal tumor cells both in vitro and in vivo. Moreover, our study provides the first evidence that the Co@Fe3O4 nanozyme is a powerful nanozyme for the generation of ROS bursts upon the addition of H2O2 at ultralow doses, presenting a potential novel avenue for tumor nanozyme catalytic therapy.

> Recently, signicant efforts have been made to explore the feasibility of application of nanozymes in in vivo clinical diagnosis and therapy.9,15–18 As the rst well-studied nanozyme, Fe3O4 nanozymes have already been evaluated in tumor catalytic therapy for catalyzing the decomposition of hydrogen peroxide to generate ROS.16,19,20 However, because of the low affinity of the Fe3O4 nanozymes to H2O2, Fe3O4 nanozyme-based catalytic therapy typically requires an additional high dose of H2O2 (approximately 103 to 104 M);19,20 this makes this nanozyme-based catalytic tumor therapy strategy unviable for practical application.

> Some heterogeneous oxide nanomaterials, such as ZnFeO3 21 and NiFeO4 22, formed by iron and other metals have been reported to exhibit enhanced peroxidase-like behavior; this indicates that transition metal doping of Fe3O4 nanozymes may be an effective way to improve the enzymatic activity of these nanoenzymes;23 interestingly, Chen et al. have reported that Fe–Co bimetallic alloy nanoparticles also exhibit high peroxidase-like activity.24 Moreover, Vetr et al. have investigated the effect of transition metal (Co, Ni, and Zn) doping on the catalytic performance of Fe3O4 nanozymes. They have demonstrated that NiFe2O4 and ZnFe2O4 NPs exhibit lower catalytic activity as compared to CoFe2O4 NPs.25 Thus, doping of cobalt, a non-noble metal, into Fe3O4 nanozymes is a promising method to improve the peroxidaselike activity of Fe3O4 nanozymes; however, all these studies focus on the in vitro biosensing applications of metal-doped Fe3O4 nanozymes, and the applications of these nanozymes in tumor catalytic therapy have not been explored.

Open Access Article. Published on 17 June 2019. Downloaded on 6/18/2019 7:31:34 PM. This article is licensed under a [Creative Commons Attribution 3.0 Unported Licence.](http://creativecommons.org/licenses/by/3.0/)

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE</DESCRIPTION_FROM_IMAGE>

a Department of Nephrology, China-Japan Union Hospital of Jilin University, Changchun, 130033, China

b The Examination Center, China-Japan Union Hospital of Jilin University, Changchun, 130033, China. E-mail: lihongjun1960@126.com

<sup>†</sup> Electronic supplementary information (ESI) available. See DOI: 10.1039/c8ra05487h

RSC Advances Paper

In this study, we demonstrated that doping of Co into Fe3O4 nanozymes (Co@Fe3O4) resulted in not only excellent peroxidase-like activity, but also a 100-fold higher affinity of Co@Fe3O4 to H2O2 than that in the case of Fe3O4 nanozymes. By employing Co@Fe3O4 nanozymes, we successfully achieved effective antitumor activity with the addition of an ultralow dose (10 nM) of H2O2 both in vitro and in vivo. This study provides a promising strategy to enhance the peroxidase-like activity of the Fe3O4 nanozyme and achieves the purpose of Fe3O4 nanozyme based-renal tumor catalytic therapy. **[View Article Online](https://doi.org/10.1039/c8ra05487h)**

## Materials and methods

#### Materials

Chemicals and materials were supplied by Sigma-Aldrich (St. Louis, MO) unless otherwise specied.

#### Synthesis and characterization of the Fe3O4 and Co@Fe3O4 nanozymes

The Fe3O4 nanozymes and Co-doped Fe3O4 nanozymes were synthesized according to the solvothermal method reported in the literature10,26 with some modications. Briey, for the Fe3O4 nanozymes, FeCl3\$6H2O (0.82 g) was dissolved in 40 mL ethylene glycol. When the solution became clear, NaAc (3.6 g) was added under continuous vigorous stirring for 30 min. The mixture was sonicated for 10 min, then transferred to a 50 mL Teon-lined stainless-steel autoclave and reacted at 200 C for 12 h. Aer the reaction was completed, the autoclave was cooled down to room temperature. Then, the products obtained were washed several times with ethanol and dried at 60 C.

The Co@Fe3O4 nanozymes were also synthesized using the same procedure but extra Co(NO3)3\$6H2O (0.82 g) was added to the reaction system.

The morphology and structure of the Fe3O4 and Co@Fe3O4 nanozymes were characterized by transmission electron microscopy (TEM, JEOL JEM-1400 120 kV), scanning electron microscopy (SEM, Zeiss Supra55) and dynamic light scattering (DLS, DynaPro Titan). Energy dispersive X-ray spectroscopy (EDX) of the Fe3O4 and Co@Fe3O4 nanozymes was conducted using the Tecnai G2 F30 instrument. X-ray diffraction (XRD) measurements were performed using the X'Pert pro Philips X-ray powder diffractometer. X-ray photoelectron spectroscopy (XPS) was performed by the ESCALab220i-XL high-performance electron spectrometer with a monochromatic Al Ka source.

#### Kinetic analysis of the Fe3O4 and Co@Fe3O4 nanozymes

The kinetic parameters of the Fe3O4 and Co@Fe3O4 nanozymes were determined by monitoring the absorbance change at 652 nm using the iMark™ Microplate Reader (Bio-Rad, USA) in the time course mode at room temperature. Kinetic assays were carried out using the Fe3O4 nanozymes (0.2 mg) or Co@Fe3O4 nanozymes (0.2 mg) in a 100 mL of reaction buffer (0.2 M NaAc buffer, pH 4.5) in the presence of H2O2 and TMB. The kinetic analysis of Fe3O4 and Co@Fe3O4 with H2O2 as the substrate was performed by varying the concentrations of H2O2 with 0.8 mM TMB and vice versa. The absorbance (652 nm) changes were calculated relative to the changes in the molar concentration of TMB using the molar absorption coefficient of 39 000 M1 cm1 for the TMBderived oxidation products according to the Beer–Lambert law.27 All the measurements were performed at least in triplicate, and the values were then averaged. The results are provided as mean the standard deviation (SD). The Michaelis–Menten constant was calculated using the Lineweaver–Burk plots of the double reciprocal of the Michaelis– Menten equation n ¼ Vmax [S]/(KM + [S]) by GraphPad Prism 6.02 (GraphPad Soware), where n is the initial velocity, Vmax is the maximal reaction velocity, [S] is the concentration of the substrate and KM is the Michaelis–Menten constant.

#### ESR spectroscopy measurements

The ESR measurements were carried out using a Bruker electron spin resonance (ESR) spectrometer (A300-10/12, Germany) at ambient temperature. Herein, y microliter aliquots of the control or sample solutions were put in glass capillary tubes with the internal diameters of 1 mm and sealed. The capillary tubes were then inserted into the ESR cavity, and the spectra were obtained at selected times. The instrument settings are as follows: 1 G eld modulation, 100 G scan range, and a 20 mW microwave power for the detection of spin adducts using spin traps. The spin trap BMPO was employed to verify the formation of hydroxyl radicals (OHc) during the degradation of H2O2 in the presence of the Fe3O4 or Co@Fe3O4 nanozymes under the same conditions. The amount of hydroxyl radicals was quantitatively estimated by the ESR signal intensity of the hydroxyl radical spin adduct (BMPO/OHc) using the peak-to-peak height of the second line of the ESR spectrum.

#### Cell viability assay

The cytotoxicity of the Fe3O4 and Co@Fe3O4 nanozymes with the addition of 10 nM H2O2 was determined using the CCK-8 cell viability assay kit (Dojindo Molecular Technologies). Briey, A-498 cells (Human renal cancer cell, ATCC, HTB-44) were plated in 96-well plates (BD Biosciences) with the density of 5 103 cells per well and cultured in 100 mL EMEM (Catalog No. 30-2003) for 1 day before the addition of Fe3O4,Co@Fe3O4 nanozymes, or only the buffer as a control. On each plate, blank wells (n ¼ 6) with media were dened as 0% viability. Moreover, the wells with only PBS-treated cells (n ¼ 6) were dened as 100% viability. The dilutions of the Fe3O4 and Co@Fe3O4 nanozymes were prepared using a buffer containing 10 nM H2O2. The cells were then exposed to the Fe3O4 or Co@Fe3O4 nanozymes at a series of concentrations (from 0 to 0.2 mg mL1 ) for 24 hours. Aer stimulation, a 10 mL CCK-8 solution was added to each well. The plates were then incubated for 4 h at 37 C. Aer this, the absorbance was determined at 450 nm using the Benchmark Plus microplate spectrophotometer (Bio-Rad Laboratories, Inc.). The results presented herein are the average of those obtained via three independent experiments.

The cellular uptake and distribution of Fe3O4 or Co@Fe3O4 nanozymes in human renal tumor cells were investigated by a confocal laser scanning microscope. Briey, the A-498 cells were plated on poly-L-lysine-treated coverslips (BD Biosciences) and cultured in a six-well plate (Corning) for 12 h before use. Aer stimulation for 48 h with the Alexa-488 labeled Fe3O4 or Co@Fe3O4 nanozymes (0.2 mg mL1 ), the cells were washed with PBS, xed in 4% cold formaldehyde in PBS for 5 min, and then permeabilized with 0.1% Triton X-100. Aer being washed with PBS, the cells were blocked in a 5% normal goat serum for 30 min at room temperature. To visualize the lysosomes, the cells were incubated with anti-Lamp1 mAb (1 : 200, clone H4A3; Invitrogen) at 37 C for 1 h. The cells were then washed three times with PBS and incubated with goat anti-mouse IgG1 conjugated with Alexa-555 (1 : 500; Invitrogen) for 1 h at 37 C. Finally, the nuclei of the cells were stained with 40 ,60 -diamidino-2-phenylindole (DAPI, 1 mg mL1 , Roche Applied Science) for 10 min at room temperature. The samples were examined using a confocal laser scanning microscope (Olympus FluoView FV-1000, Tokyo, Japan). **[View Article Online](https://doi.org/10.1039/c8ra05487h)**

#### Intracellular ROS assay

The uorescent probe 20 ,70 -dichlorouorescin diacetate (H2DCFDA, Sigma-Aldrich, D6883) was used to measure the intracellular generation of ROS by the Fe3O4 or Co@Fe3O4 nanozymes. Briey, the conuent A-498 cells on the coverslips (BD Biosciences) were incubated with Fe3O4 or Co@Fe3O4 nanozymes (0.2 mg mL1 ) for 4 hours. Aer being washed with PBS, the cells were incubated with 10 mM H2DCFDA in a serumfree DMEM for 20 min at 37 C in the dark. The uorescence intensities of H2DCFDA were measured by a confocal laser scanning microscope (Olympus FluoView FV-1000, Tokyo, Japan).

#### Apoptosis analysis

The apoptosis analysis of the treated tumor cells was conducted by PI and annexin V staining and ow cytometry (FACSCaliburTM, Becton Dickinson, Franklin Lakes, NJ, USA). Briey, the Fe3O4 and Co@Fe3O4 (0.2 mg mL1 ) nanozymes were incubated with the A-498 tumor cell lines for 24 h. Aer trypsinization, the treated A-498 tumor cells were incubated with annexin V and PI for 15 min to achieve nuclear staining. Aer this, the cells were xed and incubated with streptavidin-uorescein (5 mg mL1 ) (Sigma, USA) for 15 min. Cell death was evaluated by the quantication of annexin-stained apoptotic cells and PI-stained necrotic cells using ow cytometry.

#### Therapy studies

Herein, eighteen female BALB/c nude mice bearing A-498 tumors were randomly assigned to four groups (n ¼ 6 mice per group). All the mice were intratumorally treated with a single dose of Fe3O4 and Co@Fe3O4 nanozymes (3 mg mL1 , 100 mL) with 10 nM H2O2 when the diameter of the tumors was about 100 mm3 . For the controls, PBS was administered. The tumor size was measured 3 times a week. The tumor size was calculated as volume [mm3 ] ¼ length width2 p/6. The measured values are presented as mean SD.

### Results

#### Characterization of the Co@Fe3O4 nanozymes

The Fe3O4 nanozymes and Co-doped Fe3O4 nanozymes (Co@Fe3O4) used in this study were synthesized by the solvothermal method. To study the composition of the asprepared nanozymes, the EDX analysis was performed. As shown in Fig. S1,† the EDX spectrum of the Co@Fe3O4 nanozymes indicated that the Fe and Co elements were present in the nanoparticles. Based on the EDX mapping analysis, the content of Fe and Co in the Co@Fe3O4 nanozymes were determined as 33.48% and 16.23%, respectively (Table S1†). In conclusion, herein, the synthesized Co@Fe3O4 nanozymes contained Fe and Co with the ratio of approximately 2 : 1; this conrmed that Co was successfully doped into the Fe3O4 nanozymes by the simple solvothermal method.

To characterize the structure of the Co@Fe3O4 nanozymes, TEM, SEM, DLS and X-ray diffraction (XRD) analysis were performed. The TEM images of the as-prepared Fe3O4 and Co@Fe3O4 nanozymes are shown in Fig. 1A and B, respectively. The SEM images of the Fe3O4 and Co@Fe3O4 nanozymes are presented in Fig. S2A and B,† respectively. The results indicate that the Fe3O4 and Co@Fe3O4 nanozymes present a typical spherical morphology. The average size of the Fe3O4 nanozymes was determined to be 89.8 7.9 nm by the TEM images, whereas that of the Co@Fe3O4 nanozymes was determined to be 94.6 8.6 nm. Moreover, the Fe3O4 and Co@Fe3O4 nanozymes exhibited the average size of 90.31 0.62 nm and 95.82 3.57 nm in solution (Fig. S2C and D†), respectively. The XRD patterns of the asprepared nanozymes are shown in Fig. 1C and D, which indicate that both the Fe3O4 and Co@Fe3O4 nanozymes are well crystallized. Moreover, each characteristic diffraction peak of the Co@Fe3O4 nanozymes was similar to that of the Fe3O4 nanozymes and the standard PDF card of Fe3O4 (JCPDS card no. 19-0629); this indicated that Co-doping of the Fe3O4 nanozymes did not affect the phase pattern of Fe3O4.

To characterize the oxidation state of cobalt in the Co@Fe3O4 nanozyme, we further performed XPS analysis of the as-prepared Co@Fe3O4 nanozyme. The high-resolution XPS spectrum of Co 2p is shown in Fig. 2A. The Co 2p XPS peak at 780.8 eV was assigned to Co (2p3/2), with a shake-up satellite peak at 785.9 eV. In addition, the Co 2p XPS peak at 797.2 eV was attributed to Co (2p1/2), with a satellite peak at 803.0 eV.28 These characteristic and satellites peaks conrm that Co2+ is present in the Co@Fe3O4 nanozyme. Moreover, as shown in Fig. 2B, the Fe 2p XPS spectrum exhibited characteristic peaks with the binding energy values at 711.0 and 724.0 eV, assigned to the Fe (2p3/2) and Fe (2p1/2) peaks,29 respectively. Since the atomic radius of iron (140 pm) is

<DESCRIPTION_FROM_IMAGE>The image contains four panels labeled A, B, C, and D.

Panel A: Transmission electron microscopy (TEM) image of nanoparticles. The main image shows a distribution of spherical nanoparticles with varying degrees of aggregation. The scale bar indicates 500 nm. An inset image in the upper right corner shows a closer view of the nanoparticles, revealing their rough surface texture. The inset scale bar is 50 nm.

Panel B: Another TEM image of nanoparticles, similar to Panel A but with a different distribution. The nanoparticles appear more evenly dispersed across the field of view. The main image has a 500 nm scale bar, and the inset image in the upper right corner has a 50 nm scale bar, showing a closer view of the nanoparticle surface texture.

Panel C: X-ray diffraction (XRD) pattern. The graph shows intensity (in arbitrary units, a.u.) on the y-axis versus 2θ (in degrees) on the x-axis. The x-axis ranges from 0 to 100 degrees. The pattern displays several peaks, with the most intense peak at approximately 38 degrees 2θ. Other notable peaks are observed around 20, 30, 45, 65, and 78 degrees 2θ.

Panel D: Another XRD pattern with the same axis labels and ranges as Panel C. This pattern shows similarities to Panel C but with some differences in peak intensities. The most intense peak is still around 38 degrees 2θ, but the relative intensities of other peaks, particularly those around 30 and 45 degrees 2θ, appear to be different compared to Panel C.

These images likely represent a study of nanoparticle synthesis and characterization, comparing two different samples or synthesis conditions (A vs B, and C vs D) in terms of their morphology (TEM images) and crystal structure (XRD patterns).</DESCRIPTION_FROM_IMAGE>

Fig. 1 TEM images and XRD diffraction patterns of the Fe3O4 (A and C) and Co@Fe3O4 nanozymes (B and D), respectively.

<DESCRIPTION_FROM_IMAGE>The image contains two X-ray photoelectron spectroscopy (XPS) graphs labeled A and B.

Graph A:
This graph shows the XPS spectrum for cobalt (Co). The x-axis represents binding energy in electron volts (eV) ranging from 810 to 770 eV. The y-axis shows intensity in arbitrary units (a.u.) from 20000 to 40000. 

The spectrum is deconvoluted into several peaks:
1. Co 2p3/2 peak at around 780 eV
2. Co 2p1/2 peak at about 795 eV
3. Satellite peaks for both Co 2p3/2 and Co 2p1/2
4. Shakeup satellites

The peaks are further resolved into contributions from different oxidation states of cobalt:
- Co(II) (red peaks)
- Co(III) (blue peaks)

The green line represents shakeup satellites.

Graph B:
This graph displays the XPS spectrum for iron (Fe). The x-axis shows binding energy in eV, ranging from 740 to 700 eV. The y-axis represents intensity in arbitrary units, from 0 to 30000.

Two main peaks are visible:
1. Fe 2p3/2 peak at approximately 710 eV
2. Fe 2p1/2 peak at about 724 eV

The spectrum is not deconvoluted or fitted, showing only the raw data.

These XPS spectra provide information about the electronic states of cobalt and iron in the analyzed sample, including oxidation states for cobalt and the presence of iron.</DESCRIPTION_FROM_IMAGE>

Fig. 2 XPS spectra of the Co@Fe3O4 nanozyme. (A) The Co 2p XPS spectrum of the Co@Fe3O4 nanozyme. (B) The Fe 2p XPS spectrum of the Co@Fe3O4 nanozyme.

similar to that of the cobalt atom (135 pm), these results suggest that the cobalt atoms are probably located only at the lattice positions of the Fe3O4 crystal structure.

#### Peroxidase-like activity and steady-state kinetic assay of the Co@Fe3O4 nanozymes

To directly compare the peroxidase-like activity of the Fe3O4 and Co@Fe3O4 nanozymes, we performed typical catalytic experiments using the peroxidase substrate 3,30 ,5,50 -tetramethylbenzidine (TMB) and H2O2 as previously reported.11 The results showed that both the Fe3O4 and Co@Fe3O4 nanozymes catalyzed the oxidation of TMB with H2O2 to produce blue color products with absorption at 652 nm (Fig. 3A). Moreover, the results demonstrated that the Co@Fe3O4 nanozymes exhibited a signicant improvement in the peroxidase-like activity as compared to the Fe3O4 nanozymes; this indicated that a signicant improvement in the nanozyme activity was achieved by Co doping of the Fe3O4 nanozymes.

The mechanism of action of the Co@Fe3O4 nanozymes was investigated using the ESR method. As shown in Fig. 3B, similar to the previously reported Fe3O4 nanozymes, the Co@Fe3O4 nanozymes signicantly enhanced the generation

<DESCRIPTION_FROM_IMAGE>The image contains four panels labeled A, B, C, and D, each presenting different data related to nanozyme activity.

Panel A: Graph showing the optical density (OD) at 652 nm over reaction time (0-10 minutes) for three conditions:
1. Co@Fe3O4 nanozyme: Shows the highest increase in OD, reaching about 1.2 at 10 minutes.
2. Fe3O4 nanozyme: Shows a moderate increase in OD, reaching about 0.5 at 10 minutes.
3. Buffer: Shows no significant change in OD, remaining close to 0 throughout.

Panel B: Electron Paramagnetic Resonance (EPR) spectra for three conditions:
1. Co@Fe3O4 NPs + H2O2 + DMPO: Shows the highest intensity peaks.
2. Fe3O4 nanozyme + H2O2 + DMPO: Shows moderate intensity peaks.
3. H2O2 + DMPO: Shows minimal signal.
The magnetic field range is from 3440 to 3520 Gauss.

Panel C: Graph showing the reaction velocity (v) in mM/s against TMB concentration (0-800 μM) for:
1. Co@Fe3O4 nanozyme: Shows a steeper increase, reaching about 0.0018 mM/s at 800 μM TMB.
2. Fe3O4 nanozyme: Shows a more gradual increase, reaching about 0.0009 mM/s at 800 μM TMB.

Panel D: Graph showing the reaction velocity (v) in mM/s against H2O2 concentration (0-0.6 M) for:
1. Co@Fe3O4 nanozyme: Shows a rapid initial increase, reaching a plateau around 0.0011 mM/s.
2. Fe3O4 nanozyme: Shows a slower increase, reaching about 0.0007 mM/s at 0.6 M H2O2.

All panels consistently demonstrate that the Co@Fe3O4 nanozyme exhibits higher activity compared to the Fe3O4 nanozyme across various experimental conditions and measurements.</DESCRIPTION_FROM_IMAGE>

Fig. 3 Steady-state kinetic assay and the catalytic mechanism study for the Fe3O4 and Co@ Fe3O4 nanozymes. (A) Comparison between the peroxidase-like activities of the Fe3O4 and Co@Fe3O4 nanozymes. (B) ESR detection of the hydroxyl radical generation during the catalytic reactions of the Fe3O4 and the Co@Fe3O4 nanozymes. (C–D) Kinetic assay of Fe3O4 and Co@Fe3O4 nanozymes with TMB (C) or H2O2 (D). For C, the concentration of H2O2 was 100 mM, whereas the TMB concentration varied. For (D), the concentration of TMB was 0.8 mM, whereas the H2O2 concentration varied.

of hydroxyl radicals under acidic conditions. Importantly, the Co@Fe3O4 nanozymes generated more hydroxyl radicals than the Fe3O4 nanozymes under the same conditions; this further conrmed that Co doping signicantly improved the peroxidase-like activity of the Fe3O4 nanozymes.

To obtain the apparent kinetic parameters of the Co@Fe3O4 nanozymes, the Michaelis–Menten experiments were performed. Fig. 3C and D show the typical kinetics for TMB and H2O2, respectively. The apparent Michaelis–Menten constant (KM) and the maximum initial reaction rate (Vmax) of the Co@Fe3O4 and Fe3O4 nanozymes were calculated. Moreover, these kinetic parameters of the Co@Fe3O4 nanozymes

Table 1 Comparison between the apparent Michaelis–Menten constants (KM) and maximum initial reaction rates (Vmax) of the Fe3O4, Co@Fe3O4, Co3O4 nanozymes and horseradish peroxidase (HRP) enzymes

|                                   | KM (mM)                        |                              | Vmax<br>(108 M1 s1<br>)       |                               |                                    |
|-----------------------------------|--------------------------------|------------------------------|-------------------------------|-------------------------------|------------------------------------|
| Nanozyme                          | H2O2                           | TMB                          | H2O2                          | TMB                           | References                         |
| Co@Fe3O4<br>Fe3O4<br>Co3O4<br>HRP | 0.19<br>56.89<br>1.14<br>10.35 | 1.17<br>1.06<br>5.09<br>3.95 | 71.5<br>59.6<br>1.72<br>0.689 | 37.9<br>16.8<br>9.98<br>37.65 | This work<br>This work<br>24<br>11 |

were compared with those of the Fe3O4 and Co3O4 nanozymes and the natural enzyme HRP (Table 1). The Fe3O4 nanozymes typically exhibited low affinity to H2O2. The KM value to H2O2 for the Co@Fe3O4 nanozymes was much lower than that for the Fe3O4 and Co3O4 nanozymes; this indicated that there was a signicant improvement in the affinity of the nanozymes towards substrates aer Co doping. More importantly, the KM value to H2O2 for Co@Fe3O4 was nearly 50-fold and 100-fold lower than that of the HRP enzyme and the Fe3O4 nanozymes, respectively; this demonstrated that the Co@Fe3O4 nanozymes exhibited much higher affinity to H2O2 than HRP and the other nanozymes. The Vmax values to H2O2 for the Co@Fe3O4 nanozymes were also signicantly improved.

#### Anti-tumor activities and mechanistic study of the Co@Fe3O4 nanozymes

Tumor cells typically possess higher levels of endogenous H2O2 and reactive oxygen species (ROS) than normal cells.9,20 The balance of the ROS determines the fate of the tumor cells. It has been previously shown that stimulation of ROS is a common strategy for cancer chemotherapy.30,31 Thus, we employed the Co@Fe3O4 nanozymes to trigger the burst of ROS to kill the tumor cells.

Fe3O4 nanozymes, as the rst well-studied nanozyme, have already been evaluated in tumor catalytic therapy for

catalyzing the decomposition of hydrogen peroxide to generate ROS.19,20 However, because of the low affinity of these nanozymes to H2O2, the Fe3O4 nanozyme-based catalytic therapy typically requires additional high doses of H2O2 (approximately 103 to 104 M);19,20 this makes this nanozyme-based catalytic tumor therapy strategy unfeasible for practical application. In this study, we demonstrated that the Co@Fe3O4 nanozymes exhibited a 100-fold higher affinity to H2O2 than the Fe3O4 nanozymes. Therefore, we next evaluated the catalytic antitumor activity of the Co@Fe3O4 nanozymes with ultra-low doses of H2O2. **[View Article Online](https://doi.org/10.1039/c8ra05487h)**

Considering that the typically used concentration of H2O2 is around 103 to 104 M, we have tried to use 10 nM (108 M) H2O2 to evaluate the antitumor activities of the Co@Fe3O4 nanozymes. As shown in Fig. 4A, the buffer group containing 10 nM H2O2 exhibited no signicant toxicity to kidney cancer cells; this indicated that the tumor cells were able to survive at 10 nM H2O2. Aer incubation with 0.2 mg mL1 Fe3O4 nanozymes and 10 nM H2O2 for 24 hours, only less than 20% tumor cells were killed. These results are consistent with the previously reported results. Only a high dose of H2O2 allows the Fe3O4 nanozymes to effectively kill tumor cells. In the case of the Co@Fe3O4 nanozymes, 0.02 mg mL1 Co@Fe3O4 nanozymes with 10 nM H2O2 achieved similar antitumor activities as 0.2 mg mL1 Fe3O4 nanozymes. Moreover, 0.2 mg

mL1 Co@Fe3O4 nanozymes and 10 nM H2O2 killed more than 60% of the tumor cells within 24 hours. Thus, the Co@Fe3O4 nanozymes effectively killed tumor cells with the addition of H2O2 at ultralow doses.

As is well-known, the Fe3O4 nanozymes exhibit peroxidase-like activity only under acidic conditions.12 Since the Co@Fe3O4 nanozymes exhibit signicant antitumor activity, we infer that the Co@Fe3O4 nanozymes localize in the lysosome (pH 4–5) aer incubation with the tumor cells. To verify this hypothesis, we labeled the nanozymes with Alexa Fluor 488 to track their intracellular localization. As shown in Fig. 4B, we found that aer incubation with tumor cells for 4 hours, most of the internalized Fe3O4 nanozymes co-localized with lysosomes. Similar to the Fe3O4 nanozymes, nearly all of the internalized Co@Fe3O4 nanozymes localized in the lysosomes, the highly acidic microenvironment of which would favor the peroxidase-like activities. Thus, the colocalization analysis of the nanozymes and lysosomes demonstrated that the nanozyme-based tumor catalytic therapy strategy is feasible.

In our hypothesis, the antitumor activities of the Co@Fe3O4 nanozymes are attributed to the catalytic generation of ROS by the decomposition of hydrogen peroxide, resulting in oxidative stress in the tumor cells. To verify this hypothesis, the intracellular ROS levels in the tumor cells

<DESCRIPTION_FROM_IMAGE>The image contains four panels labeled A, B, C, and D, each presenting different aspects of a study on Fe3O4 and Co@Fe3O4 nanozymes.

Panel A: Graph showing cell viability (%) vs concentration (mg/ml) for three conditions:
1. Buffer (control): Maintains ~100% viability across all concentrations.
2. Fe3O4 nanozyme: Shows decreasing viability from ~100% to ~80% as concentration increases.
3. Co@Fe3O4 nanozyme: Exhibits the most significant decrease in viability, dropping from ~100% to ~40% as concentration increases from 0 to 0.20 mg/ml.

Panel B: Microscopy images showing intracellular localization of nanozymes:
1. Fe3O4 nanozyme: Shows colocalization with lysosomes.
2. Co@Fe3O4 nanozyme: Also demonstrates colocalization with lysosomes.
Both nanozymes appear to accumulate within lysosomal compartments.

Panel C: Fluorescence microscopy images of:
1. Buffer (control): No visible fluorescence.
2. Fe3O4 nanozyme: Shows discrete fluorescent spots.
3. Co@Fe3O4 nanozyme: Displays larger and brighter fluorescent spots compared to Fe3O4 nanozyme.

Panel D: Flow cytometry scatter plots of PI (y-axis) vs Annexin V (x-axis) for:
1. Fe3O4 nanozyme: 
   Q3-1 (top-left): 0.05%
   Q3-2 (top-right): 12.73%
   Q3-3 (bottom-left): 30.55%
   Q3-4 (bottom-right): 56.67%

2. Co@Fe3O4 nanozyme:
   Q3-1 (top-left): 0.07%
   Q3-2 (top-right): 50.29%
   Q3-3 (bottom-left): 4.54%
   Q3-4 (bottom-right): 45.10%

The flow cytometry data suggests that Co@Fe3O4 nanozyme induces more cell death (higher percentage in Q3-2) compared to Fe3O4 nanozyme.

Overall, the image demonstrates that Co@Fe3O4 nanozyme has a more potent effect on cell viability, intracellular accumulation, and cell death induction compared to Fe3O4 nanozyme.</DESCRIPTION_FROM_IMAGE>

Fig. 4 The antitumor cell activities and mechanistic study of the Fe3O4 and Co@Fe3O4 nanozymes in vitro. (A) Cell viability of the human renal cancer cells A-498 incubated with the Fe3O4 and Co@Fe3O4 nanozymes. The buffer contained 10 nM H2O2. (B) Localization of the Fe3O4 and Co@Fe3O4 nanozymes in the A-498 cells. (C) The ROS level in the A-498 cells after stimulation with nanozymes and 10 nM H2O2. Scale bar ¼ 20 mm. (D) Apoptosis analysis of the A-498 cells after incubation with nanozymes and 10 nM H2O2.

were detected by employing 20 ,70 -dichlorouorescein diacetate (H2DCFDA), a typical ROS uorescent dye. As shown in Fig. 4C, the tumor cells treated with only 10 nM H2O2 exhibited no signicant ROS signal. Aer incubation with the Fe3O4 nanozymes and 10 nM H2O2, the green uorescence intensity increased. In contrast, the tumor cells treated with the Co@Fe3O4 nanozymes and 10 nM H2O2 presented strong green uorescence intensity, indicating that the Co@Fe3O4 nanozymes catalyzed the decomposition of H2O2 to generate an ROS burst to cause cell apoptosis. As shown in Fig. 4D, the tumor cells treated with the Co@Fe3O4 nanozymes and 10 nM H2O2 exhibited a signicant apoptosis pattern. When the tumor cells were stimulated with the nanozymes at same concentration, the apoptosis induced by the Co@Fe3O4 nanozymes in the tumor cells was 4-fold higher than that of the Fe3O4 nanozymes. **[View Article Online](https://doi.org/10.1039/c8ra05487h)**

To further evaluate the antitumor activity of the Co@Fe3O4 nanozymes in vivo, we employed the human renal cancer cell A-498 xenogra in nude mice as a tumor model. The Fe3O4 nanozymes and Co@Fe3O4 nanozymes were intratumorally injected at the dose of 0.3 mg in 100 mL PBS and 10 nM H2O2 when the tumor volume reached 100 mm3 . Aer this, the tumor volumes were determined 3 times a week. As shown in Fig. 5, the Co@Fe3O4 nanozyme-treated mice exhibited signicant tumor inhibition aer Co@Fe3O4 administration, whereas the Fe3O4 nanozyme-treated mice exhibited only slight tumor inhibition when compared with the PBS-treated mice. Thus, the Co@Fe3O4 nanozymes exhibited excellent in vivo renal tumor catalytic therapy activity, whereas the Fe3O4 nanozymes only partially inhibited the renal tumor growth due to their relative low peroxidase activity and low binding affinity to H2O2; 11 this was consistent with previous studies.9

Overall, these results provide strong evidence that the Co@Fe3O4 nanozymes possess the ability to regulate intracellular ROS upon the addition of H2O2 at ultralow concentrations. Once located in the acidic microenvironment of lysosomes, these nanozymes induce cell death by boosting the level of ROS. The Co@Fe3O4 nanozymes exhibited signicant antitumor activities against human renal tumor both in vitro and in vivo.

<DESCRIPTION_FROM_IMAGE>This image shows a graph depicting tumor volume growth over time after therapy for three different treatment groups. The x-axis represents "Days after therapy" ranging from 0 to 12 days. The y-axis shows "Tumor Volume (mm³)" ranging from 0 to 1000 mm³.

Three treatment groups are compared:
1. PBS (Phosphate-buffered saline), represented by circles
2. Fe₃O₄ nanozyme, represented by squares
3. Co@Fe₃O₄ nanozyme, represented by triangles

The graph shows the following trends:

1. PBS group: Exhibits rapid tumor growth, reaching about 600 mm³ by day 9.
2. Fe₃O₄ nanozyme group: Shows moderate tumor growth, reaching about 450 mm³ by day 9.
3. Co@Fe₃O₄ nanozyme group: Demonstrates the least tumor growth, maintaining a volume around 200 mm³ throughout the 9-day period.

Error bars are included for each data point, likely representing standard deviation or standard error.

The graph includes a statistical significance indicator (NS, likely meaning "not significant") between the PBS and Fe₃O₄ nanozyme groups, and a "***" indicator (likely indicating p < 0.001) between these groups and the Co@Fe₃O₄ nanozyme group.

This graph suggests that the Co@Fe₃O₄ nanozyme treatment is significantly more effective at inhibiting tumor growth compared to both PBS and Fe₃O₄ nanozyme treatments.</DESCRIPTION_FROM_IMAGE>

Fig. 5 Antitumor activities of the Fe3O4 and Co@Fe3O4 nanozymes in vivo. n ¼ 6, ***p < 0.001, NS, no significance, unpaired Student's t test on day 9.

## Discussion and conclusion

ROS-induced apoptosis is a popular strategy for cancer therapy.32–34 The tumor therapy strategies utilizing nanozymes mainly act by stimulating the production of ROS.9 The Fe3O4 nanozymes can simulate peroxidase and thereby efficiently catalyze the decomposition of H2O2 to generate ROS to inhibit tumors in vivo. However, the low binding affinity of the Fe3O4 nanozyme to H2O2 and its relatively low catalytic activity limit the development of the Fe3O4 nanozyme-based tumor catalytic therapy.

Transition metal doping has been demonstrated to be an effective and easy way to improve the peroxidase-like activity of Fe3O4 nanozymes.23 Among the transition metals, cobalt, a nonnoble metal, has been proven to be a promising dopant to enhance the enzymatic activity of the Fe3O4 nanozyme.25 Importantly, Chen et al. have systematically studied the effects of doping Fe/Co at different ratios on the enzymatic activity of the Fe3O4 nanozyme. They have demonstrated that when the ratio of Fe/Co is around 2 : 1, the peroxidase-like activity of the Co-doped Fe3O4 nanozyme is the best enzymatic activity.24 In this study, by employing a simple solvothermal method, we fabricated the Co@Fe3O4 nanozyme with the ratio of Fe/Co around 2 : 1. Compared with the case of other strategies, including metal doping, biomimetic coating, and C-dot modi cation methods, that signicantly improved the peroxidaselike activity of the Fe3O4 nanozyme, our Co@Fe3O4 nanozyme exhibited the best binding affinity to H2O2 (Table S2†).

The XPS and EDX analysis of the Co@Fe3O4 nanozyme demonstrated that the cobalt atoms were probably located only at the lattice positions of the Fe3O4 crystal structure. Although the Co atom possesses a similar size as the Fe atom, the Co atoms doped into the Fe3O4 crystal may still slightly change the surface physical environment,35 resulting in an improved binding affinity of the nanozyme to H2O2. In addition, the Co dopant may produce more catalytically active sites and substrate-binding sites on the surface of the Co@Fe3O4 nanozyme when compared with the case of the Fe3O4 nanozyme.36 Moreover, the higher redox potential of Co3+/Co2+ (1.30 V) as compared to that of Fe3+/Fe2+ (0.771 V) in the Fe3O4 nanozyme may be another reason for the improvement in the peroxidaselike activities of Co@Fe3O4. 37,38

In conclusion, using a simple solvothermal method, we successfully synthesized Co-doped Fe3O4 (Co@Fe3O4) nanozymes that contained Fe and Co at the ratio of approximately 2 : 1. The well-crystallized Co@Fe3O4 nanozymes exhibited excellent peroxidase-like activity. More importantly, Co doping makes the Co@Fe3O4 nanozymes exhibit a 50-fold and 100-fold higher affinity to H2O2 than that of the HRP and Fe3O4 nanozymes, respectively. The improvement of the H2O2 affinity renders the Co@Fe3O4 nanozymes with excellent antitumor activity upon the addition of H2O2 at ultralow concentrations. When the Co@Fe3O4 nanozymes with enhanced peroxidase-like activities are specically located in the acidic microenvironment of the lysosomes, they induce apoptosis of human renal tumor cells (A-498) by catalyzing the decomposition of H2O2 to

generate an ROS burst. Importantly, the Co@Fe3O4 nanozymes exhibited excellent antitumor activities both in vitro and in vivo for kidney tumor catalytic therapy. **[View Article Online](https://doi.org/10.1039/c8ra05487h)**

## Conflicts of interest

There are no conicts to declare.

### References

- 1 H. Wei and E. K. Wang, Chem. Soc. Rev., 2013, 42, 6060–6093.
- 2 Y. H. Lin, J. S. Ren and X. G. Qu, Acc. Chem. Res., 2014, 47, 1097–1105.
- 3 R. Ragg, M. N. Tahir and W. Tremel, Eur. J. Inorg. Chem., 2016, 1906–1915, DOI: 10.1002/ejic.201501237.
- 4 X. Y. Wang, Y. H. Hu and H. Wei, Inorg. Chem. Front., 2016, 3, 41–60.
- 5 H. Y. Shin, T. J. Park and M. I. Kim, J. Nanomater., 2015, 756278.
- 6 Z. Zhang, X. Zhang, B. Liu and J. Liu, J. Am. Chem. Soc., 2017, 139, 5412–5419.
- 7 B. W. Liu and J. W. Liu, Nano Res., 2017, 10, 1125–1148.
- 8 K. F. Xiangqin Meng, Prog. Biochem. Biophys., 2018, 45, 218– 236.
- 9 K. Fan, J. Xi, L. Fan, P. Wang, C. Zhu, Y. Tang, X. Xu, M. Liang, B. Jiang, X. Yan and L. Gao, Nat. Commun., 2018, 9, 1440.
- 10 L. Gao, J. Zhuang, L. Nie, J. Zhang, Y. Zhang, N. Gu, T. Wang, J. Feng, D. Yang, S. Perrett and X. Yan, Nat. Nanotechnol., 2007, 2, 577–583.
- 11 K. Fan, H. Wang, J. Xi, Q. Liu, X. Meng, D. Duan, L. Gao and X. Yan, Chem. Commun., 2017, 53, 424–427.
- 12 L. Gao, K. Fan and X. Yan, Theranostics, 2017, 7, 3207–3227.
- 13 J. Xie, G. Liu, H. S. Eden, H. Ai and X. Chen, Acc. Chem. Res., 2011, 44, 883–892.
- 14 K. Ulbrich, K. Hola, V. Subr, A. Bakandritsos, J. Tucek and R. Zboril, Chem. Rev., 2016, 116, 5338–5431.
- 15 L. L. Dugan, L. L. Tian, K. L. Quick, J. I. Hardt, M. Karimi, C. Brown, S. Loin, H. Flores, S. M. Moerlein, J. Polich, S. D. Tabbal, J. W. Mink and J. S. Perlmutter, Ann. Neurol., 2014, 76, 393–402.
- 16 M. Huo, L. Wang, Y. Chen and J. Shi, Nat. Commun., 2017, 8, 357.
- 17 J. Yao, Y. Cheng, M. Zhou, S. Zhao, S. Lin, X. Wang, J. Wu, S. Li and H. Wei, Chem. Sci., 2018, 9, 2927–2933.
- 18 Y. Zhang, F. Wang, C. Liu, Z. Wang, L. Kang, Y. Huang, K. Dong, J. Ren and X. Qu, ACS Nano, 2018, 112(1), 651–661.

- 19 D. Zhang, Y. X. Zhao, Y. J. Gao, F. P. Gao, Y. S. Fan, X. J. Li, Z. Y. Duan and H. Wang, J. Mater. Chem. B, 2013, 1, 5100– 5107.
- 20 S. Fu, S. Wang, X. Zhang, A. Qi, Z. Liu, X. Yu, C. Chen and L. Li, Colloids Surf., B, 2017, 154, 239–245.
- 21 L. Su, J. Feng, X. Zhou, C. Ren, H. Li and X. Chen, Anal. Chem., 2012, 84, 5753–5758.
- 22 L. Su, W. Qin, H. Zhang, Z. U. Rahman, C. Ren, S. Ma and X. Chen, Biosens. Bioelectron., 2015, 63, 384–391.
- 23 N. Chaibakhsh and Z. Moradi-Shoeili, Mater. Sci. Eng., C, 2019, 99, 1424–1447.
- 24 Y. Chen, H. Cao, W. Shi, H. Liu and Y. Huang, Chem. Commun., 2013, 49, 5013–5015.
- 25 F. Vetr, Z. Moradi-Shoeili and S. Ozkar, ¨ Appl. Organomet. Chem., 2018, 32, e4465.
- 26 L. Z. Gao, J. M. Wu, S. Lyle, K. Zehr, L. L. Cao and D. Gao, J. Phys. Chem. C, 2008, 112, 17357–17361.
- 27 W. B. Shi, Q. L. Wang, Y. J. Long, Z. L. Cheng, S. H. Chen, H. Z. Zheng and Y. M. Huang, Chem. Commun., 2011, 47, 6695–6697.
- 28 X. Niu, Y. Xu, Y. Dong, L. Qi, S. Qi, H. Chen and X. Chen, J. Alloys Compd., 2014, 587, 74–81.
- 29 W. Wu, Q. He, H. Chen, J. Tang and L. Nie, Nanotechnology, 2007, 18, 145609.
- 30 L. Y. Tong, C. C. Chuang, S. Y. Wu and L. Zuo, Cancer Lett., 2015, 367, 18–25.
- 31 G. Y. Liou and P. Storz, Free Radical Res., 2010, 44, 479–496.
- 32 D. Trachootham, J. Alexandre and P. Huang, Nat. Rev. Drug Discovery, 2009, 8, 579–591.
- 33 T. I. Lakshmi Raj, A. U. Gurkar, A. Mandinova, S. L. Schreiber and S. W. Lee, Nature, 2011, 475, 231–234.
- 34 J. S. Zijian Zhou, L. Nie and X. Chen, Chem. Soc. Rev., 2016, 45, 6597–6626.
- 35 R. Gargallo-Caballero, L. Martin-Garcia, A. Quesada, C. Granados-Miralles, M. Foerster, L. Aballe, R. Bliem, G. S. Parkinson, P. Blaha, J. F. Marco and J. de la Figuera, J. Chem. Phys., 2016, 144, 094704.
- 36 H. Sun, Y. Zhou, J. Ren and X. Qu, Angew. Chem., Int. Ed., 2018, 57, 9224–9237.
- 37 J. Dong, L. Song, J. J. Yin, W. He, Y. Wu, N. Gu and Y. Zhang, ACS Appl. Mater. Interfaces, 2014, 6, 1959–1970.
- 38 B. Jiang, L. Yan, J. Zhang, M. Zhou, G. Shi, X. Tian, K. Fan, C. Hao and X. Yan, ACS Appl. Mater. Interfaces, 2019, 11(10), 9747–9755.