<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image appears to be a logo or header for a scientific journal, specifically the "Journal of Applied Physics" published by AIP (American Institute of Physics). While this is related to scientific publishing, it does not contain any specific chemical or scientific information that requires detailed interpretation in the context of applied chemistry or physics research.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image does not appear to contain any specific scientific or chemical information relevant to applied chemistry or scientific analysis. It appears to be an abstract or artistic image with curved lines or patterns on an orange background, which does not convey technical data or diagrams that would require detailed interpretation in a chemistry context.</DESCRIPTION_FROM_IMAGE>

## **Observation of Co/CoO nanoparticles below the critical size for exchange bias**

[A. N. Dobrynin](http://scitation.aip.org/search?value1=A.+N.+Dobrynin&option1=author), [K. Temst](http://scitation.aip.org/search?value1=K.+Temst&option1=author), [P. Lievens](http://scitation.aip.org/search?value1=P.+Lievens&option1=author), [J. Margueritat](http://scitation.aip.org/search?value1=J.+Margueritat&option1=author), [J. Gonzalo](http://scitation.aip.org/search?value1=J.+Gonzalo&option1=author), [C. N. Afonso](http://scitation.aip.org/search?value1=C.+N.+Afonso&option1=author), [E. Piscopiello](http://scitation.aip.org/search?value1=E.+Piscopiello&option1=author), and [G. Van](http://scitation.aip.org/search?value1=G.+Van+Tendeloo&option1=author) [Tendeloo](http://scitation.aip.org/search?value1=G.+Van+Tendeloo&option1=author)

Citation: [Journal of Applied Physics](http://scitation.aip.org/content/aip/journal/jap?ver=pdfcov) **101**, 113913 (2007); doi: 10.1063/1.2736303 View online: <http://dx.doi.org/10.1063/1.2736303> View Table of Contents: <http://scitation.aip.org/content/aip/journal/jap/101/11?ver=pdfcov> Published by the [AIP Publishing](http://scitation.aip.org/content/aip?ver=pdfcov)

### **Articles you may be interested in**

[Rotatable anisotropy driven training effects in exchange biased Co/CoO films](http://scitation.aip.org/content/aip/journal/jap/115/24/10.1063/1.4885157?ver=pdfcov) J. Appl. Phys. **115**, 243903 (2014); 10.1063/1.4885157

[Influence of interface roughness on the exchange bias of Co/CoO multilayers](http://scitation.aip.org/content/aip/journal/jap/113/17/10.1063/1.4795437?ver=pdfcov) J. Appl. Phys. **113**, 17D707 (2013); 10.1063/1.4795437

[Domain formation in exchange biased Co/CoO bilayers](http://scitation.aip.org/content/aip/journal/jap/93/10/10.1063/1.1540152?ver=pdfcov) J. Appl. Phys. **93**, 7726 (2003); 10.1063/1.1540152

[Unidirectional coercivity enhancement in exchange-biased Co/CoO](http://scitation.aip.org/content/aip/journal/apl/81/7/10.1063/1.1498505?ver=pdfcov) Appl. Phys. Lett. **81**, 1270 (2002); 10.1063/1.1498505

[Enhancement of magnetic coercivity and macroscopic quantum tunneling in monodispersed Co/CoO cluster](http://scitation.aip.org/content/aip/journal/apl/75/24/10.1063/1.125479?ver=pdfcov) [assemblies](http://scitation.aip.org/content/aip/journal/apl/75/24/10.1063/1.125479?ver=pdfcov) Appl. Phys. Lett. **75**, 3856 (1999); 10.1063/1.125479

<DESCRIPTION_FROM_IMAGE>ABSTRACT_IMAGE

This image is a promotional banner for a physics publication and does not contain specific scientific or chemical information relevant to the requested analysis. It features a collage of various images related to different areas of physics and natural phenomena, along with text promoting a subscription to "Physics Today". As this does not provide technical chemical or scientific data to interpret, it falls under the category of an abstract promotional image in this context.</DESCRIPTION_FROM_IMAGE>

# **[Observation of Co/CoO nanoparticles below the critical size](http://dx.doi.org/10.1063/1.2736303) [for exchange bias](http://dx.doi.org/10.1063/1.2736303)**

A. N. Dobrynin[,a](#page-1-0) K. Temst, and P. Lieven[sb](#page-1-1)

*Laboratorium voor Vaste-Stoffysica en Magnetism & INPAC-Institute for Nanoscale Physics and Chemistry, Katholieke Universiteit Leuven, Celestijnenlaan 200D, B-3001 Leuven, Belgium*

J. Margueritat[,c](#page-1-2) J. Gonzalo, and C. N. Afonso

*Laser Processing Group, Instituto de Optica, CSIC, Serrano 121, 28006 Madrid, Spain*

E. Piscopiello and G. Van Tendeloo

*Electronenmicroscopie voor Materiaalonderzoek, Universiteit Antwerpen, Groenenborgerlaan 171, B-2020 Antwerp, Belgium*

Received 14 November 2006; accepted 28 March 2007; published online 11 June 2007-

We compare the magnetic properties of pure and oxidized Co nanoparticles embedded in an amorphous Al2O3 matrix. Nanoparticles with diameters of 2 or 3 nm were prepared by alternate pulsed laser deposition in high vacuum conditions, and some of them were exposed to O2 after production and before being embedded. The nanoparticles are organized in layers, the effective edge-to-edge in-depth separation being 5 or 10 nm. The lower saturation magnetizations per Co atom for the samples containing oxidized nanoparticles provide evidence for the formation of antiferromagnetic CoO shells in the nanoparticles. None of the samples with Co/CoO nanoparticles show exchange bias, while vertical hysteresis loop shifts and enhanced coercivities as compared to samples with pure Co nanoparticles are observed. This constitutes evidence for the nanoparticles size being in all cases smaller than the critical size for exchange bias. The difference in coercivity versus temperature dependences for the samples with pure and oxidized Co nanoparticles shows that the exchange anisotropy in Co/CoO nanoparticles appears at temperatures lower than 50 K. © *2007 American Institute of Physics*. DOI: [10.1063/1.2736303](http://dx.doi.org/10.1063/1.2736303)

#### **I. INTRODUCTION**

An exchange anisotropy appears in hybrid ferromagnetic FM--antiferromagnetic AFM systems when cooling down through the Néel temperature of the antiferromagnet[.1](#page-7-0)[–5](#page-7-1) The anisotropy normally manifests as a horizontal shift of the magnetic hysteresis loop after field cooling. This shift exchange bias shows up due to an energy barrier, which appears at the FM-AFM interface after field cooling. The interfacial exchange interaction favors only one mutual orientation of the FM and the AFM spins. Therefore, the forward and backward FM spin reversal happens at different absolute values of the applied field, i.e., the hysteresis loop is biased.

Investigations of exchange anisotropy in systems of reduced dimensions may help to reveal the involved exchange mechanisms, provide insight in finite size effects[,6](#page-7-2)[–8](#page-7-0) or shed light on interface effects[.9](#page-7-3) It is also very important for nanomagnetism applications. For example, it was shown that the exchange anisotropy stabilizes magnetic moments of FM nanoparticles, embedded in an AFM matrix[,10](#page-7-4)[,11](#page-7-5) or agglomerated FM-core AFM-shell nanoparticles embedded in an amorphous matrix[.12](#page-7-6) In these systems the stability of the FM magnetic moments is limited by the blocking temperature of exchange bias, rather than by the superparamagnetic blocking temperature of the FM nanoparticles[.8](#page-7-0) It was recently shown that for isolated FM-core AFM-shell nanoparticles there is a critical size, below which exchange bias does not exist[.13](#page-7-7) In this article we present a systematic study on the production and magnetic properties of pure Co and Co-core CoO-shell nanoparticles, embedded in an amorphous Al2O3 matrix as a function of nanoparticle diameter and edge-toedge separation. The core-shell nanoparticles are zerodimensional hybrid FM-AFM systems, and, therefore, allow studying the exchange anisotropy at the nanoscale.

#### **II. SAMPLES PREPARATION AND CHARACTERIZATION**

#### **A. Pulsed laser deposition**

The embedded Co nanoparticles were prepared by alternate pulsed laser deposition in high vacuum *p* 10−7 mbar-. An ArF excimer laser -=193 nm, =20 ns full width at half maximum, repetition rate =20 Hz, energy density =1.9 J/cm2 has sequentially been focused on highpurity Al2O3 and Co rotating targets. In order to prevent oxygen contamination, the Co target was ablated in vacuum during 30 s prior to deposition while having the substrates protected. The substrates were Si 100 wafers covered by a 700 nm thick amorphous SiO2 layer, which were held at room temperature. The deposition sequence involved first the deposition of a 10 nm thick layer of amorphous *a*--Al2O3. [14](#page-7-8) Subsequently, a layer of nanoparticles was produced followed by deposition of *a*-Al2O3, this cycle being repeated

<span id="page-1-0"></span>a- Present address: Ames Laboratory, Ames, IA 50011.

<span id="page-1-1"></span>b- Electronic mail: peter.lievens@fys.kuleuven.be

<span id="page-1-2"></span>c- Also at CEMES/Université Paul Sabatier, CNRS, 29, rue Jeanne Marvig, BP 94347, 31055 Toulouse Cedex 4, France

<DESCRIPTION_FROM_IMAGE>The image depicts a schematic representation of a layered structure on a substrate. The structure consists of multiple horizontal layers with embedded particles or dots. Here's a detailed description:

1. Substrate: At the bottom of the image, there's a layer labeled "substrate".

2. Layered structure: Above the substrate, there are multiple horizontal layers, each containing embedded particles represented by black dots.

3. Particle arrangement: The particles are arranged in a regular pattern within each layer. They appear to be evenly spaced horizontally within their respective layers.

4. Vertical spacing: The vertical spacing between layers is not uniform. There are two distinct spacing measurements indicated:
   a. "D": This represents the larger spacing between some of the layers.
   b. "d": This represents the smaller spacing between other layers.

5. Top and bottom margins: Both the top and bottom of the layered structure (excluding the substrate) have a spacing of 10 nm from the edge of the structure to the nearest layer containing particles.

6. Overall structure: The layered arrangement suggests a controlled deposition or growth process, possibly representing a thin film or nanostructured material.

7. Scale: The image provides a scale reference of 10 nm, indicating that this is a nanoscale structure.

This schematic likely represents a cross-sectional view of a nanostructured material or thin film with precisely controlled layer thicknesses and particle distributions, which could be relevant for various applications in nanotechnology, optics, or materials science.</DESCRIPTION_FROM_IMAGE>

FIG. 1. Cross-section schematic drawing of a sample. Five submonolayers of nanoparticles of diameter *D* are separated by layers of amorphous Al2O3 of thickness *d*.

five times. The deposition sequence is thus designed in order to have all nanoparticles nucleating on the same surface and all covered by protective *a*-Al2O3 layers. A cross-section schematic drawing of the samples is shown in Fig. [1.](#page-2-0) Five layers of nanoparticles of diameter *D* are separated by an effective edge-to-edge in-depth distance *d* by layers of *a*-Al2O3. The samples containing pure Co nanoparticles are designated as d*x* D*y*, where *x* is the edge-to-edge nanoparticle in-depth separation, and *y* is the actual value of the nanoparticle diameter. Samples with edge-to-edge nanoparticle separations of 5 and 10 nm, and with nanoparticle diameters of 2 and 3 nm were produced.

The specimens containing oxidized nanoparticles are designated o d*x* D*y*, and were produced under identical conditions as the corresponding d*x* D*y* specimens except that the Co nanoparticles were exposed to oxygen for 20 s after production. The O2 pressure was 710−4 mbar except for o d5 D2, which was higher 210−3 mbar-. A summary of specimen features is included in Table [I.](#page-2-1)

#### **B. Transmission electron microscopy**

A control specimen with Co nanoparticles of 3 nm diameter, having nanoparticles in layers 1–3 separated by 10 nm and in layers 3–5 separated by 5 nm, has been produced on Si substrates. The purpose was to determine the actual values from cross-section transmission electron microscopy TEM- measurements. Figure [2](#page-2-2)ashows a TEM image of this speci-

<span id="page-2-1"></span>TABLE I. Nanoparticle in-depth separation *d*-, nanoparticle diameter *D*-, and transient O2 pressure *p*-, in the case of oxidized nanoparticles, relative to the samples considered in the present study.

| Sample   | d nm | D nm | p mbar |
|----------|------|------|--------|
|          |      |      |        |
| d5 D2    | 5    | 2    | -      |
| d10 D2   | 10   | 2    | -      |
| d5 D3    | 5    | 3    | -      |
| d10 D3   | 10   | 3    | -      |
| o d5 D2  | 5    | 2    | 210−3  |
| o d10 D2 | 10   | 2    | 710−4  |
| o d5 D3  | 5    | 3    | 710−4  |
| o d10 D3 | 10   | 3    | 710−4  |
|          |      |      |        |

<DESCRIPTION_FROM_IMAGE>The image consists of two transmission electron microscopy (TEM) micrographs labeled (a) and (b), both with a scale bar of 10 nm.

Micrograph (a):
This micrograph shows a high-resolution TEM image of a crystalline material. The image reveals a lattice structure with clearly visible atomic planes. The lattice fringes are oriented diagonally across the image. Two sets of parallel lines are marked on the image, labeled as [110] and d35. These labels likely correspond to specific crystallographic planes or directions. The [110] direction appears to be along the diagonal of the image, while d35 is perpendicular to it. The presence of these lattice fringes and their labeling suggests this is a high-resolution image of a crystalline material, possibly a metal or semiconductor nanostructure.

Micrograph (b):
This micrograph shows a TEM image of what appears to be an amorphous or poorly crystalline material. Unlike micrograph (a), there are no visible lattice fringes or distinct structural features. The image has a uniform, granular appearance typical of amorphous materials or very small nanoparticles. The lack of distinct features suggests this could be an amorphous phase of the material shown in (a), or a different material altogether.

The comparison between these two micrographs likely serves to illustrate the structural difference between a crystalline phase (a) and an amorphous or poorly crystalline phase (b) of the same or related materials. The scale bar of 10 nm indicates that these images are at the nanoscale, focusing on atomic-level structural details.</DESCRIPTION_FROM_IMAGE>

FIG. 2. TEM images of control specimens having 3 nm diameter pure Co nanoparticles. a- Cross-section image of specimen having nanoparticle layers separated 5 and 10 nm. b- Plan-view image of sandwich film containing Co nanoparticles with expected diameter of 3 nm.

men, where it is clearly seen that the edge-to-edge in-depth separations of the nanoparticles correspond well to the intended values.

In order to determine the *D* value finally achieved, sandwich films containing a single nanoparticle layer embedded in *a*-Al2O3 have been grown on carbon-coated mica substrates under the same conditions as the multilayer structures, both for pure Co and oxidized Co nanoparticles. TEM specimens have been straightforwardly prepared by floating the films off the substrate in de-ionized water and picking up on copper grids. Figure [2](#page-2-2)b shows a plan view of a sample containing pure Co nanoparticles with expected diameter of 3 nm. Since most of the nanoparticles are round and their dimensions are very similar in plan- and cross-section views, it can be concluded that the nanoparticles are spherical, they are well separated from each other, and their mean diameter is about 3 nm. Figures [3](#page-3-0)a and [3](#page-3-0)b show plan views of the sample with pure and oxidized 2 nm Co nanoparticles, respectively. While the exact structure of the oxidized nanoparticles is unknown, they can be considered as consisting of a pure Co core and a CoO shell probably incomplete-.

#### **C. Rutherford backscattering spectrometry**

Rutherford backscattering spectrometry using a 1.57 MeV He+ beam was used to determine the Co content in the

<DESCRIPTION_FROM_IMAGE>This image shows two transmission electron microscopy (TEM) micrographs labeled (a) and (b). Both micrographs display nanostructured surfaces at high magnification, with a scale bar of 10 nm provided for each.

Micrograph (a) shows a uniform, finely textured surface with a granular appearance. The texture is consistent across the entire image, suggesting a homogeneous nanostructure. The grains appear to be very small, likely in the range of a few nanometers in size.

Micrograph (b) displays a different nanostructure compared to (a). It shows a more ordered pattern with visible lattice fringes. These fringes appear as parallel lines or waves across the image, indicating a crystalline structure. The spacing between these fringes could potentially be used to determine the crystal lattice parameters.

The contrast between the two micrographs suggests that they may represent different materials, different crystalline orientations of the same material, or the result of different sample preparation or imaging conditions. The uniform texture in (a) might indicate an amorphous or polycrystalline structure, while the lattice fringes in (b) clearly show a crystalline arrangement.

These high-resolution TEM images provide valuable information about the nanoscale structure and crystallinity of the materials being studied, which is crucial for understanding their properties and potential applications in various fields of chemistry and materials science.</DESCRIPTION_FROM_IMAGE>

<span id="page-3-1"></span>FIG. 3. Plan TEM images of control specimens with pure a and oxidized b-Co nanoparticles with expected diameter of 2 nm.

samples, and to confirm the nanoparticles' in-depth separation. In the first case the detector was placed at an angle of 10° from the incident beam. The mean Co content of samples od*x* D3 was 3.41016 atoms/cm2 , mean deviation −35*%*, while that of samples od*x* D2 was 2.71016 atoms/cm2 , mean deviation −25*%*. In order to determine the in-depth nanoparticle separation the detector was placed at an angle of 75° from the incident beam. Using this geometry, the path of the detected backscattered He ions in the sample is larger than in the first case, which may allow the resolution of the different layers of the Co nanoparticles separated by the Al2O3 layers. Figure [4](#page-3-1) shows RBS spectra for the samples od10 D*y*. The peaks corresponding to the individual layers of Co nanoparticles are observed for samples d10 D2, d10 D3, and o d10 D2. Such a "fine structure" also means that metal diffusion is not a significant process. The individual metal layers were only resolved for d10 D*y* specimens, since for d5 D*y* specimens the Co part of the spectrum was flat due to overlapping of neighboring peaks because of the limited resolution of the spectrometer-. Intensities of the individual Co peaks are nearly equal, thus indicating that the amount of Co in each layer of nanoparticles is approximately the same. Obviously, for the sample o d10 D2 the separation between first and second layers is larger than the separation between other layers, which is a production artifact.

#### **III. MAGNETIZATION MEASUREMENTS**

The magnetization measurements were performed inplane with a vibrating sample magnetometer in the tempera-

<DESCRIPTION_FROM_IMAGE>The image presents four graphs labeled (a), (b), (c), and (d), each showing spectral data for cobalt (Co). The x-axis for all graphs is labeled "Chanel" (likely a misspelling of "Channel") and ranges from 200 to 800. The y-axis is labeled "Counts" and ranges from 0 to 400.

All four graphs show similar spectral patterns:

1. A declining trend from channel 200 to about 500, starting at around 350-400 counts and decreasing to about 200 counts.
2. A sharp peak at approximately channel 600, reaching about 300 counts.
3. A valley between channels 650-700 where the counts drop to near zero.
4. A prominent set of peaks labeled "Co" between channels 750-800.

Specific observations for each graph:

(a) The Co peaks at the end are sharp and distinct, with about 5 visible peaks reaching up to about 250 counts.

(b) Similar to (a), but the Co peaks at the end appear slightly higher, reaching about 300 counts.

(c) The Co peaks at the end are less distinct, with about 3-4 visible peaks reaching up to about 200 counts.

(d) The Co peaks at the end are less pronounced and appear as a broader, single peak reaching about 250 counts.

The graphs likely represent spectral data from an analytical technique such as X-ray fluorescence (XRF) or atomic emission spectroscopy, focusing on the detection and analysis of cobalt. The differences between the graphs might indicate different sample compositions, concentrations, or experimental conditions affecting the cobalt signal.</DESCRIPTION_FROM_IMAGE>

FIG. 4. RBS spectra of samples d10 D2 a-, d10 D3 b-, o d10 D2 c-, o d10 D3 d-.

[This article is copyrighted as indicated in the article. Reuse of AIP content is subject to the terms at: http://scitation.aip.org/termsconditions. Downloaded to ] IP: 128.59.226.54 On: Wed, 10 Dec 2014 12:49:49

<DESCRIPTION_FROM_IMAGE>The image contains four separate graphs labeled (a), (b), (c), and (d), each showing magnetization (M/Ms) as a function of an unspecified parameter (likely magnetic field or temperature) for two different sample conditions: "pure" and "oxidized".

Graph (a):
- X-axis range: -1 to 1
- Y-axis range: -2 to 2
- Pure sample shows a sharp transition from -1.5 to 1.5 near x=0
- Oxidized sample shows a more gradual S-shaped curve from -1 to 1

Graph (b):
- X-axis range: -1 to 1
- Y-axis range: -2 to 2
- Pure sample shows a sharp transition from -2 to 2 near x=0
- Oxidized sample shows a more gradual S-shaped curve from -1 to 1

Graph (c):
- X-axis range: -1 to 1
- Y-axis range: -10 to 10 (approximate)
- Pure sample shows a very sharp transition from -8 to 8 near x=0
- Oxidized sample shows a much more gradual, nearly linear increase from -1 to 1

Graph (d):
- X-axis range: -1 to 1
- Y-axis range: -3 to 3
- Pure sample shows a sharp transition from -2.5 to 2.5 near x=0
- Oxidized sample shows a more gradual S-shaped curve from -1 to 1

In all graphs, the pure sample demonstrates a much sharper transition and higher magnetization values compared to the oxidized sample. The oxidized samples consistently show a more gradual change in magnetization across the measured range.</DESCRIPTION_FROM_IMAGE>

FIG. 5. Color online- Hysteresis loops after zero field cooling from 300 to 5 K for the samples d5 D3 and o d5 D3 a-, d10 D3 and o d10 D3 b-, d5 D2 and o d5 D2 c-, d10 D2 and o d10 D2 d-. Magnetizations are normalized to the amount of Co in the samples; the saturation magnetization of the oxidized sample is taken as unity.

ture range from 5 to 300 K. In Fig. [5](#page-4-0) zero field cooled to 5 K hysteresis loops for the samples d5 D3 and o d5 D3 a-, d10 D3 and o d10 D3 b-, d5 D2 and o d5 D2 c-, d10 D2 and o d10 D2 d-, are compared. The magnetization values are normalized according to the amount of Co in the samples. The lower saturation magnetization per Co atom in the samples with oxidized nanoparticles provides clear evidence for the formation of the AFM CoO shell. The higher coercivity of samples with oxidized particles is also related to the oxide shell, since normally hybrid FM-AFM systems show an enhancement of the coercivity, in addition to the unidirectional anisotropy[.15](#page-7-9)[–17](#page-7-10) For all pairs of samples with oxidized and nonoxidized nanoparticles, the coercivity of the former at 5 K is significantly higher than that of the latter. For sample o d5 D2 the normalized saturation magnetization is the lowest, consistent with the larger AFM CoO phase due to the higher O2 pressure used when oxidizing the nanoparticles in this case, as discussed in Sec. II and seen in Table [I.](#page-2-1)

In Fig. [6](#page-4-1) the coercivity versus temperature dependences for samples d10 D3 and o d10 D3 are compared. For the sample with oxidized nanoparticles, the coercivity is close to

<DESCRIPTION_FROM_IMAGE>The image presents a graph comparing the behavior of pure and oxidized samples across a temperature range. The x-axis represents temperature (T) in Kelvin (K), ranging from 0 to 300 K. The y-axis shows the coercive field (Hc) in Oersted (Oe), ranging from 0 to 1000 Oe.

Two data series are plotted:
1. Pure sample (represented by circles)
2. Oxidized sample (represented by triangles)

The graph illustrates the following trends:

1. Pure sample:
   - Starts at approximately 400 Oe at near 0 K
   - Decreases rapidly to about 200 Oe at 25 K
   - Continues to decrease more gradually, reaching close to 0 Oe at 300 K
   - The curve shows a smooth, exponential-like decay

2. Oxidized sample:
   - Starts at a much higher value, around 1000 Oe at near 0 K
   - Decreases very rapidly to about 250 Oe at 25 K
   - Continues to decrease sharply, reaching close to 0 Oe at 50 K
   - Remains close to 0 Oe from 50 K to 300 K
   - The curve shows a much steeper initial decline compared to the pure sample

Key observations:
1. The oxidized sample has a significantly higher coercive field at low temperatures compared to the pure sample.
2. The oxidized sample's coercive field drops more rapidly with increasing temperature.
3. Both samples approach a coercive field close to 0 Oe at higher temperatures, but the oxidized sample reaches this state at a lower temperature (around 50 K) compared to the pure sample (which gradually approaches 0 Oe up to 300 K).

This graph likely represents the temperature dependence of magnetic coercivity in a material, comparing its behavior in pure and oxidized states. The oxidation appears to enhance the coercivity at low temperatures but also makes it more sensitive to temperature changes.</DESCRIPTION_FROM_IMAGE>

FIG. 6. Color online- Coercivity vs temperature for samples d10 D3 pureand o d10 D3 oxidized-. Lines are guides to the eye.

zero down to about 50 K, and with further decrease of temperature the coercivity increases abruptly. For the sample with nonoxidized nanoparticles, there is a gradual increase of the coercivity with temperature decrease. Figure [7](#page-5-0) represents the coercivity versus temperature dependences for samples d5 D3 and o d5 D3, and they demonstrate a behavior similar to the latter case: the coercivity of the sample with oxidized nanoparticles increases rapidly at temperatures below 50 K.

Such a difference in the coercivity versus temperature behavior in the samples containing oxidized and nonoxidized Co nanoparticles may be attributed to the establishment of an exchange coupling at the Co/CoO interface at temperatures below 50 K. Although this temperature is much lower than the blocking temperature of exchange bias for "thick" Co/ CoO bilayers which is slightly lower than the Néel temperature of bulk CoO 291 K-, [2](#page-7-11) in very thin AFM layers or nanoparticles the blocking temperature and the Néel temperature are known to be lower than those of the bulk counterparts[.8](#page-7-0)[,12](#page-7-6)[,18](#page-7-12)[,19](#page-7-13) The lower value of the coercivity of the oxidized samples above 50 K is due to the smaller size of the FM Co core than that in the corresponding nonoxidized samples and, therefore, a lower value of the magnetocrystalline anisotropy. The mechanisms of the coercivity increase for Co-core CoO-shell nanoparticles after establishing an AFM structure in CoO, are discussed in Sec. IV.

For samples od*x* D2 the coercivity is nonzero only at the lowest temperature at which the measurements were performed 5 K-, meaning that the superparamagnetic blocking temperature of 2 nm nanoparticles is very low. However, at 5 K the coercivity of the oxidized sample is higher than that of the nonoxidized sample: 670 against 380 Oe for samples o d10 D2 and d10 D2, and 460 against 270 Oe for the samples o d5 D2 and d5 D2, respectively. This is consistent with the results for larger nanoparticles, and shows that a Co-core CoO-shell structure is present in these samples.

In Fig. [8](#page-5-1) the coercivity versus temperature dependences for two specimens containing nonoxidized nanoparticles but

with different edge-to-edge in-depth separation d5 D3 and d10 D3 are compared. In spite of the identical particle size 3 nm-, the coercivity of the sample with an interlayer distance of 5 nm is systematically lower than that for the sample with the 10 nm interlayer separation. The matrix material is amorphous Al2O3, which renders interparticle exchange interactions unlikely. However, such coercivity difference can be explained by a stronger dipole-dipole interaction between Co nanoparticles in neighboring layers in sample d5 D3 than in sample d10 D3. The dipole-dipole interaction is long range, increases the coherence of the magnetization rotation, and decreases the coercivity.

The field cooling was performed in a field of 10 kOe from 300 to 5 K. As was discussed in the Introduction, field cooling is needed to induce an exchange anisotropy in hybrid FM-AFM systems. For all samples with pure Co nanoparticles the field cooled hysteresis loop corresponds to the zero field cooled loop. However, for samples with Co/CoO nanoparticles no exchange bias was found after field cooling. A significant vertical shift of the hysteresis loop was observed instead. In Fig. [9](#page-6-0) the zero field cooled ZFC and field cooled FC hysteresis loops for the samples o d*x* D*y* are compared. All field cooled loops differ from zero field cooled loops only by a vertical shift, while no horizontal shift is observed. The zero field cooled loops are perfectly symmetric. This symmetry proves absence of exchange biased nanoparticles in the sample, since otherwise asymmetric steps or different magnetization reversal slopes for the right and left parts of the hysteresis loop would be observed. There is no evident correlation between the value of the vertical shift, and the nanoparticles size or the interlayer distance.

#### **IV. DISCUSSION**

Absence of exchange bias also has been observed by Skumryev *et al.* in isolated Co-core CoO-shell nanoparticles in Al2O3 matrix[.10](#page-7-4) Lund *et al.*[20](#page-7-14) have shown that the total anisotropy energy of the AFM part is crucial for exchange bias to appear in FM-AFM bilayers. A model which describes magnetic behavior of hybrid FM-AFM nanoparticles has been developed in Ref. [13.](#page-7-7) Here, we summarize its key aspects.

<DESCRIPTION_FROM_IMAGE>The image presents a graph depicting the relationship between temperature (T) in Kelvin (K) and coercive field (Hc) in Oersteds (Oe) for two different sample conditions: pure and oxidized. The x-axis represents temperature ranging from 0 to 300 K, while the y-axis shows the coercive field from 0 to 1500 Oe.

Two data series are plotted:
1. Pure samples, represented by green circles
2. Oxidized samples, represented by blue triangles

The graph shows a sharp decrease in coercive field as temperature increases, with the most dramatic change occurring between 0 and 50 K. The oxidized sample exhibits a significantly higher initial coercive field (approximately 1450 Oe) at near-zero temperature compared to the pure sample (about 250 Oe).

Both curves converge as the temperature increases, with the coercive field approaching zero for both sample types above 100 K. The oxidized sample maintains a slightly higher coercive field throughout the temperature range.

Key observations:
1. The oxidized sample has a much higher coercive field at low temperatures.
2. Both samples show a rapid decrease in coercive field with increasing temperature.
3. The difference between pure and oxidized samples becomes negligible at higher temperatures (>100 K).
4. The coercive field for both samples approaches zero as temperature nears 300 K.

This graph illustrates the temperature dependence of magnetic coercivity in pure and oxidized materials, highlighting the significant impact of oxidation on magnetic properties, particularly at low temperatures.</DESCRIPTION_FROM_IMAGE>

<DESCRIPTION_FROM_IMAGE>The image presents a graph depicting the relationship between temperature (T) in Kelvin and a parameter denoted as Hc (Oe) for two different conditions. The x-axis represents temperature ranging from 0 to 300 K, while the y-axis represents Hc values from 0 to 500 Oe.

Two curves are plotted on the graph:
1. A purple curve with diamond markers, labeled "d = 5 nm"
2. A green curve with circle markers, labeled "d = 10 nm"

Both curves show a similar trend: Hc decreases as temperature increases, with the rate of decrease being more pronounced at lower temperatures and gradually leveling off at higher temperatures.

The curve for d = 10 nm (green) starts at a higher Hc value (approximately 450 Oe) at 0 K and decreases rapidly until about 50 K, then continues to decrease more gradually, approaching 0 Oe as the temperature nears 300 K.

The curve for d = 5 nm (purple) follows a similar pattern but starts at a lower Hc value (approximately 250 Oe) at 0 K. It also decreases rapidly until about 50 K and then more gradually, approaching 0 Oe as the temperature nears 300 K.

The graph illustrates that the sample with d = 10 nm consistently exhibits higher Hc values across the entire temperature range compared to the sample with d = 5 nm.

This graph likely represents the temperature dependence of the coercive field (Hc) for two different nanoparticle or thin film samples with different characteristic dimensions (d) of 5 nm and 10 nm, respectively. The observed behavior is typical for magnetic materials, showing a decrease in coercivity with increasing temperature due to thermal effects on magnetic ordering.</DESCRIPTION_FROM_IMAGE>

FIG. 8. Color online- Coercivity vs temperature for samples d5 D3 *d* =5 nm and d10 D3 *d*=10 nm-. Lines are guides to the eye.

The considered model assumes that there are three essential energies, a competition between which determines the magnetic response of the system. These are the effective Zeeman energy of the FM part *EZ*eff, the anisotropy energy of the AFM part *EA*, and the exchange energy at the FM-AFM interface *E*int. If *E*int*EZ*eff, there are two possibilities. For *E*int*EA*, the FM spins will be rotated while AFM spins will not, and exchange bias will be observed. For *EAE*int, there will be no exchange bias. AFM spins will be rotated coherently with the FM spins, and the coercivity will be larger than that for a pure FM particle of the same size. For the case of *EZ*eff*E*int there are two possibilities as well. For *EZ*eff *EA*, the Zeeman energy is not high enough either to overcome the interfacial energy barrier or to rotate the AFM spins. The FM part will stay "frozen" in an external field, and after field cooling this will show up as a vertical magnetization shift. For *EZ*eff*EA*, the Zeeman energy is high enough to rotate both FM and AFM spins. Thus, there are three possible states in the system that are summarized in Table [II](#page-6-1) and illustrated schematically in Fig. [10:](#page-6-2) exchange bias EB when *E*int*EZ*eff and *E*int*EA*; AFM spin reversion AR when *EAE*int and *EAEZ*eff; and frozen FM state, leading to the vertical shift VS after the field cooling for the case of *EZ*eff*E*int and *EZ*eff*EA*. [13](#page-7-7) It is noteworthy that this vertical shift is due not to uncompensated AFM spins, but to the frozen FM spins. If the uncompensated AFM spins contributed to the vertical shift, one would assume that the AFM spin structure stays stable during the FM magnetization reversal. In that case exchange bias would be observed, thus contradicting our observations.

In the case of a spherical FM core-AFM shell particle with radius *R* and FM core radius *r*, the considered energies can be written as

$$E_{\rm int} = 4 \,\pi \sigma r^2,\tag{1}$$

with an empirical exchange coupling constant;

$$E_A = \frac{4\pi}{3} K_A \left( R^3 - r^3 \right),\tag{2}$$

where *KA* is the volume anisotropy constant of the antiferromagnet;

<DESCRIPTION_FROM_IMAGE>The image presents four magnetization curves (hysteresis loops) labeled (a), (b), (c), and (d). Each graph shows the normalized magnetization (M/Ms) on the y-axis versus the applied magnetic field (H) on the x-axis. The x-axis ranges from -1 to 1 x 10^4 Oe (Oersted) for all graphs. The y-axis ranges from -1 to 1, representing the normalized magnetization.

Two different curves are shown in each graph, labeled as ZFC (Zero-Field Cooled) and FC (Field Cooled), represented by different line styles.

Graph (a): Both ZFC and FC curves show clear hysteresis loops with smooth transitions. The FC curve reaches saturation at a lower field strength compared to the ZFC curve.

Graph (b): The hysteresis loops are narrower compared to (a), indicating a softer magnetic material. The ZFC and FC curves are more similar to each other, with the FC curve still reaching saturation slightly earlier.

Graph (c): This graph shows more noise in the data, particularly for the FC curve. The hysteresis loops are wider than in (b), suggesting a harder magnetic material. The ZFC curve shows a more gradual approach to saturation compared to the FC curve.

Graph (d): The hysteresis loops are narrow and smooth, similar to (b). The ZFC and FC curves are very close to each other, with only slight differences in their approach to saturation.

In all graphs, the FC curves generally reach saturation at lower field strengths compared to the ZFC curves, which is consistent with the expected behavior for field-cooled samples.

These graphs likely represent magnetic characterization of different materials or the same material under different conditions, showing how the magnetization behavior changes with applied field for both zero-field cooled and field cooled samples.</DESCRIPTION_FROM_IMAGE>

$$E_{Z_{\rm eff}} = \frac{4\pi r^3}{3} \left(\mu_F H - K_F\right) = \frac{4\pi r^3}{3} \varepsilon_Z(H) \,, \tag{3}$$

with the energy density *ZH*-=*FH*−*KF*-, *F* is a specific magnetic moment, *KF* a volume anisotropy constant of the FM part, and *H* the applied magnetic field. The critical size for exchange bias corresponds to the case when all these energy terms are equal to each other[.13](#page-7-7) The critical radius for EB is

$$R_c = \frac{3\sigma}{\mathfrak{e}_Z} \left( 1 + \frac{\mathfrak{e}_Z}{K_A} \right)^{1/3} \,. \tag{4}$$

The obtained critical size for exchange bias is thus a function of the applied field. This dependence is plotted in Fig. [11](#page-7-15) for the Co/CoO case. The constants used here are =3 erg/cm2 , [21](#page-7-16) *KA*=2.7108 erg/cm3 , and *KF*=2 106 erg/cm3 . [22](#page-7-17) For a field of 104 Oe the critical diameter is 2*Rc*=12 nm, well above the mean diameter of the nanoparticles studied in this work. For a nanoparticle smaller than the critical size, the exchange bias is forbidden for *any* ratio of the FM to the AFM part in the particle. In other words, while for the shaded region in Fig. [11](#page-7-15) the exchange bias is strictly forbidden, for the region above this curve the bias exists only for certain FM to AFM parts ratios. For a nanoparticle of 3 nm diameter one should apply an external field of about 50 kOe in order to get the possibility to observe

<span id="page-6-1"></span>TABLE II. Energy conditions and corresponding states in a hybrid FM-AFM nanoparticle after field cooling and applying the opposite field below the Néel temperature of the antiferromagnet.

| Energy conditions        | State               |  |
|--------------------------|---------------------|--|
| EintEZeff<br>and EintEA  | Exchange bias       |  |
| EAEint<br>and EAEZeff    | AFM spin reversal   |  |
| EZeffEint<br>and EZeffEA | Ferromagnet pinning |  |

FIG. 9. Color online- Zero field cooled ZFC and field cooled FC at 10 kOe hysteresis loops for the samples with oxidized Co nanoparticles: o d5 D3 a-, o d10 D3 b-, o d5 D2 c-, and o d10 D2 d-. None of the samples demonstrates exchange bias after field cooling, but a significant vertical shift of the hysteresis loops.

exchange bias at a certain FM-AFM ratio in the particle. The necessity of applying such high fields makes potential applications of hybrid nanoparticles extremely difficult, since it requires massive and expensive superconducting magnets. Moreover, this can be meaningless, since the AFM spin-flop transition field is size dependent[,23](#page-7-18)[–25](#page-7-19) and therefore the AFM structure in the thin shells can be destroyed by relatively small fields of several tesla[.25](#page-7-19)

Dipole-dipole interactions are not considered in the above-described model, since they are generally weaker than other energy terms involved. Taking into account dipoledipole interactions will lead to a shift of the value of the critical size for a system of isolated nanoparticles. However, it does not change the fact that the critical size exists both for a single FM-core AFM-shell nanoparticle and for a system of such nanoparticles, isolated from each other by an amorphous insulating matrix.

#### **V. CONCLUSIONS**

In this article the production and magnetic properties of pure and oxidized Co nanoparticles embedded in an amor-

<DESCRIPTION_FROM_IMAGE>This image illustrates three different magnetic configurations in antiferromagnetic (AFM) and ferromagnetic (FM) materials under an applied magnetic field (H). The image is divided into three parts labeled (a), (b), and (c), each representing a different scenario:

(a) Exchange bias:
- Initial state: AFM spins are antiparallel (up and down), FM spins are parallel (both up).
- Final state: AFM spins remain antiparallel, FM spins flip to align with the applied field (both down).

(b) AFM spin reversal:
- Initial state: Same as the initial state in (a).
- Final state: AFM spins reverse their orientation (down becomes up and vice versa), FM spins remain aligned with the applied field (both down).

(c) FM part pinning:
- Initial state: Same as the initial state in (a) and (b).
- Final state: AFM spins reverse their orientation (as in b), but FM spins remain in their original orientation (both up), resisting the applied field.

In all cases, the applied magnetic field (H) is represented by a black arrow pointing downward. The AFM spins are represented by red arrows, while the FM spins are represented by blue arrows. The relative orientations of these spins change in response to the applied field and the interactions between the AFM and FM layers.

This diagram is crucial for understanding exchange bias phenomena and spin dynamics in magnetic multilayer systems, which are important in various applications such as magnetic sensors and data storage devices.</DESCRIPTION_FROM_IMAGE>

FIG. 10. Color online- Schematic of the ferromagnet and the antiferromagnet spin reversal. The initial state, after field cooling, is shown on the left side. On the right side the three possible variants of spin reversal are shown.

<DESCRIPTION_FROM_IMAGE>The image presents a graph depicting the relationship between particle diameter (measured in mm) and magnetic field strength (H, measured in 10^4 Oe). The graph is divided into two regions labeled "EB" and "No EB".

The x-axis represents the magnetic field strength (H) ranging from 0 to 10 x 10^4 Oe.
The y-axis represents the particle diameter, ranging from 0 to 14 mm.

The graph shows a curve that separates the two regions:

1. "EB" region: This is the area above the curve, indicating conditions where EB (likely referring to Exchange Bias) is present.
2. "No EB" region: This is the area below the curve, indicating conditions where EB is not present.

The curve follows a hyperbolic-like shape, starting at a high particle diameter (around 14 mm) at low magnetic field strength and rapidly decreasing as the field strength increases. The curve then gradually levels off, approaching but not quite reaching zero particle diameter as the magnetic field strength approaches 10 x 10^4 Oe.

This graph illustrates the critical relationship between particle size and magnetic field strength in determining the presence or absence of Exchange Bias in a magnetic system. It suggests that larger particles exhibit EB at lower field strengths, while smaller particles require higher field strengths to manifest EB effects.</DESCRIPTION_FROM_IMAGE>

FIG. 11. Critical diameter for exchange bias as a function of the applied field for single domain Co-core CoO-shell particle. In the region under the curve the exchange bias is forbidden for any ratio of the FM to the AFM part in a hybrid particle.

phous Al2O3 matrix were described. The nanoparticles are well isolated from each other by an amorphous nonconducting matrix, which eliminates any interparticle exchange interactions. A comparison of zero field cooled hysteresis loops for similar samples with oxidized and nonoxidized nanoparticles provides clear evidence for the formation of an AFM CoO shell in the oxidized Co nanoparticles. While for samples with pure Co nanoparticles the low-temperature coercivity increases with the particle size and interlayer distance increase, we do not observe such a trend for the samples with Co/CoO nanoparticles. This shows that the coercivity of the samples with oxidized Co nanoparticles is governed by the interfacial exchange interactions and anisotropy of the antiferromagnetic part, rather than by anisotropy of the Co part and interparticle dipole-dipole interactions. The coercivity versus temperature behavior for the samples with oxidized nanoparticles shows that the blocking temperature of thin CoO shells in the samples is less than 50 K. This is much less than the blocking temperature of "thick" Co/ CoO bilayers. Such a difference is a consequence of finitesize effects in ultrathin CoO shells. For all samples with oxidized nanoparticles, no exchange bias was observed after field cooling, while vertical hysteresis loop shifts were always observed. This provides evidence for the nanoparticle sizes being below the critical size for exchange bias.

#### **ACKNOWLEDGMENTS**

The authors are thankful to S.Q. Zhou and A. Vantomme for Rutherford backscattering spectrometry characterization of the samples. J.M. acknowledges an I3P fellowship from the CSIC and the European Social Fund. This work is supported by the Fund for Scientific Research-Flanders FWO-, the Flemish Concerted Action GOA/2004/02-, the Belgian Interuniversity Attraction Poles IAP/P5/01-, the Spanish Ministry of Education and Culture under MAT2005–06508 c02–01 project, and the European Community's Human Potential NanoCluster HPRN-CT-2002–00328programs.

- <span id="page-7-0"></span>1 W. H. Meiklejohn and C. P. Bean, Phys. Rev. **102**, 1413 1956-. 2
- <span id="page-7-11"></span>J. Nogués and I. K. Schuller, J. Magn. Magn. Mater. **192**, 203 1999-. 3
- A. E. Berkowitz and K. Takano, J. Magn. Magn. Mater. **200**, 552 1999-. 4
- M. Kiwi, J. Magn. Magn. Mater. **234**, 584 2001-. 5
- <span id="page-7-1"></span>R. L. Stamps, J. Phys. D **33**, R247 2000-. 6
- <span id="page-7-2"></span>J. Nogués, J. Sort, V. Langlais, V. Skumryev, S. Surinach, J. Munoz, and M. Baró, Phys. Rep. **422**, 65 2005a-. 7
- J. Nogués, J. Sort, V. Langlais, S. Doppiu, B. Dieny, J. Munoz, S. Surinach, M. D. Baró, S. Stoyanov, and Y. Zhang, Int. J. Nanotechnol. **2**, 23 2005-. 8
- A. N. Dobrynin, D. N. Ievlev, C. Hendrich, K. Temst, P. Lievens, U. Hörmann, J. Verbeeck, G. Van Tendeloo, and A. Vantomme, Phys. Rev. B **73**, 245416 2006-. 9
- <span id="page-7-3"></span>U. Wiedwald, M. Spasova, E. L. Salabas, M. Ulmeanu, M. Farle, Z. Frait, A. Fraile Rodrigez, D. Arvanitis, N. S. Sobal, M. Hilgendorff, and M. Giersig, Phys. Rev. B **68**, 064424 2003-
- <span id="page-7-4"></span>. 10V. Skumryev, S. Stoyanov, Y. Zhang, G. Hadjipanayis, D. Givord, and J. Nogués, Nature **423**, 850 2003-. 11J. Sort, V. Langlais, S. Doppiu, B. Dieny, S. Surinach, J. Munoz, M. Baró,
- <span id="page-7-5"></span>C. Laurent, and J. Nogués, Nanotechnology **15**, S211 2004-. 12J. Nogués, V. Skumryev, S. Stoyanov, J. Sort, and D. Givord, Phys. Rev.
- <span id="page-7-6"></span>Lett. **97**, 157203 2006-
- <span id="page-7-7"></span>. 13A. N. Dobrynin, D. N. Ievlev, K. Temst, P. Lievens, J. Margueritat, J. Gonzalo, C. N. Afonso, S. Q. Zhou, A. Vantomme, E. Piscopiello, and G. Van Tendeloo, Appl. Phys. Lett. **87**, 012501 2005-. 14C. N. Afonso, J. Gonzalo, R. Serna, J. C. G. de Sande, C. Ricolleau, C.
- <span id="page-7-8"></span>Grigis, M. Gandais, D. E. Hole, and P. D. Townsend, Appl. Phys. A: Mater. Sci. Process. **69**, S201 1999-
- <span id="page-7-9"></span>. 15C. Leighton, J. Nogués, B. J. Jönsson-Åkerman, and I. K. Schuller, Phys. Rev. Lett. **84**, 3466 2000-
- . 16M. D. Stiles and R. D. McMichael, Phys. Rev. B **63**, 064405 2001-
- <span id="page-7-10"></span>. 17C. Leighton, H. Suhl, M. J. Pechan, R. Compton, J. Nogués, and I. K. Schuller, J. Appl. Phys. **92**, 1483 2002-. 18T. Ambrose and C. L. Chien, Phys. Rev. Lett. **76**, 1743 1996-
- <span id="page-7-13"></span><span id="page-7-12"></span>. 19P. J. van der Zaag, Y. Ijiri, J. A. Borchers, L. F. Feiner, R. M. Wolf, J. M. Gaines, R. W. Erwin, and M. A. Verheijen, Phys. Rev. Lett. **84**, 6102 2000-. 20M. S. Lund, W. A. A. Macedo, K. Liu, J. Nogués, I. K. Schuller, and C.
- <span id="page-7-14"></span>Leighton, Phys. Rev. B **66**, 054422 2002-. 21B. H. Miller and E. D. Dahlberg, Appl. Phys. Lett. **69**, 3932 1996-
- <span id="page-7-17"></span><span id="page-7-16"></span>. 22M. Jamet, W. Wernsdorfer, C. Thirion, D. Mailly, V. Dupuis, P. Mélinon, and A. Pérez, Phys. Rev. Lett. **86**, 4676 2001-. 23F. Keffer and H. Chow, Phys. Rev. Lett. **31**, 1061 1973-
- <span id="page-7-18"></span>
- . 24R. W. Wang, D. L. Mills, E. E. Fullerton, J. E. Mattson, and S. D. Bader, Phys. Rev. Lett. **72**, 920 1994-
- <span id="page-7-19"></span>. 25R. Zysler, D. Fioriani, A. Testa, L. Suber, E. Agostinelli, and M. Godinho, Phys. Rev. B **68**, 212408 2003-.